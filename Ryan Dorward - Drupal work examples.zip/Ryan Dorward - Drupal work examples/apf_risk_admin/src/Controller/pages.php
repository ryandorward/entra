<?php

/**
 * @file
 * Contains \Drupal\apf_risk_admin\Controller\pages.
 */

namespace Drupal\apf_risk_admin\Controller;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Request;
// use Drupal\node\Entity\Node;
use \Drupal\apf_risk_entities\Entity\EventLinkType;
use \Drupal\apf_risk_entities\Entity\RiskComponent;
use \Drupal\apf_risk_entities\Actions;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Process\Process;

class pages extends ControllerBase {

  protected static function objectToArray( $in, $depth = 0 ) {
    if ($depth == 0) return "max depth";

    // Create a reflection object
    if (is_object($in)) {
      $refl = new \ReflectionClass($in);

      // Retrieve the properties and strip the ReflectionProperty objects down
      // to their values, accessing even private members.
      $out = [];
      $props = $refl->getProperties();
      foreach ($props as $prop) {
        $prop->setAccessible(true);
        $out[$prop->getName()]= $prop->getValue($in);
      }
      $in = $out;
    }

    if (is_array($in))
      foreach( $in as &$val ) {
        $val = self::objectToArray( $val, $depth - 1 );
      }

    return $in;
  }

  private static function getEventLinkTypes() {
    $linkTypeEntities = EventLinkType::getLinkTypes();
    $linkTypes = [];
    foreach ($linkTypeEntities as $linkTypeEntity)
      $linkTypes[] = [
        "id" => (int) $linkTypeEntity->id->value,
        "label" => $linkTypeEntity->title->value,
      ];
    return $linkTypes;
  }

  private static function getRiskComponents() {
    $riskComponentEntities = RiskComponent::getRiskComponents();
    $riskComponents = [];
    foreach ($riskComponentEntities as $riskComponentEntity)
      $riskComponents[] = [
        "id" => (int) $riskComponentEntity->id->value,
        "label" => $riskComponentEntity->title->value,
      ];
    return $riskComponents;
  }

  public static function event() {

    $risk_field_definitions = \Drupal::getContainer()->get('entity_field.manager')->getFieldDefinitions('risk_event',null);
    $risk_field_definitions = self::objectToArray($risk_field_definitions, 10);

    $current_user = \Drupal::currentUser();

    $spinner = '
    <span class="spinner-wrap">
      <svg viewBox="0 0 154 164" >
        <path d="M 63,153 11,9 142,116" class="a a1" pathLength="100"/>
        <path d="M 63,153 32,13 142,116" class="b b1" pathLength="100"/>
        <path d="M 63,153 53,17 142,116" class="a a2" pathLength="100"/>
        <path d="M 63,153 73,21 142,116" class="b b2" pathLength="100"/>
        <path d="M 63,153 94,25 142,116" class="a a3" pathLength="100"/>
        <path d="M 63,153 116,30 142,116" class="b b3" pathLength="100"/>
      </svg>
    </span>';

    return [
      '#type' => 'inline_template',
      '#template' => '<div class="risk-admin-root" id="apf-risk-admin-react-container">'.$spinner.'Loading Event Manager App...</div>',
      '#attached' => [
        'library' => 'apf_risk_admin/admin-tool',
        'drupalSettings' => [
          'apfRiskAdmin' => [
            'riskFieldDefs' => $risk_field_definitions,
            'eventLinkTypes' => self::getEventLinkTypes(),
            'actions' => Actions::getActions(),
            'riskComponents' => self::getRiskComponents(),
            'userRoles' => $current_user->getRoles(),
            'userId' => (int) $current_user->id(),
            'permissions' => [
              'edit_tags' => $current_user->hasPermission('edit terms in vocabulary_4'),
            ]
          ],
        ],
      ],
    ];

  }

  public static function sandbox() {
    return [
      '#type' => 'inline_template',
      '#template' => '<div class="risk-admin-root" id="apf-risk-admin-sandbox">Loading Sandbox...</div>',
      '#attached' => [
        'library' => 'apf_risk_admin/admin-tool',
      ],
    ];
  }



  public static function jurisdictions_update_runner() {

    if (!isset($_POST['action'])) {
      $warning =  "<br/>These scripts should be triggered to run when jurisdictions are added/removed/updated from the database. "
       ."If there are several updates, it would be a good idea to add/remove/update the batch before running these scripts.<br/><br/>"
       ."Warning: These scripts take many minutes to complete!<br/><br/> "
       ."Once you click the button below, the scripts will run, and you won't see the page "
       ."finish loading until all the scripts complete, so some patience is needed!<br/><br/>"
       ."Once you've clicked the button the results will be loading. Don't reload the page, and don't navigate away from it until it finishes and you see the results displayed.<br/><br/>"
       ."Reloading would trigger the scripts to re-run and request the huge download of boundary data from wikidata "
       ."again, which would be wasteful, slow, and possibly get us blocked for a while for exceeding their traffic limits.<br/><br/>"
       ."If you see any errors or timeouts displayed, please get in contact with Ryan with the details so he can fix the problem.<br/><br/>"
      ;
      return [
        '#type' => 'inline_template',
        '#template' => $warning.'<form method="post" id="jur-update-runner"><button type="submit" value="run" name="action" class="button">I understand the above. Run the jurisdiction update scripts</button></form>',
      ];
    }
    else if ($_POST['action'] !== 'run')
      return [
        '#type' => 'inline_template',
        '#template' => '<p>Invalid action</p>',
      ];

    // else action is 'run'
    ini_set('max_execution_time', '900'); // 15 minutes! We need a very long upper limit to run this script
    $process = new Process('export LANG=C.UTF-8; export LC_ALL="en_US.UTF-8"; locale; cd pgapi/db/external; ./run-jur-update-scripts.sh');
    $process->setTimeout(900);
    $process->setIdleTimeout(900);
    $process->run();
    $out = '';

    foreach ($process as $type => $data) {
      if ($process::OUT === $type) {
        $out.= "<br/><strong>Output:</strong> ".nl2br($data) . "<br/>";
      } else { // $process::ERR === $type
        $out.= "<br/><strong>Error:</strong> ".nl2br($data) . "<br/>";
      }
    }
    return [
      '#type' => 'inline_template',
      '#template' => $out,
    ];

  }




  /**
  * from: https://stackoverflow.com/questions/20107147/php-reading-shell-exec-live-output
  * Execute the given command by displaying console output live to the user.
  *  @param  string  cmd          :  command to be executed
  *  @return array   exit_status  :  exit status of the executed command
  *                  output       :  console output of the executed command
  */
  /*
  private function liveExecuteCommand($cmd)
  {

      while (@ ob_end_flush()); // end all output buffers if any

      $proc = popen("$cmd 2>&1 ; echo Exit status : $?", 'r');

      $live_output     = "";
      $complete_output = "";

      while (!feof($proc))
      {
          $live_output     = fread($proc, 4096);
          $complete_output = $complete_output . $live_output;
          echo "$live_output";
          @ flush();
      }

      pclose($proc);

      // get exit status
      preg_match('/[0-9]+$/', $complete_output, $matches);

      // return exit status and intended output
      return array (
                      'exit_status'  => intval($matches[0]),
                      'output'       => str_replace("Exit status : " . $matches[0], '', $complete_output)
                  );
  }

  */


}