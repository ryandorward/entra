<?php

namespace Drupal\apf_risk_admin\Theme;

use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Theme\ThemeNegotiatorInterface;

/**
 * Class ApfRiskAdminThemeNegotiator.
 *
 * @package Drupal\apf_risk_admin
 */
class ApfRiskAdminThemeNegotiator implements ThemeNegotiatorInterface {
  /**
   * {@inheritdoc}
   */
  public function applies(RouteMatchInterface $route_match) {
    if ($route_match->getRouteName() == 'apf_risk_admin.event' || $route_match->getRouteName() == 'apf_risk_admin.change_analysis') {
      return true;
    }
    return false;
  }

  /**
   * {@inheritdoc}
   */
  public function determineActiveTheme(RouteMatchInterface $route_match) {
    return 'claro';
  }

}