const path = require('path');

module.exports = {
  entry: './src/index.js',
  // devtool: (process.env.NODE_ENV === 'production') ? false : 'inline-source-map',
  // mode: (process.env.NODE_ENV === 'production') ? 'production' : 'development',
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'app.bundle.js',
    chunkFilename: "chunk.[contenthash].js"
  },
  module: {      
    rules: [
      {
        test: /\.(jsx|js)$/,    
        include: path.resolve(__dirname, 'src'),  
        exclude: /node_modules/,           
        use: {
          loader: 'babel-loader',
          options: {
            presets: [
              ['@babel/preset-env', { modules: false } ],                 
            ],
            plugins: ["@babel/plugin-transform-runtime"]
          }
        },                     
        resolve: {
          extensions: ['.js', '.jsx']
        },
      },
      {
        test: /\.css$/i,
        use: ['style-loader', 'css-loader']
      },
    ]
  },
  optimization: {
		usedExports: true,
	},
  resolve: {
    extensions: ['.js', '.jsx']
  },     
};