const { merge } = require('webpack-merge')
const common = require('./webpack.common.js')

module.exports = merge(common, {
	mode: 'production',
	watch: false,
	devtool: false
} )


// console.log(module.exports)