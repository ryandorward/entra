import { creds } from '../creds'

Cypress.config('defaultCommandTimeout', 8000) // this could go in cypress.json instead

Cypress.Commands.add('login', (username,password) => {
  cy.session([username,password], () => {
    let creds = { name: username, pass: password }
    cy.request('POST', 'http://www.asiapacific.local/user/login?_format=json', creds).then(
      (response) => {
        expect(response.body.current_user).to.have.property('name', creds.name)
      }
    )
  })
})

describe('Test CAST Event Admin UI', () => {

  beforeEach(() => {
    console.log(creds.name, creds.pass)
    cy.login(creds.name, creds.pass)
    cy.visit('http://asiapacific.local/admin/cast/management/event')
  })

  /*
  it('Goes to the Admin UI, creates an event, deletes it', () => {

    cy.contains('Event content management tool')
    cy.get('form.risk-admin-form')

    cy.findByLabelText('Event Title').type('Mooing Test Event')
    cy.contains('Save as new Event').click()

    cy.contains('Event was added:')
    cy.contains('Event was saved as Unpublished because')

    cy.contains('Delete Event').click()
    cy.contains('Are you sure you want to Delete this Event?')
      .parents('[role="dialog"]')
      .find('button')
      .contains('Delete')
      .click()

    cy.contains('Event was deleted')

  })
  */

  let eventAFields = {
    textFields: {
      title: {
        label: 'Event Title',
        value: 'Event A 503l33t',
      },
      archiveLink: {
        label: 'Archive Link',
        value: 'https://www.moo.com',
      },
      description: {
        label: 'Describe what happened',
        value: 'event description',
      },
      analysis: {
        label: 'Analysis of implications, impact',
        value: 'event analysis',
      },
    },
    toggleFields: {
      /*
      ongoing: {
        label: 'Is this an ongoing event?',
        value: true,
      },
      violence: {
        label: 'Was there violence involved?',
        value: false,
      },
      propertyDamage: {
        label: 'Was there property damage involved?',
        value: null,
      },
      officialResponse: {
        label: 'Was there an official response?',
        value: true,
      },
      */
      canadiansInvolved: {
        label: 'Were Canadians directly involved?',
        value: false,
      },
    },
    otherFields: {

      /*
      peopleInvolved: {
        selector: '#people-involved',
        label: 'People Involved',
        value: '1k',
      },
      */

      action: {
        controlSelector: '.action-select [class*="-control"]',
        menuSelector: '.action-select [class*="-menu"]',
        selectedSelector: '.action-select [class*="-ValueContainer"]',
        containsText: 'Policy',
        value: 'Policy announcement',
      },

      tags: {
        inputSelector: '.react-tags__search-input',
        selectedSelector: '.react-tags__selected',
        autocompleteText: 'natural',
        value: 'natural resources',
      },

      impact: {
        selector: '.event-link-card-inner .MuiAutocomplete-root input',
        autocompleteText: 'chin',
        value: "People's Republic of China"
      },
    }
  }


  let eventBFields = {
    textFields: {
      title: {
        label: 'Event Title',
        value: 'Event B l33t4+',
      },
      archiveLink: {
        label: 'Archive Link',
        value: 'https://entra.ca',
      },
      description: {
        label: 'Describe what happened',
        value: 'event description',
      },
    },
    otherFields: {
      tags: {
        inputSelector: '.react-tags__search-input',
        selectedSelector: '.react-tags__selected',
        autocompleteText: 'natural',
        value: 'natural resources',
      },
      impact: {
        selector: '.event-link-card-inner .MuiAutocomplete-root input',
        autocompleteText: 'chin',
        value: "People's Republic of China"
      },
    }
  }

  function fillFields(fields) {

    let field

    if (field = fields.otherFields?.action) {
      cy.get(field.controlSelector).click()
      cy.get(field.menuSelector).contains(field.containsText).click()
    }

    if (field = fields.otherFields?.tags) {
      cy.get(field.inputSelector).focus().type(field.autocompleteText)
      cy.get('.react-tags__suggestions',{ timeout: 40000 }).contains(field.value).click()
    }

    // iterate through all textFields object and fill the fields in
    for (const fieldName in fields.textFields) {
      let field = fields.textFields[fieldName]
      cy.findByLabelText(field.label).type(field.value)
    }

    for (const fieldName in fields.toggleFields) {
      let field = fields.toggleFields[fieldName]
      cy.contains(field.label).parent().find('button[value="' + field.value + '"]').click()
    }

    // fill the peopleInvolved select. This isn't that clean, but it was the way I could get it to work for the MUIselect
    /*
    if (field = fields.otherFields?.peopleInvolved) {
      cy.get(field.selector).click()
      cy.findByText(field.value).click()
    }
    */

    if (field = fields.otherFields?.impact) {
      cy.contains('Add an Impacted Jurisdiction').click().then(() => {
        cy.get(field.selector).type(field.autocompleteText)
      }).then(() => {
        cy.contains(field.value).click()
      })
    }

  }

  // verify that all fields match expected values
  function checkFields(fields) {
    // iterate through all textFields
    for (const fieldName in fields.textFields) {
      let field = fields.textFields[fieldName]
      cy.findByLabelText(field.label).then(($el) => {
        expect($el.val()).to.equal(field.value)
      })
    }

    // iterate through all toggleFields
    for (const fieldName in fields.toggleFields) {
      let field = fields.toggleFields[fieldName]
      cy.contains(field.label).parent().find('button[value="' + field.value + '"]').then((els) => {
        expect(els[0].getAttribute('aria-pressed')).to.equal('true')
      })
    }

    let field
    /*
    if (field = fields.otherFields?.peopleInvolved)
      cy.get(field.selector).contains(field.value)
    */

    if (field = fields.otherFields?.tags)
      cy.get(field.selectedSelector).contains(field.value)

    if (field = fields.otherFields?.action)
      cy.get(field.selectedSelector).contains(field.value)

    if (field = fields.otherFields?.impact)
      cy.get(field.selector).then(($el) => {
        expect($el.val()).to.contain(field.value)
      })
  }

  function deleteEvent() {
    cy.contains('Delete', { timeout: 10000 }).click()
    cy.contains('Are you sure you want to Delete this Event?')
      .parents('[role="dialog"]')
      .find('button')
      .contains('Delete')
      .click()
  }

  it('Creates Event A using all fields, Saves it', () => {
    cy.get('form.risk-admin-form').should('exist');
    fillFields(eventAFields)

    /* do some fields manually */
    // Actors
    cy.get('.actors-select button.adder a').click()
    cy.get('.actors-select .selection-workspace').contains('natural phenomenon').click() // select top level category
    cy.get('.actors-select .selection-workspace').contains('weather').click() // select something more specific
    cy.get('.actors-select .current-selection').contains('weather').click() // commit it to Actors list

    cy.contains('Save as new ').click()
    cy.contains('Event was added:',{ timeout: 30000 })
    cy.contains('Event was saved as Draft').should('not.exist');

    cy.contains('Start new Event').click()
  })

  it('Creates event B', () => {
    fillFields(eventBFields)

    cy.contains('Add an Event Link').click()
    cy.get('.link-type-selector').click()
    cy.contains('Causal').click()

    cy.get('.event-link-card-inner .search input').type(eventAFields.textFields.title.value)
    cy.get('.MuiAutocomplete-listbox',{ timeout: 20000} ).contains(eventAFields.textFields.title.value).click()

    cy.contains('Save as new ').click()
    // cy.contains('Event was added:',{ timeout: 60000 })
    cy.contains('Event was saved as Draft').should('not.exist');
  })

  it('Stored events properly, shows linking properly', () => {
    // Load event A
    cy.get('table',{ timeout: 20000 }).contains(eventAFields.textFields.title.value).click()
    checkFields(eventAFields)  // Check the fields in Event A to make sure they have all been stored correctly

    // Make sure "Government" is in the Actors list
    cy.get('.actors-select .selected-nodes').contains('weather').should('exist')

    // Make sure it's linked to event B properly
    cy.get('.link-type-selector .MuiSelect-select').then(($el) => {
      expect($el.text()).to.contain('Causal')
    })
    cy.get('.event-link-card-inner .search input').then(($el) => {
      expect($el.val()).to.contain(eventBFields.textFields.title.value)
    })

    // Load event B
    cy.get('table').contains(eventBFields.textFields.title.value).click()
    checkFields(eventBFields)  // Check the fields in Event A to make sure they have all been stored correctly
    // Make sure it's linked to event A properly
    cy.get('.link-type-selector .MuiSelect-select').then(($el) => {
      expect($el.text()).to.contain('Causal')
    })
    cy.get('.event-link-card-inner .search input').then(($el) => {
      expect($el.val()).to.contain(eventAFields.textFields.title.value)
    })
  })

  it('Updates Event B', () => {
    // Load event B
    cy.get('table',{ timeout: 20000 }).contains(eventBFields.textFields.title.value).click()
    eventBFields.textFields.title.value = 'Updated Event Title'

    let field = eventBFields.textFields.title
    cy.findByLabelText(field.label).clear().type(field.value)

    cy.contains('Save Draft').click()
    cy.contains('Start new Event',{timeout:20000}).click()
  })

  it('Event B was updated properly, delete it', () => {
    // Load event B
    cy.get('table',{ timeout: 20000 }).contains(eventBFields.textFields.title.value).click()
    checkFields(eventBFields)
    deleteEvent()
  })

  it('Deletes event A', () => {
     // Load event A
     cy.get('table').contains(eventAFields.textFields.title.value).click()
     deleteEvent() // delete event A
  })

})