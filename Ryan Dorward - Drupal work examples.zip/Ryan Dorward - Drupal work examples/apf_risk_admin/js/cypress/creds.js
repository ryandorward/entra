export const creds = {
  name: 'riskadmintester',
  pass: '+&?X6[E/;zBV+uE]'
}