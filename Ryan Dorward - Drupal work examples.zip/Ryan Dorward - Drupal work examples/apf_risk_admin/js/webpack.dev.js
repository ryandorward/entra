const { merge } = require('webpack-merge')
const common = require('./webpack.common.js')
const DeadCodePlugin = require('webpack-deadcode-plugin');

module.exports = merge(common, {
	mode: 'development',
	watch: true,
	devtool: 'source-map', // 'inline-source-map', // 'eval,
  plugins: [		
		new DeadCodePlugin({
			patterns: ['src/**/*.(js|jsx|css|less)'],
			detectUnusedExport: false
		})
	],
} ) 
