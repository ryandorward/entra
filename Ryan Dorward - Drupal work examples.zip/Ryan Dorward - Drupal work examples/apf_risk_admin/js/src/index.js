import React, { Suspense, useMemo, useCallback, useState } from "react"
import { render } from 'react-dom'
import {
  ApolloProvider,
  ApolloClient,
  InMemoryCache,
  ApolloLink,
  HttpLink
} from '@apollo/client'
import { onError } from "@apollo/client/link/error"
import { Button } from '@mui/material'

const EventManager = React.lazy(() => import('./EventManager'))
const JurisdictionSelector = React.lazy(() => import('./JurisdictionSelector'))

const uri = '/gql/risk' // '/gql/risk'

const MyAppolloProvider = ( props ) => {

  const showError = props.showError

  const client = useMemo(  // useMemo: calls its function and returns result, when the dependencies change (vs: useCallback which returns its function)
    () => {
      return new ApolloClient({
        link: ApolloLink.from([ // the order you add links matters! They happen serially
          onError(({ graphQLErrors, networkError }) => {
            if (graphQLErrors) {
              graphQLErrors.forEach(({ message, locations, path }) =>
                console.error(
                  `[GraphQL error]: Message: ${message}, Location: ${locations}, Path: ${path}`
                )
              )
              showError()
            }
            if (networkError) {
              console.error(`[Network error]: ${networkError}`)
              showError()
            }
          }),
          new HttpLink({ uri: uri }),
        ]),
        cache: new InMemoryCache({
          typePolicies: {
            EventLink: {
              keyFields: ['cid'] // the keyFields determine the cache key for the type
            }
          },
          // addTypename: false, // can't use this to prevent the __typename field from being delivered because that field is needed on the top level delivered object for Events (or something)
        })
      })
    },
    [showError] // useMemo is called every time the showError dependency changes
  )

  return (
    <ApolloProvider client={client}>
      <Suspense fallback={null}>
        {props.children}
      </Suspense>
    </ApolloProvider>
  )
}

const RiskAdminRoot = (props) => {
  return (
    <MyAppolloProvider showError={props.showError} >
      <React.StrictMode>
        <EventManager submitting={props.submitting} setSubmitting={props.setSubmitting}/>
      </React.StrictMode>
    </MyAppolloProvider>
  )
}

const SandboxRoot = (props) => {
  return (
    <MyAppolloProvider showError={props.showError} >
      <React.StrictMode>
        <JurisdictionSelector/>
      </React.StrictMode>
    </MyAppolloProvider>
  )
}

var elem
if (elem = document.querySelector('#apf-risk-admin-react-container')){
	render(
    <ErrorNotifier>
      {(props) => (
        <RiskAdminRoot {...props} />
      )}
    </ErrorNotifier>
    , elem
  )
}

if (elem = document.querySelector('#apf-risk-admin-sandbox')){
  render (
    <ErrorNotifier>
      {(props) => (
        <SandboxRoot {...props} />
      )}
    </ErrorNotifier>
    , elem
  )
}

// this was largely based around: https://shinesolutions.com/2021/06/30/automatically-handling-apollo-client-errors-in-your-react-ui/
function ErrorNotifier({ children }) {
  const [doShowError, setDoShowError] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const showError = useCallback(() => setDoShowError(true), []) // useCallback: returns its function when the dependencies change (vs. useMemo which calls its function and returns result)

  return (
    <>
      {doShowError ? (
        <>
          Sorry, there was a Server or API error! Please try again.<br/>
          Restore unsaved work?<br/>
          <Button
            variant="outlined"
            color="primary"
            onClick={() => {
              setDoShowError(false)
              setSubmitting(false)
            }}
          >
            YES!
          </Button>
          <br/><br/>
        </>
      ) : null}
      {children({showError: showError, submitting: submitting, setSubmitting: setSubmitting})}
    </>
  )
}