import { JurisdictionGraph } from '@apfcanada/jurisdictions'
export const graph = new JurisdictionGraph()