import React, {useEffect, useRef} from "react";
import Alert from '@mui/material/Alert';
import CloseIcon from '@mui/icons-material/Close';

/*
  consoleMessages should be an array of the form:
  [
    {
      severity: 'error',
      message: 'Error message'
    },
    {
      severity: 'warning',
      message: 'Warning message'
      items: [ 'item1', 'item2']
    },
  ]
*/

const calcOffset = () => {
  const scrollY = window.pageYOffset

  const header = document.querySelector("header.content-header")
  const form = document.querySelector('form.risk-admin-form')
  const consoleEl = document.querySelector('.console-wrap:not(.fake)')
  const positioner = document.querySelector('.console-position-marker')
  const width = document.querySelector('.risk-admin-form > div > .MuiGrid-grid-xs-6').offsetWidth - 66

  const positionerTop = positioner?.getBoundingClientRect().top + window.scrollY
  const bottom = form?.getBoundingClientRect().bottom + window.scrollY
  const formHeight = form?.getBoundingClientRect().height
  const consoleHeight = consoleEl?.getBoundingClientRect().height
  const headerTop = header?.getBoundingClientRect().top + window.scrollY

  if (consoleEl) {
    consoleEl.style.width = width + 'px'
    if (window.scrollY > (bottom - (consoleHeight+headerTop+ 40))) {
      consoleEl.style.top = (formHeight - (consoleHeight+ 40) ) + 'px'
      consoleEl.style.position = 'absolute'
      consoleEl.style.top = 'initial'
      consoleEl.style.bottom = '0'
      consoleEl.style.width = 'initial'
    }

    else if (window.scrollY > (positionerTop - headerTop - 30)) {
      consoleEl.style.position = 'fixed'
      const offset = headerTop + 20 + 'px'
      consoleEl.style.top = offset
      consoleEl.style.bottom = 'initial'
    }
    else {
      consoleEl.style.position = 'absolute'
      consoleEl.style.top = 0
    }
  }
}


export const Console = ({consoleMessages, setConsoleMessages}) => {

  const consoleRef = useRef(null)

  useEffect(() => {
      calcOffset()
      const onScroll = () => { calcOffset() }
      // clean up code
      window.removeEventListener('scroll', onScroll)
      window.addEventListener('scroll', onScroll, { passive: true })
      return () => window.removeEventListener('scroll', onScroll)
  }, []);

  const deleteMessage = (id) => {
    let newMessages = consoleMessages.filter( (elem, index) => index !== id);
    setConsoleMessages(newMessages);
  }

  if (consoleMessages !== undefined && consoleMessages.length > 0) return (
    <>
      <MessageSet consoleMessages={consoleMessages} fake={false} deleteMessage={deleteMessage} consoleRef={consoleRef}/>
      <MessageSet consoleMessages={consoleMessages} fake={true} deleteMessage={deleteMessage}/>
    </>
  );
  else return null
}

const MessageItems = ({items}) => {
  if (items?.length > 0) return (
    <ul>
      { items.map( (item, i) => <li key={i}>{item}</li> )}
    </ul>
  )
  else return (<></>)
}

const MessageSet = ({consoleMessages, fake, deleteMessage, consoleRef}) => {
  return (
    <div className={"console-wrap" + (fake ? " fake": "")} ref={consoleRef}>
      {
        consoleMessages.map((message, id) =>  {
          let severity = message.severity || 'error'
          if (severity === 'status') severity = 'success'
          return (
            <Alert
              key={id}
              severity={severity}
              className="alert"
            >
              <span className="message" dangerouslySetInnerHTML={{__html: message.message}} />
              <span
                className="close"
                onClick = { () => !fake && deleteMessage(id) }
              >
                <CloseIcon />
              </span>
              <MessageItems items={message.items} />
            </Alert>
          )
        })
      }
    </div>
  )
}