import React from 'react'
import './spinners.css'

const loaderColor = "#e63539"

// animated APFC logo

export function WindowSpinner(){
	return (
		<span className="spinner-wrap">
			<svg viewBox="0 0 154 164" >
				
				<path d="M 63,153 11,9 142,116" className="a a1" pathLength="100"/>				
				<path d="M 63,153 32,13 142,116" className="b b1" pathLength="100"/>				
				<path d="M 63,153 53,17 142,116" className="a a2" pathLength="100"/>			
				<path d="M 63,153 73,21 142,116" className="b b2" pathLength="100"/>				
				<path d="M 63,153 94,25 142,116" className="a a3" pathLength="100"/>
				<path d="M 63,153 116,30 142,116" className="b b3" pathLength="100"/>

			</svg>
		</span>
	)
}

// pulsing circles relatively centered in their parent element
const size = 60 // px, pulse size

export function Pulse({}){
	const style = `
		circle { fill: none; stroke: ${loaderColor}; }
		circle.A, circle.B { animation: pulse 1.5s linear forwards infinite; }
		circle.B { animation-delay: 0.75s; }
		@keyframes pulse {
			0% { r: 0px; stroke-width: 3px; }
			100% { r: 30px; stroke-width: 0; }
		}`
	const positionStyle = {
		display: 'block',
		position: 'absolute',
		top: `calc(50% - ${size/2}px)`,
		left: `calc(50% - ${size/2}px)`
	}
	return (
		<svg style={positionStyle} viewBox={`0 0 ${size} ${size}`} 
			width={size} height={size}>
			<style>{style}</style>
			<circle cx="50%" cy="50%" className="A"/>
			<circle cx="50%" cy="50%" className="B"/>
		</svg>
	)
}
