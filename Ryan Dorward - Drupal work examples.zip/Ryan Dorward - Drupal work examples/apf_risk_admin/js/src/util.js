export let dateToYMD = date => {
  if (typeof date == 'string')
    return date.substring(0,10)
  else {
    var d = date.getDate()
    var m = date.getMonth() + 1 //Month from 0 to 11
    var y = date.getFullYear()
    return '' + y + '-' + (m<=9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d)
  }
}

// Prevent form submission on enter. Used by various for non-multiline fields
export function generalEnterKeyHandler(e, skip = 2) {
  if ( e.key === "Enter" ) {
    // console.log("generalEnterKeyHandler")
    const form = e.target.form
    const index = [...form].indexOf(e.target)
    form.elements[index + skip].focus()
    e.preventDefault()
  }
}

export function editEventAllowed (eventOwnerId) {
  const srAnalyst = drupalSettings.apfRiskAdmin.userRoles?.includes('risk_analyst');
  const editor = drupalSettings.apfRiskAdmin.userRoles?.includes('cast_editor');
  const userId = parseInt(drupalSettings.apfRiskAdmin.userId)
  return srAnalyst || editor || eventOwnerId === undefined || eventOwnerId === userId
}