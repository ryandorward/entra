import React, { useState, useRef } from "react";
import { BrowserRouter, Route } from 'react-router-dom'
import { EventForm } from './EventForm';
import { EventLists } from './EventLists';

const EventManager = (params) => {  
  
  const [consoleMessages, setConsoleMessages] = useState([]);     
  const listRef = useRef(null);  

  return (  
    <BrowserRouter basename="/admin/cast/management/event">          
      <Route path="/:id?">
        <EventForm     
          {...params}                    
          consoleMessages={consoleMessages}
          setConsoleMessages={setConsoleMessages}                             
        />         
      </Route>           
      <EventLists 
        innerRef = {listRef}
        setConsoleMessages={setConsoleMessages}        
      />    
    </BrowserRouter>
  )
}

export default EventManager