import { gql } from '@apollo/client';

export const UPSERT_EVENT = gql`
  mutation UpsertEvent (
    $title: String
    $id: Int
    $archive_links: [String]
    $description: String
    $justification: String
    $context: String
    $event_date: String
    $impacts: [ImpactInput]
    $links: [EventLinkInput]
    $canadianInvolvement: Boolean
    # $peopleInvolved: Int
    $tags: [TagInput]
    $approved: Boolean
    $draft: Boolean
    $published: Boolean
    $action: ActionInput
    $actors: [ActorInput]
  ){
    upsertEvent(data: {
      title: $title
      id: $id
      archive_links: $archive_links
      description: $description
      justification: $justification
      context: $context
      date: $event_date
      impacts: $impacts
      links: $links
      canadianInvolvement: $canadianInvolvement
      # peopleInvolved: $peopleInvolved
      tags: $tags
      action: $action
      actors: $actors
      published: $published
      approved: $approved
      draft: $draft
    }) {
      operation
      event {
        id title archive_links description justification context event_date:date
        canadianInvolvement published approved draft status
        tags { id name }
        action { id name }
        actors { id }
        impacts {
          id componentId assessment:score
          description event { id }
        }
        links {
          id cid event { id } linkType { id }
        }
      }
      errors
    }
  }
`;

export const DELETE_EVENT = gql`
  mutation DeleteEvent (
    $id: Int!
  ){
    deleteEvent(id: $id) {
      event {
        id
        title
      }
      errors
    }
  }
`;

export const GET_ALL_EVENTS =  gql`
  query {
    events(withUnpublished: true, sort: "id", top: 100) {
      id
      title
      published
      approved
      draft
      owner { name id }
      impacts { geo_id }
    }
  }
`;

export const GET_EVENTS_QUEUE =  gql`
  query GetEventsQueue($owner: Int){
    eventsQueue(owner: $owner) {
      id
      title
      draft approved published
      owner { name id }
      impacts { geo_id }
    }
  }
`;

export const GET_EVENT =  gql`
  query GetEvent($id: Int!) {
    event(id: $id, withUnpublished: true) {
      id title archive_links description justification context event_date:date
      # wasOngoing wasViolent propertyDamage officialResponse peopleInvolved
      canadianInvolvement
      tags { id name isCanonical description }
      action { id name }
      actors { id label description }
      published approved draft status created changed
      links {
        id cid
        event { id title date published }
        linkType { id title }
      }
      impacts {
        id geo_id assessment:score
        #place
        description componentId
        component {
          id short_name long_name description
        }
      }
      owner { id name }
      lastEditor { id name }
    }
  }
`;