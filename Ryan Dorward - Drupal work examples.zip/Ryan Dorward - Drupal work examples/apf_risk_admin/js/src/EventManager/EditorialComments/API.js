import { gql } from '@apollo/client';

export const GET_COMMENTS =  gql`
  query GetComments($eventId: Int!, $latestCommentId: Int) { 
    editorialComments(eventId: $eventId, latestCommentId: $latestCommentId) { 
      id comment created owner { name id }  
    }
  }
`;

export const UPSERT_COMMENT = gql`
  mutation upsertEditorialComment (    
    $id: Int
    $eventId: Int
    $comment: String
  ){
    upsertEditorialComment(data: {     
      id: $id     
      eventId: $eventId
      comment: $comment
    }) {    
      editorialComment { id eventId event { id } comment created owner { id name } }
      errors 
    }
  }
`;

export const DELETE_COMMENT = gql`
  mutation deleteEditorialComment (    
    $id: Int!  
  ){
    deleteEditorialComment(id: $id) {    
      editorialComment { id eventId event { id } comment created owner { id name } }
      errors 
    }
  }
`;