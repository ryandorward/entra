import React, {useState} from "react"
import { useMutation } from '@apollo/client'
import CloseIcon from '@mui/icons-material/Close';
import EditIcon from '@mui/icons-material/Edit';
import { DELETE_COMMENT } from './API'
import { CommentForm } from './CommentForm'

export const Comment = ({comment, eventId}) => {   

  const [editing, setEditing] = useState(false)

  const userId = parseInt(drupalSettings.apfRiskAdmin.userId)  
  const isOwner = comment.owner.id === userId
  
  // see https://www.apollographql.com/docs/react/caching/cache-interaction/#cachemodify
  const [deleteComment, { dataDeleted }] = useMutation(DELETE_COMMENT,{
    onCompleted(data) {      
      // setConsoleMessages(data.deleteEditorialComment.errors)
    },
    update(cache, { data: { deleteEditorialComment } }) {          
      cache.modify({
        fields: {
          editorialComments(existingComments = [], { readField }) {      
            const filteredComments = existingComments.filter(
              ref => comment.id !== readField('id', ref)
            )           
            return  filteredComments                  
          }
        }              
      })
    }
  });

  const handleDelete = (e) => {        
    deleteComment({
      variables: {
        id: comment.id
      },
      optimisticResponse: {
        deleteEditorialComment: {
          editorialComment: {
            __typename: 'EditorialComment',
            comment: comment.comment,
            id: comment ? comment.id : null,
            eventId: eventId,
            event: {id: eventId},
            created: comment ? comment.created : 'Just now',
            owner: comment ? {...comment.owner} : {id: null, name: ''},
          },
          errors: {}
        }
      }  
    });       
  }

  const handleEdit = (e) => {
    setEditing(!editing)
  }

  return (
    <div className={(isOwner ? 'is-owner ': '') + 'editorial-comment'} key={comment.id}>
      <header>
        <span className='meta'>
          {comment.owner.name} commented {comment.created}
        </span>
        { isOwner && (
        <span className='actions'>
          <a className={ (editing ? 'editing ' :'') + 'edit'} onClick={handleEdit}><EditIcon/></a>
          <a className='delete' onClick={handleDelete}><CloseIcon/></a>
        </span> 
        )}
      </header>
      <div className='comment'>
        { editing ? <CommentForm comment={comment} eventId={eventId} setEditing={setEditing}/> : <div className='comment-static'>{comment.comment}</div> }              
      </div>
    </div>    
  )

}