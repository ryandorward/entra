import React from "react"
import { useQuery } from '@apollo/client'
import { GET_COMMENTS } from './API'
import { Comment } from './Comment'
import { CommentForm } from './CommentForm'
import './comments.css'
import { WindowSpinner } from '../../Spinners'

export const EditorialComments = ({eventId}) => {

  let queryParams = {
    variables: {eventId: eventId},   
    skip: !eventId, // skip the query if id is falsy - don't waste time on a query if form should be blank     
    // fetchPolicy: 'cache-and-network',       
  }
  if (!process.env.NODE_ENV || process.env.NODE_ENV !== 'development') {
    queryParams.pollInterval = 2000 // ms  - only poll on production and not dev
  }
  const { loading, error, data } = useQuery(GET_COMMENTS, queryParams)  

  if (loading) return <p className='loading'><WindowSpinner/>Loading Comments</p> 
  if (error) {   
    console.warn(error)
    return <p>ERROR: Unable to load Comments</p>    
  }
 
  const comments = (eventId && data?.editorialComments) || [] // (! id && eventDefault) 


  return (
    <div className='editorial-comments'>           
      <div className='editorial-comments-list'>  
        { comments && comments.map((comment) => <Comment key={comment.id} comment={comment} eventId={eventId}/>) }
      </div>  
      <CommentForm eventId={eventId}/>
    </div>
  )
}