import React, {useState} from "react"
import { gql, useMutation } from '@apollo/client'
import TextField from '@mui/material/TextField'
import { Button } from '@mui/material'
import { UPSERT_COMMENT } from './API'

// There are 2 formats that this form is used for
// 1. Adding a new comment. In this case, comment (and setEditing) are undefined
// 2. Editing an existing comment. In this case comment (and setEditing) will be defined
export const CommentForm = ({eventId, comment, setEditing}) => {   

  const [newCommentText, setNewCommentText] = useState(comment ? comment.comment : '')  
  const onChange = (e) => { setNewCommentText(e.target.value) }
  const userId = drupalSettings.apfRiskAdmin.userId

  const [upsertComment, { data }] = useMutation(UPSERT_COMMENT,{
    errorPolicy: 'all',
    onCompleted(data) { },   
    update(
      cache, 
      { data: { upsertEditorialComment } }
    ) {     
      cache.modify({
        fields: {
          editorialComments(existingComments = []) {                   
            if (comment) return existingComments; // update
            // it's more complicated if we're inserting, need to add the comment to the cache:
            const newCommentRef = cache.writeFragment({              
              data: upsertEditorialComment.editorialComment,
              fragment: gql`
                fragment NewEditorialComment on EditorialComment {                                                 
                  id eventId event comment created owner 
                }
              `
            })
            return [...existingComments, newCommentRef] // insert
          }
        }           
      });      
    }
  })

  const handleSubmit = () => {    
    comment?.id ? setEditing(false): setNewCommentText('')   
    upsertComment({
      variables: {
        id: comment ? comment.id : null,
        eventId: eventId,
        comment: newCommentText,       
      },           
      optimisticResponse: {
        upsertEditorialComment: {
          editorialComment: {
            __typename: 'EditorialComment',
            comment: newCommentText,
            id: comment ? comment.id : null,
            eventId: eventId,
            event: {id: eventId},
            created: comment ? comment.created : 'Just now',
            owner: comment ? {...comment.owner} : {id: userId, name: ''},
          },
          errors: {}
        }
      }
    }).then (response => {                       
      if (response.data.upsertEditorialComment?.errors?.length) {        
        console.error(response.data.upsertEditorialComment.errors)    
      }      
      // console.log("comment id", comment?.id)
      
    }) 
  }

  function handleCancel() {
    setEditing(false)
  }

  return (
    <div className = 'comment-form'>
      <TextField          
        label={comment ? '':'Leave a comment'}
        value={ newCommentText }         
        multiline
        fullWidth        
        className="long-text"   
        onChange={onChange}  
        minrows={4}        
      />     
      <Button
        variant='outlined'
        color='primary'     
        disabled={! newCommentText}
        onClick={handleSubmit}
        size='small'
      > 
        {comment ? 'Update ':''}Comment       
      </Button>
      {comment && (
      <Button className='cancel' variant='outlined' color='primary' onClick={handleCancel} size='small'> 
        Cancel
      </Button>
      )}
    </div>
  )
}