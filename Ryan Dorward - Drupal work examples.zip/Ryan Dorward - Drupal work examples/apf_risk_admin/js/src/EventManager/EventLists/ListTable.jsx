import React from "react"
import { Table, TableContainer, TableHead, TableBody, TableRow, TableCell } from '@mui/material'

export function ListTable({children}) {  
  return (            
    <div className="list-table-wrap">
      <TableContainer className="table-container">
        <Table stickyHeader aria-label="sticky table" >
          <TableHead>
            <TableRow>              
              <TableCell>
                Event Name
              </TableCell> 
              <TableCell>
                Region
              </TableCell>  
              <TableCell>
                Owner
              </TableCell>              
              <TableCell>
                Event Id
              </TableCell> 
              <TableCell>
                Status
              </TableCell>                        
            </TableRow>
          </TableHead>
          <TableBody>
            {children}
          </TableBody>
        </Table>                
      </TableContainer>  
    </div>           
  )
}