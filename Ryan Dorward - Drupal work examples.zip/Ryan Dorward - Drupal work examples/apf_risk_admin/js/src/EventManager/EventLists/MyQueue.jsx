import React from "react"
import { useQuery } from '@apollo/client'
import { GET_EVENTS_QUEUE } from '../API'

import { WindowSpinner } from '../../Spinners'
import { ListTable } from './ListTable'
import { EventListItem } from './EventListItem'

export function MyQueue({ setConsoleMessages }) {  

  const userId = drupalSettings.apfRiskAdmin.userId
  const { loading, error, data } = useQuery(GET_EVENTS_QUEUE, { variables: {owner: userId} })
  
  if (loading) return <p className='loading'><WindowSpinner/>Loading your Queue</p> 
  if (error) return <p>Error :(</p>

  return (          
    <ListTable>
      {           
        data.eventsQueue?.map((event) => {                                                       
          return (                 
            <EventListItem
              event={event}  
              key={event.id}
              setConsoleMessages={setConsoleMessages}                 
            />            
          )                          
        })
      }
    </ListTable>         
  )
}