import React from "react"
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs'
import 'react-tabs/style/react-tabs.css'
import "./eventLists.css"

import {AllEvents} from './AllEvents'
import {MyQueue} from './MyQueue'
import { propTypes } from "react-tag-autocomplete"

export const EventLists = ({setConsoleMessages, innerRef}) => {       
  return (   
    <Tabs ref={innerRef} className="tabbing-wrap">
      <TabList>
        <Tab>My Queue</Tab>
        <Tab>All Recent Events</Tab>
      </TabList>

      <TabPanel>
        <PanelInner>
          <MyQueue setConsoleMessages={setConsoleMessages} />
        </PanelInner>
      </TabPanel>

      <TabPanel>
        <PanelInner>
          <AllEvents setConsoleMessages={setConsoleMessages} />
        </PanelInner>
      </TabPanel>
    </Tabs>
  )
}

function PanelInner(props) {
  return (    
    <div className="tab-panel-inner">     
      { props.children }      
    </div>   
  )
}