import React, { useEffect, useState } from "react"
import { useHistory } from 'react-router-dom'
import { regionLabel } from '@apfcanada/jurisdictions'
import Grow from '@mui/material/Grow'
import TableRow from '@mui/material/TableRow'
import TableCell from '@mui/material/TableCell'
import { editEventAllowed } from '../../util'
import { graph } from '../../graph'

export const EventListItem = ({event, setConsoleMessages}) => {
  const [region, setRegion] = useState('')
  const editAllowed = editEventAllowed(event.owner?.id)
  const history = useHistory()

  let rowClass = 'event-list-item ' + (event.published ? 'published' : 'unpublished')
  rowClass += ' ' + (editAllowed ? 'editable' : 'non-editable')

  let status = event.draft ? 'Draft' : 'Proof'
  status = event.approved ? 'Final Proof' : status
  status = event.published ? 'Published' : status

	useEffect(()=>{
		if(!event) return;
    const geo_ids = event.impacts?.map(impact => impact.geo_id)
		graph.lookup(geo_ids).then( jurs => setRegion( regionLabel(jurs) ) )
	},[event])

  return (
    <Grow
      in={true}
      style={{ transformOrigin: 'top center' }}
      key={event.id}
      {...(true ? { timeout: 1000 } : {})}
    >
      <TableRow
        hover
        role="checkbox"
        tabIndex={event.id}
        key={event.id}
        onClick={() => {
          setConsoleMessages([])
          history.push("/"+event.id)
        }}
        className={ rowClass }
      >
        <TableCell className="event-title">
          { event.title }
        </TableCell>
        <TableCell className="event-region">
          { region }
        </TableCell>
        <TableCell className="event-owner">
          { event.owner?.name }
        </TableCell>
        <TableCell>
          { event.id }
        </TableCell>
        <TableCell>
          { status }
        </TableCell>
      </TableRow>
    </Grow>
  )
}