import React, { useState } from "react"
import { useQuery } from '@apollo/client'
import { GET_ALL_EVENTS } from '../API'

import { WindowSpinner } from '../../Spinners'
import { ToggleButton, ToggleButtonGroup } from '@mui/material';
import { ListTable } from './ListTable'
import { EventListItem } from './EventListItem'

export function AllEvents({ setConsoleMessages }) {  

  const [publishedFilter, setPublishedFilter] = useState('')
  const { loading, error, data } = useQuery(GET_ALL_EVENTS)
  
  if (loading) return <p className='loading'><WindowSpinner/>Loading Events</p> 
  if (error) return <p>Error :(</p>

  const handleChange = (e,value) => { (value !== null) && setPublishedFilter(value) }  
  return (
    <>
      <div className='list-filters'>
        <legend>Filter Events by:</legend>
        <ToggleButtonGroup        
            exclusive                         
            value={publishedFilter}
            onChange={handleChange}
            size="small"
        >
          <ToggleButton value={''}>
            All
          </ToggleButton>
          <ToggleButton value={'true'}>
            Published
          </ToggleButton>
          <ToggleButton value={'false'}>
            Unpublished
          </ToggleButton>
        </ToggleButtonGroup>
      </div>

      <ListTable>
        {           
          data.events?.map((event) => {              
            if (publishedFilter === '' || ((publishedFilter === 'true') === event.published) ) {                            
              return (                 
                <EventListItem
                  event={event}  
                  key={event.id}
                  setConsoleMessages={setConsoleMessages}                 
                />            
              )
            }             
          })
        }
      </ListTable>       
    </>  
  )
}