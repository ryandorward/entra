import React, { useState, useEffect } from "react"
import { Box, FormControl, Select, InputLabel, MenuItem, Grid }   from '@mui/material'
import { EventAutocomplete, DocTip } from './FormWidgets'
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';

function validate(link, id) {
  let validation = []
  if (!link.event )
    validation.push({
      message: 'Event Link: Event is required',
      severity: 'error',
    })
  if (link.event?.id == id) // this probably won't happen anymore because the autocomplete api should't supply self
    validation.push({
      message: 'Event Link: Link may not be to this same event',
      severity: 'error',
    })
  if (!link.linkType?.id)
    validation.push({
      message: 'Event Link: Link must have a type',
      severity: 'error',
    })
  return validation.length ? validation : null
}

export const EventLink = ({event, link, links, setLink, onDelete}) => {

  const [linkedEventIdAndLabel, setLinkedEventIdAndLabel] = useState(() => {
    return link.event ? {
      id: link.event.id,
      label: link.event.title,
      date: link.event.date,
      published: link.event.published,
    } : {}
  })

  useEffect(() => {
    link.validation = validate(link, event.id)
    setLink(link)
  },[link.event, link.linkType])

  const handleDeleteClick = (e) => onDelete()
  const onSelectLinkedEvent = (selection) => {
    setLinkedEventIdAndLabel(selection)
    link.linkedEvent = {
      id: selection.id
    }
    link.event = {id: selection.id}
    setLink(link)
  }

  let linkTypes = drupalSettings.apfRiskAdmin.eventLinkTypes
  let hrefLink = linkedEventIdAndLabel.published ?
    'https://cast.asiapacific.ca/timeline/event/'+linkedEventIdAndLabel.id
    : '/admin/cast/management/event/'+linkedEventIdAndLabel.id

  return (
    <Grid item xs={4} container spacing={2} className = "event-link-card">
      <div className="event-link-card-inner">
          <DocTip anchor="links" title ="Impacted Jurisdiction"/>
          <Grid item xs={12}>
            <Box display="flex" alignItems="center">
              <Box flexGrow={1}>Event Link</Box>
              <Box>
                <IconButton onClick={ () => handleDeleteClick() } size="large">
                  <CloseIcon />
                </IconButton>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={6}>
              <FormControl
                className="link-type-selector"
                style={{ minWidth: '100%' }}>
                <InputLabel>Link type</InputLabel>
                <Select
                  label="Link Type"
                  value={link.linkType?.id ? link.linkType.id  : ""}
                  onChange={ e => {
                    let newLink = {...link}
                    let newLinkType = {...newLink.linkType}
                    newLinkType.id = e.target.value
                    newLink.linkType = newLinkType
                    setLink(newLink)
                  }}
                >
                  {
                    linkTypes && linkTypes.map(({ id, label }) => {
                      return (
                        <MenuItem value={id} key={id}>{label}</MenuItem>
                      )
                    })
                  }
                </Select>
              </FormControl>

          </Grid>
          <br/>
          <Grid item xs={12}>
            <EventAutocomplete
              onSelection={onSelectLinkedEvent}
              linkedEventIdAndLabel={linkedEventIdAndLabel}
              excludes={[event.id, ...links.map(elem => elem.event?.id)]}
            />
          </Grid>
          { linkedEventIdAndLabel.id && (
          <Grid item xs={12} className='mini-metadata'>
            {linkedEventIdAndLabel.published ? "Published: " : "Unpublished: "}
            <a href={hrefLink}>{linkedEventIdAndLabel.published ? "View event" : "Edit event"}</a>
          </Grid>)}
      </div>
    </Grid>
  )

}