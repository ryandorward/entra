import React, {useEffect} from "react"
import { UPSERT_EVENT, DELETE_EVENT, GET_EVENTS_QUEUE} from '../API'
import { gql, useMutation, useApolloClient } from '@apollo/client'
import { Form } from './Form'

// This was the simplest way I could figure out how to define the mutations in a separate file from Form.jsx
// Don't love having to wrap Form.jsx in this, it would be nicer to be able to import the mutations somehow...
// ...but at least they're separate
export const MutationProvider = (props) => {

  const client = useApolloClient()
  const { setConsoleMessages } = props

  const [upsertEvent] = useMutation(UPSERT_EVENT,{
    errorPolicy: 'all',
    update(cache, { data: { upsertEvent } }) {
      cache.modify({
        fields: {
          events(existingEvents = []) {
            if (upsertEvent.operation == 'update') return existingEvents; // update
            // it's more complicated if we're inserting, need to add an event to the cache:
            const newEventRef = cache.writeFragment({
              data: upsertEvent.event,
              fragment: gql`
                fragment NewRiskEvent on RiskEvent {
                  title id archive_links description justification event_date impacts links wasOngoing wasViolent propertyDamage officialResponse tags published approved draft
                }
              `
            });
            return [newEventRef, ...existingEvents]; // insert
          },
          eventsQueue(existingEvents = []) {
            if (upsertEvent.operation == 'update') return existingEvents; // update is simple
            else client.refetchQueries([{ query: GET_EVENTS_QUEUE }]) // otherwise on insert, refetch events queue
          }
        }
      })
    }
  })

  // see https://www.apollographql.com/docs/react/caching/cache-interaction/#cachemodify
  const [deleteEvent] = useMutation(DELETE_EVENT,{
    onCompleted(data) {
      setConsoleMessages(data.deleteEvent.errors)
    },
    update(cache, { data: { deleteEvent } }) {
      cache.modify({
        fields: {
          events(existingEvents = [], { readField }) {
            return existingEvents.filter(ref => deleteEvent.event.id !== readField('id', ref))
          },
          eventsQueue(existingEvents = [], { readField }) {
            return existingEvents.filter(ref => deleteEvent.event.id !== readField('id', ref))
          }
        },
        optimistic: true,
      })
    }
  });

  return <Form {...{...props, upsertEvent, deleteEvent}} />
}