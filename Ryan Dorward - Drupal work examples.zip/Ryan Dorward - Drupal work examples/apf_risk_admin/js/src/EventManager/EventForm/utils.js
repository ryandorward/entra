
// Compare an array of objects for equivalence, comparing a single property
export function objArrayEquivalenceCheckByProperty (arr1, arr2, propertyName ) {
  if (arr1.length !== arr2.length)
    return false
  for (let i = 0; i < arr1.length; i++) {
    const item1 = arr1[i]
    const item2 = arr2[i]
    if (item1 === null && item2 === null)
      continue
    if (item1 === null || item2 === null)
      return false
    if (item1[propertyName] !== item2[propertyName])
      return false
  }
  return true
}