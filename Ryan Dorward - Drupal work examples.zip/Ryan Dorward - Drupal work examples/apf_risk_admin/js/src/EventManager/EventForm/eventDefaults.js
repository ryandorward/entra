const srAnalyst = drupalSettings.apfRiskAdmin.userRoles?.includes('risk_analyst');

export var baseFieldDefaults = {
  title: {
    init: '',
    docAnchor: 'title',
  },
  archive_links: {
    init: [''],
    docAnchor: 'sources',
  },
  description:  {
    init: '',
    docAnchor: 'description',
  },
  justification: {
    init: '',
    docAnchor: 'analysis',
  },
  context: {
    init: '',
  },
  event_date: {
    init: null,
  },
  canadianInvolvement: {
    init: null,
  },
  tags: {
    init: [],
    label: 'Tags',
    docAnchor: 'tags',
  },
  action: {
    init: null,
  },
  actors: {
    init: [],
    label: 'Actors',
    docAnchor: 'actors',
  }
}

export const eventDefault = {
  id: 0,
  ...Object.fromEntries(Object.entries(baseFieldDefaults).map(([k, v]) => [k, v.init])),  // this eyesore makes a new object using the keys and the init values from baseFieldDefaults
  links: [],
  impacts: [],
  // peopleInvolved: '',
  published: false,
  approved: false,
  draft: true,
}