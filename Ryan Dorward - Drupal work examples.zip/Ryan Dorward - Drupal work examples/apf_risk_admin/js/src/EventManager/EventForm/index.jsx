import React, { useEffect, useState } from "react"
import { useParams } from 'react-router-dom'
import { GET_EVENT } from '../API'
import { useQuery } from '@apollo/client'
import { eventDefault } from './eventDefaults'
import { MutationProvider } from './MutationProvider'

import { WindowSpinner } from '../../Spinners'

export const EventForm = (params) => {
  let { id } = useParams()
  id = id ? parseInt(id) : 0 // make NaN into 0
  return <EventLoader {...params} id={id}/>
}

const EventLoader = (params) => {

  const { id } = params
  // The random key below when id is not set forces the Form to rerender whenever there is a reset to the route,
  // even if the route is the same as the previous route. This is necessary.
  // const [ key, setKey ] = useState(id || Math.random())
  const [ key, setKey ] = useState(id)

  useEffect(() => {
    // setKey(id || Math.random())
    setKey(id)
  }, [id]); // This useEffect runs only when id changes

  const { loading, error, data } = useQuery(GET_EVENT,{ // skip the query if there's no id
      variables: {id: id},
      skip: !id, // skip the query if id is falsy - don't waste time on a query if form should be blank
      fetchPolicy: 'network-only', // disable caching - currently if an eventLink is changed, the cache isn't being updated properly - for eg) with cache turned back on, delete a link from one event, when you load the formerly-linked event, it will still display the deleted link.
    }
  )

  if (loading) return <p className='loading'><WindowSpinner/>Loading Event</p>
  if (error) {
    console.warn(error)
    return <p>ERROR: Unable to load Event</p>
  }

  const event = id ? data?.event : eventDefault

  if (!event)
    return <p>Unable to load event {id}. It does not exist.</p>

  // clean the problematic __typename property from tags
  // if this becomes problematic for other fields, do a generalized cleaner
  if (event.tags) {
    event.tags = event.tags.map(tag => {
      delete tag?.__typename
      return tag
    })
  }
  if (event.actors) {
    event.actors = event.actors.map(actor => {
      delete actor.__typename
      return actor
    })
  }

  // date handling widgets need the hour to make sense, and it's easier to do this as event loads
  // because if event is saved without changes, then it will still have the "noon" time. We normalize to noon.
  event.event_date && !event.event_date.includes('T') && (event.event_date += 'T12:00:00')

  return <MutationProvider {...params} event={event} key={key} setKey={setKey} />

}