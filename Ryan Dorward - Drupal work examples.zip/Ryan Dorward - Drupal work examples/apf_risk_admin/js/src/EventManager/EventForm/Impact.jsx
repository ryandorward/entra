import React, { useEffect } from "react";
import { Box, IconButton, Grid } from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import { JurisdictionAutocomplete, DocTip } from './FormWidgets'

function validate(impact) {
  return impact.place?.geo_id ? null :
    {
      message: 'Impact: Jurisdiction is required',
      severity: 'error',
    }
}

export const Impact = ({impact, setImpact, onDelete, impacts}) => {

  useEffect(() => {
    impact.validation = validate(impact)
    setImpact(impact)
  },[impact.geo_id])

  if ( impact.geo_id && !impact.place ) return <>loading</>

  const handlePlaceSelection = (place) => {
    impact.place = place
    impact.geo_id = place.geo_id
    setImpact(impact)
  }

  return (
    <Grid item xs={4} container spacing={2} className = "event-link-card">
      <div className="event-link-card-inner">
        <DocTip anchor= {"impacts"} title = {"Impacted Jurisdiction"}/>
        <Grid item xs={12}>
          <Box display="flex" alignItems="center">
            <Box flexGrow={1}>Impacted Jurisdiction</Box>
            <Box>
              <IconButton onClick={ () => onDelete() } size="large">
                <CloseIcon />
              </IconButton>
            </Box>
          </Box>
        </Grid>

        <Grid item xs={12}>
          <JurisdictionAutocomplete
            onSelection={handlePlaceSelection}
            place={impact.place}
            excludes={impacts.map(i => i?.geo_id)}
          />
          <br/>
        </Grid>

      </div>
    </Grid>
  )

}