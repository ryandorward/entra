import React, { useState, useEffect } from "react";
import Button from '@mui/material/Button';
import { Impact } from './Impact';
import Grid from '@mui/material/Grid';
import { graph } from '../../graph';

export const Impacts = ({id, impacts, setImpacts}) => {

  const [impactIndex, setImpactIndex] = useState(0);
  const [ready, setReady] = useState(false);

  // asyncronously load the 'place' data for impacts - primarily for the placename displayed in the impact jurisdiction widget
  useEffect(() => {
    const promises = []
    let newImpacts = [...impacts]
    let isSubscribed = true // this is used so we don't try to complete promises after unmounting
    impacts.map(impact => {
      if (!impact.place && isSubscribed) {
        promises.push( // queue up the promises
          graph.lookup(impact.geo_id).then( (r) => {
            impact.place = r
            newImpacts = newImpacts.map(elem => elem.id == impact.id ? impact : elem)
          }).catch(() => {})
        )
      }
    })
    // once all those promises are done, set the impacts. This way we aren't re-rendering all the time
    Promise.all(promises).then(() => {
      if (isSubscribed) {
        setImpacts(newImpacts)
        setReady(true)
      }
    })
    return () => isSubscribed = false // set isSubscribed to false so we don't try to complete promises after unmounting
  }, []); // runs only on mount

  const onAddClick = (e) => {
    setImpactIndex(impactIndex-1); // decrement index so that we never clobber ids of already-created assessments. Negative indices indicate to-be-created links
    setImpacts([...impacts,{
      id: impactIndex,
      eventId: id,
    }]);
  }

  const deleteImpact = (id) => {
    let newImpacts = impacts.filter( elem => elem.id !== id);
    setImpacts(newImpacts);
  }

  const setImpact = (impact) => {
    let newImpacts = impacts.map(elem => elem.id == impact.id ? impact : elem);
    setImpacts(newImpacts);
  }

  return ready ? (
    <Grid
      container
      direction="row"
      justifyContent="flex-start"
      alignItems="flex-start"
      spacing={4}
    >
      {
        impacts?.map((impact) => {
          return (
            <Impact
              key={impact.id}
              impact={{...impact}}
              impacts={impacts}
              setImpact={setImpact}
              onDelete={() => deleteImpact(impact.id)}
            />
          )
        })
      }

      <Grid item xs={12}>
        <Button variant="outlined" onClick={onAddClick} className="addButton">
          + Add an Impacted Jurisdiction
        </Button>
      </Grid>

    </Grid>

  ) : 'Loading jurisdiction graph data';
}