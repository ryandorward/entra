import React from 'react'
import { UPSERT_EVENT, DELETE_EVENT, GET_EVENTS_QUEUE} from '../API'
import { gql, useMutation, useApolloClient } from '@apollo/client'


export const upsertEvent = () => {

const [upsertEvent] = useMutation(UPSERT_EVENT,{
  errorPolicy: 'all',   
  update(cache, { data: { upsertEvent } }) {    
    cache.modify({
      fields: {
        events(existingEvents = []) {               
          if (id) return existingEvents; // update
          // it's more complicated if we're inserting, need to add an event to the cache:
          const newEventRef = cache.writeFragment({              
            data: upsertEvent.event,
            fragment: gql`
              fragment NewRiskEvent on RiskEvent {                                                 
                id title archive_links description justification event_date impacts links wasOngoing wasViolent propertyDamage officialResponse tags published approved draft      
              }
            ` 
          });
          return [newEventRef, ...existingEvents]; // insert
        },
        eventsQueue(existingEvents = []) {                
          if (id) return existingEvents; // update is simple
          else client.refetchQueries([{ query: GET_EVENTS_QUEUE }]) // otherwise on insert, refetch events queue
        }
      }           
    })     
  }
})

return upsertEvent

}