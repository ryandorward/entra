import React from "react";

export const Metadata = ({event}) => {
  const id = event.id
  if ( !id ) return null
  const owner = event.owner
  const lastEditor = event.lastEditor
  const created = event.created
  const changed = event.changed
  const published = event.published
  const approved = event.approved
  const draft = event.draft

  return (
    <div className='metadata'>
      <div className='editorial-status'>
        <span className={'draft' + (draft?' active':'')}>Draft</span>&nbsp;{'>'}&nbsp;
        {/*<span className={'proof' + (!draft && !approved ?' active':'')}>Proof</span>&nbsp;{'>'}&nbsp;
        <span className={'final-proof' + (approved && !published ?' active':'')}>Final Proof</span>&nbsp;{'>'}&nbsp; */}
        <span className={'proof' + (!draft && !published ?' active':'')}>Proof</span>&nbsp;{'>'}&nbsp;

        <span className={'published' + (published?' active':'')}>Published</span>
      </div>
      <br/>
      <strong>Event Id:</strong> {id}<br/>
      <strong>Owner:</strong> { owner?.name || (<em>unknown</em>) }<br/>
      <strong>Last Editor:</strong> { lastEditor?.name || (<em>unknown</em>) }<br/>
      <strong>Created:</strong> { created || (<em>unknown</em>)}<br/>
      <strong>Changed:</strong> { changed }<br/>
      { published &&
        <>
          <strong>Published: </strong>
          <a className='published-link' href={"https://cast.asiapacific.ca/timeline/event/"+id}>
            {"https://cast.asiapacific.ca/timeline/event/"+id}
          </a>
        </>
      }
      {/*
      <br/><strong>Published:</strong>{published ? "true":"false"}<br/>
      <strong>Approved:</strong>{approved ? "true":"false"}<br/>
      <strong>Draft:</strong>{draft? "true":"false"}<br/>
      *}
      {/*  !published && <>(Unpublished{ draft ? ' Draft':', submitted for approval'})</> */}
    </div>
  )
}