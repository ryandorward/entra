import React, { useState, useEffect, useRef } from 'react'
import { Prompt, useHistory } from 'react-router-dom'
import Grid from '@mui/material/Grid'
import { baseFieldDefaults, eventDefault } from './eventDefaults'
import { ActionButtons, Fields } from './FormWidgets'
import { EventLinks } from './EventLinks'
import { Impacts } from './Impacts'
import { Metadata } from './Metadata'
import { EditorialComments } from '../EditorialComments'
import { WindowSpinner } from '../../Spinners'
import { Console } from '../../Console'
import { objArrayEquivalenceCheckByProperty } from './utils'

export const Form = (props) => {
  const {event, consoleMessages, setConsoleMessages, setKey} = props
  const {submitting, setSubmitting} = props
  const {upsertEvent, deleteEvent} = props
  const [links, setLinks] = useState(event.links)
  const [impacts, setImpacts] = useState(event.impacts)
  const [dirty, setDirty] = useState(false)
  const [maskDirtyCheck, setMaskDirtyCheck] = useState(false)
  const history = useHistory()

  const draft = event.draft
  const published = event.published
  const approved = event.approved
  const peopleInvolved = event.peopleInvolved
  const id = event.id

  const isBeta = drupalSettings.apfRiskAdmin.userRoles?.includes('cast_beta')

  // Warn user when they reload or nav away from current page when form is dirty
  useEffect(() => {
    if (!maskDirtyCheck && dirty)
      window.onbeforeunload = () => true
    else
      window.onbeforeunload = undefined
  }) // runs on any state change

  // Using mounted to check if the component is *actually* mounted,
  // and to remove the browser warning for unsaved changes when the user navigates away on unmount
  const mounted = useRef(false)
  useEffect(() => {
    mounted.current = true
    return () => { // this happens on unmount
      mounted.current = false
      window.onbeforeunload = undefined
    }
  }, []) // empty set => runs only on mount/unmount

  let baseFields = []
  for (let key in baseFieldDefaults) {
    baseFields[key] = baseFieldDefaults[key]
    const [value, set] = useState(event?.[key]) // why can't we set directly to baseFields?
    baseFields[key].value = value
    baseFields[key].set = set
  }

  // Check if the field represented by key is dirty, return true if dirty
  function checkDirty(key) {
    // sketchy to use eval, but const isn't added to global namespace, so have to use eval to dynamically get the var using a string
    // one way to avoid using eval would be to put all the non-baseFields into an array, similar to how we're doing baseFields
    const value = baseFields[key] ? baseFields[key].value : eval(key)
    const originalValue = event[key]
    if (Array.isArray(value) && (value.length != originalValue.length))
      return true
    else switch (key) {
      case 'impacts':
        return !objArrayEquivalenceCheckByProperty(value, originalValue, 'geo_id')
      case 'tags':
        return !objArrayEquivalenceCheckByProperty(value, originalValue, 'id')
      case 'archive_links':
        for (let i = 0; i < value.length; i++)
          if (value[i] != originalValue[i])
            return true
        return false
      case 'links':
        for (let i = 0; i < value.length; i++)
          if ((value[i].event?.id != originalValue[i].event?.id) || (value[i].linkType != originalValue[i].linkType))
            return true
        return false
      case 'actors':
        for (let i = 0; i < value.length; i++)
          if (value[i].id != originalValue[i].id)
            return true
        return false
      default:
        if (value != originalValue)
          return true
    }
    return false
  }

  // Track dirty state of form
  useEffect(() => {
    if (maskDirtyCheck) return;
    let newDirty = false // Not dirty until proven otherwise. Resetting flag every time we check allows us to un-dirty the form by manually resetting a field to original value
    for (let key in eventDefault) {

      if (checkDirty(key)) {
        //  console.log('Dirty because', key, 'changed')
        newDirty = true
        break
      }
    }
    (dirty !== newDirty) && setDirty(newDirty)
  }) // @todo: this effect could depend on only the states we need to watch

  const resetForm = () => {
    // only set states when the component is actually mounted
    // why would this even run when component unmounted? it does eg. after changing an event and then saving
    if (mounted.current) {
      setMaskDirtyCheck(true)
      setDirty(false)
    }
    // when no id, need to set own key with a random to trigger event to be reset (and clear any dirty fields)
    if (!id) setKey(Math.random())
    history.push("/")
    mounted.current && setMaskDirtyCheck(false) // open up dirty check again
  }

  const preValidation = () => {
    var messages = []
    for (let key in baseFields) // iterate through fields for for validation messages
      baseFields[key].validation && messages.push(baseFields[key].validation)
    impacts.forEach(impact => impact.validation && messages.push(impact.validation))
    links.forEach(link => link.validation && link.validation.forEach(message => messages.push(message))) // multiple msgs possible per link
    return messages.length == 0 || (setConsoleMessages(messages) && false) // return true if valid, or print the messages and return false. Can't resist using this expression
  }

   // the optional actions parameter can be passed to indicate that the event should be switched to a different
  // editorial state when it is saved. This is necessary instead of using the state variables, because
  // changing those will change the rendering of the buttons and interrupts the submit process.
  const handleSubmit = (e, actions) => {

    e.preventDefault() // prevent form from *actually* submitting so we don't reload page after saving
    if (!preValidation()) return

    setSubmitting(true)

    let newDraft = draft
    let newApproved = approved
    let newPublished = published

    if (actions?.promote) {
      if (draft) // draft -> proof
        newDraft = false
      else if (!published ) { // proof -> published
        newApproved = true
        newPublished = true
      }
      /*
      // use this block instead once we turn on the final proof stage:
      if (draft) // draft -> proof
        newDraft = false
      else if (!approved) // !draft && !approved == proof -> final proof
        newApproved = true
      else if (!published ) // approved && !published == final proof -> published
        newPublished = true
      */
    }
    else if (actions?.demote) {
      if (!approved) { // proof -> draft
        newDraft = true
        newPublished = false
      }
      else { // published -> proof
        newApproved = false
        newPublished = false
      }
      /*
      // use this block instead once we turn on the final proof stage:
      if (!approved) // proof -> draft
        newDraft = true
      else if (!published) // final proof -> approved
        newApproved = false
      else // published -> final proof
        newPublished = false
      */
    }

    const variables = {
      id: id , // id of 0 tells API to insert a new event rather than update an existing one
      published: newPublished,
      approved: newApproved,
      draft: newDraft
    }
    Object.keys(baseFields).forEach(key => {
      // Don't try to re-set the fields above that we already set, add only set dirty fields
      if (!variables.hasOwnProperty(key) && checkDirty(key))
        variables[key] = baseFields[key].value
    }) // Add the baseFields
    variables.peopleInvolved = peopleInvolved === '' ? null : peopleInvolved; // gui component needs empty string for null, API needs actual null
    if (checkDirty('links'))
      variables.links = links.map(link => {
        return {
          id: link.id,
          linkTypeId: link.linkType.id,
          eventId: link.event?.id
        }
      })
    if (checkDirty('impacts'))
      variables.impacts = impacts.map(impact => {
        return {
          id: impact.id,
          geo_id: impact.geo_id,
          eventId: impact.eventId
        }
      })

    upsertEvent({
      variables: variables,
      // optimistic: true
    }).then (response => {
        setConsoleMessages(response.data.upsertEvent?.errors || [
          { // there should always be "errors", if not then something is wrong
            message: 'Sorry, there was a problem.',
            severity: 'error',
          }
        ])
        // success if there are only status and warning messages in "errors"
        const success = response.data.upsertEvent?.errors.reduce(
          ((accum, curr) => ['status', 'warning'].includes(curr.severity) ? accum : false)
        )
        setSubmitting(false)
        if (!success)
          return

        const destination = "/"+ response.data.upsertEvent.event.id
        if (mounted.current) {
          setMaskDirtyCheck(true) // must set the mask before setting dirty = false
          setDirty(false)
          history.push("/") // trick to get the form to reload the event from server after update: clear it first
          history.push(destination) // then load the event
          mounted.current && setMaskDirtyCheck(false) // component should be unmounted by now, but just in case
        }
        else
          history.push(destination)
      },
    )
  }

  const actionButtonProps = {
    id, dirty, draft, published, approved,
    handleSubmit, resetForm,
    deleteEntity: deleteEvent, ownerId: event.owner?.id,
  }

  if (submitting)
    return <div><WindowSpinner/>{ id ? "Updating" : "Creating"} Event...</div>
  else return (
    <form onSubmit = {handleSubmit}
      className='risk-admin-form'
    >
      <Prompt when={dirty} message="There are unsaved changes. Are you sure you want to abandon them?" />
      <Grid container spacing={3} >
        <Grid item xs={6}>
          <ActionButtons {...actionButtonProps}/>
          <Fields fields={baseFields} />
        </Grid>

        <Grid item xs={6} className='right-column'>
          <div className='pseudo-element console-position-marker'></div>
          <Console {...{consoleMessages, setConsoleMessages }}/>
          <Metadata event={event} />
          { event.id ? <EditorialComments eventId={event.id}/> : null }
        </Grid>

        <Grid item xs={12}>
          <br/>
          <Impacts {...{id, impacts, setImpacts}} />
          <br/><br/>
          <EventLinks {...{event, links, setLinks}} />
          <br/><br/>
          <ActionButtons {...actionButtonProps} />
        </Grid>
      </Grid>
    </form>
  )
}