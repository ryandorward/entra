import React, { useState, useEffect, useRef } from "react";
import Button from '@mui/material/Button';
import { EventLink } from './EventLink';
import Grid from '@mui/material/Grid';

export const EventLinks = ({event, links, setLinks}) => {  
  
  const [linkIndex, setLinkIndex] = useState(0);  

  const onAddClick = (e) => {    
    setLinkIndex(linkIndex-1); // decrement index so that we never clobber ids of already-created links. Negative indices indicate to-be-created links
    setLinks([...links,{
      id: linkIndex,
      source: {        
      },
      target: {       
      },
      linkType: {
        id: null
      },     
    }]);
  }

  const deleteLink = (id) => {           
    let newLinks = links.filter( elem => elem?.id !== id);
    setLinks(newLinks);
  }

  const setLink = (link) => {
    let newLinks = links.map(elem => elem?.id == link.id ? link : elem);
    setLinks(newLinks);
  }

   // Translate link storage into format that's logical for UI
  const transFormLinkStorageToUIFormat = (link) => {
    const uiLink = {...link};   
    if (link.source?.id == event.id) {
      uiLink.direction = "outgoing";
      uiLink.linkedEvent = link.target;
    }
    else if (link.target?.id == event.id) {
      uiLink.direction = "incoming";
      uiLink.linkedEvent = link.source;
    }   
    return uiLink;
  }

  return (
    <Grid 
      container
      direction="row"
      justifyContent="flex-start"
      alignItems="flex-start"
      spacing={3}
    >

      {
        links && links.map((link) => {
          const uiLink = transFormLinkStorageToUIFormat(link);              
          return (                 
            <EventLink             
              key={link.id}  
              event = {event} 
              link={uiLink}  
              links={links}
              setLink = {setLink}   
              onDelete = {() => deleteLink(link.id)}                                    
            />            
          )
        })
      }

      <Grid item xs={12}>
        <Button variant="outlined" onClick={onAddClick} className="addButton"> + Add an Event Link
        </Button>
      </Grid>

    </Grid>
  );

}  