<?php

namespace Drupal\Tests\apf_risk_entites\Functional;

use Drupal\Core\Url;
use Drupal\Tests\BrowserTestBase;
use Drupal\apf_risk_entities\Entity\RiskEvent;
use Drupal\taxonomy\Entity\Term;
include('vendor/rmccue/requests/library/Requests.php');

// from site root:
// vendor/bin/phpunit modules/apf_risk_entities/tests/src/Functional/RiskEventTest.php


/**
 * Simple test to ensure that main page loads with module enabled.
 *
 * @group apf_risk
 */
class RiskEventTest extends BrowserTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'apf_risk_entities',
    // 'entraTools',
    'system',
    'field',
    'link',
    'datetime',
    'taxonomy',
    'token',
    'file',
    // 'typed_data',
    // 'user',
    // 'language',
    // 'entity_reference_test',
    'file',
    // 'apf_auth'
  ];
  //protected $defaultTheme = 'apf';
  // protected $defaultTheme = 'stable';
  protected $defaultTheme = 'stark'; // recommended for test relying on no markup

  /**
   * A user with permission to administer site configuration.
   *
   * @var \Drupal\user\UserInterface
   */
  protected $user;

  public function debug($var, $label=null) {
    fwrite(STDOUT, "\r\n");
    if ($label) fwrite(STDOUT, $label . ': ');
    fwrite(STDOUT, json_encode($var));
  }

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {

    parent::setUp();

    // In case a user is needed
    /*
    $this->user = $this->drupalCreateUser(['administer site configuration']);
    $this->drupalLogin($this->user);
    */

    // Debug like this
    // $this->debug("This is a degug message to CLI");

    $this->term = Term::create([
      'name' => 'Test term',
      'vid' => 'vocabulary_4'
    ]);
    $this->term->save();
    $tid = $this->term->id();

    $this->event = RiskEvent::create([
      'title' => 'Test event',
      'description' => 'Test description',
      'tags' => [ $tid ],
      'event_date' => '2021-06-06T12:00:00',
    ]);
    $this->event->save();

    $this->unpublishedEvent = RiskEvent::create([
      'title' => 'Test event - unpublished',
      'description' => 'Lorem ipsum',
      'tags' => [ $tid ],
      'event_date' => '2021-06-06T12:00:00',
      'status' => 0
    ]);
    $this->unpublishedEvent->save();

  }

  /**
   * Tests that the home page loads with a 200 response.
   */
  /*
  public function testLoad() {
    $this->drupalGet(Url::fromRoute('<front>'));
    $this->assertSession()->statusCodeEquals(200);
  }
  */

  /**
   * Tests that the home page loads with a 200 response.
   */

  public function testLoadEvents() {

    // Make sure an event loads and that it has the title
    $event = RiskEvent::load(1);
    $this->assertNotNull($event);
    $this->assertEquals($this->event->title->value, $event->title->value);

    // Make sure some events load
    $ids = RiskEvent::getIds();
    $this->assertGreaterThan(0, count($ids));

    // Test `before` arg
    $ids = RiskEvent::getIds(['before' => '2019-01-01']);
    $this->assertEquals(0, count($ids));
    $ids = RiskEvent::getIds(['before' => 'now']);
    $this->assertGreaterThan(0, count($ids));

    // test `after` arg
    $ids = RiskEvent::getIds(['after' => 'now']);
    $this->assertEquals(0, count($ids));
    $ids = RiskEvent::getIds(['after' => '2019-01-01']);
    $this->assertGreaterThan(0, count($ids));

    // test `tags` arg
    $ids = RiskEvent::getIds(['tags' => $this->term->id()]);
    $this->assertGreaterThan(0, count($ids));
    $ids = RiskEvent::getIds(['tags' => [$this->term->id(), '999']]); // 999 is not a valid tag, but our 'term' exists, so this should still give us an event
    $this->assertGreaterThan(0, count($ids));
    $ids = RiskEvent::getIds(['tags' => '999']); // 999 is not a valid tag, should return nothing
    $this->assertEquals(0, count($ids));

    // test `withUnpublished` arg
    $ids = RiskEvent::getIds(['withUnpublished' => false]);
    $this->assertEquals(1, count($ids));
    $ids = RiskEvent::getIds(['withUnpublished' => true]);
    $this->assertEquals(2, count($ids));

    \Requests::register_autoloader();
    $headers = [
      'Content-Type' => 'application/json'
    ];
    $data = '{"query":"query{ events { id } }"}';
    $response = \Requests::post('http://www.asiapacific.local/gql/risk', $headers, $data);
    $this->assertEquals(200, $response->status_code);



    self::debug($response->body);

  }

}