<?php

// use \Drupal\Core\Entity\Sql\SqlContentEntityStorageSchemaConverter;
use Drupal\Core\Entity\EntityDefinitionUpdateManagerInterface;

/**
 * Update change_analysis to be revisionable.
 */
function apf_risk_entities_post_update_make_change_analysis_revisionable(&$sandbox) {
  $schema_converter = new EntityDefinitionUpdateManagerInterface(
    'change_analysis',
    \Drupal::entityTypeManager(),
    \Drupal::entityDefinitionUpdateManager(),
    \Drupal::service('entity.last_installed_schema.repository'),
    \Drupal::keyValue('entity.storage_schema.sql'),
    \Drupal::database()
  );

  $schema_converter->convertToRevisionable(
    $sandbox,
    [     
      'changed',
      'score',
      'datetime',
      'component',
      'score',
      'jurisdiction',
      'description',
      'tags',
    ]
  );
}

/**
 * Update risk_event to be revisionable.
 */
function apf_risk_entities_post_update_make_risk_event_revisionable(&$sandbox) {
  $schema_converter = new EntityDefinitionUpdateManagerInterface(
    'risk_event',
    \Drupal::entityTypeManager(),
    \Drupal::entityDefinitionUpdateManager(),
    \Drupal::service('entity.last_installed_schema.repository'),
    \Drupal::keyValue('entity.storage_schema.sql'),
    \Drupal::database()
  );

  $schema_converter->convertToRevisionable(
    $sandbox,
    [     
      'changed',     
      'title',      
      'event_date',
      'title',
      'archive_links',
      'archive_pdf',
      'description',
      'justification',
      'peopleInvolved',
      'wasOngoing',
      'wasViolent',
      'propertyDamage',
      'officialResponse',
      'tags'    
    ]
  );
}