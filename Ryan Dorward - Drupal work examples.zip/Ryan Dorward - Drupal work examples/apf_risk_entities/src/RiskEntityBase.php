<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\RiskEntityBase.
 */

namespace Drupal\apf_risk_entities;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\user\UserInterface;

class RiskEntityBase extends ContentEntityBase implements RiskEntityInterface {

	use EntityChangedTrait; // Implements methods defined by EntityChangedInterface.
  use RiskEntityTrait;

	/**
   * {@inheritdoc}
   */
  public function getOwner() {
    return $this->get('user_id')->entity;
  }

  /**
   * {@inheritdoc}
   */
  public function getOwnerId() {
    return $this->get('user_id')->target_id;
  }

  /**
   * {@inheritdoc}
   */
  public function setOwnerId($uid) {
    $this->set('user_id', $uid);
    return $this;
	}

	/**
   * {@inheritdoc}
   */
  public function setOwner(UserInterface $account) {
    $this->set('user_id', $account->id());
    return $this;
  }


	public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields = parent::baseFieldDefinitions($entity_type);

    // Standard field, used as unique if primary index.
    $fields['id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('ID'))
      ->setDescription(t('The ID of the Risk Event entity.'))
      ->setReadOnly(true);

    // Standard field, unique outside of the scope of the current Risk Event.
    $fields['uuid'] = BaseFieldDefinition::create('uuid')
      ->setLabel(t('UUID'))
      ->setDescription(t('The UUID of the Risk Event entity.'))
      ->setReadOnly(TRUE);

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel('Created On')
      ->setDescription(t('The time that the entity was created.'))
      ->setDisplayOptions('view', [
        'type' => 'timestamp',
        'settings' => [
          'date_format' => 'custom',
          'custom_date_format' => 'F j, Y',
        ]
      ]);

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel('Changed')
      ->setDescription(t('The time that the entity was last edited.'))
      ->setDisplayOptions('view', [
        'type' => 'timestamp',
        'settings' => [
          'date_format' => 'custom',
          'custom_date_format' => 'F j, Y',
        ]
      ]);

    /*
    $fields['langcode'] = BaseFieldDefinition::create('language')
      ->setName('langcode')
      ->setDefaultValue('x-default')// x-default is the sites default language.
      ->setStorageRequired(TRUE)
      ->setLabel(t('Language code'))
      ->setDescription(t('The language code.'))
      ->setTranslatable(TRUE);
    */

    return $fields;

  }

  // return an array of all entities of this type
  public static function getIds() {
    $ids = \Drupal::entityQuery(self::getEntityTypeId())
      ->sort('id', 'DESC')
      ->execute();
    return $ids;
  }

  public function validateFields() {
    $fieldViolations = [];
    $fields = $this->getFields();
    foreach ($fields as $field_name => $field) {
      // error_log("Validating: ". $field_name);
      $violations = $this->{$field_name}->validate();
      if (count($violations) > 0) {
        $fieldViolations[$field_name] = [
          'label' => $field_name, // $field->label(),
          'violations' => []
        ];
        foreach ($violations as $violation)
          $fieldViolations[$field_name]['violations'][] =  $violation->getMessage();
      }
    }
    if (count($fieldViolations) > 0)
      return $fieldViolations;
  }

}