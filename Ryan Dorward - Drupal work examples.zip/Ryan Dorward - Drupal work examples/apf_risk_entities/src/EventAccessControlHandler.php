<?php

namespace Drupal\apf_risk_entities;

use Drupal\Core\Session\AccountInterface;

/**
 * Event Access controller for APF Risk Event entities.
 *
 */
class EventAccessControlHandler extends GeneralAccessControlHandler {

  protected static function checkUpsertDel(AccountInterface $account) {
    // error_log("EventAccessControlHandler::checkUpsertDel");
    $roles = $account->getRoles();
    if (in_array('risk_analyst', $roles ) || in_array('risk_jr_analyst', $roles ))
      return true;
  }

}