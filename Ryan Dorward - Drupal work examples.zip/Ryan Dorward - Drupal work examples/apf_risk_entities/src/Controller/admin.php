<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\Controller\admin.
 */

namespace Drupal\apf_risk_entities\Controller;

use Drupal\Core\Controller\ControllerBase;

class admin extends ControllerBase {

  // controller for the Add Project form, used by developers
  public function addEventLinkType() {

    $link = \Drupal::entityTypeManager()
      ->getStorage('risk_event_link_type')
      ->create();

    $form = \Drupal::entityTypeManager()
      ->getFormObject('risk_event_link_type', 'default')
      ->setEntity($link);

    $builtForm = \Drupal::formBuilder()->getForm($form);

    return [
      '#theme' => 'entityFormPage',
      '#form' => [
        $builtForm,
      ],
    ];

  }

}