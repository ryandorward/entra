<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\Controller\pages.
 */

namespace Drupal\apf_risk_entities\Controller;

use Drupal\Core\Controller\ControllerBase;

class pages extends ControllerBase {

  public static function riskEntitiesHome() {

    $base_routes = [
      'Main Admin Tools' => [
        [
          'label' => 'CAST Event management tool',
          'extra' => '<- if in doubt, you probably want to go here',
          'route' => 'apf_risk_admin.event',
        ],
        [
          'label' => 'Jurisdiction management tool',
          'route' => 'apf_jurisdictions.admin',
        ],
        [
          'label' => 'Run Jurisdiction update scripts (beta)',
          'route' => 'apf_risk_admin.jurisdictions_update_runner',
        ],
        [ // @todo: this is never showing up. Hardwire the url in and check perms before displaying?
          'label' => '"Actions" vocabulary management tool',
          'route' => 'entity.taxonomy_vocabulary.overview_form',
          'route_args' => ['taxonomy_vocabulary' => 'actions'],
        ],
        [
          'label' => 'View CAST User Accounts',
          'route' => 'view.cast_user_accounts.page_1',
        ],
      ],
      'Create' => [
        [
          'label' => 'Event',
          'route' => 'entity.risk_event.add',
        ],
        [
          'label' => 'Event Theme',
          'route' => 'entity.event_theme.add',
        ],
        [
          'label' => 'Event Link',
          'route' => 'entity.risk_event_link.add',
        ],
        [
          'label' => 'Event Link Type',
          'route' => 'entity.risk_event_link_type.add',
        ],
        [
          'label' => 'Event Risk Assessment',
          'route' => 'entity.event_risk_assessment.add',
        ],
        [
          'label' => 'Risk Component',
          'route' => 'entity.risk_component.add',
        ],
        [
          'label' => 'Editorial Comment',
          'route' => 'entity.editorial_comment.add',
        ],
      ],
      'Lists' => [
        [
          'label' => 'Events',
          'route' => 'entity.risk_event.collection',
        ],
        [
          'label' => 'Event Themes',
          'route' => 'entity.event_theme.collection',
        ],
        [
          'label' => 'Event Links',
          'route' => 'entity.risk_event_link.collection',
        ],
        [
          'label' => 'Event Link Types',
          'route' => 'entity.risk_event_link_type.collection',
        ],
        [
          'label' => 'Event Risk Assessments',
          'route' => 'entity.event_risk_assessment.collection',
        ],
        [
          'label' => 'Risk Components',
          'route' => 'entity.risk_component.collection',
        ],
        [
          'label' => 'Editorial Comments',
          'route' => 'entity.editorial_comment.collection',
        ],
      ],
    ];

    $access_manager = \Drupal::service('access_manager');
    $current_user = \Drupal::currentUser();

    // Don't clutter the UI with stuff most analysts will never need
    if (!in_array('senior_admin', $current_user->getRoles())) {
      unset($base_routes['Create']);
      unset($base_routes['Lists']);
    }

    $routes = [];
    foreach ($base_routes as $key => $section) {
      $routes[$key] = [];
      foreach ($section as $item)
        if ($access_manager->checkNamedRoute($item['route'], isset($item['route_args']) ?  $item['route_args'] : [], $current_user))
          $routes[$key][] = $item;
      if (empty($routes[$key]))
        unset ($routes[$key]);
    }

    return [
      "#theme" => "riskEntitiesHome",
      '#routes' => $routes,
    ];
  }

}