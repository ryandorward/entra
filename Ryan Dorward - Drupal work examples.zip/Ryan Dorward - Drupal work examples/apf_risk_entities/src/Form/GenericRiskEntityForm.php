<?php

namespace Drupal\apf_risk_entities\Form;

use Drupal\Core\Entity\ContentEntityForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form controller for the entity edit forms.
 *
 * @ingroup risk
 */
class GenericRiskEntityForm extends ContentEntityForm {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return "generic_risk_entity_form";
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form = parent::buildForm($form, $form_state);

    // Hack the Parent Themes field to be read-only
    // field is hopefully only present on Event Theme entities
    if (isset($form['parent_themes'])) {
      $form['parent_themes']['#attributes']['readonly'] = 'readonly';
      if (isset($form['parent_themes']['widget']['add_more']))
        unset($form['parent_themes']['widget']['add_more']);
      foreach ($form['parent_themes']['widget'] as $key => &$widget) {
        if (is_array($widget) && isset($widget['target_id'])) {
          $widget['target_id']['#attributes']['readonly'] = 'readonly';
        }
      }
    }
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {

    $status = parent::save($form, $form_state);

    $entity = $this->entity;
    $args = [
      '%label' => $entity->toLink()->toString(),
      '%entityName' => $entity->getEntityType()->getLabel(),
    ];
    if ($status == SAVED_UPDATED)
      \Drupal::messenger()->addMessage($this->t('The %entityName "%label" has been updated.', $args));
    else
      \Drupal::messenger()->addMessage($this->t('The %entityName "%label" has been added.', $args));

    $form_state->setRedirectUrl($this->entity->toUrl('collection'));
    return $status;

  }
}