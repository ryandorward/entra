<?php

namespace Drupal\apf_risk_entities\Form;

use Drupal\Core\Entity\ContentEntityConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 * Provides a generic form for deleting a risk entity.
 *
 * @ingroup risk
 */
class GenericRiskEntityDeleteForm extends ContentEntityConfirmFormBase {

  /**
   * Returns the question to ask the user.
   *
   * @return string
   *   The form question. The page title will be set to this value.
   */
  public function getQuestion() {
    $args = [
      '%label' => $this->entity->label(),
      '%entityName' => $this->entity->getEntityType()->getLabel(),
    ];
    return $this->t('Are you sure you want to delete %entityName %label?', $args);
  }

  /**
   * Returns the route to go to if the user cancels the action.
   *
   * @return \Drupal\Core\Url
   *   A URL object.
   */
  public function getCancelUrl() {
    return $this->entity->toUrl('collection');   
  }

  /**
   * {@inheritdoc}
   */
  public function getConfirmText() {
    return $this->t('Delete');
  }

  /**
   * {@inheritdoc}
   *
   * Delete the entity and log the event. logger() replaces the watchdog.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $entity = $this->getEntity();
    $entity->delete();

    $args = [
      '%label' => $this->entity->label(),
      '%entityName' => $entity->getEntityType()->getLabel(),
    ];
    $this->logger('apf_risk_entities')->notice('Deleted %entityName %label.',$args);
    // Redirect to list after delete.
    $route = 'entity.' .$entity->getEntityTypeId()  . '.collection'; // @todo: there's probably a more elegant way to get this entity's collection route
    $form_state->setRedirect($route);
  }
}
?>