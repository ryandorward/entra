<?php

namespace Drupal\apf_risk_entities\Plugin\Validation\Constraint;

use Symfony\Component\Validator\Constraint;

/**
 * Checks that the submitted risk assessment is unique per event/component/jurisdiction
 *
 * @Constraint(
 *   id = "UniqueRiskAssessment",
 *   label = @Translation("Unique Risk Assessment", context = "Validation"),
 *   type = "string"
 * )
 */
class UniqueRiskAssessment extends Constraint {

  // The message that will be shown if the assessment is not unique.
  public $notUnique = '%entity is not unique per event/component/jurisdiction';

}