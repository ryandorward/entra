<?php

namespace Drupal\apf_risk_entities\Plugin\Validation\Constraint;

use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

/**
 * Validates the UniqueRiskAssessment constraint.
 */
class UniqueRiskAssessmentValidator extends ConstraintValidator {

  /**
   * {@inheritdoc}
   */
  public function validate($items, Constraint $constraint) {
    if (!$this->isUnique($items)) {
      $this->context->addViolation($constraint->notUnique, ['%entity' => "Risk Assessment"]);
    }
  }

  /**
   * Check if Risk Assessment is unique per event + jurisdiction + component
   *
   * @param string $value
   */
  private function isUnique($entity) {

    $query = \Drupal::entityQuery('event_risk_assessment');

    // event
    if (empty($entity->event->entity)) $query->condition('event',null,'IS NULL');
    else $query->condition('event',$entity->event->entity->id());

    // jurisdiction
    if (empty($entity->geo_id->value)) $query->condition('geo_id',null,'IS NULL');
    else $query->condition('geo_id',$entity->geo_id->value);

    // component
    if (empty($entity->component->entity)) $query->condition('component',null,'IS NULL');
    else $query->condition('component',$entity->component->entity->id());

    // exclude this entity from query (in case of update)
    if (! empty($entity->id())) $query->condition('id',$entity->id(), '!=');

    $ids = $query->execute();
    if (count($ids) > 0) return false;
    else return true;

  }

}