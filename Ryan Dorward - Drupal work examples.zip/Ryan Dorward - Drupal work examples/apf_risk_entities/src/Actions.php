<?php

namespace Drupal\apf_risk_entities;
use Drupal\taxonomy\Entity\Term;

/**
 * Stuff for dealing with Actions vocabulary.
 */
class Actions  {

   // This would not be very efficient on large vocabulary like Tags
  // n^2 algorithm, but we're using it on a small list of tags with 'actions' vocab
  public static function buildTermTree($parent, $terms) {
    $children = [];
    foreach ($terms as $term) {
      if (in_array($parent ? $parent->tid : '0' ,$term->parents))
        $children[] = self::buildTermTree($term, $terms);
    }
    return [
      'id' => (int) ($parent->tid ?? '0'),
      'label' => $parent->name ?? '',
      'children' => $children,
    ];
  }

  public static function getActions($rootId = null) {
    $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('actions');
    $seed = null;
    if ($rootId) {
      foreach ($terms as $term)
      if ($term->tid == $rootId) {
        $seed = $term;
        break;
      }
      if (!$seed) return []; // if a $rootId was provided and it's not found - there's no corresponding branch
    }
    $actions = self::buildTermTree($seed, $terms); // will give the whole tree if seed is null
    return $rootId ? $actions : $actions['children']; // we only want the children if seed is null. Otherwise include the seed term
  }
}