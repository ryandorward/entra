<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\Entity\RiskComponent.
 */

namespace Drupal\apf_risk_entities\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\apf_risk_entities\RiskEntityBase;

/**
 * Defines the Risk Component entity.
 *
 * @ingroup apf_risk
 *
 * @ContentEntityType(
 *   id = "risk_component",
 *   label = @Translation("Risk Component"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\apf_risk_entities\ListBuilders\RiskComponentListBuilder",
 *     "form" = {
 *       "default" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "add" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "edit" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "delete" = "Drupal\apf_risk_entities\Form\GenericRiskEntityDeleteForm",
 *     },
 *     "access" = "Drupal\apf_risk_entities\GeneralAccessControlHandler",
 *   },
 *   base_table = "risk_component",
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "title",
 *   },
 *   links = {
 *     "canonical" = "/admin/risk/risk-component/{risk_component}",
 *     "edit-form" = "/admin/risk/risk-component/{risk_component}/edit",
 *     "collection" = "/admin/risk/risk-component/list"
 *   },
 *
 * )
 */

/*
	Spec:

	CREATE TABLE risk_components (
	  uid serial PRIMARY KEY,
	  category integer NOT NULL REFERENCES risk_categories (uid),
	  title text NOT NULL,
	  description text
  );
*/

class RiskComponent extends RiskEntityBase {

	public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['title'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Title'))
      ->setSettings(array(
        'max_length' => 255,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', [
        'type' => 'string',
      ])
      ->setDisplayOptions('form', [
        'type' => 'string',
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['long_name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Long Name'))
      ->setSettings(array(
        'max_length' => 511,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', [
        'type' => 'string',
      ])
      ->setDisplayOptions('form', [
        'type' => 'string',
      ])
      ->setDisplayConfigurable('view', TRUE);

		$fields['description'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Description'))
      ->setSettings(array(
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', [
        'type' => 'text_long',
      ])
      ->setDisplayOptions('form', [
        'type' => 'text_long',
      ]);

    return $fields;
  }

  // return an array of risk component IDs
  public static function getRiskComponentsIds() {
    $ids = \Drupal::entityQuery('risk_component')
      ->sort('id', 'ASC')
      ->execute();
    return $ids;
  }

  // return an array of risk component entities
  public static function getRiskComponents() {
    $ids = self::getRiskComponentsIds();
    return self::loadMultiple($ids);
  }

}