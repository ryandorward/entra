<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\Entity\EventLink.
 */

namespace Drupal\apf_risk_entities\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\apf_risk_entities\RiskEntityBase;

/**
 * Defines the Risk Event Link entity.
 *
 * @ingroup apf_risk
 *
 * @ContentEntityType(
 *   id = "risk_event_link",
 *   label = @Translation("Event Link"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\apf_risk_entities\ListBuilders\EventLinkListBuilder",
 *     "form" = {
 *       "default" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "add" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "edit" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "delete" = "Drupal\apf_risk_entities\Form\GenericRiskEntityDeleteForm",
 *     },
 *     "access" = "Drupal\apf_risk_entities\GeneralAccessControlHandler",
 *   },
 *   base_table = "risk_event_link",
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "id",
 *   },
 *   links = {
 *     "canonical" = "/admin/risk/event-link/{risk_event_link}",
 *     "edit-form" = "/admin/risk/event-link/{risk_event_link}/edit",
 *     "collection" = "/admin/risk/event-link/list"
 *   },
 * )
 */


/*
	Spec:

	CREATE TABLE event_links (
    uid serial PRIMARY KEY,
    type integer NOT NULL REFERENCES event_link_types (uid),
    source_event integer NOT NULL REFERENCES events (uid),
    target_event integer NOT NULL REFERENCES events (uid),
    description text -- optional
  );

*/

class EventLink extends RiskEntityBase {

	public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields = parent::baseFieldDefinitions($entity_type);

		$fields['description'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Description'))
      ->setSettings([
        // 'max_length' => 255,
        'text_processing' => 0,
      ])
      ->setDisplayOptions('view', [
        'type' => 'text_long',
      ])
      ->setDisplayOptions('form', [
        'type' => 'text_long',
      ]);

    // note: see example at https://drupal.stackexchange.com/questions/194804/how-to-create-entity-reference-field-from-custom-entity-to-specific-content-type
    // note: show allowed display widgets with: drupal debug:plugin field.widget
    // note: show allowed field types with drupal debug:plugin field.field_type
    $fields['source_event'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Event 1')
      ->setSetting('target_type', 'risk_event')
      ->setSetting('handler', 'default')
      // ->setSetting('handler_settings',['target_bundles'=>['project'=>'project']] ) // if there was a specific bundle to target
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'settings' => [
          'match_operator'    => 'CONTAINS',
          'size'              => '60',
          'autocomplete_type' => 'tags',
          'placeholder'       => 'Enter title...',
        ],
      ])
      ->setDisplayOptions('view', [
        'type' => 'number',
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['target_event'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Event 2')
      ->setSetting('target_type', 'risk_event')
      ->setSetting('handler', 'default')
      // ->setSetting('handler_settings',['target_bundles'=>['project'=>'project']] ) // if there was a specific bundle to target
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'settings' => [
          'match_operator'    => 'CONTAINS',
          'size'              => '60',
          'autocomplete_type' => 'tags',
          'placeholder'       => 'Enter title...',
        ],
      ]);

    $fields['link_type'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Link Type')
      ->setSetting('target_type', 'risk_event_link_type')
      ->setSetting('handler', 'default')
      // ->setSetting('handler_settings',['target_bundles'=>['project'=>'project']] ) // if there was a specific bundle to target
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'settings' => [
          'match_operator'    => 'CONTAINS',
          'size'              => '60',
          'autocomplete_type' => 'tags',
          'placeholder'       => '',
        ],
      ]);

    return $fields;
  }

  private static function updateLinkedEventWeights($entity) {
    // get the linked events to updateWeight()
    $source_event = $entity->get('source_event')->entity;
    $source_event?->updateWeight();
    $source_event?->save();

    $target_event = $entity->get('target_event')->entity;
    $target_event?->updateWeight();
    $target_event?->save();
  }

  public function postSave(EntityStorageInterface $storage, $update = TRUE) {
    parent::postSave($storage, $update);
    self::updateLinkedEventWeights($this);
  }

  public static function postDelete(EntityStorageInterface $storage, array $entities) {
    parent::postDelete($storage, $entities);
    foreach ($entities as $entity) {
      self::updateLinkedEventWeights($entity);
    }
  }

  public static function getLinkIds() {
    $ids = \Drupal::entityQuery('risk_event_link')
      ->sort('id', 'DESC')
      ->execute();
    return $ids;
  }

  // return an array of all links
  public static function getLinks() {
    $ids = self::getLinkIds();
    return self::loadMultiple($ids);
  }

  public static function getLinkIdsBySourceEventId($id) {
    $ids = \Drupal::entityQuery('risk_event_link')
      ->condition('source_event', $id)
      ->sort('id', 'DESC')
      ->execute();
    return $ids;
  }

  public static function getLinkIdsByTargetEventId($id) {
    $ids = \Drupal::entityQuery('risk_event_link')
      ->condition('target_event', $id)
      ->sort('id', 'DESC')
      ->execute();
    return $ids;
  }

  public static function getLinksBySourceEventId($id) {
    $ids = self::getLinkIdsBySourceEventId($id);
    return self::loadMultiple($ids);
  }

  public static function getLinksByTargetEventId($id) {
    $ids = self::getLinkIdsByTargetEventId($id);
    return self::loadMultiple($ids);
  }

  public static function getOrphans($id = null) {
    $query = \Drupal::entityQuery('risk_event_link');
    if ($id) {
      $group = $query->orConditionGroup()
        ->condition('target_event', $id)
        ->condition('source_event', $id);
      $query->condition($group);
    }
    $ids = $query->execute();

    // now get all the event ids:
    $event_ids = \Drupal::entityQuery('risk_event')->execute();

    // now filter out the event links that have a source and target event to existing events:
    $event_links = self::loadMultiple($ids);
    $orphans = [];
    foreach ($event_links as $event_link) {
      $source_event_id = $event_link->get('source_event')->target_id;
      $target_event_id = $event_link->get('target_event')->target_id;
      if (!in_array($source_event_id, $event_ids) || !in_array($target_event_id, $event_ids)) {
        $orphans[] = $event_link;
      }
    }
    return $orphans;
  }


  // Gets all risk_event_link entities for which the event is a target OR source
  public static function getByEventId($id = null, $withUnpublished = false, $types = []) {
    $query = \Drupal::entityQuery('risk_event_link');
    if ($id) {
      $group = $query->orConditionGroup()
        ->condition('target_event', $id)
        ->condition('source_event', $id);
      $query->condition($group);
    }
    if (!empty($types))
      $query->condition('link_type',$types, 'IN');

    $ids = $query
      ->sort('id', 'ASC')
      ->execute();
    $links = self::loadMultiple($ids);

    // filter off links to unpublished events if needed
    if (! $withUnpublished) {
      $links = array_filter($links, function ($link) {
        /*
        if ($link->target_event->entity
            && $link->target_event->entity->status->value
            && $link->source_event->entity
            && $link->source_event->entity->status->value )
        */
        if ($link->target_event->entity
            && $link->target_event->entity->isPublished()
            && $link->source_event->entity
            && $link->source_event->entity->isPublished() )
          return $link;
      });
    }

    return $links;
  }

}