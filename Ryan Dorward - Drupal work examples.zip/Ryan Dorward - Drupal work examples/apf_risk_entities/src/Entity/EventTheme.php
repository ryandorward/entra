<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\Entity\EventTheme.
 */

namespace Drupal\apf_risk_entities\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\Cache\Cache;
use Drupal\apf_risk_entities\RiskEntityEditorialBase;
use Drupal\apf_risk_entities\Entity\RiskEvent;

/**
 * Defines the Event Theme entity.
 *
 * @ingroup apf_risk
 *
 * @ContentEntityType(
 *   id = "event_theme",
 *   label = @Translation("Event Theme"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\apf_risk_entities\ListBuilders\EventThemeListBuilder",
 *     "form" = {
 *       "default" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "add" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "edit" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "delete" = "Drupal\apf_risk_entities\Form\GenericRiskEntityDeleteForm",
 *     },
 *     "access" = "Drupal\apf_risk_entities\GeneralAccessControlHandler",
 *   },
 *   base_table = "event_theme",
 *   revision_table = "event_theme_revision",
 *   show_revision_ui = TRUE,
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "name",
 *     "revision" = "revision_id",
 *     "published" = "status",
 *   },
 *   revision_metadata_keys = {
 *     "revision_user" = "revision_user",
 *     "revision_created" = "revision_created",
 *     "revision_log_message" = "revision_log",
 *   },
 *   links = {
 *     "canonical" = "/admin/risk/event-theme/{risk_event_theme}",
 *     "edit-form" = "/admin/risk/event-theme/{risk_event_theme}/edit",
 *     "collection" = "/admin/risk/event-theme/list"
 *   },
 * )
 */


class EventTheme extends RiskEntityEditorialBase {

	public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields = [];

    $fields['name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Name'))
      ->setSettings(array(
        'max_length' => 255,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', [
        'type' => 'string',
      ])
      ->setDisplayOptions('form', [
        'type' => 'string',
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setRevisionable(TRUE);

    $fields['geo_ids'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Jurisdictions (geo_ids)'))
      ->setSettings([
        'size' => "normal",
        'unsigned' => true,
      ])
      ->setDisplayOptions('form', [
        'type' => 'string',
      ])
      ->setRevisionable(TRUE)
      ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED);

    $fields['tags'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Tags')
      ->setSetting('target_type', 'taxonomy_term')
      ->setSetting('handler', 'default:taxonomy_term')
      ->setSetting('handler_settings', [
        'target_bundles' => [
          'vocabulary_4' => 'vocabulary_4' // aka Keywords
        ]])
      ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)
      ->setDisplayOptions('form', array(
        'type' => 'entity_reference_autocomplete',
        'settings' => array(
          'match_operator' => 'CONTAINS',
          'size' => '10',
          'autocomplete_type' => 'tags',
          'placeholder' => '',
        ),
      ))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setRevisionable(TRUE);

    $fields['child_themes'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Child Themes')
      ->setSetting('target_type', 'event_theme')
      ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'settings' => [
          'match_operator'    => 'CONTAINS',
          'size'              => '60',
          'autocomplete_type' => 'tags',
          'placeholder'       => 'Enter title...',
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setRevisionable(TRUE);

    // set this to be a read only entity_reference field
    $fields['parent_themes'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Parent Themes (read only)')
      ->setSetting('target_type', 'event_theme')
      ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)
      ->setDisplayOptions('form', [
        'type' => 'hidden', // this should work but does not.
      ])
      ->setReadOnly(TRUE);

		$fields['description'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Description'))
      ->setSettings([
        // 'max_length' => 255,
        'text_processing' => 0,
      ])
      ->setDisplayOptions('view', [
        'type' => 'text_long',
      ])
      ->setInitialValue(['format' => 'plain_text']) // not working. Why?
      ->setDisplayOptions('form', [
        'type' => 'text_long',
        'format' => 'plain_text'
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setRevisionable(TRUE);

    $fields['color'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Colour'))
      ->setSettings(array(
        'max_length' => 127,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', [
        'type' => 'string',
      ])
      ->setDisplayOptions('form', [
        'type' => 'string',
      ])
      ->setDisplayConfigurable('view', TRUE)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setRevisionable(TRUE);

    $fields += parent::baseFieldDefinitions($entity_type);
    return $fields;
  }

  public static function getThemeIds() {
    $ids = \Drupal::entityQuery('event_theme')
      ->condition('status', 1)
      ->sort('id', 'DESC')
      ->execute();
    return $ids;
  }

  public function isMeta() {
    return ! empty($this->child_themes->getValue());
  }

  private function getDescendants() {
    $descendants = [
      "{$this->id()}" => $this
    ];
    foreach ($this->child_themes as $child) {
      if ($child->entity) {
        $child_descendants = $child->entity->getDescendants();
        $descendants = array_replace($descendants, $child_descendants);
      }
    }
    return $descendants;
  }

  public function getAncestors() {
    $ancestors = [
      "{$this->id()}" => $this
    ];
    foreach ($this->parent_themes as $parent) {
      $parent_ancestors = $parent->entity->getAncestors();
      $ancestors = array_replace($ancestors, $parent_ancestors);
    }
    return $ancestors;
  }

  // return an array of themes, if no $ids specified get all of them
  // $withDescendantThemes will return any descendants/children/children-of-children of "meta-themes"
  // $isMeta is for filtering meta-themes
  public static function getThemes($ids = null, $withDescendantThemes = false, $isMeta = null, $withAncestorThemes = false) {
    $ids = $ids ?? self::getThemeIds();
    $themes = self::loadMultiple($ids);
    $descendants = [];
    $ancestors = [];
    if ($withDescendantThemes) {
      foreach ($themes as $key => $theme) {
        $theme_descendants = $theme->getDescendants();
        $descendants = array_replace($descendants, $theme_descendants);
      }
    }
    if ($withAncestorThemes) {
      foreach ($themes as $theme) {
        $theme_ancestors = $theme->getAncestors();
        $ancestors = array_replace($ancestors, $theme_ancestors);
      }
    }
    $themes = array_replace($descendants, $themes);
    $themes = array_replace($ancestors, $themes);
    if ($isMeta !== null) {
      $themes = array_filter($themes, function($theme) use ($isMeta) {
        return $theme->isMeta() === $isMeta;
      });
    }
    return $themes;
  }

  // store ids of ancestors in array
  private function detectChildCycle($ancestry = []) {

    if (in_array($this->id(), $ancestry))
      return $this; // we've found a cycle
    else foreach ($this->child_themes as $child) {
      $ancestry[] = $this->id();
      $child_cycle = $child->entity->detectChildCycle($ancestry);
      if ($child_cycle)
        return $child_cycle;
    }
  }

  public function preSave(EntityStorageInterface $storage) {

    $messages = [];
    $removes = [];
    // check each child theme for a reference cycle.
    // Don't do this on new entities, they can't have a cycle yet since new and nothing else can be their parent yet
    if ($this->id())
      foreach ($this->child_themes as $key => $child) {
        if ($child->entity) {
          $child_cycle = $child->entity->detectChildCycle([$this->id()]);
          if ($child_cycle) {
            $message = 'Ancestry cycle detected on "' . $child->entity->label() . '". Theme was not added as a child to "' . $this->label() . '".';
            $removes[] = $key;
            $messages[] = $message;
          }
        }
      }

    // remove offending children
    $keep_children = [];
    foreach ($this->child_themes as $key => $child) {
      if (! in_array($key, $removes))
        $keep_children[] = $child->entity;
    }
    $this->set('child_themes',$keep_children);

    if (!empty($messages)) {
      $message = implode("<br/>", $messages);
      \Drupal::messenger()->addWarning($message);
    }

    // need the original children in postSave
    $this->original_children = [];
    if ($this->id()) {
      $original = self::load($this->id());
      foreach ($original->child_themes as $child) {
        if ($child->entity)
          $this->original_children[] = $child->entity;
      }
    }

    parent::preSave($storage);

  }

  public function postSave(EntityStorageInterface $storage, $update = TRUE) {
    // original_children was set in presave so that we can find out which children were removed
    if (isset($this->original_children)) {
      // need to check each child to see if it has been removed
      foreach ($this->original_children as $original_child) {
        $found = false;
        foreach ($this->child_themes as $child) {
          if ($child->entity->id() === $original_child->id()) {
            $found = true;
            break;
          }
        }

        if (!$found) {
          $remove_key = null;
          foreach ($original_child->parent_themes as $key => $parent) {
            if ($parent->entity->id() === $this->id()) {
              $original_child->parent_themes->removeItem($key);
              $original_child->save();
              break;
            }
          }
        }
      }
    }

    // Now we take care of any new children
    // need to do this in post save because a new node now has its ID
    foreach ($this->child_themes as $key => $child) {
      $child_theme = $child->entity;
      // check if child theme already has this theme as its parent
      $hasParent = false;
      foreach ($child_theme->parent_themes as $parent) {
        if ($parent->entity && $parent->entity->id() === $this->id()) {
          $hasParent = true;
          break;
        }
      }
      if (!$hasParent) {
        $child_theme->parent_themes->appendItem($this);
        $child_theme->save();
      }
    }

    // update the cast_event_themes table
    // first remove any existing entries for this theme
    $query = \Drupal::database()->delete('cast_event_themes')
      ->condition('theme_id', $this->id());
    $query->execute();

    // Find all events that use this theme
    // get the tag ids for this theme
    $tag_ids = [];
    foreach ($this->tags as $tag) {
      $tag_ids[] = $tag->target_id;
    }

    // Get all the events that are tagged with any of these tags
    $args = [
      'tags' => $tag_ids,
      'withUnpublished' => true
    ];
    $events = RiskEvent::getRiskEvents($args);

    // Could limit the list of updates to only those events that also match the geo_id of the theme (if any)
    // but this is already good enough. Mainly just want to not have to update the enire set of events

    // Update themes for all of these Events
    foreach ($events as $event) {
      $event->updateThemes();
    }

    parent::postSave($storage, $update);
  }

  public static function preDelete(EntityStorageInterface $storage, array $entities) {
    foreach ($entities as $entity) {
      // Clean up the parent_themes
      foreach ($entity->child_themes as $key => $child) {
        if ($child->entity)
          foreach ($child->entity->parent_themes as $key => $parent) {
            if ($parent->entity->id() === $entity->id()) {
              $child->entity->parent_themes->removeItem($key);
              $child->entity->save();
              break;
            }
          }
      }

      // Clean up the child_themes
      foreach ($entity->parent_themes as $key => $parent) {
        if ($parent->entity)
          foreach ($parent->entity->child_themes as $key => $child) {
            if ($child->entity->id() === $entity->id()) {
              $parent->entity->child_themes->removeItem($key);
              $parent->entity->save();
              break;
            }
          }
      }

      // clean up apf_event_themes
      $query = \Drupal::database()->delete('cast_event_themes')
        ->condition('theme_id', $entity->id());
      $query->execute();

    }
  }

  public static function getTagThemeIds() {
    $cache_id = "apf_risk_entities_tagThemeIds2";
    $cache_tags = ["event_theme_list"];

    if ($cache = \Drupal::cache()->get($cache_id))
      return $cache->data;

    $tag_ids = [];
    $themes = self::getThemes();
    foreach ($themes as $theme) {
      foreach ($theme->tags as $tag) {
        // this allows for fast lookups by using isset
        $tag_ids[$tag->entity->id()][] = $theme->id();
      }
    }
    \Drupal::cache()->set($cache_id, $tag_ids, Cache::PERMANENT, $cache_tags);

    return $tag_ids;
  }

  public static function getTagThemes() {
    $cache_id = "apf_risk_entities_tagThemes2";
    $cache_tags = ["event_theme_list"];

    if ($cache = \Drupal::cache()->get($cache_id))
      return $cache->data;

    $ids = self::getTagThemeIds();
    $tagThemes = [];
    foreach ($ids as $tag_id => $theme_ids) {
      $tagThemes[$tag_id] = self::loadMultiple($theme_ids);
    }
    \Drupal::cache()->set($cache_id, $tagThemes, Cache::PERMANENT, $cache_tags);

    return $tagThemes;
  }


  public static function getCannonicalTagIds() {
    // the following works because any tag in the array will be cannonical by definition
    return self::getTagThemeIds();
  }

}