<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\Entity\RiskEvent\FieldDefinitions.
 */

namespace Drupal\apf_risk_entities\Entity\RiskEvent;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\FieldStorageDefinitionInterface;

/*** ENTITY UPDATES ***/
// If there are any changes to the schema,
// In devel: run drush entity-updates if there are any changes to this
// In production: read this change-record: https://www.drupal.org/node/3034742

// In production:
// drush en -y devel_entity_updates; drush entup -y; drush pm-uninstall -y devel_entity_updates devel; drush cr;

// In development:
// drush en -y devel_entity_updates; drush entup -y; drush pm-uninstall -y devel_entity_updates;

trait FieldDefinitions {

  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields = [];

    $fields['event_date'] = BaseFieldDefinition::create('datetime')
      ->setLabel(t('Date of event'))
      ->setDescription(t('The date/time of the Event'))
      ->setDisplayOptions('view', [
        'type' => 'timestamp',
        'settings' => [
          'date_format' => 'custom',
          'custom_date_format' => 'F j, Y',
        ]
      ])
      ->setDisplayOptions('form', [
        'type' => 'datetime_default',
      ])
      ->setDisplayConfigurable('view', TRUE)
      ->setRevisionable(TRUE);

    $fields['title'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Event Title'))
      ->setSettings(array(
        'max_length' => 255,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('form', [
        'type' => 'string',
      ])
      ->setRevisionable(TRUE);

    $fields['archive_links'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Archive Link'))
      ->setDescription(t('Link to news story archived on https://web.archive.org/'))
      ->setSettings([
        'max_length' => 511,
        'text_processing' => 0,
      ])
      ->setDisplayOptions('form', [
        'type' => 'string',
      ])
      ->setRevisionable(TRUE)
      ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED);

    $fields['description'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Describe what happened'))
      ->setSettings([
        'text_processing' => 0,
      ])
      ->setDisplayOptions('view', [
        'type' => 'text_long',
      ])
      ->setRevisionable(TRUE)
      ->setDisplayOptions('form', [
        'type' => 'text_long',
      ]);

    $fields['justification'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Analysis of implications, impact'))
      ->setSettings([
        'text_processing' => 0,
      ])
      ->setDisplayOptions('view', [
        'type' => 'text_long',
      ])
      ->setDisplayOptions('form', [
        'type' => 'text_long',
      ])
      ->setRevisionable(TRUE);

    $fields['peopleInvolved'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Number of people involved'))
      ->setDescription(t('10<sup>n</sup> people'))
      ->setSettings([
        'size' => "small",
        'max' => 9,
        'min' => 0,
        'unsigned' => true,
      ])
      ->setDisplayOptions('form', [
        'type' => 'number'
      ])
      ->setRevisionable(TRUE);

    $fields['wasOngoing'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Is this an ongoing event?'))
      ->setDisplayOptions('form', [
        'type' => 'options_buttons',
      ])
      ->setRevisionable(TRUE);

    $fields['wasViolent'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Was there violence involved?'))
      ->setDisplayOptions('form', [
        'type' => 'options_buttons',
      ])
      ->setRevisionable(TRUE);

    $fields['propertyDamage'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Was there property damage involved?'))
      ->setDisplayOptions('form', [
        'type' => 'options_buttons',
      ])
      ->setRevisionable(TRUE);

    $fields['officialResponse'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Was there an official response?'))
      ->setDisplayOptions('form', [
        'type' => 'options_buttons',
      ])
      ->setRevisionable(TRUE);

    $fields['canadianInvolvement'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Were Canadians directly involved?'))
      ->setDisplayOptions('form', [
        'type' => 'options_buttons',
      ])
      ->setRevisionable(TRUE);

    $fields['visible'] = BaseFieldDefinition::create('boolean')
      ->setDisplayOptions('form', [
        'type' => 'hidden',
      ]);

    $fields['tags'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Tags')
      ->setSetting('target_type', 'taxonomy_term')
      ->setSetting('handler', 'default:taxonomy_term')
      ->setSetting('handler_settings', [
        'target_bundles' => [
          'vocabulary_4' => 'vocabulary_4' // aka Keywords
        ]])
      ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'settings' => [
          'match_operator' => 'CONTAINS',
          'size' => '10',
          'autocomplete_type' => 'tags',
          'placeholder' => '',
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setRevisionable(TRUE);

    /*
    $fields['themes'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Themes')
      ->setSetting('target_type', 'event_theme')
      ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)
      ->setReadOnly(TRUE);
    */

    $fields['context'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Additional Information'))
      ->setSettings([
        'text_processing' => 0,
      ])
      ->setDisplayOptions('view', [
        'type' => 'text_long',
      ])
      ->setDisplayOptions('form', [
        'type' => 'text_long',
      ])
      ->setRevisionable(TRUE);

    $fields['action'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Event Type')
      ->setSetting('target_type', 'taxonomy_term')
      ->setSetting('handler', 'default:taxonomy_term')
      ->setSetting('handler_settings', [
        'target_bundles' => [
          'actions' => 'actions' // aka Actions
        ]])
      //->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'settings' => [
          'match_operator' => 'CONTAINS',
          'size' => '10',
          'autocomplete_type' => 'tags',
          'placeholder' => '',
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setRevisionable(TRUE);

    $fields['actors'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Actors'))
      ->setSettings([
        'max_length' => 255,
        'text_processing' => 0,
      ])
      ->setDisplayOptions('form', [
        'type' => 'string',
      ])
      ->setRevisionable(TRUE)
      ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED);

      $field['fieldname'] = array(
        'type' => 'float',
        'unsigned' => TRUE,
        'size' => 'normal', // normal / big
        'not null' => FALSE,
        'description' => t('Field fieldname of tablename.'),
      );

      $fields['weight'] = BaseFieldDefinition::create('float')
        ->setLabel(t('Weight'))
        ->setSettings([
          'size' => 'normal',
          'unsigned' => true,
        ])
        ->setReadOnly(TRUE);

    $fields += parent::baseFieldDefinitions($entity_type);
    return $fields;

  }

}