<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\Entity\EventRiskAssessment.
 */

// @todo: this is no longer in use and should be possible to uninstall and delete
// what happens to existing entities if we uninstallt tho?
// probably should delete all these entities first, then uninstall the entity
// run the entity updates script after
// after that remove all of:
// ListBuilder,
// uniqueRiskAssessment from Plugin/Validation/Constraint,
// entries in apf_risk_entities.links.task.yml
// apf_risk_entities.routing.yml

namespace Drupal\apf_risk_entities\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Database\Database;

use Drupal\apf_risk_entities\RiskEntityBase;
use Drupal\apf_risk_entities\Entity\RiskEvent;

/**
 * Defines the Event Risk Assessment entity.
 *
 * This is now AKA "Impact"
 *
 * @ingroup apf_risk
 *
 * @ContentEntityType(
 *   id = "event_risk_assessment",
 *   label = @Translation("Event Risk Assessment"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\apf_risk_entities\ListBuilders\EventRiskAssessmentListBuilder",
 *     "form" = {
 *       "default" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "add" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "edit" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "delete" = "Drupal\apf_risk_entities\Form\GenericRiskEntityDeleteForm",
 *     },
 *     "access" = "Drupal\apf_risk_entities\GeneralAccessControlHandler",
 *   },
 *   base_table = "event_risk_assessment",
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "id",
 *   },
 *   links = {
 *     "canonical" = "/admin/risk/event-risk-assessment/{event_risk_assessment}",
 *     "edit-form" = "/admin/risk/event-risk-assessment/{event_risk_assessment}/edit",
 *     "collection" = "/admin/risk/event-risk-assessment/list"
 *   },
 *
 * )
 */


/*
	Spec:

	CREATE TABLE event_risk_assessments (
    uid serial PRIMARY KEY,
    event_uid integer NOT NULL REFERENCES events (uid),
    jurisdiction_uid integer NOT NULL REFERENCES jurisdictions (geo_id),
    component_uid integer NOT NULL REFERENCES risk_components (uid),
    assessment smallint CHECK ( assessment >= -5 AND assessment <= 5 ) -- likert scales
  );

*/

// note: show allowed display widgets with: drupal debug:plugin field.widget
// note: show allowed field types with drupal debug:plugin field.field_type

class EventRiskAssessment extends RiskEntityBase {

	public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields = parent::baseFieldDefinitions($entity_type);

    // note: see example at https://drupal.stackexchange.com/questions/194804/how-to-create-entity-reference-field-from-custom-entity-to-specific-content-type
    $fields['event'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Event')
      ->setSetting('target_type', 'risk_event')
      ->setSetting('handler', 'default')
      // ->setSetting('handler_settings',['target_bundles'=>['project'=>'project']] ) // if there was a specific bundle to target
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'settings' => [
          'match_operator'    => 'CONTAINS',
          'size'              => '60',
          'autocomplete_type' => 'tags',
          'placeholder'       => 'Enter title...',
        ],
      ])
      ->setDisplayOptions('view', [
        'type' => 'number',
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['geo_id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Jurisdiction (geo_id)'))
      ->setSettings([
        'size' => "normal",
        'unsigned' => true,
      ])
      ->setDisplayOptions('form', array(
        'type' => 'string',
      ));

    $fields['component'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Component')
      ->setSetting('target_type', 'risk_component')
      ->setSetting('handler', 'default')
     // ->setRequired(TRUE)
      // ->setSetting('handler_settings',['target_bundles'=>['project'=>'project']] ) // if there was a specific bundle to target
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'settings' => [
          'match_operator'    => 'CONTAINS',
          'size'              => '60',
          'autocomplete_type' => 'tags',
          'placeholder'       => 'Enter title...',
        ],
      ])
      ->setDisplayOptions('view', [
        'type' => 'number',
      ])
      ->setDisplayConfigurable('view', TRUE);

    // Standard field, used as unique if primary index.
    $fields['assessment'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Assessment: High number == High risk'))
      ->setDescription(t('Likert scale value'))
      ->setSettings([
        'size' => "small",
        'max' => 5,
        'min' => -5,
        'unsigned' => false,
      ])
      ->setDisplayOptions('form', [
        'type' => 'number'
      ]);

    $fields['description'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Description'))
      ->setSettings(array(
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', [
        'type' => 'text_long',
      ])
      ->setDisplayOptions('form', [
        'type' => 'text_long',
      ]);

    return $fields;
  }

  public static function getIdsByEventId($id) {
    $ids = \Drupal::entityQuery('event_risk_assessment')
      ->condition('event',$id)
      ->sort('id', 'ASC')
      ->execute();
    return $ids;
  }

  public static function getByEventId($id) {
    $ids = self::getIdsByEventId($id);
    return self::loadMultiple($ids);
  }

  public static function getIdsByEventIds($ids) {
    $ids = \Drupal::entityQuery('event_risk_assessment')
      ->condition('event',$ids, 'IN')
      ->sort('id', 'ASC')
      ->execute();
    return $ids;
  }

  public static function getByEventIds($ids) {
    $ids = self::getIdsByEventIds($ids);
    return self::loadMultiple($ids);
  }

  public static function getByJurisdictionComponents($geo_ids, $component_ids) {
    if (!is_array($geo_ids) && is_numeric($geo_ids))
      $geo_ids = [$geo_ids];
    if (!is_array($component_ids) && is_numeric($component_ids))
      $component_ids = [$component_ids];
    $query = \Drupal::entityQuery('event_risk_assessment')->sort('id', 'DESC');
    if (!empty($geo_ids))
      $query->condition('geo_id',$geo_ids, 'IN');
    if (!empty($component_ids))
      $query->condition('component',$component_ids, 'IN');
    $ids = $query->execute();
    return self::loadMultiple($ids);
  }

}