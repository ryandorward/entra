<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\Entity\EventLinkType.
 */

namespace Drupal\apf_risk_entities\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\apf_risk_entities\RiskEntityBase;

/**
 * Defines the Risk Event Link Type entity.
 *
 * @ingroup apf_risk
 *
 * @ContentEntityType(
 *   id = "risk_event_link_type",
 *   label = @Translation("Event Link Type"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\apf_risk_entities\ListBuilders\EventLinkTypeListBuilder",
 *     "form" = {
 *       "default" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "add" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "edit" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "delete" = "Drupal\apf_risk_entities\Form\GenericRiskEntityDeleteForm",
 *     },
 *     "access" = "Drupal\apf_risk_entities\GeneralAccessControlHandler",
 *   },
 *   base_table = "risk_event_link_type",
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "title",
 *   },
 *   links = {
 *     "canonical" = "/admin/risk/event-link-type/{risk_event_link_type}",
 *     "edit-form" = "/admin/risk/event-link-type/{risk_event_link_type}/edit",
 *     "collection" = "/admin/risk/event-link-type/list"
 *   },
 * )
 *
 */


/*
	Spec:

	CREATE TABLE event_link_types (
		uid serial PRIMARY KEY,
		title text NOT NULL,
		description text
	);
*/

class EventLinkType extends RiskEntityBase {

	public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['title'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Title'))
      ->setSettings(array(
        'max_length' => 255,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', [
        'type' => 'string',
      ])
      ->setDisplayOptions('form', [
        'type' => 'string',
      ])
      ->setDisplayConfigurable('view', TRUE);

		$fields['description'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Description'))
      ->setSettings(array(
        // 'max_length' => 255,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', [
        'type' => 'text_long',
      ])
      ->setDisplayOptions('form', [
        'type' => 'text_long',
      ]);

    $fields['referenceFromPast'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Reference From Past'))
      ->setSettings(array(
        'max_length' => 255,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', [
        'type' => 'string',
      ])
      ->setDisplayOptions('form', [
        'type' => 'string',
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['referenceFromFuture'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Reference From Future'))
      ->setSettings(array(
        'max_length' => 255,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', [
        'type' => 'string',
      ])
      ->setDisplayOptions('form', [
        'type' => 'string',
      ])
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

  public static function getLinkTypesIds() {
    // $uid = \Drupal::currentUser()->id();
    $ids = \Drupal::entityQuery('risk_event_link_type')
      ->sort('id', 'ASC')
      ->execute();
    return $ids;
  }

  public static function getLinkTypes($ids = null) {
    $ids = $ids ?? self::getLinkTypesIds();
    return self::loadMultiple($ids);
  }

}