<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\Entity\RiskEvent.
 */

namespace Drupal\apf_risk_entities\Entity;

use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Database\Database;
use Drupal\Core\Cache\Cache;
use Drupal\apf_risk_entities\Entity\RiskEvent\FieldDefinitions;
use Drupal\apf_risk_entities\RiskEntityEditorialBase;
use Drupal\apf_risk_api\KeywordAutocompleteMatcher;

use \Drupal\apf_risk_entities\Entity\EventTheme;
use \Drupal\apf_risk_entities\Entity\EventRiskAssessment;
use pgapi\pgConnection;

require_once DRUPAL_ROOT . '/pgapi/pgConnection.php';
require DRUPAL_ROOT . '/pgapi/public/jurFractions.php';
require_once DRUPAL_ROOT . '/pgapi/public/getJurisdictions.php';

/**
 * Defines the CAST Event entity.
 *
 * @ingroup apf_risk
 *
 * @ContentEntityType(
 *   id = "risk_event",
 *   label = @Translation("CAST Event"),
 *   base_table = "risk_event",
 *   revision_table = "risk_event_revision",
 *   show_revision_ui = TRUE,
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *   },
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\apf_risk_entities\ListBuilders\RiskEventListBuilder",
 *     "form" = {
 *       "default" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "add" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "edit" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "delete" = "Drupal\apf_risk_entities\Form\GenericRiskEntityDeleteForm",
 *     },
 *     "access" = "Drupal\apf_risk_entities\EventAccessControlHandler",
 *   },
 *   entity_keys = {
 *     "label" = "title",
 *     "uuid" = "uuid",
 *     "id" = "id",
 *     "revision" = "revision_id",
 *     "published" = "status",
 *   },
 *   links = {
 *     "canonical" = "/admin/risk/event/{risk_event}",
 *     "edit-form" = "/admin/risk/event/{risk_event}/edit",
 *     "collection" = "/admin/risk/event/list",
 *     "version-history" = "/admin/risk/event/{risk_event}/revisions",
 *     "revision" = "/admin/risk/event/{risk_event}/revisions/{risk_event_revision}/view",
 *   },
 *   revision_metadata_keys = {
 *     "revision_user" = "revision_user",
 *     "revision_created" = "revision_created",
 *     "revision_log_message" = "revision_log_message",
 *   },
 * )
*/

/*** ENTITY UPDATES ***/
// If there are any changes to the schema,
// In devel: run drush entity-updates if there are any changes to this
// In production: read this change-record: https://www.drupal.org/node/3034742

// In production:
// drush en -y devel_entity_updates; drush entup -y; drush pm-uninstall -y devel_entity_updates devel; drush cr;

// In development:
// drush en -y devel_entity_updates; drush entup -y; drush pm-uninstall -y devel_entity_updates;

// see list of possible field types using drupal console:
// drupal plugin:debug field.field_type

// drupal plugin:debug # shows the different plugins you can investigate
// drupal plugin:debug field.widget

class RiskEvent extends RiskEntityEditorialBase {

  use FieldDefinitions;

  public const status_masks = [
    'published' => 1<<0, // 0b001 == 1
    'approved' => 1<<1, // 0b010 == 2
    'draft' => 1<<2 // 0b100 == 4
  ];

  public function isPublished() {
    return (bool)($this->status->value & self::status_masks['published']);
  }
  public function isApproved() {
    return (bool)($this->status->value & self::status_masks['approved']);
  }
  public function isDraft() {
    return (bool)($this->status->value & self::status_masks['draft']);
  }

  private function setState(bool $state, string $facet) {
    $status = $this->status->value;
    $status = $state ? ($status | self::status_masks[$facet]) : ($status & ~self::status_masks[$facet]);
    $this->set('status',$status);
  }
  public function mySetPublished(bool $published) { // can't use setPublished with a bool parameter - method is already defined
    $this->setState($published,'published');
  }
  public function setPublished() { // can't use setPublished with a bool parameter
    $this->setState(true,'published');
  }
  public function setUnpublished() {
    $this->setState(false,'published');
  }
  public function setApproved(bool $approved) {
    $this->setState($approved,'approved');
  }
  public function setDraft(bool $draft) {
    $this->setState($draft,'draft');
  }

  public function updateWeight() {
    $this->set('weight', $this->calculateWeight());
  }

  public function getMyURL(array $options = []) {
    $url = '/map/event/' . $this->id();
    if ($options['absolute'])
      $url = 'https://cast.asiapacific.ca' . $url;
    return $url;
  }

  public function preSave(EntityStorageInterface $storage) {
    $uid = \Drupal::currentUser()->id();
    $uid && $this->set('editor_user_id', $uid); // Set most recent editor

    // Publishability validation:
    /* Criteria/minumum requirements for an event to be allowed to be published:
      Title
      One or more source links
      A description
      A date
      At least one assessment (Jurisdiction)
      At least one tag
    */
    if ($this->isPublished() || ! $this->isDraft()) { // only need to check if trying to save a published event
      $problems = [];

      if (empty(trim($this->title->value)))
        $problems[] = 'A Title is required.';

      // test each archive link for validity
      foreach ($this->archive_links as $link) {
        $regexPattern = '_^(?:(?:https?|ftp)://)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\x{00a1}-\x{ffff}0-9]-*)*[a-z\x{00a1}-\x{ffff}0-9]+)(?:\.(?:[a-z\x{00a1}-\x{ffff}0-9]-*)*[a-z\x{00a1}-\x{ffff}0-9]+)*(?:\.(?:[a-z\x{00a1}-\x{ffff}]{2,}))\.?)(?::\d{2,5})?(?:[/?#]\S*)?$_iuS';
        if (!preg_match($regexPattern, $link->value))
          $problems[] = 'One or more archive links are invalid.';
      }

      if(empty($this->archive_links->value))
        $problems[] = 'At least one Archive Link is required.';
      else { // still possible to have whitespace in the archive_links
        $empty = true;
        foreach ($this->archive_links as $link) {
          if (!empty(trim($link->value)))
            $empty = false;
        }
        if ($empty)
          $problems[] = 'At least one Archive Link is required.';
      }

      if (empty(trim($this->description->value)))
        $problems[] = 'A Description is required.';

      $tagsEmpty = true;
      foreach ($this->tags as $tag) {
        if ($tag->entity && $tag->entity->id())
          $tagsEmpty = false;
      }
      if ($tagsEmpty)
        $problems[] = 'At least one Tag is required.';

      if ($this->event_date && ! $this->event_date->value) {
        $problems[] = "The event must have a date.";
      }

      if ($this->event_date && $this->event_date->value) {
        $date = $this->event_date->value;
        $date = strtotime($date);
        if ($date > strtotime('+2 day'))
          $problems[] = "The date should be in the past, today, or tomorrow.";
      }

      if (!empty($problems)) {
        // @todo: could do this in one swoop by setting all bits at once.
        $this->mySetPublished(0);
        $this->setApproved(0);
        $this->setDraft(1);

        $problems = array_map(function($problem){ return '<li>' . $problem . '</li>'; }, $problems);
        $problems = implode('', $problems);
        \Drupal::messenger()->addWarning("Event " . $this->id() . " was saved as Draft, because it didn't meet the minimum requirements:<ul>".$problems.'</ul>');
      }

    }

    if ($this->isPublished() && ! $this->original->isPublished()) {
      // error_log("entity was published: see /admin/cast/management/event/".$this->id());
      $this->publicationNotifier();
    }

    $this->updateWeight();
  }

  private function publicationNotifier() {
    $mailManager = \Drupal::service('plugin.manager.mail');

    $module = 'apf_risk_entities';
    $key = 'cast_event_published';
    // $to = 'ted.fraser@asiapacific.ca, ryan@entra.ca';
    $to = 'ted.fraser@asiapacific.ca';

    $params['message'] = t(
      'A CAST event was just published: "@title". See it on the CAST admin panel at https://www.asiapacific.ca/admin/cast/management/event/@id or on the CAST website at https://cast.asiapacific.ca/timeline/event/@id',
      [
        '@title' => $this->title->value,
        '@id' => $this->id()
      ]
    );
    $params['entity'] = $this;

    $langcode = \Drupal::currentUser()->getPreferredLangcode();
    $send = true;

    $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);
    if ($result['result'] !== true) {
      $message = t('There was a problem sending CAST event publication alert email @email for the event https://www.asiapacific.ca/admin/cast/management/event/@id',
        [
          '@email' => $to,
          '@id' => $this->id()
        ]
      );
      \Drupal::logger($module)->error($message);
    }
    else {
      $message = t('An email alert has been sent to @email for the CAST event that was just published https://www.asiapacific.ca/admin/cast/management/event/@id',
        [
          '@email' => $to,
          '@id' => $this->id()
        ]
      );
      \Drupal::logger($module)->notice($message);
    }
  }

  public function postSave(EntityStorageInterface $storage, $update = TRUE) {
    $this->updateThemes();
    parent::postSave($storage);
  }

  public static function preDelete(EntityStorageInterface $storage, array $entities) {
    foreach ($entities as $entity) {
      $id = $entity->id();

      // clean up event links
      $links = EventLink::getByEventId($id, true);
      foreach ($links as $link) {
        $link->delete();
      }

      // clean up assessments
      $assessments = EventRiskAssessment::getByEventId($id);
      foreach ($assessments as $assessment)
        $assessment->delete();

      // clean up comments
      $comments = EditorialComment::getByEventId($id);
      foreach ($comments as $comment)
        $comment->delete();

      // clean up apf_event_themes
      $query = \Drupal::database()->delete('cast_event_themes')
        ->condition('event_id', $id);
      $query->execute();
    }
  }

  // Build base query for Events, optionally filtered by published and date range
  // This is used here and in the RiskEntityAutocompleteMatcher
  public static function getIdsBaseQuery($args) {

    $withUnpublished = $args['withUnpublished'] ?? false;
    $before = $args['before'] ?? null;
    $after = $args['after'] ?? null;
    $tags = $args['tags'] ?? null;
    $ids = $args['ids'] ?? null;
    $sort = $args['sort'] ?? 'event_date';
    $actor = $args['actor'] ?? null;
    $in = $args['in'] ?? null;
    $search = $args['search'] ?? null;
    $limit = $args['top'] ?? $args['limit'] ?? null;
    $offset = $args['offset'] ?? 0;
    $direction = 'DESC';

    if (!is_int($limit))
      $limit = null;
    elseif ($limit < 0) {
      $direction = 'ASC';
      $limit = abs($limit);
    }

    if (!is_int($offset))
      $offset = 0;
    elseif ($offset < 0) // @todo could try to support backwards from the end pagination using negative numbers for offset?
      $offset = abs($offset);

    $conn = Database::getConnection();
    $query = $conn->select('risk_event','re')
      ->fields('re',['id']);
    if ($sort == 'event_date')
      $query->orderBy('re.event_date',$direction);
    else if ($sort == 'weight')
      $query->orderBy('re.weight',$direction);

    $query->orderBy('re.id',$direction); // implicitly sort by id in all cases. If sorting on another field, ID will be secondary sort
    if (!$withUnpublished)
      $query->condition('re.status', self::status_masks['published'], '&'); // published, or published and approved, or published and anything else..
    if ($before && $formatted = self::getQueryableDate($before))
      $query->condition('re.event_date', $formatted, '<');
    if ($after && $formatted = self::getQueryableDate($after))
      $query->condition('re.event_date', $formatted, '>');
    if ($tags) {
      $query->join('risk_event_revision__tags','rt', 'rt.entity_id = re.id');
      $query->condition('rt.tags_target_id', $tags, 'IN');
    }
    if ($ids)
      $query->condition('re.id', $ids, 'IN');
    if ($actor) {
      $query->join('risk_event_revision__actors','rea', 'rea.entity_id = re.id');
      $query->condition('rea.actors_value', $actor);
    }
    if ($in) {
      $query->join('event_risk_assessment','ra', 'ra.event = re.id');
      $query->condition('ra.geo_id', $in, 'IN');
    }

    if ($search) {
      $words = explode(' ', $search);
      $words = array_slice($words, 0, 10); // max 10 words to avoid DDOS

      foreach ($words as $word) {
        // $word = mysql_real_escape_string($word);
        $word = str_replace(['‘','’',"'",'"',], '',$word); // remove some problematic characters: ‘ ’ ' "
        // $word = addcslashes($word, '%_');
        $word = str_replace('%', '\%',$word);
        $where = $query->orConditionGroup();


        $likeString = "%$word%";
        $where->condition('re.title', $likeString, 'LIKE');
        $where->condition('re.description__value', $likeString, 'LIKE');
        $where->condition('re.justification__value', $likeString, 'LIKE');
        $where->condition('re.context__value', $likeString, 'LIKE');

        $twquery = $conn->select('risk_event','re')
          ->fields('re',['id']);
        if (!$withUnpublished)
          $twquery->condition('re.status', self::status_masks['published'], '&');
        $twquery->join('risk_event_revision__tags','rt', 'rt.entity_id = re.id');
        $twquery->join('taxonomy_term_field_data','tfd', 'tfd.tid = rt.tags_target_id');
        $twquery->condition('tfd.name', $likeString, 'LIKE');
        // $twquery->condition('tfd.vid', 'vocabulary_4'); // could skip this because events only ever use this vocab
        $results = $twquery->execute()->fetchAllAssoc('id');
        $eventsWithTagWord  = array_keys($results);
        if (!empty($eventsWithTagWord))
          $where->condition('re.id', $eventsWithTagWord, 'IN');

        $query->condition($where);
      }

      /*
      // This way is more elegant, but was significantly slower in testing. It should be faster in theory, why isn't it?
      $query->join('risk_event_revision__tags','rt', 'rt.entity_id = re.id');
      foreach ($words as $i => $word) {

        $query->join('taxonomy_term_field_data',"tfd$i", "tfd$i.tid = rt.tags_target_id");
        $query->condition("tfd$i.vid", 'vocabulary_4'); // could skip this because events only ever use this vocab

        $where = $query->orConditionGroup();
        $likeString = "%$word%";

        $where->condition('re.title', $likeString, 'LIKE');
        $where->condition('re.description__value', $likeString, 'LIKE');
        $where->condition('re.justification__value', $likeString, 'LIKE');
        $where->condition('re.context__value', $likeString, 'LIKE');
        $where->condition("tfd$i.name", $likeString, 'LIKE');
        $query->condition($where);
      }
      */

    }

    /*

    // There is some problem with the range() function, it doesn't work with the above joins or perhaps long "IN" conditions on jurisdictions
    // so we're going to do the pagination in PHP instead
    if ($limit !== null)
      $query->range($offset,$limit);
    else if ($offset)
      $query->range($offset,PHP_INT_MAX);
    */

    return $query;
  }


  public static function getRiskEvents($args = []) {
    $ids = self::getIds($args);
    $events = self::loadMultiple($ids);
    return $events;
  }

  public function getForwardAndCausalEvents($withUnpublished = false) {
    $id = $this->id->value;

    $query = \Drupal::entityQuery('risk_event_link');
    $group = $query->orConditionGroup()
      ->condition('target_event',$id)
      ->condition('source_event',$id);
    $query->condition($group);
    $ids = $query->execute();
    $links =  EventLink::loadMultiple($ids);

    $date = $this->event_date->value;

    $forward = [];
    $forwardCausal = [];

    foreach ($links as $link) {
      $other = $link->target_event->target_id == $id ? $link->source_event : $link->target_event;
      if (!$other->entity)
        continue;
      if (!$withUnpublished && !$other->entity->isPublished())
        continue;
      if ($other->entity->event_date->value > $date) {
        $forward[] = $other;
        if ($link->link_type->target_id == 1)
          $forwardCausal[] = $other;
      }
    }

    return [
      'forward' => $forward,
      'forwardCausal' => $forwardCausal,
    ];
  }

  private static function getJurFractions() {
    $cache_id = 'apf_jurisdiction_fractions';
    $ttl = 90; // cache apc for 60 seconds
    $cache_enabled = true && function_exists('apcu_fetch');
    if ($cache_enabled && apcu_exists($cache_id))
      $fractions = apcu_fetch($cache_id);
    else {
      $pgConnection = \pgapi\pgConnection::pgConnectionObject();
      $fractions = getJurFractions();
      if ($cache_enabled)
        apcu_add($cache_id, $fractions, $ttl);
    }
    return $fractions;
  }

  private function impactScale() {
    $fractions = self::getJurFractions();
    $impacts = EventRiskAssessment::getByEventId($this->id->value);
    $impactScale = 0;
    foreach ($impacts as $impact) {
      if (isset($fractions[$impact->geo_id->value]))
        $impactScale += $fractions[$impact->geo_id->value];
    }
    return min($impactScale,1);
  }

  // simply returns the precalculated weight. Depends on this field being properly updated
  public function getWeight() {
    return $this->weight->value ?? 0.0;
  }

  public function calculateWeight() {

    $cache_id = "apf_risk_event_weight_event-id-{$this->id->value}";
    $cache_tags = ['risk_event_link_list',"risk_event:{$this->id->value}"]; // vary cache by THIS event, and ANY event link. Could be more specific with links probably

    if ($cache = \Drupal::cache()->get($cache_id))
      return $cache->data;

    $fce = $this->getForwardAndCausalEvents();
    $weight = ($this->canadianInvolvement->value ? 3 : 1) *
      sqrt($this->archive_links->count()) *
      $this->impactScale() *
      (1 + count($fce['forwardCausal'])) *
      pow(1 + count($fce['forward']),0.25);

    \Drupal::cache()->set($cache_id, $weight, Cache::PERMANENT, $cache_tags);

    return $weight;

  }


  private static function getTagIdsFromSearchWord($word, $args) { //, $excludes = []) {

    $query = self::getIdsBaseQuery($args);
    if (!empty($excludes))
        $query->condition('re.id', $excludes, 'NOT IN');
    $query->join('risk_event_revision__tags','rt', 'rt.entity_id = re.id');
    $query->join('taxonomy_term_field_data','tfd', 'tfd.tid = rt.tags_target_id');
    $query->condition('tfd.name', "%$word%", 'LIKE');
    $query->condition('tfd.vid', 'vocabulary_4'); // could skip this because events only ever use this vocab

    $results = $query->execute()->fetchAllAssoc('id');
    return array_keys($results);

    /*
    // prior to most recent refactor. This should be a tiny bit slower:
    $res = KeywordAutocompleteMatcher::getVocabularyTermIds('vocabulary_4',$word);
    $tids = array_values($res);
    if (!empty($tids)) {
      $keywordsQuery = self::getIdsBaseQuery($args);
      if (!empty($excludes))
        $keywordsQuery->condition('re.id', $excludes, 'NOT IN');
      $keywordsQuery->join('risk_event_revision__tags','rt', 'rt.entity_id = re.id');
      $keywordsQuery->condition('rt.tags_target_id', $tids, 'IN');
      //if (!empty($excludes))
      // $keywordsQuery->condition('re.id', $excludes, 'NOT IN');
      $results = $keywordsQuery->execute()->fetchAllAssoc('id');
      return array_keys($results);
    }
    return [];
    */

  }

  // This  could be refactored to eliminate the "IN" subquery by using a join to the taxonomy_term_field_data table
  /*
  private static function buildStringSearchQueryGroup($string, $group, $args) {
    $words = explode(' ', $string);
    $words = array_slice($words, 0, 10); // max 10 words to avoid DDOS

    foreach ($words as $word) {
      $orGroup = $group->orConditionGroup();
      $likeString = "%$word%";
      $orGroup->condition('re.title', $likeString, 'LIKE');
      $orGroup->condition('re.description__value', $likeString, 'LIKE');
      $orGroup->condition('re.justification__value', $likeString, 'LIKE');
      $orGroup->condition('re.context__value', $likeString, 'LIKE');
      $eventsWithTagWord = self::getTagIdsFromSearchWord($word, $args);
      if (!empty($eventsWithTagWord))
        $orGroup->condition('re.id', $eventsWithTagWord, 'IN');
      $group->condition($orGroup);
    }
  }
  */

  public static function getEventsFromSearch(
    $string = '', $date = '', $withUnpublished = false,
    $excludes = [], $limit = 10, $sort = "event_date"
  ) {
    $ids = self::getEventIdsFromSearch($string, $date, $withUnpublished, $excludes, $limit, $sort);
    $events = self::loadMultiple($ids);
    return $events;
  }

  // This should only be  used by the autocomplete matcher REST API. Was formerly used by the GQL resolver as well (via this class)
  public static function getEventIdsFromSearch(
    $string = '', $date = '', $withUnpublished = false,
    $excludes = [], $limit = 10, $sort = "event_date"
  ) {

    // allow search by event id
    if (is_numeric($string) && !in_array($string, $excludes))
      return [(int) $string];
    else {
      $args = [
        'withUnpublished' => $withUnpublished,
        'before' => $date,
        'sort' => $sort,
        'search' => $string,
      ];

      $query = self::getIdsBaseQuery($args);
      if (!empty($excludes))
        $query->condition('re.id', $excludes, 'NOT IN');

      if ($limit) $query->range(0,$limit); // caution: range is not working properly on some queries, at least with many joins. Seems to be working here for now tho
      $results = $query->execute()->fetchAllAssoc('id');
      $ids = array_keys($results);
      return $ids;
    }
  }

  private static function getEventIdsFromRegexSearch($args = []) {

    $regex = $args['re_search'];
    unset($args['search']); // don't want to use this in the base query, we're ignoring regular search if using regex search
    $query = self::getIdsBaseQuery($args);

    $vocabulary = 'vocabulary_4'; // tags
    $tquery = \Drupal::entityQuery('taxonomy_term')
      ->condition('vid', $vocabulary)
      ->condition('name', $regex, 'REGEXP');
    $tids = $tquery->execute();
    $tids = array_values($tids);

    $orGroup = $query->orConditionGroup();
    $orGroup->condition('re.title', $regex, 'REGEXP');
    $orGroup->condition('re.description__value', $regex, 'REGEXP');
    $orGroup->condition('re.justification__value', $regex, 'REGEXP');
    $orGroup->condition('re.context__value', $regex, 'REGEXP');
    if (!empty($tids)) {
      $query->join('risk_event_revision__tags','rt', 'rt.entity_id = re.id');
      $orGroup->condition('rt.tags_target_id', $tids, 'IN');
    }
    $query->condition($orGroup);
    $results = $query->execute()->fetchAllAssoc('id');
    return array_keys($results);

  }

  public static function getIds($args = []) {

    if (!empty($args['re_search'])) {
      return self::getEventIdsFromRegexSearch($args);
    }

    $query = self::getIdsBaseQuery($args);
    $results = $query->execute()->fetchAllAssoc('id');
    $ids = array_keys($results);

    $limit = $args['top'] ?? $args['limit'] ?? null;
    $offset = $args['offset'] ?? 0;

    if (!is_int($limit))
      $limit = null;
    elseif ($limit < 0)
      $limit = abs($limit);

    if (!is_int($offset))
      $offset = 0;
    elseif ($offset < 0) // @todo could try to support backwards from the end pagination using negative numbers for offset?
      $offset = abs($offset);

    if ($limit !== null)
      $ids = array_slice($ids, $offset, $limit);
    else if ($offset)
      $ids = array_slice($ids, $offset);

    return $ids;
  }

  public function getThemes($isMeta = null) {

    // get themes by querying cast_event_themes table for all the columns
    $conn = Database::getConnection();
    $query = $conn->select('cast_event_themes')
      ->fields('cast_event_themes', ['theme_id', 'tag_intersect_weight'])
      ->condition('event_id', $this->id->value);
    $results = $query->execute()->fetchAllAssoc('theme_id');
    $theme_ids = array_keys($results);
    $themes = EventTheme::loadMultiple($theme_ids);
    foreach ($themes as $theme) {
      $theme->tag_intersect_weight = $results[$theme->id()]->tag_intersect_weight;
    }

    // $themes = $this->calculateThemes(); // this was the old way of computing themes on the fly

    // if isMeta is null, or true
    if ($isMeta !== false) {
      // Discover the meta-themes/parent_themes by looking through all themes and finding the ones that are parents of the event's themes
      $ancestor_themes = [];
      foreach ($themes as $theme) {
        foreach ($theme->parent_themes as $parent_theme)
          $ancestor_themes = array_replace($ancestor_themes, $parent_theme->entity->getAncestors());
      }
      foreach ($ancestor_themes as $id => $theme) {
        if (!isset($themes[$id])) {
          $themes[$id] = $theme;
          $theme->tag_intersect_weight = 0.0; // meta themes don't have a tag_intersect_weight, so set it to 0.0
          // if they _did_ have an intersection weight, it would have showed up in the query above
          // they can have a residual weight attached to them from a previous query, so clean that off! (there is a bug if you don't)
          // be very careful setting properties on these objects that end up getting shared!!!!! (like tag_intersect_weight)
        }
      }
    }

    if ($isMeta !== null)
      $themes = array_filter ($themes, function($theme) use ($isMeta) {
        return $theme->isMeta() == $isMeta;
      });

    foreach ($themes as $theme) {
      if (!$theme->tag_intersect_weight)
        $theme->tag_intersect_weight = 0.0;
    }

    // sort themes by tag_intersect_weight, descending
    // all themes should have been assigned a weight above
    usort($themes, function($a, $b) {
      return $b->tag_intersect_weight > $a->tag_intersect_weight ? 1 : -1;
    });

    return $themes;
  }

  // update the stored-in-db Themes data for this event
  public function updateThemes() {
    $themes = $this->calculateThemes();

    // Now Update the database with the themes and their weights.
    // Step 1. Delete all the existing themes for this event
    $conn = Database::getConnection();
    $query = $conn->delete('cast_event_themes')
      ->condition('event_id', $this->id->value);
    $query->execute();

    // Step 2. Insert the new themes for this event
    foreach ($themes as $theme) {
      $query = $conn->insert('cast_event_themes')
        ->fields([
          'event_id' => $this->id->value,
          'theme_id' => $theme->id->value,
          'tag_intersect_weight' => $theme->tag_intersect_weight,
        ]);
      $query->execute();
    }
  }

  public function calculateThemes() {

    // get the tag ids
    $entity_tags = array_map(function($tag) {
      return $tag['target_id'];
    }, $this->tags->getValue());

    // get the risk assessments AKA impacts, use them to get the jurisdictions
    $ras = EventRiskAssessment::getByEventId($this->id->value);
    $entity_jurisdictions = [];
    foreach ($ras as $ra)
      $entity_jurisdictions[] = $ra->geo_id->value;

    $pgConnection = pgConnection::pgConnectionObject(); // need an active postgres connection. Use the singleton
    $cache_enabled = true && function_exists('apcu_fetch');

    // get all themes, and then filter them down to the ones that apply to this event
    $allThemes = EventTheme::getThemes();
    $themes = array_filter($allThemes, function($theme) use ($entity_jurisdictions, $entity_tags, $cache_enabled ) {

      // get all the tag ids from this theme
      $theme_tags = array_map(function($tag) {
        return $tag['target_id'];
      }, $theme->tags->getValue());

      // if there are none, this theme won't apply to this event, and the weight is 0 - we don't want div by 0 below
      if (empty($theme_tags)) {
        $theme->tag_intersect_weight = 0;
        return false;
      }
      $tag_intersect = array_intersect($theme_tags, $entity_tags);
      $tag_intersect_count = count($tag_intersect);
      $theme->tag_intersect_weight = $tag_intersect_count/count($theme_tags);

      // the jurisdictions lookup is expensive and can happen repeatedly on bulk calculations. Cache it.
      $cache_id = 'apf_risk_admin_event_resolver_theme_' . $theme->id->value;
      $ttl = 20; // cache apc for 20 seconds
      if ($cache_enabled && apcu_exists($cache_id)) {
        $jurisdictions = apcu_fetch($cache_id);
      }
      else {
        $parent_geo_ids = [];
        foreach ($theme->geo_ids as $geo_id)
          $parent_geo_ids[] = $geo_id->value;
        $jurisdictions = empty($parent_geo_ids) ? [] : getDescendantsGeoId($parent_geo_ids);
        if ($cache_enabled)
          apcu_add($cache_id, $jurisdictions , $ttl);
      }

      // if this theme has no jurisdictions, it is considered a global theme, so only consider tag intersection
      if (empty($jurisdictions))
        return $tag_intersect_count > 0;

      $jurisdiction_intersect = array_intersect($jurisdictions, $entity_jurisdictions);
      return count($jurisdiction_intersect) > 0 && $tag_intersect_count > 0;
    });

    $keyed_themes = [];
    foreach ($themes as $theme) {
      $keyed_themes[$theme->id->value] = $theme;
    }
    $themes = $keyed_themes;

    return $themes;
  }

  public static function bulkUpdateEventWeights() {
    // load all events
    $events = self::loadMultiple();
    foreach ($events as $event) {
      // error_log("Updating weight for event {$event->id()}");
      $event->updateWeight();
      $event->save();
    }
  }

  // drush php-eval "\Drupal\apf_risk_entities\Entity\RiskEvent::bulkUpdateEventThemes();"
  public static function bulkUpdateEventThemes() {
    $events = self::loadMultiple();
    foreach ($events as $event)
      $event->updateThemes();
  }
}