<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\Entity\EditorialComment.
 */

namespace Drupal\apf_risk_entities\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\apf_risk_entities\RiskEntityEditorialBase;

/**
 * Defines the CAST Editorial Comment entity.
 *
 * @ingroup apf_risk
 *
 * @ContentEntityType(
 *   id = "editorial_comment",
 *   label = @Translation("Editoral Comment"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\apf_risk_entities\ListBuilders\EditorialCommentListBuilder",
 *     "form" = {
 *       "default" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "add" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "edit" = "Drupal\apf_risk_entities\Form\GenericRiskEntityForm",
 *       "delete" = "Drupal\apf_risk_entities\Form\GenericRiskEntityDeleteForm",
 *     },
 *     "access" = "Drupal\apf_risk_entities\EditorialCommentAccessControlHandler",
 *   },
 *   base_table = "cast_editorial_comment",
 *   revision_table = "cast_editorial_comment_revision",
 *   show_revision_ui = TRUE,
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "comment",
 *     "revision" = "revision_id",
 *     "published" = "status",
 *   },
 *   links = {
 *     "canonical" = "/admin/risk/editorial-comment/{editorial_comment}",
 *     "edit-form" = "/admin/risk/editorial-comment/{editorial_comment}/edit",
 *     "revision" = "/admin/risk/editorial-comment/{editorial_comment}/revisions/{cast_editorial_comment_revision}/view",
 *     "collection" = "/admin/risk/event-link-type/list",
 *   },
 *   revision_metadata_keys = {
 *     "revision_user" = "revision_user",
 *     "revision_created" = "revision_created",
 *     "revision_log_message" = "revision_log_message",
 *   },
 * )
 *
 */

class EditorialComment extends RiskEntityEditorialBase {

	public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields['event'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel('Event')
      ->setSetting('target_type', 'risk_event')
      ->setSetting('handler', 'default')
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'settings' => [
          'match_operator'    => 'CONTAINS',
          'size'              => '60',
          'autocomplete_type' => 'tags',
          'placeholder'       => 'Enter title...',
        ],
      ])
      ->setDisplayOptions('view', [
        'type' => 'number',
      ])
      ->setDisplayConfigurable('view', TRUE);

		$fields['comment'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Comment'))
      ->setSettings(array(
        // 'max_length' => 255,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', [
        'type' => 'text_long',
      ])
      ->setDisplayOptions('form', [
        'type' => 'text_long',
      ]);

    $fields += parent::baseFieldDefinitions($entity_type);
    return $fields;
  }

  // Gets all editorial comments for an event
  public static function getByEventId($id = null, $latestCommentId = 0) {
    $query = \Drupal::entityQuery('editorial_comment')
      ->sort('id', 'ASC')
      ->condition('id', $latestCommentId, '>');
    if ($id)
      $query->condition('event',$id);

    $ids = $query->execute();
    return self::loadMultiple($ids);
  }

}