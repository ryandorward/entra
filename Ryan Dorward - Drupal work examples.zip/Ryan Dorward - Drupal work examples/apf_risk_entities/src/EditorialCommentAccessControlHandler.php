<?php

namespace Drupal\apf_risk_entities;

use Drupal\Core\Session\AccountInterface;

/**
 * Editorial Comment Access controller for APF Risk Event editorial comments.
 *
 */
class EditorialCommentAccessControlHandler extends GeneralAccessControlHandler {

  protected static function checkView(AccountInterface $account) {
    $roles = $account->getRoles();
    if (in_array('risk_analyst', $roles ) || in_array('risk_jr_analyst', $roles ))
      return true;
  }

  protected static function checkUpsertDel(AccountInterface $account) {
    $roles = $account->getRoles();
    if (in_array('risk_analyst', $roles ) || in_array('risk_jr_analyst', $roles ))
      return true;
  }

}