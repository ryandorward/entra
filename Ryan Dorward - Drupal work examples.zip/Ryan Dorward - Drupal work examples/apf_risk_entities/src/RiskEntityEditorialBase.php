<?php

/**
 * @file
 * Contains \Drupal\apf_risk_entities\RiskEntityEditorialBase.
 */

namespace Drupal\apf_risk_entities;

use Drupal\Core\Entity\EditorialContentEntityBase;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\user\UserInterface;
use Drupal\Core\Entity\EntityStorageInterface;

class RiskEntityEditorialBase extends EditorialContentEntityBase implements RiskEntityInterface {

	use EntityChangedTrait; // Implements methods defined by EntityChangedInterface.
  use RiskEntityTrait;

	/**
   * {@inheritdoc}
   */
  public function getOwner() {
    return $this->get('user_id')->entity;
  }

  /**
   * {@inheritdoc}
   */
  public function getOwnerId() {
    return $this->get('user_id')->target_id;
  }

  /**
   * {@inheritdoc}
   */
  public function setOwnerId($uid) {
    $this->set('user_id', $uid);
    return $this;
	}

	/**
   * {@inheritdoc}
   */
  public function setOwner(UserInterface $account) {
    $this->set('user_id', $account->id());
    return $this;
  }

  public function postCreate(EntityStorageInterface $storage) {
    $uid = \Drupal::currentUser()->id();
    $uid && $this->setOwnerId($uid); // Always set owner of entity to first creator
    //  $now = date('Y-m-d\TH:i:s');
    // $this->set('created', $now);

    parent::postCreate($storage);
  }

  public function preSave(EntityStorageInterface $storage) {
    $uid = \Drupal::currentUser()->id();
    $uid &&  $this->set('editor_user_id', $uid); // Set most recent editor
    // $this->set('status',0);
    // $now = date('Y-m-d\TH:i:s');
    // $now = date('F j, Y h:m');
    // error_log("trying to set changed value to : " . $now);
    //  $this->set('changed', $now);

    parent::preSave($storage);
  }

	public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields = parent::baseFieldDefinitions($entity_type);

    // Standard field, used as unique if primary index.
    $fields['id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('ID'))
      ->setDescription(t('The ID of the Risk entity.'))
      ->setReadOnly(true);

    // Standard field, unique outside of the scope of the current Risk Event.
    $fields['uuid'] = BaseFieldDefinition::create('uuid')
      ->setLabel(t('UUID'))
      ->setDescription(t('The UUID of the Risk entity.'))
      ->setReadOnly(TRUE);

     // Owner field of the entity.
    // Entity reference field, holds the reference to the user object.
    // The view shows the user name field of the user.
    $fields['user_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Owner'))
      ->setSetting('target_type', 'user')
      ->setSetting('handler', 'default')
      ->setDisplayOptions('form', [
        'type' => 'hidden',
      ])
      ->setDisplayConfigurable('form', false)
      ->setDisplayConfigurable('view', false);

    // Most recent editor of the entity.
    // Entity reference field, holds the reference to the user object.
    // The view shows the user name field of the user.
    $fields['editor_user_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Last Editor'))
      ->setSetting('target_type', 'user')
      ->setSetting('handler', 'default')
      ->setDisplayOptions('form', [
        'type' => 'hidden',
      ])
      ->setDisplayConfigurable('form', false)
      ->setDisplayConfigurable('view', false);

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel('Created On')
      ->setDescription(t('The time that the entity was created.'))
      ->setDisplayOptions('view', [
        'type' => 'timestamp',
        'settings' => [
          'date_format' => 'custom',
          'custom_date_format' => 'F j, Y',
        ]
      ]);

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel('Changed')
      ->setDescription(t('The time that the entity was last edited.'))
      ->setDisplayOptions('view', [
        'type' => 'timestamp',
        'settings' => [
          'date_format' => 'custom',
          'custom_date_format' => 'F j, Y h:m',
        ]
      ])
      ->setRevisionable(TRUE);

    $fields['status']->setDisplayOptions('form', [
      'type' => 'boolean_checkbox',
      'weight' => 100,
    ]);


   /*
    $fields['langcode'] = BaseFieldDefinition::create('language')
      ->setName('langcode')
      ->setDefaultValue('x-default')// x-default is the sites default language.
      ->setStorageRequired(TRUE)
      ->setLabel(t('Language code'))
      ->setDescription(t('The language code.'))
      ->setRevisionable(TRUE)
      ->setTranslatable(TRUE);
    */

    return $fields;

  }

  // return an array of all entities of this type
  public static function getIds() {
    $ids = \Drupal::entityQuery(self::getEntityTypeId())
      ->sort('id', 'DESC')
      ->execute();
    return $ids;
  }

  public function validateFields() {
    $fieldViolations = [];
    $fields = $this->getFields();
    foreach ($fields as $field_name => $field) {
      // error_log("Validating: ". $field_name);
      $violations = $this->{$field_name}->validate();
      if (count($violations) > 0) {
        $fieldViolations[$field_name] = [
          'label' => $field_name, // $field->label(),
          'violations' => []
        ];
        foreach ($violations as $violation)
          $fieldViolations[$field_name]['violations'][] =  $violation->getMessage();
      }
    }
    if (count($fieldViolations) > 0)
      return $fieldViolations;
  }

}