<?php

namespace Drupal\apf_risk_entities;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\datetime\Plugin\Field\FieldType\DateTimeItemInterface;

trait RiskEntityTrait {
  // Convert the API-standard ISO YYYY-MM-DD strings (+ 'now') into format acceptable for Drupal EntityQueury
  protected static function getQueryableDate(String $date) {
    if (self::checkYmd($date) || $date==="now") { // Check if date matches "Y-m-d" format and is a valid date
      if ($date==="now") {
        // Convert now into today noon. WARNING: This assumes client is at server timezone. This can introduce edge case issue
        $date = new DrupalDateTime("now");
        $date = $date->format("Y-m-d");
      }
      $date = DrupalDateTime::createFromFormat("Y-m-d H:i:s", $date.' 12:00:00');
      $formatted = $date->format(DateTimeItemInterface::DATETIME_STORAGE_FORMAT);
      return $date->format(DateTimeItemInterface::DATETIME_STORAGE_FORMAT);
    }
  }

  // Assert that date follows the expected format
  protected static function checkYmd($date) {
    $oDate = \DateTime::createFromFormat('Y-m-d', $date);
    if ($oDate && $oDate->format('Y-m-d') === $date)
      return true;
  }
}