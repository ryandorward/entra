<?php

namespace Drupal\apf_risk_entities;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Generic Access controller for APF Risk entities.
 *
 */
class GeneralAccessControlHandler extends EntityAccessControlHandler {

  protected static function checkView(AccountInterface $account) {
    return true;
  }

  protected static function checkUpsertDel(AccountInterface $account) {
    $roles = $account->getRoles();
    if (in_array('risk_analyst', $roles ) || in_array('risk_jr_analyst', $roles ))
      return true;
  }

  /**
   * {@inheritdoc}
   *
   * Link the activities to the permissions. checkAccess is called with the
   * $operation as defined in the routing.yml file.
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    switch ($operation) {
      case 'view':
        return AccessResult::allowedIf(static::checkView($account));

      case 'edit':
      case 'update': // aka edit sometimes? wtf?
      case 'delete':
        return AccessResult::allowedIf(static::checkUpsertDel($account));
    }
    return AccessResult::forbidden();
  }

  /**
   * {@inheritdoc}
   *
   * Separate from the checkAccess because the entity does not yet exist, it
   * will be created during the 'add' process.
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
    return AccessResult::allowedIf(static::checkUpsertDel($account));
  }

}
?>