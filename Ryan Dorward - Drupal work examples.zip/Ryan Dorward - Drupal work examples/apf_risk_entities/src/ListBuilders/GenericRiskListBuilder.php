<?php

namespace Drupal\apf_risk_entities\ListBuilders;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;

/**
 * Provides a list controller for a risk entity.
 *
 * @ingroup apf_risk_entities
 */
class GenericRiskListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   *
   * We override ::render() so that we can add our own content above the table.
   * parent::render() is where EntityListBuilder creates the table using our
   * buildHeader() and buildRow() implementations.
   */
  public function render() {
    $build['description'] = [
      '#markup' => $this->t('<p><a class="button button--primary" href="@add">+ Add a @humanName</a> <a class="button" href="@riskEntitiesHome">< Back to Risk Admin Home</a></p><p>This the list of all @humanName entities:</p>',
        [
          '@riskEntitiesHome' => \Drupal::urlGenerator()
            ->generateFromRoute('apf_risk_entities.home'),
          '@humanName' => $this->entityType->getLabel(),
          '@add' => \Drupal::urlGenerator()
            ->generateFromRoute("entity.{$this->entityTypeId}.add"),
        ]
      ),
    ];

    $build += parent::render();
    return $build;
  }

  /**
   * {@inheritdoc}
   *
   * Building the header and content lines for the contact list.
   *
   * Calling the parent::buildHeader() adds a column for the possible actions
   * and inserts the 'edit' and 'delete' links as defined for the entity type.
   */
  public function buildHeader() {
    $header['id'] = $this->t('ID');
    $header['edit'] = "Edit";
    $header['delete'] = "Delete";
    return $header;
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row['id'] = $entity->id();
    $row['edit'] = $this->t('<a class="button button--primary" href="@url">Edit</a>',
      [ '@url' =>
        \Drupal::urlGenerator()->generateFromRoute("entity.{$this->entityTypeId}.edit_form", [$this->entityTypeId => $entity->id()])
      ]
    );
    $row['delete'] = $this->t('<a class="button" href="@url">Delete</a>',
      [ '@url' =>
        \Drupal::urlGenerator()->generateFromRoute("entity.{$this->entityTypeId}.delete_form", [$this->entityTypeId => $entity->id()])
      ]
    );

    return $row;
  }

}