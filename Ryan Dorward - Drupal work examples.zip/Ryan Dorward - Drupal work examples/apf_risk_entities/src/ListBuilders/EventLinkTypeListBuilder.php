<?php

namespace Drupal\apf_risk_entities\ListBuilders;

use Drupal\Core\Entity\EntityInterface;

/**
 * Provides a list controller for event_link_type entity.
 *
 * @ingroup apf_risk_entities
 */
class EventLinkTypeListBuilder extends GenericRiskListBuilder {

  public function buildHeader() {
    $header['title'] = $this->t('Title');
    $header['description'] = $this->t('Description');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row['title'] = $entity->title->value;
    $description = ["#markup" => $entity->description->value];
    $row['description'] = render ($description);
    return $row + parent::buildRow($entity);
  }

}