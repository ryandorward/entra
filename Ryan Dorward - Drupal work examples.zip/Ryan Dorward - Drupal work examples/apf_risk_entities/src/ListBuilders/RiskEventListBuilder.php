<?php

namespace Drupal\apf_risk_entities\ListBuilders;

use Drupal\Core\Entity\EntityInterface;

/**
 * Provides a list controller for Risk Event entities.
 *
 * @ingroup apf_risk_entities
 */
class RiskEventListBuilder extends GenericRiskListBuilder {

  public $fields = [
    'title',
    'event_date',
    'description',
    'justification',

  ];

  public function buildHeader() {

    $fields = \Drupal::service('entity_field.manager')->getFieldDefinitions($this->entityTypeId,null);

    $header = [];
    foreach ($this->fields as $field)
      $header[$field] = $fields[$field]->getLabel();

    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {

    $row = [];
    foreach ($this->fields as $field)
      $row[$field] = ( empty($entity->{$field}->value) ? "" :
           $this->t($entity->{$field}->value));

    if (!empty($row['archive_link']))
      $row['archive_link'] = $this->t('<a target= "_blank" href="'.$entity->archive_link->value.'">(link)</a>');

    return $row + parent::buildRow($entity);
  }

}