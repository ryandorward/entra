<?php

namespace Drupal\apf_risk_entities\ListBuilders;

use Drupal\Core\Entity\EntityInterface;

/**
 * Provides a list controller for Risk Assessment entities.
 *
 * @ingroup apf_risk_entities
 */
class EventRiskAssessmentListBuilder extends GenericRiskListBuilder {

  public function buildHeader() {
    $header['event'] = 'Event';
    $header['geo_id'] = 'geo_id';
    $header['component'] = 'Component';
    $header['assessment'] = 'Assessment';
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row['event'] = (empty($entity->event->entity) ? "(none)" : $entity->event->entity->toLink());
    $row['geo_id'] = $entity->geo_id->value;
    $row['component'] = (empty($entity->component->entity) ? "(none)" : $entity->component->entity->toLink());
    $row['assessment'] = $entity->assessment->value;
    return $row + parent::buildRow($entity);
  }

}