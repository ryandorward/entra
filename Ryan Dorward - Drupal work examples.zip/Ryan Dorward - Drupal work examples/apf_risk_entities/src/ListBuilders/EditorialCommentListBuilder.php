<?php

namespace Drupal\apf_risk_entities\ListBuilders;

use Drupal\Core\Entity\EntityInterface;

/**
 * Provides a list controller for Editorial Comments
 *
 * @ingroup apf_risk_entities
 */
class EditorialCommentListBuilder extends GenericRiskListBuilder {

  public function buildHeader() {
    $header['event'] = 'Event';
    $header['comment'] = 'Comment';
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row['event'] = (empty($entity->event->entity) ? "(none)" : $entity->event->entity->toLink());
    $row['comment'] = (empty($entity->comment->value) ? "(none)" : $entity->comment->value);
    return $row + parent::buildRow($entity);
  }

}
