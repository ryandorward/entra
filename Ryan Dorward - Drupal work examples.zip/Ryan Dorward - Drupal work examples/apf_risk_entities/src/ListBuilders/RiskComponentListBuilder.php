<?php

namespace Drupal\apf_risk_entities\ListBuilders;

use Drupal\Core\Entity\EntityInterface;

/**
 * Provides a list controller for Risk Component entities.
 *
 * @ingroup apf_risk_entities
 */
class RiskComponentListBuilder extends GenericRiskListBuilder {

  public function buildHeader() {
    $header['title'] = $this->t('Title');
    $header['category'] = 'Category';
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row['title'] = $entity->title->value;
    $row['category'] = (empty($entity->category->entity) ? "(none)" : $entity->category->entity->toLink());
    return $row + parent::buildRow($entity);
  }


}