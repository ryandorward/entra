<?php

namespace Drupal\apf_risk_entities\ListBuilders;

use Drupal\Core\Entity\EntityInterface;

/**
 * Provides a list controller for Event Link entities.
 *
 * @ingroup apf_risk_entities
 */
class EventLinkListBuilder extends GenericRiskListBuilder {

  public function buildHeader() {
    $header['source'] = 'Source';
    $header['target'] = 'Target';
    $header['type'] = 'Link Type';
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row['source'] = (empty($entity->source_event->entity) ? "(none)" : $entity->source_event->entity->toLink());
    $row['target'] = (empty($entity->target_event->entity) ? "(none)" : $entity->target_event->entity->toLink());
    $row['type'] = (empty($entity->link_type->entity) ? "(none)" : $entity->link_type->entity->toLink());
    return $row + parent::buildRow($entity);
  }

}