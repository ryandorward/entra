<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use Drupal\graphql\GraphQL\Execution\ResolveContext;
use Drupal\graphql\GraphQL\Execution\FieldContext;
use GraphQL\Type\Definition\ResolveInfo;
use Drupal\apfRelatedContent\relatedContent;

use \Drupal\Core\Url;
use Drupal\entraTools\my;

class RelatedContentResolvers {

  protected static $myType = 'NodeContent';

  static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {

    $registry->addFieldResolver('Query', 'relatedContent',
      $builder->compose(
        $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
          $context->addCacheTags(['node_list']);
          $tags = $args['tags'] ?? [];
          if (is_numeric($tags))
            $tags = [$tags];
          return relatedContent::getCastRelated($tags);
        })
      )
    );

    // Shorthand field resolvers
    $fieldMapCallback = [
      'id' => function ($entity) {
        return $entity->id() ?: "0"; // if the entity was not saved (like when someone without correct permissions tries to save), it won't have an ID
      },
      'title' => function ($entity) {
        return $entity->title->value;
      },
      'tags' => function ($entity) {
        $tags = [];
        foreach ($entity->taxonomy_vocabulary_4 as $tag) {
          $tags[] = $tag->entity;
          /*
          $tags[] = [
            'id' => $tag->entity->id(),
            'name' => $tag->entity->label()
          ];
          */
        }
        return $tags;
      },
      'published' => function ($entity) {
        return $entity->isPublished();
      },
      'path' => function ($entity) {
        return $entity->getMyLink();
      },
      'typeLabel' => function ($entity) {
        return $entity->getMyTypeLabel(false,false,false);
      },
      'imageSources' => function ($entity) {
        return my::getImageSources($entity->getMyKeystoneImageField());
      },
      'posted' => function ($entity) {
        return $entity->getPublishedFormatted();
      },
    ];

    foreach ($fieldMapCallback as $field => $callback) {
      $registry->addFieldResolver(self::$myType, $field,
        $builder->callback($callback));
    }

  }
}