<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use \Drupal\apf_risk_entities\Entity\EventRiskAssessment;
use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;

use Drupal\graphql\GraphQL\Execution\ResolveContext;
use Drupal\graphql\GraphQL\Execution\FieldContext;
use GraphQL\Type\Definition\ResolveInfo;

use pgapi\pgConnection;

class ImpactResolvers {

  public static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {

    $registry->addFieldResolver('Query', 'eventRiskAssessments',
      $builder->compose(
        $builder->fromArgument('eventId'),
        $builder->callback(function ($id, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
          $context->addCacheTags(['event_risk_assessment_list']);
          return EventRiskAssessment::getByEventId($id);
        })
      )
    );

    $registry->addFieldResolver('Query', 'eventImpacts',
      $builder->compose(
        $builder->fromArgument('eventId'),
        $builder->callback(function ($id) {
          return EventRiskAssessment::getByEventId($id);
        })
      )
    );

    $registry->addFieldResolver('Query', 'impacts',
      $builder->compose(
        $builder->callback(function ($null, $args) { // *** UNDOCUMENTED FEATURE? *** all query args passed to second arguement of fn as an array
          $in = empty($args['in']) ? null : $args['in'];
          $components = empty($args['components']) ? null : $args['components'];
          return EventRiskAssessment::getByJurisdictionComponents($in, $components);
        })
      )
    );



    $registry->addFieldResolver('ImpactResponse', 'impact',
      $builder->callback(function (EntityResponse $response) {
        return $response->entity();
      })
    );
    $registry->addFieldResolver('ImpactResponse', 'errors',
      $builder->callback(function (EntityResponse $response) {
        return $response->getViolations();
      })
    );

    $registry->addFieldResolver('Impact', 'id',
      $builder->callback(function ($entity) {
        return $entity->id() ?: "0"; // if the entity was not saved (like when someone without correct permissions tries to save), it won't have an ID
      })
    );

    $registry->addFieldResolver('Impact', 'event',
      $builder->callback(function ($entity) {
        return $entity->event->entity;
      })
    );

    $registry->addFieldResolver('Impact', 'geo_id',
      $builder->callback(function ($entity) {
        return $entity->geo_id->value;
      })
    );

    // @todo: this field can likely be removed
    $registry->addFieldResolver('Impact', 'place',
      $builder->callback(function ($entity) {
        if ($entity->geo_id->value) {
          $options = (object)[
            'geometry'=>false,
            'name'=>true,
            'type'=>true,
	          'canadian' => false,
            'ancestors' => false,
          ];
          $pgConnection = new pgConnection(); // need an active postgres connection
          $place = getBasicJurisdiction($entity->geo_id->value, $options);
          if($place && !is_null($place->parent)){
            $place->parent = getBasicJurisdiction($place->parent, $options); // just fetch ancestors one level up, all that's needed for now. In future, could recursively fetch all the way up.
          }
          return $place;
        }
        return null;
      })
    );

    $registry->addFieldResolver('Impact', 'componentId',
      $builder->callback(function ($entity) {
        if (!empty($entity->component->entity))
          return $entity->component->entity->id->value;
      })
    );

    $registry->addFieldResolver('Impact', 'component',
      $builder->callback(function ($entity) {
        if (!empty($entity->component->entity))
          return $entity->component->entity;
      })
    );

    $registry->addFieldResolver('Impact', 'description',
      $builder->callback(function ($entity) {
        return trim($entity->description->value);
      })
    );

    // @todo: this field is deprecated
    $registry->addFieldResolver('Impact', 'assessment',
      $builder->callback(function ($entity) {
        return $entity->assessment->value;
      })
    );
    $registry->addFieldResolver('Impact', 'score',
      $builder->callback(function ($entity) {
        return $entity->assessment->value;
      })
    );

  }

  public static function registerMutationResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {
    $registry->addFieldResolver('Mutation', 'createImpact',
      $builder->produce('create_risk_assessment')
        ->map('data', $builder->fromArgument('data'))
    );
    $registry->addFieldResolver('Mutation', 'upsertImpact',
      $builder->produce('upsert_risk_assessment')
        ->map('data', $builder->fromArgument('data'))
    );
    $registry->addFieldResolver('Mutation', 'deleteImpact',
      $builder->produce('delete_event_risk_assessment')
        ->map('id', $builder->fromArgument('id'))
    );
  }

}