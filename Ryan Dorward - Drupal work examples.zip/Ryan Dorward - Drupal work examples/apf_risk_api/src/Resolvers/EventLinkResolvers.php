<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use \Drupal\apf_risk_entities\Entity\EventLink;
use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\graphql\GraphQL\Execution\ResolveContext;
use Drupal\graphql\GraphQL\Execution\FieldContext;
use GraphQL\Type\Definition\ResolveInfo;

class EventLinkResolvers {
  public static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {    
    
    $registry->addFieldResolver('Query', 'eventLinks',    
      $builder->compose(                         
        $builder->fromArgument('eventId'),
        $builder->callback(function ($id, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
          $context->addCacheTags(['risk_event_link_list']);
          if (isset($args['isOrphan']) && $args['isOrphan'])
            return EventLink::getOrphans($id);                    
          return EventLink::getByEventId($id);                
        })      
      )
    );

    $registry->addFieldResolver('Mutation', 'createEventLink',
      $builder->produce('upsert_risk_event_link')
        ->map('data', $builder->fromArgument('data'))
    );
    $registry->addFieldResolver('Mutation', 'upsertEventLink',
      $builder->produce('upsert_risk_event_link')
        ->map('data', $builder->fromArgument('data')) 
    );
    $registry->addFieldResolver('Mutation', 'deleteEventLink',
      $builder->produce('delete_risk_event_link')
        ->map('id', $builder->fromArgument('id'))              
    ); 
    
    $registry->addFieldResolver('EventLinkResponse', 'eventLink',
      $builder->callback(function (EntityResponse $response) {
        return $response->entity();
      })
    );
    $registry->addFieldResolver('EventLinkResponse', 'errors',
      $builder->callback(function (EntityResponse $response) {
        return $response->getViolations();
      })
    );  

    $registry->addFieldResolver('EventLink', 'id',
      $builder->callback(function ($entity) {          
        return $entity->id() ?: "0"; // if the entity was not saved (like when someone without correct permissions tries to save), it won't have an ID
      })  
    ); 
    
    // property that combines id with parent event id if available for contextual cache-variance
    $registry->addFieldResolver('EventLink', 'cid',
      $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {                                     
        $self_id = $entity->id() ?: "0"; // if the entity was not saved (like when someone without correct permissions tries to save), it won't have an ID       
        $parent_id = '';
        if ( $parentEventId = $context->getContextValue($info,"eventId")) { // discover the parent event ID          
          if ($entity->source_event->entity && $entity->source_event->entity->id() !== $parentEventId)
            $parent_id = $entity->source_event->entity->id();
          else if ($entity->target_event->entity && $entity->target_event->entity->id() !== $parentEventId)
            $parent_id = $entity->target_event->entity->id();                 
        }               
        $_id = $self_id;
        if ($parent_id)
          $_id .= '.' . $parent_id;           
        return $_id;
      })  
    ); 

    $registry->addFieldResolver('EventLink', 'event',    
      $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {                             
        if ( $parentEventId = $context->getContextValue($info,"eventId")) { // discover the parent event ID
          if ($entity->source_event->entity && $entity->source_event->entity->id() !== $parentEventId)
            return $entity->source_event->entity;
          else if ($entity->target_event->entity && $entity->target_event->entity->id() !== $parentEventId)
            return $entity->target_event->entity;
          else // something is amiss
            return null;
        }
        else return null;
      })
    );

    $registry->addFieldResolver('EventLink', 'events',    
      $builder->callback(function ($entity) {  
        return [
          $entity->source_event->entity,
          $entity->target_event->entity
        ]; 
      })
    );

    $registry->addFieldResolver('EventLink', 'source',    
      $builder->callback(function ($entity) {                 
        return $entity->source_event->entity;
      })
    );

    $registry->addFieldResolver('EventLink', 'target',
      $builder->callback(function ($entity) {         
        return $entity->target_event->entity;
      }) 
    );
  
    $registry->addFieldResolver('EventLink', 'linkType',
      $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {  
        $context->addCacheTags(['risk_event_link_type_list']);       
        return $entity->link_type->entity;
      }) 
    );    
    
  }

}