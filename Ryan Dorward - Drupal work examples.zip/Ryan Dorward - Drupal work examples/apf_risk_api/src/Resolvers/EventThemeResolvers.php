<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use \Drupal\apf_risk_entities\Entity\EventTheme;
use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\graphql\GraphQL\Execution\ResolveContext;
use GraphQL\Type\Definition\ResolveInfo;
use Drupal\graphql\GraphQL\Execution\FieldContext;
use Drupal\apf_risk_api\Resolvers\EventResolvers;
use Drupal\Core\Database\Database;

class EventThemeResolvers {

  protected static $myType = 'Theme';

  static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {

    $registry->addFieldResolver('Query', 'themes',
      $builder->compose(
        $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
          $context->addCacheTags(['event_theme_list']);
          $id = $args['id'] ?? null;
          $isMeta = $args['isMeta'] ?? null;
          if (is_numeric($id))
            $id = [$id];
          return EventTheme::getThemes($id, false, $isMeta);
        })
      )
    );

    $registry->addFieldResolver('Query', 'theme',
      $builder->compose(
        $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
          $id = $args['id'] ?? null;
          if (is_numeric($id))
            $id = [$id];
          $themes = EventTheme::getThemes($id);
          return array_pop($themes);
        })
      )
    );

    // Shorthand field resolvers
    $fieldMapCallback = [
      'id' => function ($entity) {
        return $entity->id() ?: "0"; // if the entity was not saved (like when someone without correct permissions tries to save), it won't have an ID
      },
      'name' => function ($entity) {
        return $entity->name->value;
      },
      'tags' => function ($entity) {
        $tags = [];
        foreach ($entity->tags as $tag) {
          $tags[] = $tag->entity;
        }
        return $tags;
        /*
        foreach ($entity->tags as $tag) {
          $tags[] = [
            'id' => $tag->entity->id(),
            'name' => $tag->entity->label()
          ];
        }
        return $tags; */
      },
      'description' => function ($entity) {
        return $entity->description->value;
      },
      'color' => function ($entity) {
        return $entity->color->value;
      },
      'geo_ids' => function ($entity) {
        $geo_ids = [];
        foreach ($entity->geo_ids as $geo_id)
          $geo_ids[] = $geo_id->value;
        return $geo_ids;
      },
      'tagIntersectionWeight' => function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
        $context->addCacheTags(['risk_event_list']); // this is probably actually not necessary. But I might not be thinking about it properly, and having it here shouldn't have a negative impact if it's not necessary.

        /*
        // This way would be a good way to serve up intersection weights, rather than setting the property
        // when the event is asked for it's themes.
        // But it's not quite working right and I'm, not sure why at the moment of writing.
        // It would simplify things to be able to do it this way (if this works then refactor RiskEvent::getThemes() to get rid of setting the tag_intersect_weight property)
        if ( $parentEventId = $context->getContextValue($info,"eventId")) {
          $conn = Database::getConnection();
          $query = $conn->select('cast_event_themes')
            ->fields('cast_event_themes', ['tag_intersect_weight'])
            ->condition('theme_id', $entity->id())
            ->condition('event_id', $parentEventId);
          $results = $query->execute()->fetchCol(0);
          return ($results[0] ?? null);
        }
        else return null;
        */

        return (isset($entity->tag_intersect_weight) ? $entity->tag_intersect_weight : null);
      },
      'events' => function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
        $args['themes'] = [$entity->id()];
        // Shouldn't need to set the cache tags here because the cache tags are set in the EventResolvers::eventsQueryCallback() method
        return EventResolvers::eventsQueryCallback($entity, $args, $context, $info, $field);
      },
      'isMeta' => function ($entity) {
        return $entity->isMeta();
        //return ! empty($entity->child_themes->getValue());
      },
      'childThemes' => function ($entity) {
        $child_themes = [];
        foreach ($entity->child_themes as $child_theme) {
          $child_themes[] = $child_theme->entity;
        }
        return $child_themes;
      },
      'parentThemes' => function ($entity) {
        $parent_themes = [];
        foreach ($entity->parent_themes as $parent_theme) {
          $parent_themes[] = $parent_theme->entity;
        }
        return $parent_themes;
      }
    ];

    foreach ($fieldMapCallback as $field => $callback) {
      $registry->addFieldResolver(self::$myType, $field,
        $builder->callback($callback));
    }

  }
}