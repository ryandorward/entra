<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use Drupal\apf_risk_entities\Entity\RiskComponent;

class ComponentResolvers {
  static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {    

    $registry->addFieldResolver('Query', 'components',  
      $builder->compose(                        
        $builder->callback(function ($null, $args) { // *** UNDOCUMENTED FEATURE? *** all query args passed to second arguement of fn as an array          
          if (empty($args['id']))
            return RiskComponent::getRiskComponents();
          if (!empty($args['id']))
            return [RiskComponent::load($args['id'])];
        })
      )  
    ); 

    $registry->addFieldResolver('Query', 'component',  
      $builder->compose(                        
        $builder->callback(function ($null, $args) { // *** UNDOCUMENTED FEATURE? *** all query args passed to second arguement of fn as an array                 
          if (!empty($args['id']))
            return RiskComponent::load($args['id']);
        })
      )  
    ); 

    $registry->addFieldResolver('Component', 'id',
      $builder->callback(function ($entity) {         
        return $entity->id();
      }) 
    );
    
    $registry->addFieldResolver('Component', 'short_name',
      $builder->callback(function ($entity) {         
        return $entity->title->value;
      }) 
    );

    $registry->addFieldResolver('Component', 'long_name',
      $builder->callback(function ($entity) {         
        return $entity->long_name->value;
      }) 
    );

    $registry->addFieldResolver('Component', 'description',
      $builder->callback(function ($entity) {         
        return $entity->description->value;
      }) 
    );
  }
}