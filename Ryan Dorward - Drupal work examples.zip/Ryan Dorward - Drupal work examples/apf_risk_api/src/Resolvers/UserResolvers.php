<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;

use Drupal\graphql\GraphQL\Execution\ResolveContext;
use Drupal\graphql\GraphQL\Execution\FieldContext;
use GraphQL\Type\Definition\ResolveInfo;

class UserResolvers {
  static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {    

    $registry->addFieldResolver('User', 'id',    
      $builder->callback(function ($entity) {       
        return $entity->id();
      }) 
    );

    $registry->addFieldResolver('User', 'name',    
      $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {        
        return $entity->getDisplayName();
      })
    );
    
  }
}