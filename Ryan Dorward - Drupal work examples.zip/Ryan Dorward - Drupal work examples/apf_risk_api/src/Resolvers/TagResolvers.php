<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use \Drupal\apf_risk_entities\Entity\EventTheme;

use Drupal\graphql\GraphQL\Execution\ResolveContext;
use Drupal\graphql\GraphQL\Execution\FieldContext;
use GraphQL\Type\Definition\ResolveInfo;

class TagResolvers {
  static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {
    $registry->addFieldResolver('Query', 'tags',
      $builder->compose(
        $builder->callback(function ($value, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
          $context->addCacheTags(['taxonomy_term_list']);
          $ids = $args['id'] ?? [];
          if (is_numeric($ids))
            $ids = [$tags];
          $terms = \Drupal\taxonomy\Entity\Term::loadMultiple($ids);
          /*
          $tags = array_map(function($term) {
            return [
              'id' => $term->tid->value,
              'name' => $term->name->value,
            ];
          }, $terms);
          return $tags;
          */
          return $terms;
        })
      )
    );

    $registry->addFieldResolver('Tag', 'id',
      $builder->callback(function ($entity) {
        return $entity->tid->value;
      })
    );

    $registry->addFieldResolver('Tag', 'name',
      $builder->callback(function ($entity) {
        return trim($entity->name->value);
      })
    );

    $registry->addFieldResolver('Tag', 'description',
      $builder->callback(function ($entity) {
        return trim($entity->field_description->value);
      })
    );

    $registry->addFieldResolver('Tag', 'isCanonical',
      $builder->callback(function ($entity) {
        $cache_enabled = true && function_exists('apcu_fetch');
        $cache_id = 'apf_risk_entities_cannonical_tag_ids';
        $ttl = 90; // cache apc for 20 seconds
        if ($cache_enabled && apcu_exists($cache_id)) {
          $canonical_ids = apcu_fetch($cache_id);
        }
        else {
          $canonical_ids = EventTheme::getCannonicalTagIds(); // repeatedly asking for this is slow, so we apcu cache it. Even though the tags are cached in Drupal
          if ($cache_enabled)
            apcu_add($cache_id, $canonical_ids , $ttl);
        }
        return isset($canonical_ids[$entity->tid->value]); // faster than: in_array($entity->tid->value, $canonical_ids);
      })
    );

    $registry->addFieldResolver('Tag', 'themes',
      $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
        $context->addCacheTags(['event_theme_list']);

        $cache_enabled = true && function_exists('apcu_fetch');
        $cache_id = 'apf_risk_entities_tag_theme_ids-tag_id:' . $entity->tid->value;
        $ttl = 90; // cache apc for 20 seconds
        if ($cache_enabled && apcu_exists($cache_id)) {
          $themes = apcu_fetch($cache_id);
        }
        else {
          $all_tag_themes = EventTheme::getTagThemes();
          $themes = isset($all_tag_themes[$entity->tid->value]) ? $all_tag_themes[$entity->tid->value] : []; // repeatedly asking for this is slow, so we apcu cache it. Even though the tags are cached in Drupal
          if ($cache_enabled)
            apcu_add($cache_id, $themes, $ttl);
        }
        return $themes;


        /*
        // old way, can delete after testing:

        $themes = EventTheme::getThemes();
        $themes = array_filter($themes, function($theme) use ($entity ) {
          $theme_tags = array_map(function($tag) {
            return $tag['target_id'];
          }, $theme->tags->getValue());
          if (empty($theme_tags)) return false;
          if (in_array($entity->tid->value, $theme_tags)) return true;
        });
        return $themes;
        */


      })
    );

  }
}