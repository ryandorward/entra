<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use pgapi\pgConnection;

require DRUPAL_ROOT . '/pgapi/public/getBusinesses.php';

class BusinessResolvers {
  static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {    
    $registry->addFieldResolver('Query', 'businesses',   
      $builder->compose(                
        $builder->fromArgument('in'),
        $builder->callback(function ($geo_id) {   
          $pgConnection = new pgConnection();    
          return (empty($geo_id) ? businesses() : businessesIn($geo_id));                       
        })
      )      
    );
  }
}