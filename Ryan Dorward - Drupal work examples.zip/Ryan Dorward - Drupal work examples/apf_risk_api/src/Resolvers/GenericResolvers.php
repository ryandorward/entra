<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;

class GenericResolvers {
  
  protected static $myType = 'MyType';
  protected static $fieldMapCallback = [];

  static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {    

    foreach (static::$fieldMapCallback as $field => $callback) {
      $registry->addFieldResolver(static::$myType, $field, 
        $builder->callback($callback));
    }
           
  }
}