<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use Drupal\taxonomy\Entity\Term;
use \Drupal\apf_risk_entities\Actions;

class ActionResolvers {

  protected static $myType = 'Action';

  public static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {

    // Shorthand field resolvers
    $fieldMapCallback = [
      'id' => function ($entity) {
        return $entity->tid->value ?: "0"; // if the entity was not saved (like when someone without correct permissions tries to save), it won't have an ID
      },
      'name' => function ($entity) {
        return trim($entity->name->value);
      },
      'description' => function ($entity) {
        return trim($entity->field_description->value);
      },
      'parent' => function ($term) {
        return $term->parent->entity;
      },
      'children' => function ($entity) {
        $children = [];
        $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('actions');
        foreach ($terms as $term)
          if (in_array($entity->tid->value, $term->parents))
            $children[] = Term::load($term->tid);
        return $children;
      }
    ];

    foreach ($fieldMapCallback as $field => $callback)
      $registry->addFieldResolver(self::$myType, $field, $builder->callback($callback));

    $registry->addFieldResolver('Query', 'actionsTree',
      $builder->compose(
        $builder->fromArgument('id'),
        $builder->callback(function ($id) {
          return Actions::getActions($id);
        })
      )
    );

  }

}