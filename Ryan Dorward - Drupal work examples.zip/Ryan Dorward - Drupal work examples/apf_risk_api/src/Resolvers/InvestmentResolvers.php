<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use Drupal\graphql\GraphQL\Execution\ResolveContext;
use Drupal\graphql\GraphQL\Execution\FieldContext;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Error\Error;

use pgapi\pgConnection;

require_once DRUPAL_ROOT . '/pgapi/public/investment/involving.php';
require_once DRUPAL_ROOT . '/pgapi/public/investment/between.php';
require_once DRUPAL_ROOT . '/pgapi/public/investment/naics.php';
require_once DRUPAL_ROOT . '/pgapi/public/investment/uid.php';

class InvestmentResolvers {
  
  static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {    
    $registry->addFieldResolver('Query', 'investments',    
      
      $builder->compose(                                
        $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {                                                           
          $setArgCnt = 0;
          foreach (['uid','involving','between','naics'] as $argName) {            
            $setArgCnt += isset($args[$argName]);
            ${$argName} = $args[$argName] ?? null;
          }         
          $r_and_d = isset($args['r_and_d']) ? $args['r_and_d'] : null;
         
          $pgConnection = new pgConnection();                     
          if ($between && count($between) !== 2)          
            throw new Error("Invalid request. Please use an array of exactly two locations for the 'between' argument.");          

          $results = [];
          // Some args can be combined: $naics and $involving, or $naics and $between.
          // Any args can be combined with $r_and_d.
          if ($setArgCnt == 2 && $naics && $involving)
            $results = investmentInvolving($involving, $naics, $r_and_d);    
          else if ($setArgCnt == 2 && $naics && $between)
            $results = investmentBetween($between[0], $between[1], $naics, $r_and_d);
         
          else if ($setArgCnt !== 1) // this count does not include $r_and_d
            throw new Error('Invalid argument count/combination. Please use valid arguements for this query.');                           
          else if ($uid)            
            $results = investmentByUid((string) $uid, $r_and_d);
          else if ($involving) 
            $results = investmentInvolving($involving, $naics, $r_and_d);
          else if ($between)           
            $results = investmentBetween($between[0], $between[1], $naics, $r_and_d);
          else if ($naics)
            $results = investmentByNaics($naics, $r_and_d);                           

          // postprocess results
          foreach ($results as &$result)          
            if (isset($result['r_and_d'])) { // convert Postgres' 't' and 'f' to true and false
              if ($result['r_and_d'] == 't')
                $result['r_and_d'] = true;
              else if ($result['r_and_d'] == 'f')
                $result['r_and_d'] = false;
              else $result['r_and_d'] = null; //undefined
            }
          return $results;

        })
      )
      
    );
  }
  
}