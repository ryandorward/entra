<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use \Drupal\apf_risk_entities\Entity\EditorialComment;
use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;

use Drupal\graphql\GraphQL\Execution\ResolveContext;
use Drupal\graphql\GraphQL\Execution\FieldContext;
use GraphQL\Type\Definition\ResolveInfo;
use Drupal\user\Entity\User;
use Drupal\apf_risk_entities\EditorialCommentAccessControlHandler;
use Drupal\entraTools\my;

class EditorialCommentResolvers {

  protected static $myType = 'EditorialComment';

  private static function getAccessControlHandler() {
    return \Drupal::entityTypeManager()->getAccessControlHandler('editorial_comment');
  }

  private static function checkViewAccess() {
    // this doesn't work because can't access the protected method
    // return self::getAccessControlHandler()->checkView(\Drupal::currentUser());
    $roles = \Drupal::currentUser()->getRoles();
    if (in_array('risk_analyst', $roles ) || in_array('risk_jr_analyst', $roles ))
      return true;
  }

  public static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {

    $registry->addFieldResolver('Query', 'editorialComments',
      $builder->compose(
        $builder->fromArgument('eventId'),
        $builder->callback(function ($id, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
          $context->addCacheTags(['editorial_comment_list']); // @todo: could make a custom tag for list per event id
          $context->addCacheContexts(['user.permissions']); // This should have already been added in the $context's constructor, but just to be safe...

          if (!self::checkViewAccess())
            return [];

          $latestCommentId = $args['latestCommentId'] ?? 0;
          return EditorialComment::getByEventId($id,$latestCommentId);
        })
      )
    );

    $registry->addFieldResolver('EditorialCommentResponse', 'editorialComment',
      $builder->callback(function (EntityResponse $response) {
        return $response->entity();
      })
    );
    $registry->addFieldResolver('EditorialCommentResponse', 'errors',
      $builder->callback(function (EntityResponse $response) {
        return $response->getViolations();
      })
    );

    // Shorthand field resolvers
    $fieldMapCallback = [
      'id' => function ($entity) {
        return $entity->id() ?: "0"; // if the entity was not saved (like when someone without correct permissions tries to save), it won't have an ID
      },
      'eventId' => function ($entity) {
        return $entity->event->target_id;
      },
      'event' => function ($entity) {
        return $entity->event->entity;
      },
      'comment' => function ($entity) {
        return $entity->comment->value;
      },
      'created' => function ($entity) {
        if ($entity->created->value) {
          $date = new \DateTime();
          $date->setTimestamp($entity->created->value);
          return my::myFormatPublishedDate($entity->created->value, true);
        }
      },
      'owner' => function ($entity) {
        $id = $entity->user_id->target_id;
        if ($id)
          return User::load($id);
      },
    ];

    foreach ($fieldMapCallback as $field => $callback)
      $registry->addFieldResolver(self::$myType, $field, $builder->callback($callback));

  }

  public static function registerMutationResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {
    $registry->addFieldResolver('Mutation', 'upsertEditorialComment',
      $builder->produce('upsert_editorial_comment')
        ->map('data', $builder->fromArgument('data'))
    );
    $registry->addFieldResolver('Mutation', 'deleteEditorialComment',
      $builder->produce('delete_editorial_comment')
        ->map('id', $builder->fromArgument('id'))
    );
  }
}