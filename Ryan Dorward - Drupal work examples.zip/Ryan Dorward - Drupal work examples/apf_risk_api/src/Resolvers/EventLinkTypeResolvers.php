<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use Drupal\apf_risk_entities\Entity\EventLinkType;

use Drupal\graphql\GraphQL\Execution\ResolveContext;
use Drupal\graphql\GraphQL\Execution\FieldContext;
use GraphQL\Type\Definition\ResolveInfo;

class EventLinkTypeResolvers {
  public static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {    

    $registry->addFieldResolver('Query', 'eventLinkTypes',  
      $builder->compose(                        
        $builder->callback(function ($null, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
          $context->addCacheTags(['risk_event_link_type_list']);
          $ids = $args['ids'] ?? null;
          return EventLinkType::getLinkTypes($ids);
        })
      )  
    );

    $registry->addFieldResolver('EventLinkType', 'id',
      $builder->produce('entity_id')
        ->map('entity', $builder->fromParent())
    ); 

    $registry->addFieldResolver('EventLinkType', 'title',
      $builder->callback(function ($entity) {         
        return $entity->title->value;
      })
    ); 

    $registry->addFieldResolver('EventLinkType', 'description',
      $builder->callback(function ($entity) {         
        return $entity->description->value;
      })
    ); 

    $registry->addFieldResolver('EventLinkType', 'referenceFromPast',
      $builder->callback(function ($entity) {         
        return $entity->referenceFromPast->value;
      })
    ); 

    $registry->addFieldResolver('EventLinkType', 'referenceFromFuture',
      $builder->callback(function ($entity) {         
        return $entity->referenceFromFuture->value;
      })
    ); 

  }
}