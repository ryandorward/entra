<?php

namespace Drupal\apf_risk_api\Resolvers;
use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use \Drupal\apf_risk_entities\Entity\RiskEvent;
use \Drupal\apf_risk_entities\Entity\EventLink;
use \Drupal\apf_risk_entities\Entity\EventRiskAssessment;
use \Drupal\apf_risk_entities\Entity\EventTheme;
use \Drupal\apf_risk_entities\Entity\ChangeAnalysisLink;
use \Drupal\apf_risk_entities\Entity\ChangeAnalysis;
use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\graphql\GraphQL\Execution\ResolveContext;
use Drupal\graphql\GraphQL\Execution\FieldContext;
use GraphQL\Type\Definition\ResolveInfo;
use Drupal\apfRelatedContent\relatedContent;
use Drupal\user\Entity\User;

use pgapi\pgConnection;

require DRUPAL_ROOT . '/pgapi/public/getActor.php';

class EventResolvers {

  protected static $myType = 'Event';

  /*
  public static function apcu_doer($cache_id, $callback, $ttl=30 ) {
    $cache_enabled = true && function_exists('apcu_fetch');
    if ($cache_enabled && apcu_exists($cache_id))
      return apcu_fetch($cache_id);
    $value = $callback();
    if ($cache_enabled)
      apcu_add($cache_id, $value, $ttl);
    return $value;
  }
  */

  public static function eventsQueryCallback($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {

    $cache_tags = ['risk_event_list'];
    if (isset($args['in']) || isset($args['search']))
      $cache_tags[] = 'event_risk_assessment_list';
    if (isset($args['theme']))
      $cache_tags[] = 'event_theme_list';
    $context->addCacheTags($cache_tags);

    // preprocess some of the args
    foreach (['tags','ids','themes','search'] as $argName) {
      $arg = $args[$argName] ?? null; // if the arg isn't set, then set it to null
      $args[$argName] = is_int($arg) ? [$arg] : $arg;  // if arg is an int, make it an array
    }
    foreach (['withDescendants','indirect','withUnpublished'] as $argName)
      $args[$argName] = $args[$argName] ?? false;
    $args['sort'] = $args['sort'] ?? 'event_date';
    if ($args['sort'] == 'date') // alias for event_date
      $args['sort'] = 'event_date';

    if ($args['withUnpublished']) {
      // make sure current user has permission to view unpublished events
      $roles = \Drupal::currentUser()->getRoles();
      $args['withUnpublished'] = $args['withUnpublished'] && (in_array('risk_analyst', $roles ) || in_array('risk_jr_analyst', $roles ));
    }

    // downstream queries need to know the context of withUnpublished
    $context->setContextValue($info, "withUnpublished", $args['withUnpublished']);

    // themes define a preset set of tags and jurisdictions (with their descendants)
    // if there are theme arg, fish out the tags and jurisdictions from the themes
    // and then bosh them onto the respective arg
    // @todo: now that we're precomputing events' themes, we could just put some joins in the query
    // but make sure that's actually faster, it might not be!
    $theme_jurisdictions = [];
    if (!empty($args['themes'])) {
      // Get themes and their descendant themes (i.e. for meta-themes)
      $themes = EventTheme::getThemes($args['themes'],true);
      $tags = [];
      if (!empty($themes)) foreach ($themes as $theme) { // Parse themes for their jurisdictions and tags
        foreach ($theme->geo_ids as $geo_id)
          $theme_jurisdictions[] = $geo_id->value;
        foreach ($theme->tags->getValue() as $tag) {
          $tags[] = $tag['target_id'];
        }
      }

      // themes could have overlapping tags and jurisdictions
      $tags = array_unique($tags);
      $theme_jurisdictions = array_unique($theme_jurisdictions);

      // At this point, if either $tags or $jurisdictions is empty,
      // then we're looking at a theme that should have no events.
      if (empty($tags) && empty($theme_jurisdictions))
        return [];

      // reconcile tags: intersect any 'tags' args with tags from the themes, unless tags arg was empty
      $args['tags'] = empty($args['tags']) ? $tags : array_intersect($args['tags'], $tags);

      // theme jurisdictions always include their decendants
      $pgConnection = pgConnection::pgConnectionObject(); // need an active postgres connection. Use the singleton
      $theme_jurisdictions = getDescendantsGeoId($theme_jurisdictions);
    }

    // Set up jurisdiction filters
    if (!empty($args['in'])) {
      $ancestors = [];
      $descendants = [];
      if (!empty($args['withDescendants'] || !empty($args['indirect']))) {
        if (empty($pgConnection))
          $pgConnection = pgConnection::pgConnectionObject(); // need an active postgres connection. Use the singleton
        $descendants = getDescendantsGeoId($args['in']);
      }
      if (!empty($args['indirect']))
        $ancestors = getAncestorsGeoId($args['in']);
      $args['in'] = array_merge($args['in'], $ancestors, $descendants);
      $args['in'] = array_unique($args['in']);
      $args['in'] = array_values($args['in']); // reindex the array
    }

    // Reconcile theme jurisdictions with the `in` arg
    // treat empty $theme_jurisdictions as global i.e. Themes with no jurisdictions are geographically global in scope
    if (!empty($theme_jurisdictions)) {
      // merge any 'in' args with jurisdictions from the themes. Use the intersect so that the 'in' param is filtering on the theme jurisdictions
      $args['in'] = empty($args['in']) ? $theme_jurisdictions : array_intersect($args['in'], $theme_jurisdictions);
      if (empty($args['in']))
        return []; // if the intersection is empty, then there are no events that match the themes AND the in param
    }

    $events =  RiskEvent::getRiskEvents($args);

    return $events;
  }

  public static function registerResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {

    $registry->addFieldResolver('Query', 'event',
      $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
        $withUnpublished = $args['withUnpublished'] ?? false;

        if ($withUnpublished) {
          // make sure current user has permission to view unpublished events
          $roles = \Drupal::currentUser()->getRoles();
          $withUnpublished = $withUnpublished  && (in_array('risk_analyst', $roles ) || in_array('risk_jr_analyst', $roles ));
        }

        $context->setContextValue($info, "withUnpublished", $withUnpublished);

        if (!empty($args['id'])) {
          $context->setContextValue($info, "eventId", $args['id']); // child links need to know which parent event called them
          $event = RiskEvent::load($args['id']);
          if ($withUnpublished || $event?->isPublished())
            return $event;
        }
      })
    );

    $registry->addFieldResolver('Query', 'events',
      $builder->compose(
        $builder->callback([__CLASS__,'eventsQueryCallback']) // this is how you pass a static method as a callback, within the same class
      )
    );

    $registry->addFieldResolver('Query', 'eventsQueue',
      $builder->compose(
        $builder->callback(function ($non, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
          $context->addCacheTags(['risk_event_list']);
          $ownerId = $args['owner'] ?? null;
          $query = \Drupal::entityQuery('risk_event')
            ->sort('created', 'DESC');
          if ($ownerId) {
            $owner = User::load($ownerId);
            if ($owner->hasRole('risk_analyst')) {
              $query->range(0,1000); // @todo: running into some memory issues with large result sets. Need to do a more sophisticated query for 'risk_analyst' instead of just filtering in php on these entities
              $ids = $query->execute();
              $events = RiskEvent::loadMultiple($ids);
              return array_filter($events, function ($event) use ($ownerId) {
                if ($event->user_id->target_id == $ownerId && !$event->isPublished()) // include own unpublished events
                  return true;
                return (!$event->isPublished() && !$event->isDraft()); // include others' unpublished non-drafts
              });
            }
            else if ($owner->hasRole('risk_jr_analyst')) {
              // get own drafts
              $query->condition('user_id', $ownerId);
              $draft_mask = RiskEvent::status_masks['draft'];
              $query->condition('status', $draft_mask, '&');
              $ids = $query->execute();
              return( RiskEvent::loadMultiple($ids));
            }
          }
        })
      )
    );


    $registry->addFieldResolver('EventResponse', 'event',
      $builder->callback(function (EntityResponse $response) {
        return $response->entity();
      })
    );
    $registry->addFieldResolver('EventResponse', 'errors',
      $builder->callback(function (EntityResponse $response) {
        return $response->getViolations();
      })
    );
    $registry->addFieldResolver('EventResponse', 'operation',
      $builder->callback(function (EntityResponse $response) {
        return $response->getOperation();
      })
    );

    $registry->addFieldResolver('Event', 'id',
      $builder->callback(function ($entity) {
        return $entity->id() ?: "0"; // if the entity was not saved (like when someone without correct permissions tries to save), it won't have an ID
      })
    );

    $registry->addFieldResolver('Event', 'title',
      $builder->callback(function ($entity) {
        return trim($entity->title->value);
      })
    );
    $registry->addFieldResolver('Event', 'archive_link',
      $builder->callback(function ($entity) {
        return 'archive_link field is deprecated, please use archive_links instead.';
      })
    );
    $registry->addFieldResolver('Event', 'archive_links',
      $builder->callback(function ($entity) {
        $links = [];
        foreach ($entity->archive_links as $link)
          $links[] = trim($link->value);
        return $links;
      })
    );
    $registry->addFieldResolver('Event', 'description',
      $builder->callback(function ($entity) {
        return trim($entity->description->value);
      })
    );
    $registry->addFieldResolver('Event', 'justification',
      $builder->callback(function ($entity) {
        return trim($entity->justification->value);
      })
    );

    $registry->addFieldResolver('Event', 'context',
      $builder->callback(function ($entity) {
        return trim($entity->context->value);
      })
    );

    $registry->addFieldResolver('Event', 'date',
      $builder->callback(function ($entity) {
        if ($entity->event_date->value)  {
          return $entity->event_date->date->format("Y-m-d");
        }
      })
    );

    $registry->addFieldResolver('Event', 'links',
      $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {

        $context->addCacheTags(['risk_event_link_list']);

        $type = $args['type'] ?? null; // set type default to null
        $type = is_int($type) ? [$type] : $type;  // if arg is an int, make it an array

        $context->setContextValue($info, "eventId", $entity->id()); // child links need to know which parent event called them
        if ($context->hasContextValue($info,"withUnpublished"))
          $withUnpublished = $context->getContextValue($info,"withUnpublished");
        else $withUnpublished = true; // it is necessary to set this to true because when returning the links after Event Upsert, the context won't be set. It may be that there is a way to set the context properly in that situation that I haven't figured out
        return EventLink::getByEventId($entity->id->value, $withUnpublished, $type);
      })
    );

    $registry->addFieldResolver('Event', 'impacts',
      $builder->callback(function ($entity) {
        // this should not be necessary, because impacts are self-contained to the event, and will only get changed if the event changes, and the cache already varies by that event
        // $context->addCacheTags(['event_risk_assessment_list']);
        $impacts = EventRiskAssessment::getByEventId($entity->id->value);
        return $impacts;
      })
    );

    $registry->addFieldResolver('Event', 'peopleInvolved',
      $builder->callback(function ($entity) {
        return $entity->peopleInvolved->value;
      })
    );

    $registry->addFieldResolver('Event', 'wasOngoing',
      $builder->callback(function ($entity) {
        return $entity->wasOngoing->value;
      })
    );

    $registry->addFieldResolver('Event', 'wasViolent',
      $builder->callback(function ($entity) {
        return $entity->wasViolent->value;
      })
    );

    $registry->addFieldResolver('Event', 'propertyDamage',
      $builder->callback(function ($entity) {
        return $entity->propertyDamage->value;
      })
    );

    $registry->addFieldResolver('Event', 'officialResponse',
      $builder->callback(function ($entity) {
        return $entity->officialResponse->value;
      })
    );

    $registry->addFieldResolver('Event', 'canadianInvolvement',
      $builder->callback(function ($entity) {
        return $entity->canadianInvolvement->value;
      })
    );

    $registry->addFieldResolver('Event', 'tags',
      $builder->callback(function ($entity, $args) {
        $isCanonical = $args['isCanonical'] ?? false;
        if ($isCanonical)
          $canonical_ids = EventTheme::getCannonicalTagIds();
        $tags = [];
        foreach ($entity->tags as $tag) {
          if ( $tag->entity && (!$isCanonical || isset($canonical_ids[$tag->target_id]))) // faster than in_array($tag->target_id, $canonical_ids))
            $tags[] = $tag->entity;
        }
        return $tags;
      })
    );

    $registry->addFieldResolver('Event', 'themes',
      $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
        $context->addCacheTags(['event_theme_list']);
        // preprocess some of the args. If these are unset, set them to null
        foreach (['isMeta'] as $argName)
          $args[$argName] = $args[$argName] ?? null;

        $context->setContextValue($info, "eventId", $entity->id()); // child themes need to know which parent event for tagIntersectionWeight
        return $entity->getThemes($args['isMeta']);
      })
    );

    $registry->addFieldResolver('Event', 'relatedContent',
      $builder->callback(function ($entity, $args, ResolveContext $context, ResolveInfo $info, FieldContext $field) {
        $context->addCacheTags(['node_list']); // @todo: could be more granular here and vary only by the content types that can show up in related content
        return relatedContent::getCastRelated($entity);
      })
    );

    // Shorthand field resolvers
    $fieldMapCallback = [
      'published' => function ($entity) {
        return $entity->isPublished();
      },
      'approved' => function ($entity) {
        return $entity->isApproved();
      },
      'draft' => function ($entity) {
        return $entity->isDraft();
      },
      'status' => function ($entity) {
        return $entity->status->value;
      },
      'owner' => function ($entity) {
        $id = $entity->user_id->target_id;
        if ($id)
          return User::load($id);
      },
      'lastEditor' => function ($entity) {
        $id = $entity->editor_user_id->target_id;
        if ($id)
          return User::load($id);
      },
      'created' => function ($entity) {
        if ($entity->created->value) {
          $date = new \DateTime();
          $date->setTimestamp($entity->created->value);
          return $date->format("Y-m-d H:i:s") . " (PST)";
        }
      },
      'changed' => function ($entity) {
        if ($entity->changed->value) {
          $date = new \DateTime();
          $date->setTimestamp($entity->changed->value);
          return $date->format("Y-m-d H:i:s") . " (PST)";
        }
      },
      'weight' => function ($entity) {
        return $entity->getWeight();
      },
      // this is deprecated, remove asap; use 'weight' instead
      'frozenWeight' => function ($entity) {
        return $entity->weight->value;
      },
      'calculatedWeight' => function ($entity) {
        return $entity->calculateWeight();
      },
      'action' => function ($entity) {
        return $entity->action[0]?->entity;
      },
      'actors' => function ($entity) {
        $actors = [];
        $pgConnection = pgConnection::pgConnectionObject(); // need an active postgres connection. Use the singleton
        foreach ($entity->actors as $actor) {
          $id = $actor->value;
          $result = getActor($id);
          $actors[] = [
            'id' => $id,
            'label' => $result?->label ?? null,
            'description' => $result?->description ?? null
          ];
        }
        return $actors;
      },
    ];

    foreach ($fieldMapCallback as $field => $callback) {
      $registry->addFieldResolver(self::$myType, $field,
        $builder->callback($callback));
    }

  }

  public static function registerMutationResolvers(ResolverRegistryInterface $registry, ResolverBuilder $builder) {
    /****
      Create risk event mutation.

      Use it like this:
      mutation {
        createEvent(data: {
          title: "Risk Event Created in GraphQL"
          geo_id: "58"
        }) {
          event {
            id
            title
          }
        }
      }
    ****/
    $registry->addFieldResolver('Mutation', 'createEvent',
      $builder->produce('upsert_risk_event')
        ->map('data', $builder->fromArgument('data'))
    );

    $registry->addFieldResolver('Mutation', 'updateEvent',
      $builder->produce('upsert_risk_event')
        ->map('data', $builder->fromArgument('data'))
    );

    $registry->addFieldResolver('Mutation', 'upsertEvent',
      $builder->produce('upsert_risk_event')
        ->map('data', $builder->fromArgument('data'))
    );

    /****
     *
     * Use delete like this:
     *
      mutation {
        deleteEvent(id: 4) {
          event {
            id
            title
          }
        }
      }
     *
    ****/
    $registry->addFieldResolver('Mutation', 'deleteEvent',
      $builder->produce('delete_risk_event')
        ->map('id', $builder->fromArgument('id'))
    );

  }
}