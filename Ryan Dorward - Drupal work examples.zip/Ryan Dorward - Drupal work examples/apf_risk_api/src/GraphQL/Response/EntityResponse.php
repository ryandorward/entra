<?php

namespace Drupal\apf_risk_api\GraphQL\Response;

use Drupal\Core\Entity\EntityInterface;
use Drupal\graphql\GraphQL\Response\Response;

/**
 * Type of response used when an event is returned.
 */
class EntityResponse extends Response {

  /**
   * The Risk Entity to be served.
   *
   * @var \Drupal\Core\Entity\EntityInterface|null
   */
  protected $entity;
  protected $operation;

  /**
   * Sets the content.
   *
   * @param \Drupal\Core\Entity\EntityInterface|null $entity
   *   The entity to be served.
   */
  public function setEntity(?EntityInterface $entity): void {
    $this->entity = $entity;
  }

  /**
   * Gets the entity to be served.
   *
   * @return \Drupal\Core\Entity\EntityInterface|null
   *   The entity to be served.
   */
  public function entity(): ?EntityInterface {
    return $this->entity;
  }

  public function setOperation(string $operation): void {
    $this->operation = $operation;
  }
  public function getOperation(): string {
    return $this->operation;
  }

}
