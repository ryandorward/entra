<?php

namespace Drupal\apf_risk_api\Plugin\GraphQL\DataProducer;

use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\apf_risk_entities\Entity\EventLink;
use Drupal\apf_risk_api\DeleteEntity;

/**
 * Deletes an event link entity.
 *
 * @DataProducer(
 *   id = "delete_risk_event_link",
 *   name = @Translation("Delete EventLink"),
 *   description = @Translation("Deletes a risk event link."),
 *   produces = @ContextDefinition("any",
 *     label = @Translation("Risk Event Link")
 *   ),
 *   consumes = {
 *     "id" = @ContextDefinition("any",
 *       label = @Translation("Risk Event Link id")
 *     )
 *   }
 * )
 */
class DeleteEventLink extends DeleteEntity {

  protected static function load($id) {
    return EventLink::load($id);
  }

}
