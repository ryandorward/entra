<?php

namespace Drupal\apf_risk_api\Plugin\GraphQL\DataProducer;

use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\apf_risk_entities\Entity\EventRiskAssessment;
use Drupal\apf_risk_api\UpsertEntity;

/**
 * Update/Create a risk assessment entity.
 *
 * @DataProducer(
 *   id = "upsert_risk_assessment",
 *   name = @Translation("Upsert Risk Assessment"),
 *   description = @Translation("Update/Create a Risk Assessment."),
 *   produces = @ContextDefinition("any",
 *     label = @Translation("Risk Assessment")
 *   ),
 *   consumes = {
 *     "data" = @ContextDefinition("any",
 *       label = @Translation("Risk Assessment data")
 *     )
 *   }
 * )
 */
class UpsertImpact extends UpsertEntity {

   // Fields that don't need any processing
   protected static $fieldNameMap = [
    'eventId' => 'event',
    'componentId' => 'component',
    'score' => 'assessment',
    'description',
    'geo_id',
  ];

  protected static function getValuesFromData($data) {
    $values = parent::getValuesFromData($data);
    if (!empty ($data['place']['geo_id']))
      $values['geo_id'] = $data['place']['geo_id'];

    return $values;
  }

  protected static function load($id) {
    return EventRiskAssessment::load($id);
  }

  protected static function createEntity($id) {
    return EventRiskAssessment::create($id);
  }

}