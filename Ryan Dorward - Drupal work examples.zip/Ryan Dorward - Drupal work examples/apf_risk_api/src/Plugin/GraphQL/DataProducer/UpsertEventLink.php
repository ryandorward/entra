<?php

namespace Drupal\apf_risk_api\Plugin\GraphQL\DataProducer;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\graphql\Plugin\GraphQL\DataProducer\DataProducerPluginBase;
use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\apf_risk_api\UpsertEntity;
use Drupal\apf_risk_entities\Entity\RiskEvent;
use Drupal\apf_risk_entities\Entity\EventLink;
use Drupal\apf_risk_entities\Entity\EventLinkType;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Updates/creates a new risk event link entity.
 *
 * @DataProducer(
 *   id = "upsert_risk_event_link",
 *   name = @Translation("Upsert Risk Event Link"),
 *   description = @Translation("Upsert a new Risk Event Link."),
 *   produces = @ContextDefinition("any",
 *     label = @Translation("Risk Event Link")
 *   ),
 *   consumes = {
 *     "data" = @ContextDefinition("any",
 *       label = @Translation("Risk Event Link data")
 *     )
 *   }
 * )
 */
class UpsertEventLink extends UpsertEntity {

  // Fields that don't need any processing
  protected static $fieldNameMap = [
    'sourceId' => 'source_event',
    'targetId' => 'target_event',
    'linkTypeId' => 'link_type',
  ];

  protected static function load($id) {
    return EventLink::load($id);
  }

  protected static function createEntity($id) {
    return EventLink::create($id);
  }

}
