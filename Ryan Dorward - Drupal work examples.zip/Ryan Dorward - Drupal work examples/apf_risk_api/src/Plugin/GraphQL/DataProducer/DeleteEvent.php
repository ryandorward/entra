<?php

namespace Drupal\apf_risk_api\Plugin\GraphQL\DataProducer;

use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\apf_risk_entities\Entity\RiskEvent;
use Drupal\apf_risk_entities\Entity\EventLink;
use Drupal\apf_risk_api\DeleteEntity;

/**
 * Deletes an event entity.
 *
 * @DataProducer(
 *   id = "delete_risk_event",
 *   name = @Translation("Delete RiskEvent"),
 *   description = @Translation("Deletes a risk event."),
 *   produces = @ContextDefinition("any",
 *     label = @Translation("Risk Event")
 *   ),
 *   consumes = {
 *     "id" = @ContextDefinition("any",
 *       label = @Translation("Risk Event id")
 *     )
 *   }
 * )
 */
class DeleteEvent extends DeleteEntity {

  protected static function load($id) {     
    return RiskEvent::load($id);  
  }

}
