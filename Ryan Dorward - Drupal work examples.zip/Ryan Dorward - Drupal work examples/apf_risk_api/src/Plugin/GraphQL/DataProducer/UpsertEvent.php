<?php

namespace Drupal\apf_risk_api\Plugin\GraphQL\DataProducer;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\graphql\Plugin\GraphQL\DataProducer\DataProducerPluginBase;
use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\apf_risk_api\UpsertEntity;
use Drupal\apf_risk_entities\Entity\RiskEvent;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\apf_risk_api\Plugin\GraphQL\DataProducer\UpsertImpact;
use Drupal\apf_risk_api\Plugin\GraphQL\DataProducer\UpsertEventLink;
use Drupal\apf_risk_entities\Entity\EventRiskAssessment;
use Drupal\apf_risk_entities\Entity\EventLink;
use Drupal\user\Entity\User;
use Drupal\Core\Messenger\MessengerTrait;
/**
 * Upsert a new risk event entity.
 *
 * @DataProducer(
 *   id = "upsert_risk_event",
 *   name = @Translation("Create/Update Risk Event"),
 *   description = @Translation("Creates/Updartes a Risk Event."),
 *   produces = @ContextDefinition("any",
 *     label = @Translation("Risk Event")
 *   ),
 *   consumes = {
 *     "data" = @ContextDefinition("any",
 *       label = @Translation("Risk Event data")
 *     )
 *   }
 * )
 */
class UpsertEvent extends UpsertEntity {

  use MessengerTrait;

  // Fields that don't need any processing
  protected static $fieldNameMap = [
    'title',
    'archive_links',
    'description',
    'justification',
    'context',
    'date' => 'event_date',
    'peopleInvolved',
    'wasOngoing',
    'wasViolent',
    'propertyDamage',
    'officialResponse',
    'canadianInvolvement',
    'tags',
    'action',
    'actors'
    //  'published' => 'status' // now that we're switching to bitmasks and status holding binary representation of Published,
  ];

  protected static function getValuesFromData($data) {

    $values = parent::getValuesFromData($data);
    // Date may need some processing
    // Check if date matches "Y-m-d" format and is a valid date:
    if (isset($data['date'])) {
      $oDate = \DateTime::createFromFormat('Y-m-d', $data['date']);
      if ($oDate && $oDate->format('Y-m-d') === $data['date']) {
        $values['event_date'] = $data['date'] . 'T12:00:00'; // if so, append noon time, which storage demands
      }
    }
    // Other formats will not be modified.

    if (isset($data['tags'])) {
      $values['tags'] = self::getTagValuesFromData($data['tags']);
      $values['tags'] = array_unique($values['tags']);
    }

    if (isset($data['action']))
      $values['action'] = $data['action']['id'];

    if (isset($data['actors'])) {
      foreach ($data['actors'] as $actor)
        $values['actors'][] = $actor['id'];
    }

    // trim some fields:
    $single_value = ['title', 'description', 'justification', 'context',];
    foreach ($single_value as $field) {
      if (isset($values[$field]))
        $values[$field] = trim($values[$field]);
    }
    if (isset($values['archive_links'])) {
      foreach ($values['archive_links'] as $key => $link) {
        $values['archive_links'][$key] = trim($link);
      }
    }

    return $values;
  }

  private function processImpacts($impactsData, $parentId, $response) {

    $oldImpacts = EventRiskAssessment::getByEventId($parentId);

    foreach ($impactsData as $impactData) {
      $impactData['eventId'] = $parentId; // Now that entity ID has been established
      $values = UpsertImpact::getValuesFromData($impactData);
      if (isset($impactData['id']) && $impactData['id'] > 0) { // this is an update to an Impact
        unset ($oldImpacts[$impactData['id']]); // unmark this Impact from the list of old ones, means it was not deleted
        $assessment = EventRiskAssessment::load($impactData['id']);
        foreach ($values as $field => $value)
          $assessment->set($field, $value);
      }
      else
        $assessment = EventRiskAssessment::create($values);

      $violations = $assessment->validateFields();
      // @todo: refactor here. Should override parent ->validate() method to include ->validateFields used above
      // and then some kind of violation processor to organize the violations into a transmittable format (or send them raw and theme in react?)
      $entityViolations = $assessment->validate();
      if ($entityViolations->count() > 0)
        $violations['assessment'] = [
          'label' => 'Risk Assessment',
          'violations' => [],
        ];
      foreach ($entityViolations as $violation)
        $violations['assessment']['violations'][] = $violation->getMessage();

      if (!empty($violations)) {
        $message = $this->t('There was a validation error with the Risk Assessment. Risk Assessment was not added.');
        foreach ($violations as $violation)
          $message .= " " . $violation['label'] . ": " . implode(' ',$violation['violations']);
        // $response->addViolation($message,['severity' => 'error','check' => $check]); //@todo: do we need this 'check'?
        $response->addViolation($message,['severity' => 'error']);
      }
      else
        $assessment->save();
    }

    // Anything left in $oldImpacts was a Impact that was removed during an update
    foreach ($oldImpacts as $key => $oldImpact)
      $oldImpact->delete();

  }

  /*
    If event links are set, will need some special handling
    also, compare the new list of links to previous to check for deletes
  */
  private function processEventLinks($linksData, $parentId) {

    $oldEventLinks = EventLink::getByEventId($parentId,true); // withUnpublished = true

    foreach ($linksData as $linkData) {
      $linkData['sourceId'] = $parentId;
      $linkData['targetId'] = $linkData['eventId'];
      $values = UpsertEventLink::getValuesFromData($linkData);

      if (isset($linkData['id']) && $linkData['id'] > 0) { // this is an update to a linkEvent
        unset ($oldEventLinks[$linkData['id']]); // unmark this event from the list of old links, means it was not deleted
        $link = EventLink::load($linkData['id']);
        foreach ($values as $field => $value)
          $link->set($field, $value);
      }
      else $link = EventLink::create($values);
      $link->save();
    }

    // Anything left in $oldEventLinks was a link that was removed during an update
    foreach ($oldEventLinks as $key => $oldEventLink)
      $oldEventLink->delete();

  }

  /**
   * Creates an event.
   *
   * @param array $data
   *   The submitted values for the event.
   *
   * @return \Drupal\graphql_composable\GraphQL\Response\EntityResponse
   *   The newly created event.
   *
   * @throws \Exception
   */
  public function resolve(array $data) {

    // Is this an update or create?
    $response = new EntityResponse();
    $operation = (isset($data['id']) && $data['id'] !== 0) ? "update" : "create";  // id of 0 indicates this is a new entity
    $response->setOperation($operation);
    $values = self::getValuesFromData($data);

    if ($operation == "update")
      $entity = RiskEvent::load($data['id']);
    else if ($operation == "create")
      $entity = RiskEvent::create($values);

    // if current user doesn't have access, deliver unsaved entity and failure message
    if (! $check = $entity->access($operation) ) {
      $response->setEntity($entity); // GraphQL wants to see unsaved entity if possible
      $response->addViolation(
        $this->t('You do not have permission to add or edit risk events. Event was not saved.'),
        ['severity' => 'error','check' => $check]
      );
      return $response;
    }

    // Get and set needed values for upate action
    if ($operation == "update") {
      foreach ($values as $field => $value)
        $entity->set($field, $value);
    }

    // handle status (published, approved, draft)
    $entity->mySetPublished($data['published'] ?? false);
    $entity->setApproved($data['approved'] ?? false);
    $entity->setDraft($data['draft'] ?? false);

    $save_result = $entity->save();
    $eventId = $entity->id();
    $response->setEntity($entity);

    $response->addViolation(
      $this->t("Event was " . ($save_result === SAVED_NEW ? "added" : ($save_result === SAVED_UPDATED ? "updated" : "") )  . ': <a href="/admin/cast/management/event/'.$eventId.'">"' . $entity->title->value . '"</a>'),
      ['severity' => 'status']
    );

    /** Impacts **/
    if (isset($data['impacts']))
      self::processImpacts(
        impactsData: $data['impacts'],
        parentId: $entity->id(),
        response: $response
      );
    // At least one impact is required
    if (empty(EventRiskAssessment::getByEventId($entity->id())) && !$entity->isDraft()) {
      \Drupal::messenger()->addWarning("Event was saved as Draft because it should have at least one Impact");
      $entity->mySetPublished(0);
      $entity->setApproved(0);
      $entity->setDraft(1);
      $entity->save(); // have to save again to set that status update.
    }

    /**  Event Links **/
    if (isset($data['links']))
      self::processEventLinks(
        linksData: $data['links'],
        parentId: $entity->id(),
      );

    // Handle any messages that may have been generated by the save() call for the event, or other entities
    $messages = $this->messenger()->all();
    foreach ($messages as $type => $category) {
      foreach ($category as $message) {
        $response->addViolation($message, ['severity' => $type, 'check' => $check]);
      }
    }
    // We're outputting messages over the response, so can clear them now.
    // This prevents the messages from showing up on the Drupal UI
    $this->messenger()->deleteAll();

    return $response;
  }

}