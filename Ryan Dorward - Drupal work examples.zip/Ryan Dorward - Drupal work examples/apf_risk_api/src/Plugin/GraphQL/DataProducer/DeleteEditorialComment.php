<?php

namespace Drupal\apf_risk_api\Plugin\GraphQL\DataProducer;

use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\apf_risk_entities\Entity\EditorialComment;
use Drupal\apf_risk_api\DeleteEntity;

/**
 * Deletes an Editorial Comment entity.
 *
 * @DataProducer(
 *   id = "delete_editorial_comment",
 *   name = @Translation("Delete Editorial Comment"),
 *   description = @Translation("Deletes an Editorial Comment"),
 *   produces = @ContextDefinition("any",
 *     label = @Translation("Editorial Comment")
 *   ),
 *   consumes = {
 *     "id" = @ContextDefinition("any",
 *       label = @Translation("Editorial Comment")
 *     )
 *   }
 * )
 */

class DeleteEditorialComment extends DeleteEntity {

  protected static function load($id) {     
    return EditorialComment::load($id);  
  }
  
}
