<?php

namespace Drupal\apf_risk_api\Plugin\GraphQL\DataProducer;

use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\apf_risk_entities\Entity\EventRiskAssessment;
use Drupal\apf_risk_api\DeleteEntity;

/**
 * Deletes a risk assessment entity.
 *
 * @DataProducer(
 *   id = "delete_event_risk_assessment",
 *   name = @Translation("Delete Impact"),
 *   description = @Translation("Deletes a CAST Impact."),
 *   produces = @ContextDefinition("any",
 *     label = @Translation("Impact")
 *   ),
 *   consumes = {
 *     "id" = @ContextDefinition("any",
 *       label = @Translation("Impact id")
 *     )
 *   }
 * )
 */
class DeleteImpact extends DeleteEntity {

  protected static function load($id) {
    return EventRiskAssessment::load($id);
  }

}
