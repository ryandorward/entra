<?php

namespace Drupal\apf_risk_api\Plugin\GraphQL\DataProducer;

use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\apf_risk_entities\Entity\EditorialComment;
use Drupal\apf_risk_api\UpsertEntity;

/**
 * Update/Create an Editorial Comment.
 *
 * @DataProducer(
 *   id = "upsert_editorial_comment",
 *   name = @Translation("Upsert Editorial Comment"),
 *   description = @Translation("Update/Create an Editorial Comment."),
 *   produces = @ContextDefinition("any",
 *     label = @Translation("Editorial Comment")
 *   ),
 *   consumes = {
 *     "data" = @ContextDefinition("any",
 *       label = @Translation("Editorial Comment data")
 *     )
 *   }
 * )
 */
class UpsertEditorialComment extends UpsertEntity {

   // Fields that don't need any processing
   protected static $fieldNameMap = [
    'eventId' => 'event',
    'comment',
  ];

  protected static function load($id) {
    return EditorialComment::load($id);
  }

  protected static function createEntity($id) {
    return EditorialComment::create($id);
  }

}