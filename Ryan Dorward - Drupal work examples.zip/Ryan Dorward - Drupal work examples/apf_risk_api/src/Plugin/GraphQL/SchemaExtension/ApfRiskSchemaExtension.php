<?php

namespace Drupal\apf_risk_api\Plugin\GraphQL\SchemaExtension;

require DRUPAL_ROOT . '/pgapi/pgConnection.php';
require DRUPAL_ROOT . '/pgapi/public/getJurisdictions.php';

use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use Drupal\graphql\GraphQL\Response\ResponseInterface;
use Drupal\graphql\Plugin\GraphQL\SchemaExtension\SdlSchemaExtensionPluginBase;
use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use \Drupal\apf_risk_api\Resolvers\BusinessResolvers;
use \Drupal\apf_risk_api\Resolvers\InvestmentResolvers;
use \Drupal\apf_risk_api\Resolvers\ComponentResolvers;
use \Drupal\apf_risk_api\Resolvers\ImpactResolvers;
use \Drupal\apf_risk_api\Resolvers\EventLinkTypeResolvers;
use \Drupal\apf_risk_api\Resolvers\EventLinkResolvers;
use \Drupal\apf_risk_api\Resolvers\EventResolvers;
use \Drupal\apf_risk_api\Resolvers\EventThemeResolvers;
use \Drupal\apf_risk_api\Resolvers\RelatedContentResolvers;
use \Drupal\apf_risk_api\Resolvers\TagResolvers;
use \Drupal\apf_risk_api\Resolvers\UserResolvers;
use \Drupal\apf_risk_api\Resolvers\EditorialCommentResolvers;
use \Drupal\apf_risk_api\Resolvers\ActionResolvers;

/**
 * @SchemaExtension(
 *   id = "apf_risk_extension",
 *   name = "APF CAST extension",
 *   description = "Extension provides read access to the APF CAST schema.",
 *   schema = "apf_risk"
 * )
 */
class ApfRiskSchemaExtension extends SdlSchemaExtensionPluginBase {

  /**
   * {@inheritdoc}
   */
  public function registerResolvers(ResolverRegistryInterface $registry) {
    $builder = new ResolverBuilder();
    EventResolvers::registerResolvers($registry, $builder);
    EventLinkResolvers::registerResolvers($registry, $builder);
    EventLinkTypeResolvers::registerResolvers($registry, $builder);
    ImpactResolvers::registerResolvers($registry, $builder);
    ComponentResolvers::registerResolvers($registry, $builder);
    BusinessResolvers::registerResolvers($registry, $builder);
    InvestmentResolvers::registerResolvers($registry, $builder);
    EventThemeResolvers::registerResolvers($registry, $builder);
    RelatedContentResolvers::registerResolvers($registry, $builder);
    TagResolvers::registerResolvers($registry, $builder);
    UserResolvers::registerResolvers($registry, $builder);
    EditorialCommentResolvers::registerResolvers($registry, $builder);
    ActionResolvers::registerResolvers($registry, $builder);

    // Response type resolver.
    $registry->addTypeResolver('Response', [
      __CLASS__,
      'resolveResponse',
    ]);
  }

  /**
   * Resolves the response type.
   *
   * @param \Drupal\graphql\GraphQL\Response\ResponseInterface $response
   *   Response object.
   *
   * @return string
   *   Response type.
   *
   * @throws \Exception
   *   Invalid response type.
   */
  public static function resolveResponse(ResponseInterface $response): string {
    // Resolve content response.
    if ($response instanceof EntityResponse) {
      return 'EntityResponse';
    }
    throw new \Exception('Invalid response type.');
  }

}