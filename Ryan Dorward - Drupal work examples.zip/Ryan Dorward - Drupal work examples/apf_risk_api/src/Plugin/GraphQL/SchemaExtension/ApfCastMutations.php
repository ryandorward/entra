<?php

namespace Drupal\apf_risk_api\Plugin\GraphQL\SchemaExtension;

use Drupal\graphql\GraphQL\ResolverBuilder;
use Drupal\graphql\GraphQL\ResolverRegistryInterface;
use Drupal\graphql\GraphQL\Response\ResponseInterface;
use Drupal\graphql\Plugin\GraphQL\SchemaExtension\SdlSchemaExtensionPluginBase;
use Drupal\graphql_composable\GraphQL\Response\ArticleResponse;

use \Drupal\apf_risk_api\Resolvers\EventResolvers;
use \Drupal\apf_risk_api\Resolvers\ImpactResolvers;
use \Drupal\apf_risk_api\Resolvers\EditorialCommentResolvers;

/**
 * @SchemaExtension(
 *   id = "apf_cast_mutations_extension",
 *   name = "APF CAST mutations extension",
 *   description = "Extend the APF CAST schema with mutations.",
 *   schema = "apf_risk"
 * )
 */
class ApfCastMutations extends SdlSchemaExtensionPluginBase {

  /**
   * {@inheritdoc}
   */
  public function registerResolvers(ResolverRegistryInterface $registry): void {
    $builder = new ResolverBuilder();
    EventResolvers::registerMutationResolvers($registry, $builder);
    ImpactResolvers::registerMutationResolvers($registry, $builder);
    EditorialCommentResolvers::registerMutationResolvers($registry, $builder);

    // Response type resolver.
    $registry->addTypeResolver('Response', [
      __CLASS__,
      'resolveResponse',
    ]);
  }

  /**
   * Resolves the response type.
   *
   * @param \Drupal\graphql\GraphQL\Response\ResponseInterface $response
   *   Response object.
   *
   * @return string
   *   Response type.
   *
   * @throws \Exception
   *   Invalid response type.
   */
  public static function resolveResponse(ResponseInterface $response): string {
    // Resolve content response.
    if ($response instanceof EntityResponse) {
      return 'EntityResponse';
    }
    throw new \Exception('Invalid response type.');
  }

}