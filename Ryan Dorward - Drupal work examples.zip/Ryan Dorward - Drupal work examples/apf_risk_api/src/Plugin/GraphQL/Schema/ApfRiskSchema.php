<?php

namespace Drupal\apf_risk_api\Plugin\GraphQL\Schema;

use Drupal\graphql\Plugin\GraphQL\Schema\ComposableSchema;

/**
 * @Schema(
 *   id = "apf_risk",
 *   name = "APF Risk schema",
 *   extensions = "apf_risk",
 * )
 */
class ApfRiskSchema extends ComposableSchema {

}
