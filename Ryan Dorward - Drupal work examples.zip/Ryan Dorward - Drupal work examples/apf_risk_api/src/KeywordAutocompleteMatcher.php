<?php
/**
 * @file
 * Contains \Drupal\apf_risk_api\KeywordAutocompleteMatcher
 */

namespace Drupal\apf_risk_api;

use Drupal\Component\Utility\Html;
use Drupal\Component\Utility\Tags;
use Drupal\Core\Entity\EntityAutocompleteMatcher;
use Drupal\apf_risk_entities\Entity\EventTheme;

class KeywordAutocompleteMatcher extends EntityAutocompleteMatcher {

  /**
   * Gets matched labels based on a given search string.
   */

  public static function getVocabularyTermIds($vocabulary, $words = [],$excludes=[],$canonical=false) {
    if (!empty($words) && !is_array($words))
      $words= [$words];
    $query = \Drupal::entityQuery('taxonomy_term')
      ->condition('vid', $vocabulary);
    if (!empty($excludes))
      $query->condition('tid', $excludes, 'NOT IN');
    if (!empty($words)) foreach ($words as $word)
      $query->condition('name', $word, 'CONTAINS');
    if ($canonical) {
      $tag_ids = array_keys(EventTheme::getCannonicalTagIds());
      $query->condition('tid', $tag_ids, 'IN');
    }
    $tids = $query->execute();
    return $tids;
  }

  //public function getMatches($vocabulary, $selection_handler=null, $selection_settings, $string = '', $excludes=[], $canonical=false) {
  public function getMatches($vocabulary, $selection_settings, $selection_handler=null, $string = '', $excludes=[], $canonical=false) {

    $matches = [];
    if (isset($string)) {
      $string = mb_strtolower($string);
      $words = explode(' ', $string);
      $ids = self::getVocabularyTermIds($vocabulary, $words, $excludes, $canonical);
      $entities = \Drupal::entityTypeManager()
        ->getStorage('taxonomy_term')
        ->loadMultiple($ids);
      $canonical_ids = EventTheme::getCannonicalTagIds();
      foreach ($entities as $entity) {
        $matches[] = [
          'name' => $entity->label(),
          'id' => (int) $entity->id(),
          'isCanonical' => isset($canonical_ids[$entity->id()]), // faster than in_array
          'description' => $entity->field_description->value,
        ];
      }
      // now sort matches by canoncial, with canonical tags first
      usort($matches, function($a, $b) {
        if ($a['isCanonical'] == $b['isCanonical']) return 0;
        return ($a['isCanonical'] > $b['isCanonical']) ? -1 : 1;
      });

      // limit matches to a maximum of 30. As of right now we are using 12 for the Admin UI
      if (count($matches) > 30) {
        $matches = array_slice($matches, 0, 30);
      }

    }
    return $matches;
  }

}