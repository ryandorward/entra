<?php

namespace Drupal\apf_risk_api\Controller;

use Drupal\system\Controller\EntityAutocompleteController;
use Drupal\Component\Utility\Tags;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Drupal\apf_risk_api\RiskEntityAutocompleteMatcher;
use Drupal\Core\KeyValueStore\KeyValueStoreInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Defines a route controller for entity autocomplete form elements.
 */
class RiskEntityAutocompleteController extends EntityAutocompleteController {

  /**
   * The autocomplete matcher for entity references.
   */
  protected $matcher;

  /**
  * {@inheritdoc}
  */
  public function __construct(RiskEntityAutocompleteMatcher $matcher, KeyValueStoreInterface $key_value) {
    $this->matcher = $matcher;
    $this->keyValue = $key_value;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('apf_risk_api.autocomplete_matcher'),
      $container->get('keyvalue')->get('entity_autocomplete')
    );
  }

  /**
   * Autocomplete the label of an entity.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The request object that contains the typed tags.
   * @param string $target_type
   *   The ID of the target entity type.
   * @param string $selection_handler
   *   The plugin ID of the entity reference selection handler.
   * @param string $selection_settings_key
   *   The hashed key of the key/value entry that holds the selection handler
   *   settings.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   The matched entity labels as a JSON response.
   *
   * @throws \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException
   *   Thrown if the selection settings key is not found in the key/value store
   *   or if it does not match the stored data.
   */
  public function handleAutocomplete(Request $request, $target_type, $selection_handler, $selection_settings_key = null) {
    $matches = [];

    $userRoles = \Drupal::currentUser()->getRoles();

    // protect this API
    if (! in_array('risk_analyst',$userRoles) && ! in_array('risk_user',$userRoles) && ! in_array('risk_jr_analyst',$userRoles))
      throw new AccessDeniedHttpException('Access Denied.');

   // $typed_string = Tags::explode($input);
    // $typed_string = mb_strtolower(array_pop($typed_string));

    // @todo: for now the valid target types are hardwired in, but perhaps should gather entity types dynamically from apf_risk_entities
    $valid_target_types = [
      'risk_event',
      'risk_event_link',
      'risk_event_link_type',
      'event_risk_assessment',
      'risk_category',
      'risk_component',
    ];
    if (! in_array($target_type, $valid_target_types))
      throw new AccessDeniedHttpException('Access Denied. Invalid type.');

    if ($data = $request->getContent()) {
      $data = json_decode($data);
      if (isset($data->search)) {
        $typed_string = Tags::explode($data->search);
        $typed_string = mb_strtolower(array_pop($typed_string));
        $before = $data->before ?? null;
        $withUnpublished = $data->withUnpublished ?? false;
        $exclude = $data->excludes ?? null;
        $excludes = explode(',', $exclude);
        $limit = $data->limit ?? 10;
        $matches = $this->matcher->getMatches($target_type, $selection_handler, [], $typed_string, $before, $withUnpublished, $excludes, $limit);
      }
    }

    return new JsonResponse($matches);

    /* This is the old way from when we were using the GET method:

    // Get the typed string from the URL, if it exists.
    if ($input = $request->query->get('q')) {

      $typed_string = Tags::explode($input);
      $typed_string = mb_strtolower(array_pop($typed_string));

      // @todo: for now the valid target types are hardwired in, but perhaps should gather entity types dynamically from apf_risk_entities
      $valid_target_types = [
        'risk_event',
        'risk_event_link',
        'risk_event_link_type',
        'event_risk_assessment',
        'risk_category',
        'risk_component',
      ];
      if (! in_array($target_type, $valid_target_types))
        throw new AccessDeniedHttpException('Access Denied.');

      $before = $request->query->get('before');
      $withUnpublished = $request->query->get('withUnpublished') ?? false;
      $exclude = $request->query->get('exclude') ?? null;
      $excludes = explode(',', $exclude);
      $limit = $request->query->get('limit') ?? 10;
      $matches = $this->matcher->getMatches($target_type, $selection_handler, [], $typed_string, $before, $withUnpublished, $excludes, $limit);
    }

    return new JsonResponse($matches);
    */
  }

}