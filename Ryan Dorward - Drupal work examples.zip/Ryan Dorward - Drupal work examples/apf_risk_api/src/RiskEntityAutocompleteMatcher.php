<?php

namespace Drupal\apf_risk_api;

use Drupal\Component\Utility\Html;
use Drupal\Component\Utility\Tags;
use Drupal\Core\Entity\EntityAutocompleteMatcher;
use Drupal\entraTools\my;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\datetime\Plugin\Field\FieldType\DateTimeItemInterface;
use \Drupal\apf_risk_entities\Entity\RiskEvent;
use \Drupal\apf_risk_api\KeywordAutocompleteMatcher;

class RiskEntityAutocompleteMatcher extends EntityAutocompleteMatcher {

  /**
   * Gets matched labels based on a given search string.
   */
  public function getMatches(
    $target_type, $selection_handler, $selection_settings,
    $string = '', $date = '', $withUnpublished = false,
    $excludes = [], $limit =10
  ) {

    $entities = [];
    $matches = [];

    if (isset($string)) {
      if ($target_type !== 'risk_event') // only support risk_event for now
        throw new \Exception('This API does not support target type ' . $target_type);

      $entity_type = \Drupal::entityTypeManager()
        ->getDefinition($target_type); // need entityManager still
      $label_key = $entity_type->getKey('label'); // We want to search on the entity's primary label field

      if ($target_type == 'risk_event') {

        $entities = RiskEvent::getEventsFromSearch(
          $string, $date, $withUnpublished, $excludes, $limit
        );

        foreach ($entities as $entity) {
          $matches[] = [
            'label' => $entity->label(),
            'id' => (int) $entity->id(),
            'date' => $entity->event_date->date ? $entity->event_date->date->format("Y-m-d") : '',
            'published' => $entity->isPublished(),
          ];
        }

      }
    }

    return $matches;
  }

}