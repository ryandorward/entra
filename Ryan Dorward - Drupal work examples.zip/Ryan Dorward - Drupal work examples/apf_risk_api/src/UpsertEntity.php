<?php

namespace Drupal\apf_risk_api;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\graphql\Plugin\GraphQL\DataProducer\DataProducerPluginBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

use Drupal\apf_risk_entities\RiskEntityBase;
use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;
use Drupal\taxonomy\Entity\Term;

class UpsertEntity extends DataProducerPluginBase implements ContainerFactoryPluginInterface {

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $currentUser;

  // Elements in this array can be;
  // A) A string when the API field name matches internal Entity field name
  // or B) a map of: "{api_field_name}" => "{entity_field_name}"
  protected static $fieldNameMap = [];

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('current_user')
    );
  }

  /**
   * CreateEvent constructor.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param array $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Session\AccountInterface $current_user
   *   The current user.
   */
  public function __construct(array $configuration, string $plugin_id, array $plugin_definition, AccountInterface $current_user) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->currentUser = $current_user;
  }

  // format submitted data to valid entity values
  protected static function getValuesFromData($data) {
    $values = [];
    // map base values that don't need any processing
    foreach (static::$fieldNameMap as $key => $value) {
      if (is_int($key) && isset($data[$value]))
        $values[$value] = $data[$value];
      /*
      else if (is_int($key) && !isset($data[$value])) {
        $values[$value] = null;
      }
      */
      else if (is_string($key) && isset($data[$key]))
        $values[$value] = $data[$key];
    }
    // error_log(print_r($values, TRUE));
    return $values;
  }

  protected static function getTagValuesFromData($data) {

    $vocabulary = 'vocabulary_4';

    if (isset($data)) {
      $value = [];
      foreach ($data as $tag) {
        if (isset($tag['id']))
          $value[] = $tag['id'];
        else if (isset($tag['name'])) {

          //first check if the name already exists in the vocabulary:
          // (its possible someone typed in an existing name, instead of re-using the existing term)
          $tids = \Drupal::entityQuery('taxonomy_term')
            ->condition('name', $tag['name'])
            ->condition('vid', $vocabulary)
            ->execute();
          if (count($tids))
            $value[] = array_pop($tids); // use the last item that matches

          else { // otherwise make a new term and use that
            $term = Term::create([
              'name' => $tag['name'],
              'vid' => $vocabulary,
            ]);
            $term->save();
            $value[] = $term->id();
          }

        }
      }
      return $value;
    }

  }

  protected static function load($id) {
    return RiskEntityBase::load($id);
  }

  protected static function createEntity($id) {
    return RiskEntityBase::create($id);
  }

  /**
   * Creates an entity
   *
   * @param array $data
   *   The submitted values for the event.
   *
   * @return \Drupal\graphql_composable\GraphQL\Response\EntityResponse
   *   The newly created event.
   *
   * @throws \Exception
   */
  public function resolve(array $data) {
    $response = new EntityResponse();

    $operation = (isset($data['id']) && $data['id'] !== 0) ? "update" : "create";  // id of 0 indicates this is a new entity
    $values = static::getValuesFromData($data);

    if ($operation == "update")
      $entity = static::load($data['id']);
    else if ($operation == "create")
      $entity = static::createEntity($values);

    if (! $entity) {
      $response->addViolation(
        $this->t(($operation=='update'?"Could not find entity with id $id":"Could not create entity")),
        ['severity' => 'error']
      );
      return $response;
    }

    $typeLabel = $entity->getEntityType()->getLabel();

    // if current user doesn't have access, deliver unsaved entity and failure message
    if (! $entity->access($operation) ) {
      $response->addViolation(
        $this->t("You do not have permission to $operation the $typeLabel. $typeLabel was not saved."),
        ['severity' => 'error']
      );
    }
    else {
      // Set values for upate action
      if ($operation == "update") {
        foreach ($values as $field => $value)
          $entity->set($field, $value);
      }
      if ($entity->save()) {
        $response->addViolation(
          $this->t("$typeLabel was saved" . ': "' . $entity->label() . '"'),
          [ 'severity' => 'success']
        );
      }
    }

    if (! $entity->access("view") ) {
      $response->addViolation(
        $this->t("You do not have permission to view $typeLabel $id"),
        ['severity' => 'error']
      );
    }
    else
      $response->setEntity($entity);

    return $response;
  }

}