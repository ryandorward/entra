<?php

namespace Drupal\apf_risk_api;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\graphql\Plugin\GraphQL\DataProducer\DataProducerPluginBase;
use Drupal\apf_risk_api\GraphQL\Response\EntityResponse;

use Symfony\Component\DependencyInjection\ContainerInterface;

use Drupal\apf_risk_entities\RiskEntityBase;

class DeleteEntity extends DataProducerPluginBase implements ContainerFactoryPluginInterface {

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $currentUser;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('current_user')
    );
  }

  /**
   * DeleteEvent constructor.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param array $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Session\AccountInterface $current_user
   *   The current user.
   */
  public function __construct(array $configuration, string $plugin_id, array $plugin_definition, AccountInterface $current_user) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->currentUser = $current_user;
  }

  protected static function load($id) {
    return RiskEntityBase::load($id);
  }

  /**
   * Deletes a risk entity.
   *
   * @param int $id
   *   The submitted values for the event.
   *
   * @return \Drupal\graphql_composable\GraphQL\Response\EntityResponse
   *   The deleted event (should be null?).
   *
   * @throws \Exception
   */
  public function resolve(int $id) {
    $response = new EntityResponse();
    $entity = static::load($id);

    if (! $entity) {
      $response->addViolation(
        $this->t("Could not find entity with id $id"),
        ['severity' => 'error']
      );
      return $response;
    }

    $typeLabel = $entity->getEntityType()->getLabel();

    if (! $entity->access("view") ) {
      $response->addViolation(
        $this->t("You do not have permission to view $typeLabel $id"),
        ['severity' => 'error']
      );
    }
    else
      $response->setEntity($entity); // GraphQL wants to see unsaved entity if possible

    if (! $entity->access("delete") ) {
      $response->addViolation(
        $this->t("You do not have permission to Delete $typeLabel $id"),
        ['severity' => 'error',]
      );
    }
    $entity->delete();
    $response->addViolation(
      $this->t("$typeLabel was deleted"   . ': "' . $entity->label() . '"'),
      [ 'severity' => 'success']
    );


    return $response;
  }

}
