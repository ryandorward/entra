<?php

/**
 * @file
 * Contains \Drupal\apf_risk_ui\Util.
 */

namespace Drupal\apf_risk_ui;

class Util {
  static public function isRiskSub() {
    // Check if we're on risk subdomain
    $sub = explode('.',  $_SERVER['HTTP_HOST'])[0];
    if ($sub == 'risk' || $sub == 'cast') return true;
    else return false;
  }
}