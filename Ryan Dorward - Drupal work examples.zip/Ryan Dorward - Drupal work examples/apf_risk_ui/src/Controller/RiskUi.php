<?php

/**
 * @file
 * Contains \Drupal\apf_risk_ui\Controller\RiskUi.
 */

namespace Drupal\apf_risk_ui\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Routing\TrustedRedirectResponse;
use Drupal\entraTools\my;
use Drupal\apfHelper\Controller\Insights;

class RiskUi extends ControllerBase {

  public static function home() {

    $current_user = \Drupal::currentUser();
    $protectCast = false;

    if ($protectCast && !in_array('risk_analyst',$current_user->getRoles()) && !in_array('risk_user',$current_user->getRoles()))
      throw new \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException();

    $ids = \Drupal::entityQuery('node')
      ->condition('type','publication')
      ->condition('status', 1)
      ->condition('field_publication_type', 'cast-insight')
      ->sort('created', $direction = 'DESC')
      ->execute();

    // load the nodes
    $nodes = \Drupal\node\Entity\Node::loadMultiple($ids);

    $insights = array_map(function($node) {
      return [
        'id' => $node->id(),
        'title' => $node->title->value,
        'path' => $node->getMyLink(),
        'published' => $node->isPublished(),
        'imageSources' => my::getImageSources($node->getMyKeystoneImageField()),
        'posted' => $node->getPublishedFormatted(),
        'region' => Insights::getRegion($node),
      ];
    },$nodes);
    $insights = array_values($insights); // this is to prevent it from being a keyed array, which is not what we want on the other end for hte react app

    return [
      '#markup' => '<div id="root" data-context="drupal"></div>',
      '#attached' => [
        'library' => 'apf_risk_ui/ui',
        'drupalSettings' => [
          'apfRiskUi' => [
            'userRoles' => $current_user->getRoles(),
            'insights' => $insights, // @todo: get rid of this insights, just load over API
          ],
        ],
      ],
      '#cache' => [
        'tags' => ['node_list:publication'],
      ],
    ];
  }

  // using the main controller presently, so this is not being used.
  // @todo: load insights via API
  public static function insights() {
    $build = self::home();

    $ids = \Drupal::entityQuery('node')
      ->condition('type','publication')
      ->condition('status', 1)
      ->condition('field_publication_type', 'cast-insight')
      ->sort('created', $direction = 'DESC')
      ->execute();

    // load the nodes
    $nodes = \Drupal\node\Entity\Node::loadMultiple($ids);

    $insights = array_map(function($node) {
      return [
        'id' => $node->id(),
        'title' => $node->title->value,
        'path' => $node->getMyLink(),
        'published' => $node->isPublished(),
        'imageSources' => my::getImageSources($node->getMyKeystoneImageField()),
        'posted' => $node->getPublishedFormatted(),
      ];
    },$nodes);
    $insights = array_values($insights); // this is to prevent it from being a keyed array, which is not what we want on the other end for hte react app

    $build['#attached']['drupalSettings']['apfRiskUi']['insights'] = $insights;
    return $build;

  }

  public static function homeRedirector() {
    $host = \Drupal::request()->getHost();
    $host_names = explode(".", $host);
    $bottom_host_name = $host_names[count($host_names)-2] . "." . $host_names[count($host_names)-1];
    $scheme = \Drupal::request()->getScheme();
    return new TrustedRedirectResponse($scheme . '://cast.' . $bottom_host_name);
  }

}