<?php

namespace Drupal\apf_risk_ui\Theme;

use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Theme\ThemeNegotiatorInterface;
use Drupal\apf_risk_ui\Util;

/**
 * Class ApfRiskUiThemeNegotiator.
 *
 * @package Drupal\apf_risk_ui
 */
class ApfRiskUiThemeNegotiator implements ThemeNegotiatorInterface {
  /**
   * {@inheritdoc}
   */
  public function applies(RouteMatchInterface $route_match) {
    if (Util::isRiskSub()) {
      $route = $route_match->getRouteName();
      if ($route && (($route == "apfHelper.home") || preg_match('/^apf_risk_ui\./',$route)))
        return true; // use the theme for all risk. subdomain using apf_risk_ui routes, or the homepage with risk subdomain
    }
    return false;
  }

  /**
   * {@inheritdoc}
   */
  public function determineActiveTheme(RouteMatchInterface $route_match) {
    return 'apf_risk_front';
  }

}