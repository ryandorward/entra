import { host as home } from './url.js'
import { login } from './drupalLogin.js'

describe('Walk through',(done)=>{
	beforeEach(()=>{
		login()
	})
	/*
	it('appears as expected',()=>{
		cy.visit(`${home}/timeline/event/999`)
		cy.get('.shepherd-content').contains(/don't show me this again/i).click()
		cy.contains(/got it/i).click()
		cy.get('.shepherd-content').should('not.exist').then(()=>{
			expect(window.localStorage.getItem('event-tour-complete')).to.eq('true')
		})
	})
	*/
})
