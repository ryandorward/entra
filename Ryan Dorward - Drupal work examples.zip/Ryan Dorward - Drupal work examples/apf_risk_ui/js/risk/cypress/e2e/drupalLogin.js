Cypress.Commands.add('login', (username,password) => {
  cy.session([username,password], () => {
    let creds = { name: username, pass: password }
    cy.request('POST', 'http://www.asiapacific.local/user/login?_format=json', creds).then(
      (response) => {
        expect(response.body.current_user).to.have.property('name', creds.name)
      }
    )
  })
})

export function login() {
	if (Cypress.env('environment') == "dev-drupal")
		cy.login(Cypress.env('username'), Cypress.env('password'))
}