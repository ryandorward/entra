export const host = Cypress.env('host')
export const home = Cypress.env('environment') == 'dev-drupal' ? `${host}/apfhome` : host
