import { host as home } from './url.js'
import { login } from './drupalLogin.js'

describe('Initial settings',(done)=>{
	beforeEach(()=>{
		login()

	})
	it('have menu start closed, openable',()=>{
		cy.visit(`${home}/timeline/events`)
		window.localStorage.setItem('event-tour-complete',true)
		cy.get('.main-menu.collapsed').should('exist').click()
		cy.get('.main-menu.open').should('exist')
		// cy.reload()
		// cy.get('.main-menu.open').should('exist')
	})
	/*
	// Got rid of the more/less button Nov 14 2022
	it('are inclined to read less',()=>{
		cy.visit(`${home}/timeline/event/999`)
		window.localStorage.setItem('event-tour-complete',true)
		cy.contains('...read more').click()
		cy.contains('show less')
		cy.reload()
		cy.contains('show less')
	})
	*/

	/*
	it('have legend displayed',()=>{
		cy.visit(`${home}/map/events`)
		window.localStorage.setItem('event-tour-complete',true)
		cy.get('.legend.open').should('exist').contains('Legend').click()
		cy.get('.legend.collapsed').should('exist')
		cy.reload()
		cy.get('.legend.collapsed').should('exist')
	})
	*/

	// got rid of indirect query option Dec 1 2022
	/*
	it('display direct impacts only',()=>{
		cy.visit(`${home}/timeline/events/jurisdiction/6`)
		window.localStorage.setItem('event-tour-complete',true)
		cy.get('input#indirect').should('not.be.checked').check()
		cy.reload()
		cy.get('input#indirect').should('be.checked')
	})
	*/
})
