(Cypress.env('environment') == 'dev-drupal') && describe('Test embedded CAST components on APF homepage', () => {

	beforeEach(() => {
		cy.visit("http://asiapacific.local")
  })

	it('Check CAST headlines', () => {
		cy.get('.cast-headlines').find('#CAST-headlines')
    cy.get('.cast-headlines #CAST-headlines').find('.headline',{ timeout: 10000 })

		// Tagtrends has been removed from the homepage
    // cy.get('.cast-tagtrends').find('#CAST-tagtrends')
    // cy.get('.cast-tagtrends #CAST-tagtrends').find('.frequency-stream svg',{ timeout: 10000 })
	})

})
