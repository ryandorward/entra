import { home } from './url.js'
import { login } from './drupalLogin.js'

describe('Single event pages', () => {
	beforeEach(()=>{
		login()
		window.localStorage.setItem('event-tour-complete',true)
		cy.visit(home)
	})
	it("display title, date, sources, tags, themes, jurisdictions", () => {
		for (var i = 0; i < 3; i++) {
			window.localStorage.setItem('event-tour-complete',true)
			// click on Nth/3 headlines from homepage
			cy.get(".headline").eq(i).click()
			cy.get(".panel")
				.find("h1")
				.invoke("text")
				.its("length")
				.should("be.gt", 10)
				.should('be.lt',200)
			cy.get(".source-links"); // source
			cy.get('.date').contains(/20\d{2}/); // a year this century (format varies per locale)
			cy.get('.panel').find('a[href*="tag"]')
			cy.get('.panel').find('a[href*="theme"]')
			cy.get('.panel').find('a[href*="jurisdiction"]')
			cy.go("back");
		}
	});
});
