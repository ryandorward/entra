import { host } from './url.js'
import { login } from './drupalLogin.js'

const waitInterval = 200

describe('Visit page about', () => {

	beforeEach(() => {
    login()
  })
	it('About CAST, methodology', () => {
		cy.visit(`${host}/about`).get('h1')
		// get the href containing href='/about/methodology', click it
		cy.get('a[href*="/about/methodology"]').first().click()
		cy.contains(/Methodology/i)
		cy.wait(waitInterval)
	})

	/*

	// pause testing on these sections, since they're currently not accessible via the GUI

	it('twinning data', () => {
		cy.visit(`${host}/about/methodology/connections/twinning`).get('p')
		cy.wait(waitInterval)
	})
	it('jurisdictions data', () => {
		cy.visit(`${host}/about/methodology/jurisdictions`).get('p')
		cy.wait(waitInterval)
	})
	it('the ESG framework', () => {
		cy.visit(`${host}/about/methodology/events/ESG`).get('p')
		cy.wait(waitInterval)
	})
	it('FDI data', () => {
		cy.visit(`${host}/about/methodology/connections/investment`).get('p')
		cy.wait(waitInterval)
	})
	it('Canadian business data', () => {
		cy.visit(`${host}/about/methodology/connections/business`).get('p')
		cy.wait(waitInterval)
	})
	it('diplomatic and trade missions data', () => {
		cy.visit(`${host}/about/methodology/connections/diplomacy`).get('p')
		cy.wait(waitInterval)
	})
	*/

	/*
	This test doesn't work on standalone because it depends on data coming from the Drupal site *
	it('insights', () => {
		cy.visit(`${host}/insights`,{ timeout: 40000 }).get('.publication-card')
		cy.get('button.region-filter').contains(/South Asia/i).click().get('.publication-card')
		cy.wait(waitInterval)
	})
	*/


	/*
	it('methodology', () => {
		cy.visit(`${host}/about/methodology`)
		cy.contains(/Methodology/i)
		cy.wait(waitInterval)
	})
	*/
	it('a particular jurisdiction', () => {
		cy.visit(`${host}/map/events/jurisdiction/3`).get('h1')
		cy.wait(waitInterval)
	})
	it("What's happening in", () => {
		cy.visit(`${host}/map/events/theme/19`).get('.event-theme-header')
		cy.wait(waitInterval)
	})
	it('single event', () => {
		cy.visit(`${host}/map/event/1015`).get('p')
		cy.wait(waitInterval)
	})
	it('Events tagged', () => {
		cy.visit(`${host}/map/events/tag/8364`).get('h1')
		cy.wait(waitInterval)
	})
	it('trade agreements of a jurisdiction', () => {
		cy.visit(`${host}/map/connections/trade/jurisdiction/2?tab=1`).get('h3')
		cy.wait(waitInterval)
	})


})
