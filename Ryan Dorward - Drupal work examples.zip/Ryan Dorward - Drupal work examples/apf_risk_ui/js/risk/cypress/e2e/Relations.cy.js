import { host as home } from './url.js'
import { login } from './drupalLogin.js'


describe('Connections exist between jurisdictions', () => {

  beforeEach(() => {
    login()
  })

  it('Find Japan', () => {
    /*
    cy.visit(home)
    cy.contains(/search for a jurisdiction/i)
      .parent()
      .find('input')
      .type('japan')
    cy.get('[id*="option"]').contains(/^Japan$/).click()
    cy.url().should('include','/jurisdiction/4')
    */
    cy.visit(`${home}/timeline/events/jurisdiction/4`)
    cy.contains('Japan')
  })
  it('Japan has connections with Canada', () => {
    cy.visit(`${home}/map/jurisdiction/4`)
    cy.contains('a','Connections').click()
    cy.contains('Canada')
  })
  it('Canadian ties with Japan - Twinning', () => {
    cy.visit(`${home}/map/connections/jurisdiction/4`)
    cy.contains('twinning relations').click()
    cy.get('.twin')
  })
  it('Canadian ties with Japan - Businesses', () => {
    cy.visit(`${home}/map/connections/business/jurisdiction/4`)
    cy.get('ul.bizlist').find('a').its('length').should('be.gt',30)
  })
  it('Canadian ties with Japan - Investments', () => {
    cy.visit(`${home}/map/connections/investment/jurisdiction/4`)
    cy.contains('$',{ timeout: 10000 })
    cy.contains('div.investment-jur-summary','Canada')
    cy.contains('div.investment-jur-summary','Japan').get('.children')
      .within( () => {
        //iterating through first 4 prefectures of the list under Japan
        for(var i= 0; i<3; i++){
          cy.get('div.investment-jur-summary').eq(i).within(()=>{
            cy.get('.expand-icon').click()
            //check if it has investment numbers
            cy.contains('$').should('exist')
            cy.get('.collapse-icon').click()
            // no investment numbers displayed once collapsed
            cy.contains('$').should('not.exist')
          })
        }
      })
  })
})
