import { home } from './url.js'
import { login } from './drupalLogin.js'


describe('Basic user-stories', () => {

	beforeEach(() => {
    login()
		cy.visit(home, { timeout: 40000 })
		window.localStorage.setItem('event-tour-complete',true)
  })

	it("Check for tooltips corresponding to some events, Make sure map has some Markers", () => {
		for (var i = 0; i < 3; i++) {
			cy.get(`.top-events .headline`,{ timeout: 20000 }).eq(i).should(($headline) => {
				const title = $headline.find('.title').text()
				const id = $headline.attr('data-id')
				console.log(`title: ${title} id: ${id}`)
				expect(title).to.be.a('string')
				id && cy.get(`.react-tooltip .event-link.event-${id}`).contains(title)
			})
		}
		cy.get(".mapboxgl-map").find(".mapboxgl-marker")
	})

	it('Read about the event behind a headline on the homepage', () => {
		cy.get('.headline',{ timeout: 90000 }).find('.age') // this has a very long timeout because this script is doubling as a cache-warmer, and this first load can take a very long time
		cy.get('.frequency-stream svg',{ timeout: 200001 }) // this also need a long timeout because it's a long-running process when the caches aren't warm
		cy.get('.headline').find('.region-label')
		cy.get('.headline').eq(0).click()
		cy.url().should('match',/\/map\/event\/\d+/)
		cy.get('h2')
		cy.get('.date')
		cy.get('.description')
	})

	it('Check for Mapbox map on homepage', () => {
		cy.get('.mapboxgl-map').find('.mapboxgl-canvas') // make sure map has loaded
		cy.get('.react-tabs__tab-list').find('.react-tabs__tab:nth-child(2)').click() // switch to charts tab
    cy.get('.trending-tags').find('.frequency-stream svg',{ timeout: 10000 })
	})


	// There is currently not a way on the homepage to navigate to see a jurisdiction directly.
	// Not running this test currently
	/*
	it("Do some digging on Japan", () => {
		cy.visit(home);
		cy.contains(/search for a jurisdiction/i)
			.parent().find('input').type('japan')
		cy.get('[id*="option"]').eq(0).click()
		cy.url().should('match',/\/map\/jurisdiction\/4/i)
		cy.contains('Japan')
		cy.contains(/Connections/i).click();
		cy.contains(/investments/i)
  });
	*/

})
