var webpack = require('webpack')
const { merge } = require('webpack-merge')
const common = require('./common.js')
const path = require('path')
const dotenv = require('dotenv').config(
	{ path: path.resolve(__dirname, '../.env') }
)

module.exports = merge(common, {
	mode: 'production',
	watch: false,
	devtool: 'source-map',
	plugins: [
		new webpack.DefinePlugin({
			'process.env.REACT_APP_CREDS': JSON.stringify(dotenv.parsed)
		}),
	],
	optimization: {
		// @todo: experiment with removing these optimization settings
		// to find minimum settings customization that don't break production
		// The necessary one is likely sideEffects: false
    minimize: false,
    removeAvailableModules: true,
    usedExports: true,
    concatenateModules: true,
    sideEffects: false, // <----- in prod defaults to true if left blank
	}
} )
