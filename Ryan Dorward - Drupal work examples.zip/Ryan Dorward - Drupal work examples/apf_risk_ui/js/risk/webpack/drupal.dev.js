const { merge } = require('webpack-merge')
const dev = require('./dev.js')
const drupal = require('./drupal.js')

module.exports = merge(dev,drupal)
