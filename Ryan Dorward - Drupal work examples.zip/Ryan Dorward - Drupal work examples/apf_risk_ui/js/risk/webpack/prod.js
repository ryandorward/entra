const { merge } = require('webpack-merge')
const common = require('./common.js')

module.exports = merge(common, {
	mode: 'production',
	watch: false,
	devtool: 'source-map',
	//devtool: 'inline-source-map',
	performance: {
		maxEntrypointSize: 350000, // 350kb
		maxAssetSize: 350000 // 350kb
   },
	optimization: {
		// @todo: experiment with removing these optimization settings
		// to find minimum settings customization that don't break production
		// The necessary one is likely sideEffects: false
    minimize: true,
    removeAvailableModules: true,
    usedExports: true,
    concatenateModules: true,
    sideEffects: false, // <----- in prod defaults to true if left blank
	}
} )
