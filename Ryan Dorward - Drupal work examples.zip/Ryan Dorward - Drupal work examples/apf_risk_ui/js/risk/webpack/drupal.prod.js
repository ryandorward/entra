const { merge } = require('webpack-merge')
const prod = require('./prod.js')
const drupal = require('./drupal.js')

module.exports = merge(prod,drupal)
