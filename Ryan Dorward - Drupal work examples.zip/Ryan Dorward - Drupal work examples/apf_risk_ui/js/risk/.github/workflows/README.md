# Automated linting + integration testing

This script tells Github to automatically run linting and integration tests for PRs on the master branch. 
