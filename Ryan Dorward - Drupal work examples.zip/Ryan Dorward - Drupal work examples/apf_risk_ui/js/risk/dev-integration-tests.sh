#!/bin/bash
echo "Running lint"
npm run lint
echo "Running headless cypress tests. If you need to run them in the browser, use: npx cypress open"
echo "To run a singe test: e.g.: npx cypress run --spec cypress/e2e/basic.cy.js" 
npx cypress run 
