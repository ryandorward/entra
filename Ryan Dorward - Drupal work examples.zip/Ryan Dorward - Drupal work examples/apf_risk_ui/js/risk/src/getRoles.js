const aliases = [
	{ ui: 'developer' },
	{ ui: 'analyst', drupal: 'risk_analyst' },
	{ ui: 'jrAnalyst', drupal: 'risk_jr_analyst' },
	{ ui: 'user', drupal: 'risk_user' }
]

export function roles(){
	const givenRoles = window.drupalSettings?.apfRiskUi?.userRoles;
	if(givenRoles){
		const highestRoleIndex = aliases.findIndex(r=>givenRoles.includes(r?.drupal))
		return aliases.slice(highestRoleIndex).map(r=>r.ui)
	}
	// if undefined, then this *should* be a local build not served by drupal
	// ergo, a developer, so assign all roles
	return aliases.map(r=>r.ui);
}

export function isBetaTester(){
	return window.drupalSettings?.apfRiskUi?.userRoles?.includes('cast_beta')
}

export function isDeveloper(){
	return window.drupalSettings?.apfRiskUi?.userRoles?.includes('senior_admin')
}