import { lazy, useEffect } from 'react'
import { Routes, Route, Navigate, useLocation, useParams } from 'react-router-dom'
import { useReactiveVar } from '@apollo/client'
import ReactGA from 'react-ga4'

import Frame from './layouts/AppMenuLayout'
import ProsePage from './layouts/ProsePage'
import GridPage from './layouts/GridPage'
import VisPage from './layouts/VisPage'

import './styles/main.less'

// const MapLayoutOld = lazy(()=>import('./maps/MapLayout-old'))
const MapLayout = lazy(()=>import('./maps/MapLayout'))

const Pages = {
	// Home: lazy(()=>import('./HomePage/index.jsx.off')),
	topics: {
		people: lazy(()=>import('./topics/PeopleAndCulture')),
		business: lazy(()=>import('./topics/BusinessAndTrade')),
		research: lazy(()=>import('./topics/Research')),
		vis: lazy(()=>import('./topics/Vis'))
	},
	about: {
		index: lazy(()=>import('./doc')),
		api: lazy(()=>import('./doc/API')),
		methodology: lazy(()=>import('./doc/Method')),
		connections: lazy(()=>import('./connections/doc')),
		events: {
			index: lazy(()=>import('./events/doc')),
			sources: lazy(()=>import('./events/doc/FindingSources'))
		},
		esg: lazy(()=>import('./events/ESG/doc')),
		business: lazy(()=>import('./connections/business/doc')),
		jurisdictions: lazy(()=>import('./jurisdictions/doc')),
		twinning: lazy(()=>import('./connections/twinning/doc')),
		diplomacy: lazy(()=>import('./connections/diplomacy/doc')),
		investment: lazy(()=>import('./connections/investment/doc')),
		terms: lazy(()=>import('./doc/Terms')),
	},
	Theme: lazy(()=>import('./events/themes/AboutPage')),
	source: lazy(()=>import('./events/sources/Known')),
	Insights: lazy(()=>import('./Pages/Insights')),
	contact: lazy(()=>import('./doc/Contact')),
	// jurisdictions: lazy(()=>import('./topics/BrowseJurisdictions2')),
}

import { titleVar } from './components/Title'

import { mapTypes } from './maps/mapTypes.js'
const StatsPages = lazy(()=>import('./events/stats/Routes'))

export default function() {

	const { pathname } = useLocation()
	const title = useReactiveVar(titleVar)

	useEffect(() => {
		/*
		setTimeout(() => {
			// const path = pathname + search
			const gaObj = { hitType: "pageview", page: pathname, title: document.title }
			console.log('gaObj',gaObj)
			ReactGA.send(gaObj)
		}, 4000);
		*/
		// title(null)
		titleVar(null)
	}, [pathname])

	useEffect(() => {
		if (title) {
			const gaObj = { hitType: "pageview", page: pathname, title: title }
			console.log('gaObj',gaObj)
			ReactGA.send(gaObj)
		}
	}, [title])

	return (
		<Routes>
			<Route path="/*" element={<Frame/>}>
				<Route path="apfhome" element={<Navigate to="/"/>}/>
				<Route path="topic" element={<GridPage/>}>
					<Route path="people" element={<Pages.topics.people/>}/>
					<Route path="business" element={<Pages.topics.business/>}/>
					<Route path="research" element={<Pages.topics.research/>}/>
				</Route>

				<Route path="topic" element={<VisPage/>}>
					<Route path="vis" element={<Pages.topics.vis/>}/>
				</Route>
				<Route path="timeline/event/:event_id" element={<Redirector basePath="/map/event/" slugId='event_id'/>}/>
				<Route path="timeline/events/tag/:tag_id" element={<Redirector basePath="/map/events/tag/" slugId='tag_id'/>}/>
				<Route path="timeline/events/theme/:theme_id" element={<Redirector basePath="/map/events/theme/" slugId='theme_id'/>}/>
				<Route path="timeline/events/jurisdiction/:geo_id" element={<Redirector basePath="/map/events/jurisdiction/" slugId='geo_id'/>}/>
				{/* <Route path="graph/*" element={<MapLayoutOld type={mapTypes.network}/>}/> */}
				{/* <Route path="nmap/*" element={<MapLayoutOld type={mapTypes.geographic}/>}/> */}
				<Route path="timeline/*" element={<MapLayout type={mapTypes.timeline}/>}/>
				<Route path="about" element={<ProsePage/>}>
					<Route index element={<Pages.about.index/>}/>
					<Route path="api" element={<Pages.about.api/>}/>
					<Route path="cast-terms-of-use" element={<Pages.about.terms/>}/>
					<Route path="methodology">
						<Route index element={<Pages.about.methodology/>}/>
						<Route path="events">
							<Route index element={<Pages.about.events.index/>}/>
							<Route path="finding-sources" element={<Pages.about.events.sources/>}/>
							<Route path="ESG" element={<Pages.about.esg/>}/>
						</Route>
						<Route path="jurisdictions" element={<Pages.about.jurisdictions/>}/>
						<Route path="connections">
							<Route index element={<Pages.about.connections/>}/>
							<Route path="business" element={<Pages.about.business/>}/>
							<Route path="twinning" element={<Pages.about.twinning/>}/>
							<Route path="diplomacy" element={<Pages.about.diplomacy/>}/>
							<Route path="investment" element={<Pages.about.investment/>}/>
						</Route>
					</Route>
					<Route path="events">
						<Route path="theme/:theme_id" element={<Pages.Theme/>}/>
						<Route path="stats/*" element={<StatsPages/>}/>
						<Route path="source">
							<Route index element={<Pages.source/>}/>
							<Route path=":source_id" element={<Pages.source/>} />
						</Route>
					</Route>
				</Route>
				<Route path="insights" element={<ProsePage/>}>
					<Route index element={<Pages.Insights/>}/>
				</Route>
				<Route path="contact" element={<ProsePage/>}>
					<Route index element={<Pages.contact/>}/>
				</Route>

				{/* redicect all routes following the pattern nmap/connections/jurisdiction/:geo_id to map/connections/jurisdiction/:geo_id} */}
				{/* these may be removable */}
				<Route path="nmap/connections/jurisdiction/:geo_id" element={<Redirector basePath="/map/connections/jurisdiction/" slugId='geo_id'/>}/>
				<Route path="nmap/connections/business/jurisdiction/:geo_id" element={<Redirector basePath="/map/connections/business/jurisdiction/" slugId='geo_id'/>}/>
				<Route path="nmap/connections/investment/jurisdiction/:geo_id" element={<Redirector basePath="/map/connections/investment/jurisdiction/" slugId='geo_id'/>}/>

				{/* everything else defaults to grid page + map */}
				<Route path="*" element={<GridPage><MapLayout/></GridPage>}/>

			</Route>
		</Routes>
	)
}


// make a redirector component to handle redirect of old urls to new urls using nmap
function Redirector({basePath, slugId = 'geo_id'}) {
	const params = useParams()
	return <Navigate to={`${basePath}${params[slugId]}`} replace={true}/>
}