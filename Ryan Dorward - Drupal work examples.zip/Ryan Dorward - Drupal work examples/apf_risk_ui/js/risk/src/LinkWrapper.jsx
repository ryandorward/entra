
// import { forwardRef } from 'react'
import { Link, useInRouterContext } from 'react-router-dom'
import { site } from './API.js'

export default function LinkWrapper({path, children, innerRef, ...props}){
	const inRouter = useInRouterContext()
	props.ref = innerRef
	return inRouter ?
		<Link {...props} to={path}>{children}</Link>
		: <a {...props} href={`${site}/${path}`} target='_blank' rel='noopener noreferrer'>{children}</a>
}