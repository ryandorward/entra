import PageTitle from '../layouts/GridPageTitle'
import BusinessGlobe from '../HomePage/BusinessModule'
import Headlines from '../events/Headlines'
import Agreements from '../connections/tradeAgreements/AgreementsList'
import Construction from '../layouts/ConstructionTape'

export default function(){
	return (
		<>
			<PageTitle>Business & Trade</PageTitle>
			<div className='passive-height-scrollable'>{/* height of this cell will be determined by max in it's row */}
				<div>
					<h3>Recent Events</h3>
					<div className="scrollable-overflow">
						<div className="scrollable-overflow-inner">
							<Headlines top={15} sort="date" themes={[26]}/>
						</div>
					</div>
				</div>
			</div>
			<BusinessGlobe/>
			<div>
				<h3>Canada&apos;s Trade Agreements</h3>
				<Agreements/>
			</div>
			<div>
				<h3>Foreign Direct Investment</h3>
				<Construction message="We're still working on the overview for this topic."/>
			</div>
		</>
	)
}
