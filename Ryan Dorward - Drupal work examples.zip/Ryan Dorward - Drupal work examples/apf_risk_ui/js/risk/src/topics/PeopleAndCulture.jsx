import PageTitle from '../layouts/GridPageTitle'
import SelectTwinners from '../connections/twinning/SelectByCountry'
import Construction from '../layouts/ConstructionTape'
import Headlines from '../events/Headlines'
import Immigration from '../connections/people/ImmigrationToCanada'
import Languages from '../connections/people/LanguagesInCanada'

export default function(){
	return (
		<>
			<PageTitle>People & Culture</PageTitle>
			<div className='passive-height-scrollable'>{/* height of this cell will be determined by max in it's row */}
				<div>
					<h3>Recent Events</h3>
					<div className="scrollable-overflow">
						<div className="scrollable-overflow-inner">
							<Headlines top={15} sort="date" 
								tags={[4481,8063,6901,5702,7618,7694,6998,3437,7515,7919]}/> 
						</div>
					</div>
				</div>
			</div>
			<div style={{zIndex:1}}>
				<h3>Twinning relations.</h3>
				<p><i>Twinning</i> or <i>sister-city</i> relations are a way for cities around the world to promote and develop a practice of cultural exchange with selected foreign partners. Many of Canada&apos;s sister city agreements were signed decades ago and have grown relatively dormant over the years, but some are freshly inked and some older relationships are staying active through annual exchanges of students, trade and business ties, and regular delegations sent back and forth.</p>
				<SelectTwinners/>
			</div>
			<div>
				<h3>Diaspora communities</h3>
				<Construction message="We&apos;re still working on analyzing and structuring the data on this topic."/>
				<p>Reliable data on the location of Canadians abroad is extremely hard to come by, but we do have detailed data from Statistics Canada on the location of diaspora and linguistic communities across Canada. Ranging from the well known China-Towns or Little Indias of the major cities to smaller ethnic enclaves like Toronto&apos;s Little Tibet or Koreatown or Vancouver&apos;s Japantown.</p>
			</div>
			<Immigration/>
			<Languages/>
		</>
	)
}
