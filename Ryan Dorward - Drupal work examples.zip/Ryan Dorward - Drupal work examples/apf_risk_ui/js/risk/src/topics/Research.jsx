import PageTitle from '../layouts/GridPageTitle'
import Construction from '../layouts/ConstructionTape'
import Headlines from '../events/Headlines'
import RandDnumbers from '../connections/investment/RandDnumbers'

export default function(){
	return (
		<>
			<PageTitle>Research & Innovation</PageTitle>
			<div className='passive-height-scrollable'>{/* height of this cell will be determined by max in it's row */}
				<div>
					<h3>Recent Events</h3>
					<div className="scrollable-overflow">
						<div className="scrollable-overflow-inner">
							<Headlines top={15} sort="date" themes={[25]}/> 
						</div>
					</div>
				</div>
			</div>
			<RandDnumbers/>
			<div>
				<h3>Research Collaborations</h3>
				<Construction>
					We&apos;re still working on analyzing and structuring the data on this topic.
				</Construction>
			</div>
		</>
	)
}
