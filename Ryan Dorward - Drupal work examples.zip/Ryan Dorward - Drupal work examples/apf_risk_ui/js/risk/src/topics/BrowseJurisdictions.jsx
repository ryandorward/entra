import { useRef, useEffect, useState } from 'react'
import mapboxgl from '!mapbox-gl'
import 'mapbox-gl/dist/mapbox-gl.css'
import './browse-jurisdictions.less'
import {useNavigate} from 'react-router-dom'
import graph from '../jurisdictions/graph'
import { isDeveloper } from '../getRoles'
import useWindowDimensions from '../hooks/useWindowDimensions'
import FlexList from '../layouts/FlexList'
import Title from '../components/Title'
import { cast_jurs } from '../jurisdictions/castJurs'

function PageTitle() {
	return <Title>Explore Jurisdictions</Title>
}

export default function () {
	const { width } = useWindowDimensions()
	return (width < 660) ? <List /> : <Globe />
}

function List() {
	const [nations, setNations] = useState([])
	useEffect(() => {
		getNations().then(jurs => {
			setNations(jurs)
		})
	}, [])
	return (
		<>
			<div className="small-screen-nations">
				<PageTitle />
				<FlexList list={nations}
					nameFunc={jur=>jur.name.en}
					linkFunc={jur=>`/map/events/jurisdiction/${jur.geo_id}`}
					classFunc={()=>`jurisdiction jurisdiction-link`}
				/>
			</div>
		</>
	)
}

mapboxgl.accessToken = 'pk.eyJ1IjoiYXBmY2FuYWRhIiwiYSI6ImNrY3hpdzcwbzAwZzIydms3NGRtZzY2eXIifQ.E7PbT0YGmjJjLiLmyRWSuw'

// Clustering:
// See: https://docs.mapbox.com/mapbox-gl-js/example/cluster-html/

// Zoom to bounds:
// https://visgl.github.io/react-map-gl/examples/zoom-to-bounds (react-map-gl)
// the above will use this: https://www.npmjs.com/package/@turf/bbox

// the react-map-gl will probably be very useful
// full boundaries data: https://demos.mapbox.com/boundaries-explorer/?country=US&layer=adm1&worldview=US#3.3/41/-100

function Globe() {
	// the position the map will be viewed from after the initial load animation/fly

	// Scale zoom such that <660px -> 2, >1200px -> 2.6, linearly in between
	const initialZoom = 2 + (window.innerWidth - 660) / (1200 - 660) * 0.6
	const start = {
		lng: 111.5,
		lat: 18.5,
		zoom: initialZoom,
	}
	const beforeStart = {
		lng: start.lng + (Math.random() * 60 - 30),
		lat: start.lat + (Math.random() * 20 - 10),
		zoom: start.zoom - Math.random(),
	}

	const mapContainer = useRef()
	const map = useRef()
	const [nations, setNations] = useState([])
	const [lng, setLng] = useState(beforeStart.lng)
	const [lat, setLat] = useState(beforeStart.lat)
	const [zoom, setZoom] = useState(beforeStart.zoom)
	const navigate = useNavigate()
	const labels = {}

	useEffect(() => {

		if (map.current) return // initialize map only once
		map.current = new mapboxgl.Map({
			container: mapContainer.current,
			style: 'mapbox://styles/apfcanada/clbwbhi8o000014ojadj1zfud',
			center: [lng, lat],
			zoom: zoom,
			maxZoom: 10,
			minZoom: 1,
			maxBounds: [30, -45, 175, 70], // LngLatBounds object, an array of LngLatLike objects in [sw, ne] order, or an array of numbers in [west, south, east, north] order.
		})

		const mc = map.current // convenience

		mc.on('load', () => {

			// 3D extruded buildings layer
			/*
			mc.addLayer({
				'id': 'add-3d-buildings',
				'source': 'composite',
				'source-layer': 'building',
				'filter': ['==', 'extrude', 'true'],
				'type': 'fill-extrusion',
				'minzoom': 15,
				'paint': {
					'fill-extrusion-color': '#aaa',
					// Use an 'interpolate' expression to
					// add a smooth transition effect to
					// the buildings as the user zooms in.
					'fill-extrusion-height': [
						'interpolate',
						['linear'],
						['zoom'],
						15,
						0,
						15.05,
						['get', 'height']
					],
					'fill-extrusion-base': [
						'interpolate',
						['linear'],
						['zoom'],
						15,
						0,
						15.05,
						['get', 'min_height']
					],
					'fill-extrusion-opacity': 0.6
				}
			})
			*/

			mc.addSource('nations', {
				type: 'geojson',
				data: {
					type: 'FeatureCollection',
					features: [],
				},
				generateId: true
			})
			mc.addLayer({ // this layer is just for attaching the Markers to
				id: 'nation-circles',
				type: 'circle',
				source: 'nations',
				paint: {
					'circle-color': 'white',
					'circle-opacity': 1,
					'circle-radius': 1,
				},
			})

			mc.addSource('boundaries', {
				type: 'vector',
				url: 'mapbox://mapbox.country-boundaries-v1'
			})

			getNations().then(nations => {
				setNations(nations)
				addNationFeatures(mc, nations)
				addBoundariesLayer(mc, nations)
			})

			mc.on('mousemove', 'country-boundaries-fill', (event) => {
				if (event.features.length === 0) return
				// (mc.activeID !== event.features[0].id) && console.log('hovering over ', event.features[0])
				mc.getCanvas().style.cursor = 'pointer'
				deactiveAll() // if mouse has moved from one country to another, need to turn off previous country

				// store the active ID on the map instance. This could be fragile because of possible namespace collisions
				if (!mc.maskBoundaryHover) {
					mc.activeID = event.features[0].id
					mc.active_wikidata_id = event.features[0].properties.wikidata_id
					setBoundaryHoverState(event.features[0].id, true)
					labels[mc.active_wikidata_id]['_element'].classList.add('active')
				}
			})

			mc.on('mouseleave', 'country-boundaries-fill', () => {
				mc.getCanvas().style.cursor = ''
				deactiveAll()
			})

			mc.on('render', () => {
				mc.getSource('nations') && updateNations()
			})

		})

		// Update map meta indicators with any move
		map.current.on('move', () => {
			setLng(map.current.getCenter().lng.toFixed(4))
			setLat(map.current.getCenter().lat.toFixed(4))
			setZoom(map.current.getZoom().toFixed(2))
		})

		// animate the map loading zoom/globe spin effect:
		map.current.flyTo({
			center: [start.lng, start.lat],
			zoom: start.zoom,
			speed: 0.2,
			curve: 1,
		})
	})

	useEffect( () => {
		if (!map.current) return
		const mc = map.current // convenience
		mc.on('click', function (e) {
			var features = mc.queryRenderedFeatures(e.point)
			// check if one of the clicked features is a nation
			for (var i = 0; i < features.length; i++) {
				if (features[i].layer.id === 'country-boundaries-fill') {
					// if so, navigate to the nation page. Find the geo_id of the nation
					for (const nation of nations) {
						if (nation.wikidata === features[i].properties.wikidata_id) {
							// window.location.href = `/map/events/jurisdiction/${nation.geo_id}`
							navigate(`/map/events/jurisdiction/${nation.geo_id}`)
							break
						}
					}
				}
			}
		})
	}, [nations])

	// resize the map when it's container is resized, especially for the sidebar expand/contract
	useEffect( () => {
		if (!mapContainer.current) return
		function resizer(){
			map.current.resize()
			// window.dispatchEvent(new Event('resize')) // was hoping this would avoid the blinking but it didn't
		}
		var debounce
		const resizeObserver = new ResizeObserver(() => {
			clearTimeout(debounce)
			debounce = setTimeout(resizer(), 20)
		})
		resizeObserver.observe(mapContainer.current)
		return () => resizeObserver.disconnect()
	}, [])

	return (
		<div className='map-outer'>
			{ isDeveloper() &&
			<div className='map-meta'>
				Longitude: {lng} | Latitude: {lat} | Zoom: {zoom}
			</div>
			}
			<PageTitle />
			<div ref={mapContainer} className='map-container' />
		</div>
	)

	function setBoundaryHoverState(id, state) {
		map.current.setFeatureState(
			{
				source: 'boundaries',
				sourceLayer: 'country_boundaries',
				id: id
			},
			{ hover: state }
		)
	}

	function deactiveAll() {
		if (map.current.activeID) {
			setBoundaryHoverState(map.current.activeID, false)
			labels[map.current.active_wikidata_id]['_element'].classList.remove('active')
		}
		map.current.activeID = null
		map.current.active_wikidata_id = null
	}

	// add a linked labels to the map for each jurisdictions at its centroid
	function updateNations() {
		const features = map.current.querySourceFeatures('nations')
		for (const feature of features) {
			const props = feature.properties
			let label = labels[props.wikidata_id]
			if (!label) {
				const el = document.createElement('a')
				el.className = `jurisdiction-label geo_id-${props.geo_id} wikidata_id-${props.wikidata_id}`
				// el.href = `/map/events/jurisdiction/${props.geo_id}`
				el.textContent = props.label

				el.addEventListener("mouseover", () => {
					// deactiveAll()
					// const id = wikidata_id_to_mapbox_id[props.wikidata_id]
					const id = cast_jurs[props.wikidata_id].mapbox_id
					id && setBoundaryHoverState(id, true)
					map.current.maskBoundaryHover = true
				}, false)

				el.addEventListener("mouseleave", () => {
					const id = cast_jurs[props.wikidata_id].mapbox_id
					id && setBoundaryHoverState(id, false)
					map.current.maskBoundaryHover = false
				}, false)

				el.addEventListener("click", () => {
					navigate(`/map/events/jurisdiction/${props.geo_id}`)
				})

				label = labels[props.wikidata_id] = new mapboxgl.Marker({
					element: el,
					anchor: 'center',
				}).setLngLat(feature.geometry.coordinates).addTo(map.current)
			}
		}
	}

}

function addNationFeatures(map, nations) {
	const features = nations.map(nation => {
		return {
			type: 'Feature',
			properties: {
				geo_id: nation.geo_id,
				wikidata_id: nation.wikidata,
				label: nation.name.en,
				id: nation.geo_id,
			},
			geometry: {
				type: 'Point',
				coordinates: nationLabelPositions[nation.geo_id] ?? nation.geom.point.coordinates,
			},
		}
	})

	map.getSource('nations').setData({
		type: 'FeatureCollection',
		features: features,
	})
}

function addBoundariesLayer (map, nations) {
	map.addLayer({
		id: 'country-boundaries-fill',
		type: 'fill',
		source: 'boundaries',
		'source-layer': 'country_boundaries',
		paint: {
			'fill-color': [
				'case',
				['boolean', ['feature-state', 'hover'], false],
				'rgba(255, 255, 255,0.33)',
				'rgba(255, 255, 255,0)',
			],
		},
		filter: [
			'all',
			[ // filter the boundaries to only show the nations of concern to CAST
				'any',
				...nations.map(nation => ['==', nation.wikidata, ['get', 'wikidata_id']])
			],
			[ // filter the boundaries to only show the US/all worldview
				"any",
				["==", "all", ["get", "worldview"]],
				["in", "US", ["get", "worldview"]]
			]
		]
	})

}

// get national level jurisdictions, formatted as mapbox features
async function getNations(){
	const jursExclude = [ // this is repeated in jur picker, could centralize
		6, // Australia
		8, // new zealand
		35 // Mongolia
	]
	return graph.countries().then((jurs) => {
		jurs = jurs
			.filter(jur => !jursExclude.includes(jur.geo_id))
			.sort((a,b)=>a.name.en.localeCompare(b.name.en))
		return jurs
	})
}

const nationLabelPositions = {
	3: [107,32], // China
	4: [140.3,36.6], // Japan
	5: [128.3,35], // S. Korea
	31: [108.2,15.8], // Vietnam
	74: [104.8, 11.4], // Cambodia
	606: [108,5], // Malaysia
	917: [91.6,27], // Bhutan
	1465: [103.8,1.25], // Singapore
}