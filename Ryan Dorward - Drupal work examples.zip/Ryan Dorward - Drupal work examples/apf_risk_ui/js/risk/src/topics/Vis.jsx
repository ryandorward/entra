import { useRef, useEffect, useState } from 'react'
import mapboxgl from '!mapbox-gl'
import 'mapbox-gl/dist/mapbox-gl.css'
import { gql, useApolloClient, useReactiveVar } from '@apollo/client'
import './vis-map-style.css'
import graph from '../jurisdictions/graph'
import Slider from '../input/TimeSlider'
import { dateRange } from '../input/TimeSlider'

mapboxgl.accessToken = 'pk.eyJ1IjoiYXBmY2FuYWRhIiwiYSI6ImNrY3hpdzcwbzAwZzIydms3NGRtZzY2eXIifQ.E7PbT0YGmjJjLiLmyRWSuw'
const query = gql`
	query ($startDate: String!, $endDate: String!) {
		events(after: $startDate, before: $endDate) {
			id
			date
			title
			impacts {
				id
				geo_id
			}
		}
	}
`
let mapFeatures = []
let mapFeaturesBorder = []
export default function vis() {
	const client = useApolloClient()
	const { start, end } = useReactiveVar(dateRange)
	const mapContainer = useRef(null)
	const map = useRef(null)
	const [lng, setLng] = useState(110.1455)
	const [lat, setLat] = useState(5.9642)
	const [zoom, setZoom] = useState(2.64)
	const tooltip = new mapboxgl.Popup({
		closeButton: true,
		closeOnClick: false,
	})
	let hoveredStateId = null;
	// let a = [1,2,[[1,2],[2,4],[4,6,[5,4]],[3,5]]]
	// console.log(a.flat().flat().flat().flat().flat())

	useEffect(() => {
		map.current = new mapboxgl.Map({
			container: mapContainer.current,
			style: 'mapbox://styles/mapbox/light-v10',
			center: [lng, lat],
			zoom: zoom,
		})
		map.current.on('load', (e) => {
			e.target.addSource('events', {
				type: 'geojson',
				data: {
					type: 'FeatureCollection',
					features: mapFeatures,
				},
			})
			e.target.addSource('eventsBorder', {
				type: 'geojson',
				data: {
					type: 'FeatureCollection',
					features: mapFeaturesBorder,
				},
			})

			e.target.addLayer({
				id: 'polygon',
				type: 'fill',
				source: 'eventsBorder',
				layout: {},
				paint:{
					'fill-color': '#0080ff',
					'fill-opacity': [
						'case',
						['boolean', ['feature-state', 'hover'], false],
						1,
						0.5
						]
				}
			})
			e.target.addLayer({
				id: 'event-circles',
				type: 'circle',
				source: 'events',
				paint: {
					'circle-color': 'red', //['interpolate', ['linear'], ['get', 'mag'], 6, 'red', 8, 'blue'],
					'circle-opacity': 0.4,
					'circle-radius': 10, // ['interpolate', ['linear'], ['get', 'mag'], 6, 10, 8, 40],
				},
			})
			map.current.on('mouseenter', 'event-circles', (e) => {
				map.current.getCanvas().style.cursor = 'pointer'
				const coordinates = e.lngLat
				const description = e.features[0].properties.description
				tooltip.setLngLat(coordinates).setHTML(description).addTo(map.current)
			})
			map.current.on('mousemove', 'polygon', (e) => {
				console.log(e)
					if (e.features.length > 0) {
						if (hoveredStateId !== null) {
							map.current.setFeatureState(
									{ source: 'eventsBorder', id: hoveredStateId },
									{ hover: false }
								);
					}

					map.current.setFeatureState(
						{ source: 'eventsBorder', id: hoveredStateId },
						{ hover: true }
					);
				}
			});


			map.current.on('mouseleave', 'event-circles', () => {
				map.current.getCanvas().style.cursor = ''
			})
			// map.current.on('mouseout', function () {
			// 	tooltip.remove()
			// })
			map.current.on('click', () => {
				tooltip.remove()
			})
		})
	}, [])

	useEffect(() => {
		client
			.query({
				query,
				variables: {
					startDate: start.toISODate(),
					endDate: end.toISODate(),
				},
			})
			.then(({ data }) => {
				const jurClasses = new Map()
				data.events.flatMap((event) => {
					event.impacts.map((impact) => {
						if (!jurClasses.has(impact.geo_id)) {
							return jurClasses.set(impact.geo_id, { date: event.date, title: event.title, id: event.id })
						}
					})
				})
				graph.lookup([...jurClasses.keys()]).then((jurs) => {
					mapFeatures = []
					mapFeaturesBorder = []
					jurs.map((g) => {
						var featuresData = {
							type: 'Feature',
							properties: {},
							geometry: {
								type: 'Point',
							},
						}
						var featuresDataBorder = {
							type: 'Feature',
							properties: {},
							geometry: {

							},
						}
						var eventAttr = jurClasses.get(g.geo_id)
						featuresData.properties.id = eventAttr.id
						featuresData.properties.description = '<strong class ="hola">Event Info</strong>' + '</br>' +
						'<strong>' + eventAttr.date + ' </strong>' + '</br>' +
						'<strong style = font-size:20> Location:' + g.name.en + '</strong>' +
						'<strong> (' + g.type.label.en + ')</strong>' + '</br>' + '</br>' +
						'<strong>' + eventAttr.title + '</strong>' + '</br>' +
						'<a class ="readmore" href= "/map/event/' + eventAttr.id + '">read more...</a>'

						var checkPoly= 'polygon' in g.geom
						if(checkPoly==true ){
							var checkCoor ='coordinates' in g.geom.polygon
							if (checkCoor==true ){
								featuresDataBorder.geometry.type=g.geom.polygon.type
								featuresDataBorder.geometry.coordinates=g.geom.polygon.coordinates

							}
						}
						var checkCoorFeatures= 'coordinates' in featuresDataBorder.geometry
						console.log(checkCoorFeatures)
						if (checkCoorFeatures== true){
							mapFeaturesBorder.push(featuresDataBorder)
						}
						featuresData.geometry.coordinates = g.geom.point.coordinates
						mapFeatures.push(featuresData)
					})
				})

				if (map.current && map.current.getSource('events')) {
					map.current.getSource('events').setData({
						type: 'FeatureCollection',
						features: mapFeatures,
					})
					map.current.getSource('eventsBorder').setData({
						type:'FeatureCollection',
						features:mapFeaturesBorder,
					})
					return
				}
			})
	}, [start, end])

	useEffect(() => {
		if (!map.current) return // wait for map to initialize
		map.current.on('move', () => {
			setLng(map.current.getCenter().lng.toFixed(4))
			setLat(map.current.getCenter().lat.toFixed(4))
			setZoom(map.current.getZoom().toFixed(2))
		})
	})

	return (
		<div>
			<Slider />
			<div className='sidebar'>
				Longitude: {lng} | Latitude: {lat} | Zoom: {zoom}
			</div>
			<div ref={mapContainer} className='map-container' />
		</div>
	)
}
