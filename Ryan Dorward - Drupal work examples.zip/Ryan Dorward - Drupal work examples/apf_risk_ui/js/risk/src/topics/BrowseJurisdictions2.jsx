// This is almost functioning properly and is much cleaner than the OG BrowseJurisdictions.jsx
// However there are a few little glitches that need to be fixed before it can be used.
// For example: hovering over a label that sits on top of another jur will cause them both to be highlighted,
// and the click doesn't happen on the right jur
// Another problem is that the labels are fuzzy on some screens when they are hovered.

// The OG component is terribly complex though (and way more lines), so it would be nice to get this working properly.

// Eventually it will be nice to have the map just load once and simply reposition and add/remove layers as needed.
// When we get there, will need to have this refactored version of the component working properly so the map can always come from the same "thing"

import { useRef, useEffect, useState } from 'react'
import 'mapbox-gl/dist/mapbox-gl.css'
import {default as MapGL, Marker, Source, Layer}  from 'react-map-gl'
import {useNavigate} from 'react-router-dom';
import { isDeveloper } from '../getRoles'
import useWindowDimensions from '../hooks/useWindowDimensions'
import FlexList from '../layouts/FlexList'
import Title from '../components/Title'
import './browse-jurisdictions.less'

import { wikidata_id_to_mapbox_id, nationLabelPositions} from '../jurisdictions/castJurs.js'
import { getNations } from '../maps/geographic/maputils.jsx'

const accessToken = 'pk.eyJ1IjoiYXBmY2FuYWRhIiwiYSI6ImNrY3hpdzcwbzAwZzIydms3NGRtZzY2eXIifQ.E7PbT0YGmjJjLiLmyRWSuw'

function PageTitle() {
	return <Title>Explore Jurisdictions2</Title>
}

export default function () {
	const { width } = useWindowDimensions()
	return (width < 660) ? <List /> : <Globe />
}

function List() {
	const [nations, setNations] = useState([])
	useEffect(() => {
		getNations().then(jurs => {
			setNations(jurs)
		})
	}, [])
	return (
		<>
			<div className="small-screen-nations">
				<PageTitle />
				<FlexList list={nations}
					nameFunc={jur=>jur.name.en}
					linkFunc={jur=>`/map/events/jurisdiction/${jur.geo_id}`}
					classFunc={()=>`jurisdiction jurisdiction-link`}
				/>
			</div>
		</>
	)
}

// Clustering:
// See: https://docs.mapbox.com/mapbox-gl-js/example/cluster-html/

function Globe() {
	// the position the map will be viewed from after the initial load animation/fly

	// Scale zoom such that <660px -> 2, >1200px -> 2.6, linearly in between
	const initialZoom = 2 + (window.innerWidth - 660) / (1200 - 660) * 0.6
	const start = {
		lng: 111.5,
		lat: 18.5,
		zoom: initialZoom,
	}
	const beforeStart = {
		lng: start.lng + (Math.random() * 60 - 30),
		lat: start.lat + (Math.random() * 20 - 10),
		zoom: start.zoom - Math.random(),
	}

	const mapContainer = useRef()
	const mapRef = useRef()

  const [viewState, setViewState] = useState({
    longitude: beforeStart.lng,
    latitude: beforeStart.lat,
    zoom: beforeStart.zoom
  })

  const [nations, setNations] = useState([])
  const [activeFeature, setActiveFeature] = useState(null)
  const [activeWikidataId, setActiveWikidataId] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    getNations().then(jurs => {
      setNations(jurs)
    })
  }, [])

	// resize the map when it's container is resized, especially for the sidebar expand/contract
	useEffect( () => {
		if (!mapContainer.current) return
		function resizer(){
			mapRef.current.resize()
			// window.dispatchEvent(new Event('resize')) // was hoping this would avoid the blinking but it didn't
		}
		var debounce
		const resizeObserver = new ResizeObserver(() => {
			clearTimeout(debounce)
			debounce = setTimeout(resizer(), 20)
		})
		resizeObserver.observe(mapContainer.current)
		return () => resizeObserver.disconnect()
	}, [])

	return (
		<div className='map-outer'>
      { isDeveloper() &&
        <div className='map-meta'>
          Longitude: {viewState.longitude.toFixed(2)}
          | Latitude: {viewState.latitude.toFixed(2)}
          | Zoom: {viewState.zoom.toFixed(2)}
        </div>
      }
			<PageTitle />
      <div className='map-container'>
        <MapGL
          {...viewState}
          ref={mapRef}
          mapStyle='mapbox://styles/apfcanada/clbwbhi8o000014ojadj1zfud'
          mapboxAccessToken={accessToken}
          interactiveLayerIds={['country-boundaries-fill']}
          onMove={e => setViewState(e.viewState)}
          onMouseMove={(e) => {
            if (e.features?.length === 0) return // if mouse is not over a country
            const map = e.target
            map.getCanvas().style.cursor = 'pointer'
            e.features[0].id !== activeFeature && deactiveAll() // if mouse has moved from one country to another, need to turn off previous country
            if (!mapRef.current.maskBoundaryHover) {
              setActiveFeature(e.features[0].id)
              setActiveWikidataId(e.features[0].properties.wikidata_id)
              setBoundaryHoverState(e.features[0].id, true)
            }
          }}
          onMouseLeave={(e) => {
            const map = e.target
            map.getCanvas().style.cursor = ''
            deactiveAll()
          }}
          onClick={(e) => {
            e.features.forEach((feature) => {
              if (feature.layer.id === 'country-boundaries-fill') {
                // if so, navigate to the nation page. Find the geo_id of the nation
                for (const nation of nations) {
                  if (nation.wikidata === feature.properties.wikidata_id) {
                    navigate(`/map/events/jurisdiction/${nation.geo_id}`)
                    break
                  }
                }
              }
            })
          }}
          onLoad={(e)=> {
            const map = e.target
            map.flyTo({
              center: [start.lng, start.lat],
              zoom: start.zoom,
              speed: 0.2,
              curve: 1,
            })
          }}
          projection='globe'
          boxZoom={false}
          doubleClickZoom={false}
          cooperativeGestures={true}
          className='map-container'
        >
          <ExplorerBoundaries nations={nations} />
          {/*
          <Source
            type='vector'
            url='mapbox://mapbox.country-boundaries-v1'
            id='boundaries'
          >
            <Layer
              id='country-boundaries-fill'
              source-layer='country_boundaries'
              type='fill'
              paint={{
                'fill-color': [
                  'case',
                  ['boolean', ['feature-state', 'hover'], false],
                  'rgba(255, 255, 255,0.33)',
                  'rgba(255, 255, 255,0)',
                ],
              }}
              filter={[
                'all',
                [ // filter the boundaries to only show the nations of concern to CAST
                  'any',
                  ...nations.map(nation => ['==', nation.wikidata, ['get', 'wikidata_id']])
                ],
                [ // filter the boundaries to only show the US/all worldview
                  "any",
                  ["==", "all", ["get", "worldview"]],
                  ["in", "US", ["get", "worldview"]]
                ]
              ]}
            />
            </Source> */}
          { nations && nations.map(nation => {
            return (
              <NationMarker
                key={nation.geo_id}
                nation={nation}
                setBoundaryHoverState={setBoundaryHoverState}
                activeWikidataId={activeWikidataId}
                deactiveAll={deactiveAll}
                activeFeature={activeFeature}
                map={mapRef.current}
              />
            )}
          )}
        </MapGL>
      </div>
		</div>
	)



	function setBoundaryHoverState(id, state) {
		mapRef.current.setFeatureState(
			{
				source: 'boundaries',
				sourceLayer: 'country_boundaries',
				id: id
			},
			{ hover: state }
		)
	}

	function deactiveAll() {
		if (activeFeature) {
			setBoundaryHoverState(activeFeature, null)
		}
		setActiveFeature(null)
		setActiveWikidataId(null)
	}

}

function ExplorerBoundaries({nations}) {

  return (
    <Source
          type='vector'
          url='mapbox://mapbox.country-boundaries-v1'
          id='boundaries'
        >
          <Layer
            id='country-boundaries-fill'
            source-layer='country_boundaries'
            type='fill'
            paint={{
              'fill-color': [
                'case',
                ['boolean', ['feature-state', 'hover'], false],
                'rgba(255, 255, 255,0.33)',
                'rgba(255, 255, 255,0)',
              ],
            }}
            filter={[
              'all',
              [ // filter the boundaries to only show the nations of concern to CAST
                'any',
                ...nations.map(nation => ['==', nation.wikidata, ['get', 'wikidata_id']])
              ],
              [ // filter the boundaries to only show the US/all worldview
                "any",
                ["==", "all", ["get", "worldview"]],
                ["in", "US", ["get", "worldview"]]
              ]
            ]}

          />
        </Source>
  )

}

function NationMarker({nation, setBoundaryHoverState, activeWikidataId, deactiveAll, activeFeature, map}) {
  const coords = nationLabelPositions[nation.geo_id] ?? nation.geom.point.coordinates
  const id = wikidata_id_to_mapbox_id[nation.wikidata]
  return (
    <Marker
      key={nation.geo_id}
      longitude={coords[0]}
      latitude={coords[1]}
    >
      <a
        onMouseEnter={() => {
          map.maskBoundaryHover = true
          id !== activeFeature && deactiveAll()
          setBoundaryHoverState(id, true)
        }}
        onMouseLeave={() => {
          map.maskBoundaryHover = false
          setBoundaryHoverState(id, false)
        }}
        href={`/map/events/jurisdiction/${nation.geo_id}`}
        className={`jurisdiction-label geo_id-${nation.geo_id} wikidata_id-${nation.wikidata} ${nation.wikidata === activeWikidataId ? 'active' : ''}`}
      >
        {nation.name.en}
      </a>
    </Marker>
  )
}