import { Link } from 'react-router-dom'
import ShowOnlyTo from '../ShowOnlyTo'
import Title from '../components/Title'
// import ConstructionTape from '../layouts/ConstructionTape'

export default function(){
	return (<>
		<Title>CAST Methodology</Title>
		{/*
		<ConstructionTape>
			You are reading the documentation for CAST. The project is still developing and so is the documentation; please bear with us.
		</ConstructionTape>
	*/}

		<ShowOnlyTo minRole="jrAnalyst">
			<p>Hello, and welcome!</p>

			<p>If you can read this, it’s because you’ve been given responsibility for helping us populate CAST with events and perhaps other datasets as well. The documentation on this page is meant for a general audience, but we’ve also inserted some little snippets like this one throughout to offer more practical advice for APFC staff.</p>

			<p>There are more notes at the bottom of this page for you.</p>
		</ShowOnlyTo>

		<h2>Events Database</h2>

<p>The CAST events database summarizes ESG-related events in the Indo-Pacific region to provide greater situational awareness and actionable intelligence for Canadian stakeholders interested in Asia’s economies, policies, and societies.</p>

<p>Each event is summarized, linked to other events, and categorized under <strong>seven themes</strong> and <strong>14 sub-themes</strong>, all under the umbrella of <strong>environmental, social, and governance (ESG)</strong> developments in the region:</p>

<ul>
	<li>Environment</li>

	<ul>
		<li>Emissions and Pollution: This sub-theme explores events caused by man-made emissions and pollution, including those that directly contribute to global warming. This sub-theme captures data related to emissions and the pollution of air, land, and water; (non-renewable) energy; waste management (recycling and upcycling); and extends to policies and strategies that aim to manage and/or mitigate the impacts of environmental degradation. The theme also captures the costs of emissions and pollution on the general population (health issues), corporate responsibilities and strategies, and government reactions.</li>
		<li>Natural Capital Use and Management: This sub-theme brings together a broad range of topics focused on natural resources, their use, and management. It includes data on wildlife (conservation), natural environment (conservation), and biodiversity (conservation). It includes data related to the use of natural resources (wood, coal, oil, soil, minerals), renewable energy (solar, tidal, nuclear), agriculture, food, and issues such as energy security, food security, and water security, among others. The sub-theme captures events related to these areas and explores related policies, existing datasets, trade and investment agreements, and crises.</li>
	</ul>
</ul>

<ul>
	<li>Environment and Social
	<ul>
		<li>Climate Change and Resilience: This sub-theme focuses on the causes and consequences of anthropogenic climate change and the long-term impacts of greenhouse gas emissions. Climate change is widely understood to be a collective-action problem, placing the issue squarely into the Governance category as well as being an obvious Environmental issue. Strong and organized government and regulatory interventions will be needed from all levels of government to meet the ongoing climate crisis.</li>
	</ul>
	</li>
	<li>Social
	<ul>
		<li>Education, Skills &amp; Competencies: This sub-theme explores the critical variables of equal access to education that can directly impact society and the general public&apos;s quality of life. It includes factors such as quality of education, gender balance in education, and access to education (urban &amp; rural divide). It further explores the impacts of digitalization and innovation (connected communities) and university partnerships between Canada and Asia.</li>
		<li>Employment and Social Development: This sub-theme encompasses the crucial issue of life and livelihood and focuses on the labour market and the quality of living in Asia. Some of the variables explored under this sub-theme include unemployment rates, particularly against the backdrop of burgeoning educated and young populations in many countries. It also explores the labour market, both formal and informal labour sectors (including unpaid labour and the gig economy), and the factors that impact the labour market, such as the demand and supply of labour, labour shortages, and labour laws and regulations. The sub-theme houses issues such as income inequality, cost of living, poverty, access to the social safety net and social services, and how various social aspects such as gender, race, and ethnicity play a role in the process. It also captures developments and disruptions in the labour force, including labour union activities and strikes. Impacts of the fourth industrial revolution (automation, advanced manufacturing, deglobalization/glocalization) are also a crucial component of this category.</li>
		<li>Media and Public Opinion: This sub-theme explores various news and entertainment media issues across the Indo-Pacific, including press freedom, violence against journalists, media censorship, and regressive government policies curbing media freedom. It also covers public discourse on these issues, including freedom of speech, state-sponsored oppression and repression of public opinion, social media movements, social activism and boycotts, and the exploration of civil society organisations and non-governmental organizations NGO statements.</li>
	</ul>
	</li>
	<li>Social and Governance
	<ul>
		<li>Inclusive Development and Human Rights: This sub-theme explores the issues faced by minority populations across Asia. Minority populations here include, but are not limited to, sexually- and gender-diverse people (LGBTQ+), Indigenous peoples (Adivasis, etc.), and ethnic, religious, and linguistic minorities. Mainly focusing on the issue of equality and equity, the sub-theme brings forward human rights violations in Asia (reasons, status, official responses) and underscores the importance of empowering minority groups for inclusive and sustainable development. This sub-theme also includes policy discussions and framing that endeavour or should have inclusive elements.</li>
		<li>Public Health: This sub-theme monitors emerging viruses and biological threats (COVID-19, Monkeypox), health crises related to nutrition that point to interesting trends and population changes (malnutrition, obesity), aging population-related health issues, health care for sensitive/at-risk populations (immigrants and refugees), and the movement of and trends impacting health-care workers (growth or absence, areas of growth). It also captures news about advancements in the field of medicine and health care, medical research and development, biomedicine and biotechnology (trade and investment collaborations, deals, agreements). The growing trend of health care digitization and trade and investment stories about medical supplies and equipment (masks, vaccines, etc.) are also a focus of this sub-theme.</li>
		<li>Politics and Global Governance: This sub-theme explores various Asian economies&apos; political issues, political parties and representation (including diverse and inclusive representation), elections, and other related issues such as corruption, the rule of law, and the stability of governments. This sub-theme also covers global governance issues, emphasizing international and multilateral organizations and networks (civil society networks, think-tanks, NGOs, corporate governance networks), world leaders, public diplomacy, foreign policy, and the decline of democracy in various regions. This sub-theme also covers defence, regional security, global security threats, and domestic and international terrorism.</li>
		<li>Social and Public Welfare: Policies and governance issues that directly impact people&apos;s social well-being are covered under this sub-theme. An increasing economic and digital divide has raised questions about public welfare and the need for social safety nets. Public-funded health care and education policies are crucial to ensuring equitable access to growth and development. This sub-theme also includes topics related to the judicial system and explores issues of laws and regulations (including disputes), court proceedings and rulings on matters of social interest, and the penalties and punishments (including capital), among other related issues.</li>
	</ul>
	</li>
	<li>Governance
	<ul>
		<li>Digital Governance, Privacy and Technology: The emphasis on digital transformation across sectors requires a broader focus on crucial governance issues related to the digital world. First and foremost under this sub-theme are the looming issues of cybersecurity, privacy, and intellectual property rights. Another prime focus area is emerging technologies and tech giants, Information and Communication Technologies manufacturing, and the tech innovation environment. With digital currency growing increasingly popular, this sub-theme crosses over into economic and governance issues related to crypto, blockchain, and other digital currencies and transaction systems emerging worldwide. Digital trade policies and agreements and relatedly digitization of governance and banking (ids, paperwork, applications, etc.) are also among the topics covered in this sub-theme.</li>
		<li>Economy, Trade, and Investment: This sub-theme follows developments related to banking and finance, macro- and micro-economic policies, international trade and investment agreements (policies, statements, including restrictive policies), and factors around subsidies and taxation that are crucial for economic engagement. The scope of this sub-theme is broad and covers overseas development assistance (ODA), issues of financial stability and supply chain (resilience), the economic environment of Indo-Pacific economies, and government investments in various projects (infrastructure).</li>
	</ul>
	</li>
	<li>Governance and Environment
	<ul>
		<li>Corporate ESG Initiatives: This sub-theme covers corporate social responsibility (CSR), plurilateral, and bilateral relationships with corporations and governments; funding and initiatives; and equal representation and inclusion.</li>
	</ul>
	</li>
	<li>Environment, Social, and Governance
	<ul>
		<li>Urbanization and Smart cities: Under this theme, topics include growing cities and urban areas; the development of sustainable cities; the need and development of sustainable architecture and infrastructure; the development of smart cities (use of ICT to improve management and governance, and streamline operations such as transportation and documentation); lifestyle changes (eco-friendly living); and the migration of people from rural to urban areas due to economic, environmental, or socio-political reasons.</li>
	</ul>
	</li>
</ul>

<p></p>

<h2>Event Parameters</h2>

<p></p>

<p>Each CAST event is assigned <strong>descriptive tags</strong> intended to make events more searchable and group them into various <strong>topics</strong>. Topics are identified based on the tags analysts assign to events. Events are also related to each other and linked into larger networks or patterns of events. Sometimes the relations between events can be straightforwardly causal, where A causes B, which causes C. This sort of relationship adds a clear context to all three events. Analysts also look at A and identify a direct cause or look at B to explore its singular causal relationship within an evolving situation. The ability to define these various relationships between events allows our analysts to add updates and context around what would otherwise appear as isolated incidents lacking causality.</p>

<p></p>

<p>We have defined several types of event relationships. The types of relationships within the scope of a selected event are shown in the timeline legend of each event.</p>

<p></p>

<p>Existing types of event relations are:</p>

<p></p>

<p><strong>Causal</strong>: cause and effect; one event causes the other.</p>

<p><strong>Recurrent</strong>: the same kind of event has taken place before.</p>

<p><strong>Developmental</strong>: a new event changes or updates the situation in a previous event.</p>

<p><strong>Contrasting</strong>: an event opposes, overturns, or strikingly differs from a previous event.</p>

<p><strong>Relational</strong>: events are strongly related in a way not otherwise defined.</p>

<p></p>

<h2>Data and Sources</h2>

<p>CAST tracks a variety of specific economic and cultural connections between Canada and Asia. These different types of connections are used to refine the geographic focus of event tracking. Each connection links two or more jurisdictions between Canada and Asia.</p>

<p>The data used to show the connections and the level of connectivity between Canadian and Asian jurisdictions is taken from various publicly available sources, APF Canada <a href="https://www.asiapacific.ca/investmentmonitor">Investment Monitor</a> data, and <a href="https://openalex.org/about">OpenAlex</a>, a free and open catalogue of the world&apos;s scholarly papers, researchers, journals, and institutions.</p>

<p>***The Connections section is under construction.</p>

<h2>Jurisdictions</h2>

<p>We define jurisdictions as geographically bounded, political administrative units, including countries, provinces/states/prefectures/administrative subdivisions, and cities. The main requirement is that the boundaries are defined, and that some form of government directly administers the unit. Jurisdictions may be nested within each other but cannot overlap or share territory at the same level in the hierarchy.</p>

<p>Some borders are contested; CAST relies on internationally recognized borders to identify jurisdictions.</p>

<p></p>

		<ShowOnlyTo minRole="jrAnalyst">
		<p>CAST works to put unfolding developments in the Asia Pacific in the context of Canada’s direct and ongoing engagement with the region. This means that we are actively working to collect and maintain two (actually three) different types of data.</p>

		<h2>Event Monitoring</h2>
		<p>We engage in daily collection of open-source reporting in local languages across the Asia Pacific (starting initially with Greater China). This means our regional/country experts spend time reading local news sources in their original language, understanding events from multiple angles and providing you with written summary of what happened, where, when, etc.</p>
		<p>Read more about <Link to="events">how we track events</Link>.</p>

		<h2>Canada–Asia Connections</h2>
		<p>APF Canada’s logo is meant to symbolize all of the connections tying together Canada and the Asia Pacific. Trade, migration, family, culture, food... to list all of the ways two regions may be connected is to enumerate the human experience. Acknowledging this breadth, CAST attempts to identify and quantify a wide range of connections, especially where we can do so with data covering all or most of the Asia Pacific.</p>
		<p>Read more about the specific types of <Link to="connections">connections we track</Link>.</p>

		<h2>Jurisdictions</h2>
		<p>We bring together events and connections by assigning them to jurisdictions, a set of defined geographic, political, and administrative units. These may be nested, where for example a country contains provinces, and a province contains cities. This allows CAST to offer both high-level country statistics and detailed city-to-city profiles.</p>
		<p>Read more about <Link to="jurisdictions">how we define jurisdictions</Link>.</p>
		</ShowOnlyTo>

	</>)
}
