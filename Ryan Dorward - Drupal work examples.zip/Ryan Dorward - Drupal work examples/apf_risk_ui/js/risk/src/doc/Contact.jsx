import Title from '../components/Title'
import Fb from '../images/social-icons/facebook-icon.svg'
import Tw from '../images/social-icons/twitter-icon.svg'
import Ig from '../images/social-icons/APF-instagram-icon.svg'
import Li from '../images/social-icons/linkedin-icon.svg'
import Yt from '../images/social-icons/youtube-icon.svg'
// import Rss from '../images/social-icons/rss-icon.svg'
import './contact.less'

export default function Contact() {
  return (
    <>
      <Title>Contact the CAST Team</Title>
      <div dangerouslySetInnerHTML= {{__html: `

      <h2>Connect with Us</h2>
      Technical Support: <a href="mailto:info@asiapacific.ca">info@asiapacific.ca</a><br/>
      Tailored Reports & Briefings: <a href="mailto:rosie.bolderston@asiapacific.ca">rosie.bolderston@asiapacific.ca</a><br/>
      Publications & Media: <a href="mailto:communications@asiapacific.ca">communications@asiapacific.ca</a><br/>
      General: <a href="mailto:info@asiapacific.ca">info@asiapacific.ca</a><br/>
      <br/>

      <h2>Head Office</h2>
      Asia Pacific Foundation of Canada<br/>
      680-1066 W. Hastings Street<br/>
      Vancouver, BC<br/>
      Canada V6E 3X2<br/>
      T: <a href="tel:604-684-5986">604-684-5986</a><br/>
      W: <a href="https://www.asiapacific.ca" target="_blank">asiapacific.ca</a><br/>
      <br/>

      `}}/>
      <div className="social-follow">
        <div className="links blue">
          <ul>

            <li className="facebook">
              <a href="http://www.facebook.com/asiapacificfoundationofcanada" target="_blank" rel="noreferrer" aria-label="Follow us on Facebook">
                <Fb />
              </a>
            </li>

            <li className="twitter">
              <a href="http://twitter.com/AsiaPacificFdn" target="_blank" rel="noreferrer" aria-label="Follow us on Twitter">
                <Tw />
              </a>
            </li>

            <li className="linkedin">
              <a href="https://www.linkedin.com/company/522469/" target="_blank" rel="noreferrer" aria-label="Follow us on LinkedIn">
                <Li />
              </a>
            </li>

            <li className="youtube">
              <a href="http://www.youtube.com/channel/UCkieSwux1pmkNv2hvUsXjKg" target="_blank" rel="noreferrer" aria-label="Follow us on YouTube">
                <Yt />
              </a>
            </li>

            <li className="insta">
              <a href="https://www.instagram.com/asiapacificfoundation/" target="_blank" rel="noreferrer" aria-label="Follow us on Instagram">
                <Ig />
              </a>
            </li>

          </ul>

        </div>
      </div>
    </>
  )
}