import { Link } from "react-router-dom"
import Title from '../components/Title'

export default function AboutPage(){
	return (
		<>
		<Title useMetaSuffix={false}>About CAST</Title>
		<p>
		The Canada-Asia Sustainability Tracker (CAST) is an online platform and resource hub providing
		greater situational awareness and actionable intelligence for Canadian stakeholders interested
		in Asia&apos;s economies, policies, and societies.
		</p>
		<p>
		CAST features data and analysis for companies with operations on the ground, exporters
		looking to break into new markets, investors monitoring existing or emerging opportunities,
		policy-makers who rely on up-to-date knowledge of the region, and the organizations that
		support these cohorts.
		</p>
		<p>
		CAST&apos;s content is anchored in APF Canada&apos;s expert tracking of sub-national events across four
		regions: Greater China, Northeast Asia, South Asia, and Southeast Asia.
		</p>
		<p>
		Our analysts review hundreds of open sources daily and contextualize &apos;events&apos; of particular
		importance for Canadian audiences. Events include an action or announcement made by an
		individual, a government, or an organization, or a disruption to the status quo: a natural
		disaster, social unrest, or a public health crisis. While all events occur at a specific place or time,
		they potentially lead to or signal a disruption within the overall operating environment. In line
		with emerging trade and investment trends, CAST focuses on events related to environmental,
		social, and governance (ESG) developments in the region.
		</p>
		<p>
		In addition to the online platform allowing users to search events by sub-national jurisdiction
		and keyword, CAST is a hub for deeper intelligence on the region. Every week, APF Canada
		publishes four regional <i>Insights</i> - two-page snapshots that explain an event of particular
		importance in greater detail - and a weekly Asia Watch newsletter capturing and summarizing
		critical events our analysts are tracking.
		</p>
		<p>
		APF Canada will soon release business intelligence, climate-change impact, and
		political risk reports - all powered by CAST - alongside annual state of the region reports
		and innovative &apos;foresight&apos; reports projecting Canada&apos;s interests in the region into the future.
		</p>
		<p>
		And our CAST team also provides expert advisory services to Canadian businesses, institutions,
		and organizations seeking a better understanding of local and regional trends across Asia,
		including board briefings and CEO roundtables, tailored reports and data analysis, and
		subscriptions to the CAST database.
		</p>
		<p>To learn more, please refer to our <Link to="methodology">methodology</Link>.</p>
		</>
	)

	/*
	// old
	return (<>
		<h1>About CAST</h1>

		<p>The Canada-Asia Sustainability Tracker (CAST) is an ongoing effort to identify and track <Link to="methodology/events">events in Asia</Link> having potential <Link to="methodology/events/ESG">ESG</Link> impacts for Canada&apos;s <Link to="methodology/connections">interests in the region</Link>. This wide-ranging data collection effort will inform the work of the Asia Pacific Foundation of Canada as we help Canadians to engage with Asia knowledgeably. Our goal is to provide up-to-date, local-level, practical information for Canadians.</p>

		<p>CAST will provide three main points of access for public users, partner agencies, and researchers. At the highest level will be the <b>regular reports</b> we generate from our trend analyses of the data collected by our analysts. Next, we are building an <Link to="/">online interface</Link> to help users explore trends in the data in a more up-to-date and self-guided way. Finally, we provide a <Link to="api">data API</Link> for our own analysts and other research users to explore the full database in depth.</p>

		<p>To learn more, please refer to our <Link to="methodology">documentation</Link>.</p>
	</>)
	*/
}
