import { Link } from 'react-router-dom'
import ConstructionTape from '../layouts/ConstructionTape'
import Title from '../components/Title'

export default function ApiDocs(){
	return (<>
		<Title>CAST data APIs</Title>
		<p>CAST provides a <a href="https://graphql.org/">GraphQL</a> API to access the data we collect on <Link to="../methodology/events">events</Link> and certain other datasets. Users who are logged in with access to CAST are able to access the API endpoint at:</p>

		<code>https://cast.asiapacific.ca/gql/risk</code>

		<ConstructionTape>
			The API is partially self-documenting, however we will be working on more extensive documentation to be added here later on.
		</ConstructionTape>

	</>)
}
