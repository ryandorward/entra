import Title from '../components/Title'

export default function Terms() {
  return (
    <>
    <Title>Website Terms of Use</Title>
    <div dangerouslySetInnerHTML= {{__html: `
<a name="2" id="2"></a>
<h2>Legal Notice<br />
Copyright</h2>

<p>All content, including text and images, appearing on the Asia Pacific Foundation of Canada website (this "Website") is the property of the Asia Pacific Foundation of Canada ("APF Canada" or the "Foundation"), or is used by it under license or with the permission of the copyright owner, and is protected by international copyright laws. Such content does not constitute material in the public domain under such copyright laws and is subject to the restrictions on use set out in this legal notice.&nbsp;</p>

<p>No part of this Website may be copied, reproduced, posted, transmitted, published, stored, re-distributed or otherwise exploited for any other purpose in any form or by any means without the express advance written permission of the Asia Pacific Foundation of Canada. Unauthorized use or distribution of any part of this Website is strictly prohibited. For information on obtaining permission to use or distribute the contents of this Website please contact: <a href="mailto:info@asiapacific.ca">info@asiapacific.ca.</a></p>

<p>Despite the foregoing limitations, visitors to this Website are permitted "fair dealing" of this Website's content without express permission. "Fair dealing" includes the making of one copy of copyrighted materials for research and educational or private study purposes.</p>

<p>Where any content of this Website is copied, reproduced, posted, transmitted, published, stored, re-distributed or otherwise exploited in accordance with this legal notice, all documents and communications containing such content, including other websites, must acknowledge the source of the content by providing a source citation stating "Source: Asia Pacific Foundation of Canada Website" followed by the full URL of the source pages and the date of extraction from this Website.</p>

<h3>Disclaimer</h3>

<p>The Asia Pacific Foundation of Canada makes no express or implied warranty about the accuracy, usefulness, merchantability or fitness for any purpose of any content appearing on this Website, whether owned by the Asia Pacific Foundation of Canada or any other person or entity. The Asia Pacific Foundation of Canada does not guarantee the accuracy of any information available on this Website and assumes no responsibility for the use of such information. In no event will the Asia Pacific Foundation of Canada be liable to any person or entity for any costs or damages of any kind whatsoever, whether based on contract, negligence or tort, or any punitive, exemplary, incidental, consequential or special damages or any loss of profits, business use or data, resulting from any use of any content available on this Website.</p>

<p>The presentation of any views or opinions expressed by any experts or specialists on this Website does not constitute or imply any endorsement of such views and opinions by the Asia Pacific Foundation of Canada, and such views and opinions do not necessarily reflect those of the Asia Pacific Foundation of Canada.</p>

<h3>Links</h3>

<p>The Asia Pacific Foundation of Canada provides links to other websites (a "Linked Website") which may be of interest to users of this Website (each a "User") solely for the convenience of such Users. These links will allow a User to leave the Asia Pacific Foundation of Canada Website. The Linked Websites are not under the control of the Asia Pacific Foundation of Canada and the Asia Pacific Foundation of Canada does not endorse nor assume any responsibility for any content contained on any Linked Website, nor any responsibility for any changes or updates thereto, or any content contained on links contained in a Linked Website. The Asia Pacific Foundation of Canada is not responsible for Webcasting or any other form of sound or video broadcasts received by any User from any Linked Website. The Asia Pacific Foundation of Canada is not able to inspect or confirm the correctness or accuracy of any content contained on any Linked Websites and makes no express or implied warranty about the accuracy, usefulness, merchantability or fitness for any purpose of any content contained on any Linked Websites.</p>

<a name="3" id="3"></a>
<h2>Privacy Policy</h2>

<p>The Asia Pacific Foundation of Canada (“the Foundation”) is an independent, not-for-profit think-tank on Canada's relations with Asia established by an Act of the Parliament of Canada. The Foundation functions as a knowledge broker, bringing together people and knowledge to provide the most current and comprehensive research, analysis and information on Canada's transpacific relations; it is defined as a government institution under the Access to Information Act and the Privacy Act.</p>

<h3>Commitment</h3>

<p>The Foundation is committed to protecting the privacy of the personal information of its staff, board members, fellows, contractors and partners. The Foundation values the trust of those we deal with, and of the public, and recognizes that maintaining this trust requires that we be accountable and transparent in how we treat the information that is shared with us.</p>

<p>Through its various programs and activities, the Foundation frequently gathers and uses personal information. Any information collected by the Foundation is subject to the Privacy Act. The purpose of the Privacy Act is to protect the privacy of individuals with respect to personal information held by a government institution and to provide individuals with a right of access to such information.</p>

<p>Each User acknowledges that all conferences, blogs, networks, bulletin boards and any other communications forums hosted by this Website are publicly available to other Users and are not private communications. Further, each User acknowledges that all postings, conferences and other communications by other Users appearing on this Website have not been endorsed by the Asia Pacific Foundation of Canada and have not been, nor shall they be deemed to have been, reviewed, screened or approved by the Asia Pacific Foundation of Canada.</p>

<h3>Use and Disclosure of Personal Information Provided to the Foundation</h3>

<p>The Asia Pacific Foundation of Canada collects personal identifying information relating to its Users only when such Users register with this Website or with the Asia Pacific Foundation of Canada. Registration may be required for the receipt of subscription-based products online or for access to certain portions of this Website where Users submit content or participate in interactive online activities (i.e., bulletin boards, blogs, forums). The Asia Pacific Foundation of Canada shall restrict its use of any personal identifying information to use for its internal purposes only and shall not knowingly disclose any such information to any third party, except where required by law. For the purposes of this section, "internal purposes" shall include the conduct of surveys, marketing studies and promotional activities, program planning, evaluation and audits for the Asia Pacific Foundation of Canada, the monitoring of compliance with the terms and conditions of use and the privacy policy set out in this legal notice, and upon notice to the User, editorial and feedback purposes. If a User objects to the use of his or her personal identifying information for any reason, the User may modify his or her registration information online or the User may forward an email request to the Asia Pacific Foundation of Canada at <a href="mailto:info@asiapacific.ca">info@asiapacific.ca</a> requesting that it cease all use of such information, upon receipt of which the Asia Pacific Foundation of Canada will cease such use. The Asia Pacific Foundation of Canada will make every reasonable effort to maintain all personal identifying information received from its Users in a secure environment.</p>

<p>For further clarification, in the case of personal information collected and shared on networks set up and managed by the Foundation, after a User has consented to share their personal information with other Users of the same network, APF Canada will no longer be in a position to control how other members of a network will use or further share these elements of personal information with third parties, and that APF Canada accepts no responsibility for the consequences that may result from such uses and disclosures. A User may at any time rescind their consent to disclosure by deleting their personal information or by requesting that APF Canada remove their information from public view, in which case their information will cease to be visible to the other members within two business days.</p>

<p>All personal information collected by the Foundation about grant or fellowship and other award or contract applicants is used to review applications and to administer and monitor awards, which are part of the Foundation’s mandate of promoting dialogue on economic, security, political and social issues, to help foster informed decision-making in the Canadian public, private and non-governmental sectors. Consistent with these purposes, applicants should also expect that information collected by the Foundation may come to be used and disclosed in the following activities:</p>

<p>1. As part of the review process, applications are disclosed to selection committees which may be composed of experts recruited from relevant sectors of society. All participants in these review activities are advised of the Foundation's expectations with regard to the confidentiality and protection of the information entrusted to them.</p>

<p>2. The Foundation routinely publishes and disseminates certain details about successful applications, including the name of the applicant, a biography, the amount awarded, the institution and department or organization where they study or work, the field of research or work, and the project title of their research. The information will normally be published on the Foundation’s website.</p>

<h3>Privacy Practices</h3>

<p>Personal information gathered by the Foundation is kept in confidence. Foundation personnel are authorized to access personal information only as required to deal with the information for the reason(s) for which it was obtained. Safeguards are in place to ensure that the information is not disclosed or shared more widely than is necessary to achieve the purpose(s) for which it was obtained. We also take measures to ensure that the integrity of this information is maintained and to prevent it being lost, stolen or destroyed.</p>

<p>The Foundation retains the personal information it collects for a period of not less than two years. When personal information is disposed of by the Foundation, care is taken to ensure that there is no recoverable trace of the information.</p>

<h3>Access to Personal Information</h3>

<p>The&nbsp;Privacy Act grants all individuals in Canada the right to access any personal information about themselves that is held by institutions such as the Foundation. It also gives individuals the right to request the correction of their personal information where they find it to be erroneous.</p>

<p>For instructions on how to make a formal request of access to personal information pursuant to the Privacy Act, please visit the website of the Office of the Privacy Commissioner of Canada at <a href="https://www.priv.gc.ca/en/" target="_blank">https://www.priv.gc.ca/en/</a></p>

<p>Please note that although the Privacy Act provides for a formal procedure for requesting access to personal information held by the Foundation, regular channels of communication are also available to anyone wishing to obtain information from the Foundation.</p>

<h3>Privacy Policy Updates</h3>

<p>The Foundation will review its Privacy Policy regularly. We may revise our Privacy Policy, and if so we will provide the revised policy on our website. At all times, the current Privacy Policy may be viewed online at <a href="http://www.asiapacific.ca/">www.asiapacific.ca</a>.</p>

<h3>Contact Information</h3>

<p>We have appointed an officer at the Foundation to address any queries, concerns or complaints you may have. Our Privacy Officer can be reached by email at <a href="mailto:atip.coordinator@asiapacific.ca">atip.coordinator@asiapacific.ca</a> or by mail at the following address:</p>

<p>Access to Information and Privacy Coordinator<br />
Asia Pacific Foundation of Canada<br />
680-1066 West Hastings Street<br />
Vancouver, B.C.<br />
Canada V6E 3X2</p>

<p><a className="file file--mime-application-pdf file--application-pdf" data-entity-type="file" data-entity-uuid="cca67050-5ef1-43e1-9872-0fdb83275138" href="/sites/default/files/inline-files/PIA_2008.pdf" target="_blank">Privacy Impact Assessment</a>&nbsp;(2008)</p>

<h2>Acceptance of These Terms</h2>

<p>Each User of this Website who continues use of this Website shall be deemed to have consented to and agreed to comply with the terms and conditions of use and the Privacy Policy established by the Asia Pacific Foundation of Canada and set out in this legal notice. Any visitor to this Website who does not agree with the terms and conditions of use and the privacy policy set out in this legal notice is hereby given notice to cease all use of this Website.</p>
`}} /></>

  )

}