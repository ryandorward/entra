import { gql } from '@apollo/client'

// The fields this componenet needs are imported by the central querying component
export const jurisdictionTrendEventFields = gql`
fragment jurisdictionTrendEventFields on Event {
	id date impacts { id geo_id }
}`

/*
import { useEffect, useState, useContext, useRef } from 'react'
import { Link } from 'react-router-dom'
import { gql, useReactiveVar } from '@apollo/client'
import { assignBoundaries } from '@apfcanada/jurisdictions'
import Globe, { Context as globeContext } from '../maps/globe/Map'
import graph from '../jurisdictions/graph'
import { rankIDs } from '../utilities/frequency.js'
import { Spinner } from '../Spinners'
import { topWeightedEvents, topWeightedEventsLoading } from './Filters'
import highlight from '../maps/geographic/styles/highlight.module.css'
import ReactTooltip from 'react-tooltip'



const title = <h2>Events Locator</h2>

export default function JurisdictionTrends(){
	const [ topJurs, setTopJurs ] = useState([])
	const events = useReactiveVar(topWeightedEvents)
	const loading = useReactiveVar(topWeightedEventsLoading)

	useEffect(()=>{
		if (events){
			const rankedIDs = rankIDs(
				events.map( event => event.impacts.map( impact => (
					{ date: event.date, id: impact.geo_id }
				) ) ).flat()
			)
			graph.lookup(rankedIDs.slice(0,30)).then(setTopJurs)
		}
	}, [events])

	if(loading) return <div>{title}<Spinner contained size={50}/></div>;
	return (
		<div className="trending-jurisdictions">
			{title}
			<ReactTooltip type="dark" effect="float" place="top" id='globe-tip' className='react-tooltip-general globe-tip'/>
			<Globe><GlobeContent jurisdictions={topJurs}/></Globe>
		</div>
	)
}

export function GlobeContent({jurisdictions}){
	const [ jurs, setJurs ] = useState([])
	const { pathGen, setLoading } = useContext(globeContext)
	useEffect(()=>{
		setLoading(true)
		assignBoundaries(jurisdictions).then( jurs => {
			setJurs(jurs.sort((a,b)=>a.depth-b.depth))
			setLoading(false)

		} )
	},[jurisdictions])
	const mounted = useRef();
	useEffect(() => {
		if (!mounted.current) {
			// do componentDidMount logic
			mounted.current = true;
		} else {
			ReactTooltip.rebuild() // this is necessary to update the ReactTooltips as elements in the svg change
		}
	})
	return jurs.map( jur => {
		let point
		if( pathGen.area(jur.boundary) <= 4.5**2 ){ point = jur.geom.point }
		return (
		<Link key={jur.geo_id} to={`/map/events/jurisdiction/${jur.geo_id}`}>
			<path
				className={highlight.jurisdictionInFocus}
				d={pathGen(point??jur.boundary)}
				data-tip={jur.name.en}
				data-for='globe-tip'
			>
			</path>
		</Link>
		)
	} )
}
*/