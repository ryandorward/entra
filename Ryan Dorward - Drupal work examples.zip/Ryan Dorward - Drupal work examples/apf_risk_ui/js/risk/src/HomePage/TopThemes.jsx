import { Link } from 'react-router-dom'
import { gql, useReactiveVar } from '@apollo/client'
import { scaleLinear } from 'd3-scale'
import { useEffect, useState } from 'react'
import { rankWithWeight } from '../utilities/frequency.js'
import { lighter } from '../utilities/lighter.js'
import { topWeightedEvents, topWeightedEventsLoading } from './Filters'
import { Spinner } from '../Spinners'
import './top-themes.less'

let widthScale = scaleLinear().range([10, 100])

/*
const query = gql`
query (
	$startDate: String!
	$endDate: String!
	$in: [Int]
	$search: String
) {
	events( after: $startDate, before: $endDate top: 100 sort: "weight" in: $in search: $search ) {
		id date themes { id weight:tagIntersectionWeight name color }
	}
}`
*/

// The fields this componenet needs are imported by the central querying component
export const topThemesEventFields = gql`
fragment topThemesEventFields on Event {
	id date themes { id weight:tagIntersectionWeight name color }
}`

const title = <h2>Trending Topics</h2>

export default function Themes() {
	const events = useReactiveVar(topWeightedEvents)
	const loading = useReactiveVar(topWeightedEventsLoading)
	const [ topThemes, setTopThemes ] = useState(undefined)

	useEffect(()=>{
		if (events){
			const unrankedThemes = events.flatMap( event => event.themes.map( theme => {
				return { date: event.date, ...theme }
			} ) ).filter( theme => ! [12,13,14].includes(theme.id) )
			let themes = rankWithWeight( unrankedThemes, theme=>theme.weight, true )
			themes = themes.slice(0,8)

			let weights = themes.map(theme=>theme.weight)
			widthScale.domain([Math.min(...weights), Math.max(...weights)])
			setTopThemes( themes.map ( theme => {
				return { ...theme, width: widthScale(theme.weight)}
			}))
		}
	}, [events])

	if( loading ) return <div>{title}<Spinner contained size={50}/></div>

	return (
		<div className="top-themes">
			{title}
			<div className = "top-themes-container">
				{topThemes && topThemes.map((theme) => (
					<Link key={theme.id} to={`/timeline/events/theme/${theme.id}`} className="top-theme">
						<div className="bar"
							style={{width:`${widthScale(theme.weight)}%`,backgroundColor:lighter(theme.color)}}>
						</div>
						<div className="text">
							{theme.name}
						</div>
					</Link>
				) )}
			</div>
		</div>
	)
}
