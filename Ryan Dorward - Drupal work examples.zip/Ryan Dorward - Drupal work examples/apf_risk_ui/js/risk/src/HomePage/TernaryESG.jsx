import { useRef, useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { ternaryPlot } from 'd3-ternary'
import { gql, useReactiveVar } from '@apollo/client'
import { Delaunay } from 'd3-delaunay'
import { scalePow } from 'd3-scale'
import { bins, barycentricScale, color } from '../events/ESG/scale.js'
import { reduceThemesToESG } from '../events/ESG/reduceThemesToESG.js'
import { eventThemes } from '../events/ESG/themesFragments.js'
import { lighter } from '../utilities/lighter.js'
import { currentlyHoveredEventId, listenForHoverEvent } from '../utilities/hover.js'
import CirclePulse from '../maps/CirclePulse'
import styles from '../events/ESG/scale.module.css'
// import { dateRange } from '../input/TimeSlider'
// import { activeJurs, activeKeyword } from './Filters'
import { topWeightedEvents, topWeightedEventsLoading } from './Filters'
import { Spinner } from '../Spinners'
import {TooltipProvider, Tooltip } from 'react-tooltip'
import 'react-tooltip/dist/react-tooltip.css'

const worker = new Worker( new URL('./ternaryLayoutWorker.js',import.meta.url) )
const [width,height,padding] = [400,360,10]
const radius = scalePow().exponent(0.5).range([6,12])

const tp = ternaryPlot(barycentricScale)
	.radius(width/2-padding)
	.labels(['Environment','Social','Governance'])
	.labelOffsets([15,15,15])

// get triangle point coordinates
let displayBins = bins.map( bin => {
	let [x,y] = tp(bin);
	return { x, y, ...bin }
} )
// get bin coordinates
let tesselation = Delaunay.from(displayBins.map(d=>[d.x,d.y]))
	.voronoi([-width/2,-height/2-40,width/2,height/2])

displayBins.forEach( (d,i) => d.pathData = tesselation.renderCell(i) )

/*
const query = gql`
${eventThemes}
query ESGtriangle (
	$startDate: String!
	$endDate: String!
	$in: [Int]
	$search: String
)  {
	events( after: $startDate, before: $endDate top: 50 sort: "weight" themes: [12,13,14] in: $in search: $search) {
		id title weight ...eventThemes
	}
}`
*/

/*
Fragment looks like this:

export const eventThemes = gql`
fragment eventThemes on Event {
	themes {
		id color tagIntersectionWeight isMeta
		parentThemes {
			id
			parentThemes
			{ id }
		}
	}
}`

Could optimize by computing events' themes every time:
- update an event's theme record every time it is CRUDed
- update all event's themes every time a theme is CRUDed

*/

// The fields this componenet needs are imported by the central querying component
export const ternaryESGEventFields = gql`
${eventThemes}
fragment ternaryESGEventFields on Event {
	id title weight ...eventThemes
}`

const title = (
	<h2>
		<Link to="/about/methodology/events/ESG">ESG</Link> Event Tracker
	</h2>
)

export default function(){

	/*
	const mounted = useRef();
	useEffect(() => { // update the ReactTooltips as elements in the svg/map change
		mounted.current ? ReactTooltip.rebuild() : mounted.current = true
	})
	*/

	/*
	const { start, end } = useReactiveVar(dateRange)
	const jurs = useReactiveVar(activeJurs)
	const search = useReactiveVar(activeKeyword)
	*/
	const [ eventScores, setEventScores ] = useState(undefined)

	const rawEvents = useReactiveVar(topWeightedEvents)
	const loading = useReactiveVar(topWeightedEventsLoading)

	useEffect(()=>{
		if (rawEvents){
			let events = rawEvents.map( ({id,title,weight,themes}) => {
				const {E,S,G} = reduceThemesToESG(themes)
				//if (id == 859)
				//	console.log({E,S,G}, themes, weight)
				const [x,y] = tp({E,S,G})
				const ESGcolor = color({E,S,G})
				return {cx:x,cy:y,id,title,weight,ESGcolor}
			} )
			const weights = events.map(e=>e.weight)
			radius.domain([Math.min(...weights),Math.max(...weights)])
			events.forEach( event => event.r = radius(event.weight) )
			worker.postMessage({events,vertices:tp.vertices()})
			worker.onmessage = ({data}) => setEventScores(data.events.reduce( (acc,cur) => { // make eventScores unique by id
				if( ! acc.find( e => e.id === cur.id ) ) acc.push(cur)
				return acc
			}, [] ))
		}
	}, [rawEvents])

	/*
	useQuery(
    query, {
      variables: {
        startDate: start.toISODate(),
				endDate: end.toISODate(),
				in: jurs?.length ? jurs.map(jur => jur?.geo_id ) : null,
				search: search
      },
      onCompleted: data => {
				let events = data.events.map( ({id,title,weight,themes}) => {
					const {E,S,G} = reduceThemesToESG(themes)
					const [x,y] = tp({E,S,G})
					const ESGcolor = color({E,S,G})
					return {cx:x,cy:y,id,title,weight,ESGcolor}
				} )
				const weights = events.map(e=>e.weight)
				radius.domain([Math.min(...weights),Math.max(...weights)])
				events.forEach( event => event.r = radius(event.weight) )
				worker.postMessage({events,vertices:tp.vertices()})
				worker.onmessage = ({data}) => setEventScores(data.events)
      }
    }
  )
	*/

	if( loading || ! eventScores ) return <div>{title}<Spinner contained size={50}/></div>

	return (
		<div className={styles['ternary-esg'] + ' ternary-esg'}>
			<TooltipProvider>
				{title}
				<svg viewBox={`${-width/2} ${-height/2-40} ${width} ${height}`}>
					<defs>
						<clipPath id="triangle"><path d={tp.triangle()}/></clipPath>
					</defs>
					<g clipPath="url(#triangle)">
						{displayBins.map( (d,i) => (
							<path key={i} className={styles.voronoiBin}
								d={d.pathData} style={{fill:lighter(d.color)}}/>
						) )}
					</g>
					<path d={tp.triangle()} className={styles.outerTriangle}/>
					{eventScores.map( props => <Event key={props.id} {...props}/> ) }
					{tp.axisLabels().map( ({position:[x,y],angle,label}) => {
						return (
						<text key={label} style ={{fontWeight: "bold"}}
							transform={`translate(${x},${y}) rotate(${angle})`}
							textAnchor="middle">
							{label}
						</text>
					) } )}
				</svg>
				{eventScores.map( props => <Tip key={props.id} id={props.id} title={props.title}/> ) }
			</TooltipProvider>
		</div>
	)
}

function Event({id,x,y,r,ESGcolor}){
	const ref = useRef()
	useEffect(()=>{
		listenForHoverEvent(ref.current,id)
	},[])
	const hoveredEventId = useReactiveVar(currentlyHoveredEventId)
	const style = {
		r: r,
		fill: ESGcolor, fillOpacity: 0.7,
		stroke: 'white', strokeWidth: 1
	}
	return (
		<Link to={`/map/event/${id}`}>
			<circle className={styles.circle} ref={ref} style={style} cx={x} cy={y}
				id={`esg-tip-${id}`}
			>
			</circle>
			{id == hoveredEventId && <CirclePulse x={x} y={y} radius={r}/> }
		</Link>
	)
}

function Tip({id, title}) {
	return <Tooltip
		variant='dark'
		anchorId={`esg-tip-${id}`}
		className='react-tooltip-general esg-tip'
		float={false}
		place='top'
		content={title}
		clickable={true}
	>
		<Link
			to={`/map/event/${id}`}
			className='event-link'
    >
			{title}
		</Link>
	</Tooltip>

}