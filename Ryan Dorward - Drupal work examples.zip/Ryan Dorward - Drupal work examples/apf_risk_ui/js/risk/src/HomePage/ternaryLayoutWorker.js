import { forceSimulation, forceX, forceY, forceCollide } from 'd3-force'
import forceSurface from 'd3-force-surface'

const collision = forceCollide().radius(d=>d.r).strength(0.1).iterations(3)
const triangleBounds = forceSurface().elasticity(0)

self.onmessage = ({data})=>{
	const { events, vertices:v } = data
	
	const surfaces = [
		{ from:{x:v[0][0],y:v[0][1]}, to:{x:v[1][0],y:v[1][1]}, label:'ES' },
		{ from:{x:v[1][0],y:v[1][1]}, to:{x:v[2][0],y:v[2][1]}, label:'SG' },
		{ from:{x:v[2][0],y:v[2][1]}, to:{x:v[0][0],y:v[0][1]}, label:'GE' }
	]
	
	forceSimulation(events)
		.force('x',forceX().x(e=>e.cx).strength(0.05))
		.force('y',forceY().y(e=>e.cy).strength(0.05))
		.force('collide',collision)
		.force('bounds',triangleBounds.surfaces(surfaces))
		.stop().tick(200)
	self.postMessage({events})
}
