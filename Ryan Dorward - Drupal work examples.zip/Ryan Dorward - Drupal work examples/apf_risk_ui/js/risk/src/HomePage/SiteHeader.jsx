import { Routes, Route } from 'react-router-dom'
import PageTitle from '../layouts/GridPageTitle'
import './site-header.less'

export default function() {
  return (
    <div className='site-header-outer'>
      <Routes>
        <Route path="" element={<SiteHeader/>}/>
      </Routes>
    </div>
  )
}

function SiteHeader () {
  return (
    <PageTitle metaTitle="Home | Canada–Asia Sustainability Tracker">
      Canada–Asia &shy;Sustainability Tracker
    </PageTitle>
  )
}