import { Link } from 'react-router-dom'
import ShowOnlyTo from '../ShowOnlyTo'

const statsPath = 'about/events/stats'

export default function(){
	return (
		<ShowOnlyTo minRole="jrAnalyst">
			<span>Event statistics tables:</span> 
			<ul>
				<li><Link to={`${statsPath}/actors`}>
					actors
				</Link></li>
				<li><Link to={`${statsPath}/sources-used`}>
					sources used
				</Link></li>
				<li><Link to={`${statsPath}/impacts`}>
					jurisdictions impacted
				</Link></li>
				<li><Link to={`${statsPath}/tags`}>
					tags
				</Link></li>
				<li><Link to={`${statsPath}/weight`}>
					weights
				</Link></li>
				<li><Link to={`${statsPath}/themes`}>
					themes
				</Link></li>
				<li><Link to={`${statsPath}/users`}>
					users
				</Link></li>
			</ul>
			<span>See also:</span>
			<ul>
				<li><Link to={`${statsPath}/sources-known`}>
					Known media sources by country
				</Link></li>
			</ul>
		</ShowOnlyTo>
	)
}
