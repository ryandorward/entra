import { useEffect, useState } from 'react'
import { useApolloClient, gql } from '@apollo/client'
import BigNumber from '../layouts/BigNumber'
import graph from '../jurisdictions/graph'
import Search from '../jurisdictions/Search'
import { Spinner } from '../Spinners'

const query = gql`query eventStats { events { id impacts { geo_id } } }`

export default function JurisdictionNumbers(){
	const [ canJurCount, setCanJurCount ] = useState(0)
	const [ asiaJurCount, setAsiaJurCount ] = useState(0)
	const [ eventJurCount, setEventJurCount ] = useState(0)
	const client = useApolloClient()
	useEffect(()=>{
		graph.readyWith(/.*/).then( graph => {
			const allConnectedJurs = new Set(
				graph.lookupNow(2).connections(/.*/,{descendants:true})
					.map(c=>c.jurisdictions).flat()
					.map(j=>[j,...j.ancestors]).flat()
			)
			setCanJurCount( [...allConnectedJurs].filter(j=>j.canadian).length )
			setAsiaJurCount( [...allConnectedJurs].filter(j=>!j.canadian).length )
		} )
		client.query({query}).then(({data})=>{
			const geo_ids = new Set(
				data.events.flatMap(e=>e.impacts).map(i=>i.geo_id)
			)
			setEventJurCount(geo_ids.size)
		})
	},[])
	
	// wait for at least one data source to return
	if(!(canJurCount||asiaJurCount)) return (
		<div><Spinner contained size={50}/></div>
	)
	return(
		<div>
			<Search/>
			<BigNumber number={canJurCount}
				labelPlural="Canadian jurisdictions connected to Asia"/>
			<BigNumber number={asiaJurCount}
				labelPlural="Asian jurisdictions connected to Canada"/>
			<BigNumber number={eventJurCount}
				labelPlural="jurisdictions impacted by events we're tracking"/>
		</div>
	)
}
