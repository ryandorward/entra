import Headlines from '../events/Headlines'
import {useReactiveVar} from '@apollo/client'
import { dateRange } from '../input/TimeSlider'
import './headlines.less'
import { activeJurs, activeKeyword } from './Filters'

export default function HomePageHeadlines(){
	const { start, end } = useReactiveVar(dateRange)
	const jurs = useReactiveVar(activeJurs)
	const search = useReactiveVar(activeKeyword)
	return (
		<div className="top-events passive-height-scrollable">
			<div>
				<h2>Active Events</h2>
				<div className="scrollable-overflow">
					<div className="scrollable-overflow-inner">
						<Headlines top={100} sort="event_date"
							before={end.toISODate()}
							after={start.toISODate()}
							search={search}
							in={jurs?.length ? jurs.map((jur) => jur?.geo_id) : null}
							withDescendants={true}
						/>
					</div>
				</div>
			</div>
		</div>
	)
}