import { useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { gql,makeVar, useReactiveVar, useQuery } from '@apollo/client'
import Slider, { dateRange } from '../input/TimeSlider'
import TextInput from '../input/TextInput'
import JurisdictionSelector from '../input/JurisdictionSelector'
import './filters.less'
import { topThemesEventFields } from './TopThemes'
import { tagTrendEventFields } from '../TagTrends/tagTrendsFragments.js'
// import { eventHeadlineData } from '../events/headlineDataFragment.js'
import { jurisdictionTrendEventFields } from './JurisdictionTrends'
import { ternaryESGEventFields } from './TernaryESG'

export const activeJurs = makeVar([])
export const activeKeyword = makeVar('')
export const topWeightedEvents = makeVar()
export const topWeightedEventsLoading = makeVar()

// export const topNEvents = makeVar()
// export const topNEventsLoading = makeVar()

// This query is watched by TopThemes TagTrends JurisdictionTrends and ESGTriange
// this query should be good for top themes AND tag trends
const topWeightedQuery = gql`
${topThemesEventFields}
${tagTrendEventFields}
${jurisdictionTrendEventFields}
${ternaryESGEventFields}

query filtersTopWeightedEvents (
  $startDate: String!
  $endDate: String!
  $in: [Int]
  $search: String
){ events ( after: $startDate, before: $endDate top: 50 sort: "weight" in: $in search: $search withDescendants: true ) {
    ...topThemesEventFields
    ...tagTrendEventFields
    ...jurisdictionTrendEventFields
    ...ternaryESGEventFields
  }
}`

/*
const topNQuery = gql`
${eventHeadlineData}
query eventHeadlines2 (
	$endDate: String $startDate: String
	$top: Int $sort: String $tags: [Int] $themes: [Int]
	$in: [Int] $withDescendants: Boolean $ids: [Int] $indirect: Boolean
	$search: String $offset: Int
) {
	events(
		ids: $ids before: $endDate after: $startDate
		tags: $tags themes: $themes top: $top offset: $offset sort: $sort
		in: $in withDescendants: $withDescendants indirect: $indirect search: $search
	) {
		...eventHeadlineData
	}
}`
*/

export default function () {
  return (
    <div className="filters">
      <Routes>
        <Route path="">
          <Route path="" element={<Filters/>}/>
        </Route>
        <Route path="*">
          <Route path="" element={null}/>
        </Route>
      </Routes>
    </div>
  )
}

function Filters(){
  const jurs = useReactiveVar(activeJurs)
  const search = useReactiveVar(activeKeyword)
  const { start, end } = useReactiveVar(dateRange)

  const { loading } = useQuery(
    topWeightedQuery, {
      variables: {
        startDate: start.toISODate(),
        endDate: end.toISODate(),
        in: jurs?.length ? jurs.map(jur => jur?.geo_id ) : null,
        search: search
      },
      onCompleted: data => {
        topWeightedEvents(data.events)
      }
    }
  )
  useEffect(()=>{
		topWeightedEventsLoading(loading)
	}, [loading])

  return (
    <div className="filters-inner">
      <h2>Filters</h2>
      <div className="controls controls-top">
        <Slider/>
        <div className="jur-selection-outer">
          <JurisdictionSelector
            values={jurs}
            onChange={(jurs) => {
              activeJurs(jurs)
            }}
          />
        </div>
        <div className="text-search-outer">
          <TextInput
            placeholder="Keyword search"
            value={search}
            onChange={e => {
              activeKeyword(e.target.value)
            }}
          />
        </div>
      </div>
      <div className="controls controls-bottom">
      </div>
    </div>
  )
}