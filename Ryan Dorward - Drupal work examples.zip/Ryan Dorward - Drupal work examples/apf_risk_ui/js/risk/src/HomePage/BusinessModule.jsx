import { Link } from 'react-router-dom'
import SelectBusinessJurs from '../connections/business/SelectJurisdiction'
import BusinessGlobe from '../connections/business/Globe'

export default function BusinessModule(){
	return (
		<div>
			<h3>Canadian Businesses In Asia<sup><Link to="/about/methodology/connections/business">*</Link></sup></h3>
			<SelectBusinessJurs/>
			<BusinessGlobe/>
		</div>
	)
}
