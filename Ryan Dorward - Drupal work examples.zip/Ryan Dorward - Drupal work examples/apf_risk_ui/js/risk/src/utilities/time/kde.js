import { gaussian } from '../gaussian.js'
const bw = 1*24*60*60 // 1 day bandwidth (seconds)

export function kde( thresholds, data,bandwidth=bw ){ // bandwidth is in seconds
	return thresholds.map( tval => {
		let density = sum( data.map( dval => gaussian(tval-dval,bandwidth) ) )
		return [ tval, density ]
	} )
}

function sum(array){
	return array.reduce((runningSum,val)=>runningSum+val)
}
