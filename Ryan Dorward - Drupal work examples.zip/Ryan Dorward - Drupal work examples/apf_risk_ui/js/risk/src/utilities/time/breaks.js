import { DateTime } from 'luxon'

const defaultMinSpace = 18 // px
const stepByUnits = ['year','month','week','day']

// https://moment.github.io/luxon/#/formatting?id=table-of-tokens
const labelFormats = {
	today: () => 'Today',
	year: (date) => date.toFormat('LLL. d, y'),
	month: (date) => date.toFormat('LLLL d'),
	week: (date) => date.toFormat('LLL d'),// ('ccc. LLL d')
	day: (date) => date.toFormat('cccc')
}

export function tickMaker(startDate,endDate,pxOfSpace,minSpace){
	minSpace = minSpace ?? defaultMinSpace
	const pxPerSec = pxOfSpace / (endDate.toSeconds()-startDate.toSeconds())
	function enoughSpace(date1,date2){
		return Math.abs(date1.toSeconds()-date2.toSeconds()) * pxPerSec >= minSpace
	}
	const ticks = [ { date: DateTime.now().startOf('day') , type: 'today' } ]
	for(const unit of stepByUnits){
		let tickDate = startDate.startOf(unit)
		let nextTick = tickDate.plus({[unit]:1})
		if( ! enoughSpace(tickDate,nextTick) ) break;
		while(tickDate < endDate){
			if( tickDate < startDate || ticks.some(t=>!enoughSpace(t.date,tickDate)) ){
				// outside range, or too close to an existing tick; do not add
			}else{
				ticks.push( { date: tickDate, type: unit } )
			}
			tickDate = tickDate.plus({[unit]:1})
		}
	}
	// format labels per major type
	ticks.map( tick => { tick.label = labelFormats[tick.type](tick.date) } )
	return ticks.sort((a,b)=>b.date-a.date)
}
