import { DateTime } from 'luxon'
// import { Interval } from 'luxon'

export function reformat(dateString){
	let date = DateTime.fromISO(dateString)
	return date.toLocaleString({
		day:'numeric',
		month:'short',
		year:'numeric'
	})
}

export function timeAgo(dateString){

	return reformat(dateString)
	/*
	let today = DateTime.now().startOf('day')
	let theDate = DateTime.fromISO(dateString).startOf('day')
	let past = true
	let i = Interval.fromDateTimes( theDate, today )
	if( i.invalid ){ // negative intervals are invalid
		past = false
		i = Interval.fromDateTimes( today, theDate )
	}
	let suffix = past ? 'ago' : 'from now'
	let days = Math.round(i.length('days'))
	if( days == 0 ){
		return 'Today'
	}else if( days == 1){
		return past ? 'Yesterday' : 'Tomorrow'
	}else if( days < 7 ){
		return `${days} days ${suffix}`
	}
	// if it's further out, just print the date
	return reformat(dateString)
	*/
}

export function timeRelative(dateString,referenceDateString){
	// ensure everything is treated as having the same time
	let reference = DateTime.fromISO(referenceDateString).startOf('day');
	let date = DateTime.fromISO(dateString).startOf('day');
	let diff = date.diff(reference);
	let days = Math.round(diff.as('days'))
	if( days == 0 ){ return 'the same day' }
	if(days == -1){ return 'the day before' }
	if(days == 1){ return 'the next day' }
	const preposition  = days > 0 ? 'later' : 'earlier'
	if( Math.abs(days) < 14 ){ return `${Math.abs(days)} days ${preposition}` }
	const weeks = Math.round(Math.abs(diff.as('weeks')))
	if(weeks < 8){ return `${weeks} weeks ${preposition}` }
	const months = Math.round(Math.abs(diff.as('months')))
	return `${months} months ${preposition}`
}

export function formatDateRange(start,end){
	if( start.year == end.year ){
		let year = start.toLocaleString({year:'numeric'})
		let startDay = start.toLocaleString({day:'numeric',month:'short'})
		let endDay = end.toLocaleString({day:'numeric',month:'short'})
		return `${startDay} - ${endDay}, ${year}`
	}else{
		let startDate = start.toLocaleString({day:'numeric',month:'short',year:'numeric'})
		let endDate = end.toLocaleString({day:'numeric',month:'short',year:'numeric'})
		return `${startDate} - ${endDate}`
	}
}
