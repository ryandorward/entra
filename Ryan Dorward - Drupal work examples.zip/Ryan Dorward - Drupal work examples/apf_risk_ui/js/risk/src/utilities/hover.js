import { makeVar } from '@apollo/client'

export const currentlyHoveredEventId = makeVar(null)
export const currentlyHoveredTagId = makeVar(null)

export function listenForHoverEvent(element,event_id){
	listenForHover(element,event_id,currentlyHoveredEventId)
}

export function listenForHover(element,event_id,hoverVar){
	const handleEntry = () => {
		hoverVar(event_id)
		if(hoverVar()!==event_id) console.log("hoverVar broken",hoverVar(),event_id)
		// if(hoveredEventId!==event_id) console.log("hoverVar broken (2)",hoveredEventId,event_id)
		//element.addEventListener('mouseleave',handleExit)
	}
	const handleExit = () => {
		// this is an attempt to debounce and/or prevent race condition where the next element is hovered before the previous one is unhovered
		// console.log('exit',event_id)
		setTimeout(()=>{
			if(hoverVar()==event_id) hoverVar(null)
		},1)
	}

	element.addEventListener('mouseenter',handleEntry)
	element.addEventListener('mouseleave',handleExit)

}

