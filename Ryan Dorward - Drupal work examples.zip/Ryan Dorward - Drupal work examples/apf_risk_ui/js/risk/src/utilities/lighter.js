import { cubehelix } from 'd3-color'

export function lighter(colour){
	if(!colour) return
	const CHcolour = cubehelix(colour)
	CHcolour.l += ( 1 - CHcolour.l ) / 2
	return CHcolour.toString()
}
