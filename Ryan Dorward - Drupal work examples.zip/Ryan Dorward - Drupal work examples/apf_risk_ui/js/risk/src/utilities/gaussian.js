// https://en.wikipedia.org/wiki/Gaussian_function
const [a,b] = [1,0]; // default bandwidth is 1

export function gaussian(x,bw){
	const c = bw ?? 1;
	return a*Math.exp( - ( ((x-b)**2)/(2*c**2) ) )
}
