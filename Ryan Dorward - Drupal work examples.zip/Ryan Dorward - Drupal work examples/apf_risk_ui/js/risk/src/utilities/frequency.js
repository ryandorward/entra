// takes a list of objects each having an id property
// returns a list of IDs sorted by frequency or other cumulative function
export function rankIDs(...args){
	return rankWithWeight(...args).map(d=>d.id)
}

export function rankWithWeight(list,value=()=>1,spreadVals){
	return [ ...list.reduce(
		( m, data ) => {
			let id = data.id
			if (m.has(id))
				m.get(id).weight += value(data)
			else {
				let vals = spreadVals ? {...data} : {}
				vals.id = id
				vals.weight = value(data)
				m.set(id, vals)
				// m.set(id,{id,weight:value(data)})
			}
			return m
		}, new Map()
	).values() ].sort((a,b)=>b.weight-a.weight)
}
