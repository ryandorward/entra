export function scrollToAnchor() {
	const hash = window.location.hash.substring(1) // get hash from url
	hash ?
		tryHash(hash, 5) : // try up to 5 times to find the hash if there is one
		window.scrollTo(0,0) // if there is no hash, go to top of page. As we click around, scroll position gets stuck otherwise
}

function tryHash (hash, tries = 0) {
	const anchor = document.getElementById(hash)
	if (anchor)
		anchor.scrollIntoView({behavior: "smooth"})
	else if (tries) {
		setTimeout(() => {
			tryHash(hash, tries-1)
		}, 100)
	}
}