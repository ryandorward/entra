import { getCookie, setCookie } from './utilities/cookies'
import { userToken } from './API.js'

export const authenticate = async () => {
	// 1. Check if we are authenticating by looking for creds
	// if the creds are not set, then we'll go ahead without authentication
	// this will be the case on the live site
	// live will still work without creds because user is logged in and API calls are not cross-origin
	let creds
	try { creds = process.env.REACT_APP_CREDS }
	catch { return false }
	let token
	// 2. Check if we are already authenticated
	// for more security, we can skip this by setting enableCookie to false
	// then client would have to login on each page load
	// for speed, set enableCookie = true
	const enableCookie = true
	const cookieName = 'accessToken'
	// use token from cookie if available
	if (enableCookie) {
		token = getCookie(cookieName)
		if (token) return token
	}
	// 3. Authenticate
	// on dev the creds will be set in an env variable
	// use these creds to log in and get the JWT token
	return fetch( `${userToken}?_format=json`, {
		method: 'POST',
		headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json'
		},
		body: JSON.stringify(creds) // this will contain u/p if available.
	}).then(response =>response.json()).then( data => {
		token = data.access_token
		enableCookie && setCookie(cookieName, token, 0.5)
		return token
	} )
}
