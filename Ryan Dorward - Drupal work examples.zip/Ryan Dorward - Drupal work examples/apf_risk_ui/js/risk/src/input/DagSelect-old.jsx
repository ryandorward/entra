import {useState, useEffect} from 'react'
import './style/dagSelect.css'

const defaultLabels = {
  add_node: 'add a node',
  select_option: 'Select an Option below',
  top_level_descriptor: 'Options',
  less_specific: 'Less Specific',
  more_specific: 'More Specific',
}

export const DagSelect = ({ values, onChange, getNodes, ...props }) => {

  const [active, setActive] = useState(null)
  const [selections, setSelections] = useState(values)
  const [parents, setParents] = useState([])
  const [children, setChildren] = useState([])
  const [loading, setLoading] = useState(false)
  const [dialogueOpen, setDialogueOpen] = useState(false)
  const labels = {...defaultLabels, ...props.labels}

  /*
    By managing state of selections (values) internally, we eliminate dependency on
    parent doing something sensible with this state, and this component is
    self-contained.
  */
  useEffect(() => {
    onChange(selections)
  },[selections])

  useEffect(() => {
    setLoading(true)
    getNodes(active?.id).then(nodes => {
      setChildren(nodes.more_specific)
      setParents(nodes.actors || nodes.more_general) //
      setLoading(false)
    })
  },[active])

  // make sure active node isn't in current selected nodes set
  const addable = active && !selections.find(node => node.id === active.id)

  return (
    <div className={'dag-select' + (dialogueOpen ? ' expanded':'') + ( props.className ? ' ' +  props.className : '')}>
      <div className = "react-tags-outer"
        onKeyDown={(e) => {
          e.code === 'Enter' &&  e.preventDefault() // this prevents unintentional form sumbission on enter from the fields
        }}
      >
        <SelectedNodes
          nodes={selections}
          onDelete={i => {
            const newNodes = [...selections]
            newNodes.splice(i, 1)
            setSelections(newNodes)
          }}
          dialogueOpen={dialogueOpen}
          setDialogueOpen={setDialogueOpen}
          labels={labels}
        />
      </div>

      { dialogueOpen && (
      <div className='selection-workspace'>
        <div className = 'current-selection'>
          <h3>{active ? 'Current Selection' : labels.select_option}</h3>
          { active && (
              <Node
                node={active}
                className={addable?'adder':'not-addable'}
                title={addable?'Add to selections':'This option has already been selected. Try choosing something less or more specific.'}
                onClick={e => {
                  e.preventDefault()
                  if (addable) {
                    setSelections([...selections, active])
                    setActive(null)
                    setDialogueOpen(false)
                  }
                }}
              />
          )}
          <button
            className='cancel'
            onClick={() => {
              setActive(null)
              setDialogueOpen(false)
            }}
          >
            <a>cancel</a>
          </button>
        </div>

        <div className='columns'>
          <Column
            label={ active ? labels.less_specific : labels.top_level_descriptor}
            className='parents'
            nodes={parents}
            setActive={setActive}
            loading={loading}
            spinner={props.spinner}
          />
          <Column
            label={ active ? labels.more_specific : ''}
            className='children'
            nodes={children}
            setActive={setActive}
            loading={loading}
            spinner={props.spinner}
          />
        </div>
      </div> )}
    </div>
  )
}

function SelectedNodes({nodes, onDelete, dialogueOpen, setDialogueOpen, labels}) {
  return (
    <div className='selected-nodes'>
      { nodes.map((node, i) => (
        <Node key={node.id} node={node} onClick={() => onDelete(i)} />
      ))}
      {!dialogueOpen && (
        <button type='button' className='adder'
          onClick = {e => {
            e.preventDefault()
            setDialogueOpen(true)
          }}
        >
          <a>{labels.add_node}</a>
        </button>
      )}
    </div>
  )
}

const Column = ({ nodes, label, className, loading, setActive, children, spinner}) => {
  const classes = `column ${className}` + ((nodes?.length > 0) ? '' : ' empty')
  return (
    <div className={classes}>
      { label && <h3>{label}</h3> }
      { loading ? spinner
        : nodes?.map(node => node &&
        <Node
          key={node.id}
          node={node}
          onClick={e => {
            e.preventDefault()
            setActive(node)
          }}
        />)
      }
      { children }
    </div>
  )
}

export const Node = ({node, onClick, children, className, title}) => {
  return (
    <button
      type='button'
      className={className}
      title={title || node.description && '"'+node.label+'": '+node.description} onClick = {onClick}
    >
      <a>{node.label}</a>
      { children }
    </button>
  )
}