import { DagSelect } from './DagSelect'
import { Spinner } from '../Spinners'
import { JurisdictionGraph } from '@apfcanada/jurisdictions'

const graph = new JurisdictionGraph()


const jursExclude = [
  6, // Australia
  8, // new zealand
  35 // Mongolia
]

export const JurisdictionSelector = ({values, onChange}) => {
  const formattedValues = values.map(jur=>formatJur(jur)) // need to format the jurs to values for DagSelect
  return (
    <DagSelect values={formattedValues} onChange={ (values) => {
      graph.lookup(values.map(val => (val.id ?? val.geo_id))).then(
        (jurs) => { onChange(jurs)}
      )}
    } getNodes={getJurisdictions}
      labels = {{
        add_node: 'Add a jurisdiction',
        top_level_descriptor: 'Countries',
        select_option: 'Select a jurisdiction below, or',
      }}
      spinner={<Spinner/>}
    />
  )
}
export default JurisdictionSelector

async function getJurisdictions(id){
  if (!id)
    return graph.countries().then((jurs) => {
      return {
        more_general: jurs.filter(jur => !jursExclude.includes(jur.geo_id)).map(j => formatJur(j)).sort((a,b)=>a.label.localeCompare(b.label)),
      }
    })
  return graph.lookup(id).then((jur) => {
    return {
      more_specific: jur.children?.map(j => formatJur(j)).sort((a,b)=>a.label.localeCompare(b.label)),
      more_general: jur.parent && [formatJur(jur.parent)],
      id: jur.geo_id
    }
  })
}

/* Copied from NameHeader.jsx */
function typeArticle(jur){
	return /island|auto*|uninc*/i.test(jur.type.label.en) ? 'an' : 'a'
}

/* Copied from NameHeader.jsx */
function preposition(jur){
	return /island/i.test(jur.type.label.en) ? 'on' : 'in'
}

/* Bastardized from NameHeader.jsx */
function description(jur) {
  if (!jur.parent)  // a country
    return `a ${jur.type.label.en}`
  else if (jur.parent == jur.administers)
    return `${jur.type.label.en} and capital of ${jur.administers.name.en}`
  else {
    let description = `${typeArticle(jur)} ${jur.type.label.en} ${preposition(jur.parent)} ${jur.parent.name.en}`
    jur.administers && (description += ` and capital of ${jur.administers.name.en}`)
    return description
  }
}

function formatJur(jur) {
  return {
    id: jur.geo_id,
    label: jur.name.en,
    description: description(jur)
  }
}