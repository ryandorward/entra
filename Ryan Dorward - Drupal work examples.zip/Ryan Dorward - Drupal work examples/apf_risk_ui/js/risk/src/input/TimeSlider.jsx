import { useRef, useEffect, useState } from 'react'
import { makeVar, useReactiveVar } from '@apollo/client'
import { select } from 'd3-selection'
import { brushX } from 'd3-brush'
import { DateTime } from 'luxon'
import { scaleTime } from 'd3-scale'
import { formatDateRange } from '../utilities/time/format.js'
import './time-slider.less'

const [ width, height, padding ] = [ 300, 30, 5 ]

const today = DateTime.now().plus({days:1})
const earliest = DateTime.fromISO('2021-06-16')
const lastMonth = DateTime.now().minus({days:365})

export const dateRange = makeVar({start:lastMonth,end:today})

let X = scaleTime()
	.domain([earliest.toJSDate(),today.toJSDate()])
	.range([5,width-padding])

export default function TimeSlider(){
	const ref = useRef()
	const [ tempDateRange, setTempDateRange ] = useState(dateRange)
	const { start, end } = useReactiveVar(dateRange)

	const [ { brush } ] = useState(
		{ brush: brushX().extent([[padding,0],[width-padding,5]]) }
	)

	useEffect(() => {
		select(ref.current)
			.call(brush)
			// .call(brush.move, defaultSelection) // not necessary here
			.attr('transform', 'translate(-5,10)')
		brush
			.on('brush',({sourceEvent,selection}) => {
				sourceEvent && setTempDateRange(dateRangeFromSelection(selection))
			})
	},[])

	useEffect(() => {
		brush
			.on('end',({selection}) => {
				// for some reason d3 gives null for selection when it has 0 width for the end event
				// when this happens, set dateRange using previously set temp instead
				const newDateRange = selection ? dateRangeFromSelection(selection) : tempDateRange
				dateRange(newDateRange)
			})
	},[tempDateRange])

	useEffect(()=>{
		select(ref.current)
			.call( brush.move, [ X(start.toJSDate()), X(end.toJSDate()) ] )
	},[start.toISODate(),end.toISODate()])

	return (
		<div className="time-slider">
			<div className="dateRange">
				<span className="dateRangeLabel">
					Date Range:&nbsp;
				</span>
				<span>
					{ formatDateRange(tempDateRange.start ?? start, tempDateRange.end ?? end) }
				</span>
			</div>
			<svg viewBox={`0 0 ${width} ${height}`}>
				<g ref={ref}/>
			</svg>
		</div>
	)
}

function dateRangeFromSelection(selection){
	var start = DateTime.fromJSDate(X.invert(selection[0]))
	var end = DateTime.fromJSDate(X.invert(selection[1]))
	return {start,end}
}