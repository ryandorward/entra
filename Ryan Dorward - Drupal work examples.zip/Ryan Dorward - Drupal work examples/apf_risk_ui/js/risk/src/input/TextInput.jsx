// import Input from 'rc-input'
import { useState } from 'react'
import './text-input.less'
import {
	IoIosClose
} from 'react-icons/io'

export default function TextInput(props){
	const [focused, setFocused] = useState(false)
	return (
		<div className="clearable-text-input">
			<input
				type="text"
				{...props}
				placeholder={focused? '' : props.placeholder}
				onFocus={() => setFocused(true)}
				onBlur={() => setFocused(false)}
			/>
			<IoIosClose
				className={"clear-icon " + (props.value ? 'active' : '')}
				onClick={() => {props.onChange({target: {value: ''}})}}
			/>
		</div>
	)
}