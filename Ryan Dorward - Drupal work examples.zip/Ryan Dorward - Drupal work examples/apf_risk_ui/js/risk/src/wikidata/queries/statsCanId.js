import { wikidataQuery } from '@apfcanada/wikidata'

export default async function(Qid){
	const query = `SELECT ?statsCanID WHERE { wd:${Qid} wdt:P3012 ?statsCanID. }`
	return wikidataQuery(query).then( r => r[0].statsCanID.value )
}
