import { wikidataQuery } from '@apfcanada/wikidata'

export default async function(countryQid){
	const query = `
	SELECT 
		( substr(str(?publisher),32) as ?id )
		( ?publisherLabelEN as ?label )
		( GROUP_CONCAT( DISTINCT ?typeLabelEN; separator=" / " ) AS ?types )
		( GROUP_CONCAT( DISTINCT ?website; separator=" | " ) AS ?websites )
		( GROUP_CONCAT( DISTINCT ?hqLabelEN; separator=" / " ) AS ?HQ )
		( GROUP_CONCAT( DISTINCT ?languageLabelEN; separator=' / ' ) as ?languages )
		( GROUP_CONCAT( DISTINCT ?alignmentLabelEN; separator=' / ' ) as ?politicalBias )
	WHERE {
		{ ?publisher wdt:P31/wdt:P279* wd:Q1193236 ; 
			} UNION { ?publisher wdt:P31/wdt:P279* wd:Q192283 }
		?publisher wdt:P17 wd:${countryQid} ; wdt:P31 ?type .
		OPTIONAL { ?publisher wdt:P407 ?language }
		OPTIONAL { ?publisher wdt:P856 ?website }
		OPTIONAL { ?publisher wdt:P159 ?hq }
		OPTIONAL { ?publisher (wdt:P1387|wdt:P1142) ?alignment }
		SERVICE wikibase:label { 
			bd:serviceParam wikibase:language "en-ca,en,fr,zh,ja" . 
			?publisher rdfs:label ?publisherLabelEN .
			?type rdfs:label ?typeLabelEN .
			?hq rdfs:label ?hqLabelEN .
			?language rdfs:label ?languageLabelEN .
			?alignment rdfs:label ?alignmentLabelEN .
		}
		FILTER ( NOT EXISTS { ?publisher wdt:P576 ?dissolution } )
		FILTER ( NOT EXISTS { ?publisher wdt:P1366 ?replacement } )
	}
	GROUP BY ?publisher ?publisherLabelEN`
	return wikidataQuery(query)
}
