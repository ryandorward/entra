import { wikidataQuery, values } from '@apfcanada/wikidata'
import { Jurisdiction } from '@apfcanada/jurisdictions'
import graph from '../../jurisdictions/graph'

// accepts and returns either a jurisdiction or an array of Jurisdiction objects
export default async function assignBorders(jurisdictions){
	// is this a single or an array? Let's just handle arrays
	var single = false
	if(jurisdictions instanceof Jurisdiction){
		jurisdictions = [jurisdictions]
		single = true
	}
	// which jurisdictions need to be queried? Don't do more than 200 at once
	const jursToQuery = jurisdictions
		.filter( j => j.queryStatus.neighbors == 0)
		.slice(0,500)
	if(jursToQuery.length == 0) return single ? jurisdictions[0] : jurisdictions
	jursToQuery.map(j=>j.queryStatus.neighbors = 1) // request in progress
	const idString = values(jursToQuery.map(j=>j.wikidata))
	const query = `
	SELECT 
	  ( substr(str(?place),32) as ?a ) 
	  ( GROUP_CONCAT(substr(str(?borderPlace),32);separator=",") as ?borders )
	WHERE {
	  VALUES ?place { ${idString} }
	  ?place wdt:P47 ?borderPlace .
	} 
	GROUP BY ?place`
	return wikidataQuery(query).then( data => {
		data.map( result => {
			const a = graph.lookupNow(result.a.value)
			result.borders.value.split(',').map( borderQID => {
				const b = graph.lookupNow(borderQID)
				if(b) a.borderWith(b)
			} )
		} ) 
		jursToQuery.map( j => j.queryStatus.neighbors = 2 ) // query accomplished
		// are there any we haven't queried yet?
		if( jurisdictions.some( j => j.queryStatus.neighbors == 0 ) ){
			return assignBorders(jurisdictions)
		}
		return single ? jurisdictions[0] : jurisdictions
	} )
}
