import { wikidataQuery, values } from '@apfcanada/wikidata'

export default async function(jurisdictions){
	let jursToQuery = jurisdictions.filter(j=>j.queryStatus.population==0)
	jursToQuery.map( j => j.queryStatus.population = 1 ) // in progress
	let batchSize = 500, i = 0
	while( i < jursToQuery.length ){
		let batch = jursToQuery.slice(i,i+batchSize)
		i += batchSize
		const query = `
		SELECT ( substr(str(?jurisdiction),32) as ?jur ) ?pop
		WHERE {
			VALUES ?jurisdiction { ${values(batch.map(j=>j.wikidata))} }
			OPTIONAL { ?jurisdiction wdt:P1082 ?pop }
		}`
		await wikidataQuery(query).then( data => {
			jursToQuery.map( j => j.queryStatus.population = 2 ) // received
			data.map( result => {
				let jur = batch.find( j => j.wikidata == result.jur.value )
				if(result?.pop){
					return jur.setPopulation(Number(result.pop.value))
				}
				console.warn(`${jur.name.en} (${jur.wikidata}) is missing population data`)
			} )
		} )
	}
	// return all jurisdictions regardless of sucess/failure
	return jurisdictions
}
