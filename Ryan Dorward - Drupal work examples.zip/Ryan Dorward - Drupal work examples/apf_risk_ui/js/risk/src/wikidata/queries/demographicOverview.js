import { wikidataQuery } from '@apfcanada/wikidata'

export default async function(Qid){
	const query = `
	SELECT 
		?population ?lifeExpectancy ?fertility ?literacy
		?income ?incomeIsoCode
		?GDP ?GDPIsoCode
	WHERE { 
		VALUES ?place { wd:${Qid} }
		OPTIONAL { ?place wdt:P1082 ?population }
		OPTIONAL { ?place wdt:P2250 ?lifeExpectancy }
		OPTIONAL { ?place wdt:P4841 ?fertility }
		OPTIONAL { ?place wdt:P6897 ?literacy }
		OPTIONAL { 
			?place p:P3529 [ 
				a wikibase:BestRank ; psv:P3529 [ 
					wikibase:quantityAmount ?income ; 
					wikibase:quantityUnit ?incomeUnit
				] 
			] .
			?incomeUnit wdt:P498 $incomeIsoCode .
		}
		OPTIONAL { 
			?place p:P2131 [ 
				a wikibase:BestRank ; 
				   psv:P2131 [ 
					wikibase:quantityAmount ?GDP ; 
					wikibase:quantityUnit ?GDPUnit
				] 
			] .
			?GDPUnit wdt:P498 $GDPIsoCode .
		}
	}
	LIMIT 1`
	// TODO convert to CAD?
	return wikidataQuery(query).then( resp => {
		const data = {}
		Object.entries(resp[0]).map( ([key,val]) => {
			if( val?.value ){ 
				data[key] = isNaN(val.value) ? val.value : Number(val.value) 
			}
		} )
		return data
	} )
}
