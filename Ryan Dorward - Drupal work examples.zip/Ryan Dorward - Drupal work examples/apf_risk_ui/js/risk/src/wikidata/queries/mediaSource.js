import { wikidataQuery } from '@apfcanada/wikidata'

export default async function(Qid){
	const query = `
		SELECT 
			( ?publisherLabelEN as ?label )
			( GROUP_CONCAT( DISTINCT ?typeLabelEN; separator="/" ) AS ?types )
			( GROUP_CONCAT( DISTINCT ?website; separator=" | " ) AS ?websites )
			( GROUP_CONCAT( DISTINCT substr(str(?hq),32); separator="," ) AS ?HQs )
			( GROUP_CONCAT( DISTINCT ?langLabelEN; separator=' / ' ) as ?languages )
			( GROUP_CONCAT( DISTINCT ?alignmentLabelEN; separator='/' ) as ?biases )
			( GROUP_CONCAT( DISTINCT substr(str(?coverage),32); separator='/' ) as ?jursCovered )
		WHERE {
			VALUES ?publisher { wd:${Qid} }
			?publisher wdt:P31 ?type .
			OPTIONAL { ?publisher wdt:P407 ?lang }
			OPTIONAL { ?publisher wdt:P856 ?website }
			OPTIONAL { ?publisher wdt:P159 ?hq }
			OPTIONAL { ?publisher (wdt:P1387|wdt:P1142) ?alignment }
			OPTIONAL { ?publisher wdt:P2541 ?coverage }
			SERVICE wikibase:label { 
				bd:serviceParam wikibase:language "en-ca,en,fr,zh,ja" . 
				?publisher rdfs:label ?publisherLabelEN .
				?type rdfs:label ?typeLabelEN .
				?hq rdfs:label ?hqLabelEN .
				?lang rdfs:label ?langLabelEN .
				?alignment rdfs:label ?alignmentLabelEN .
			}
		}
		GROUP BY ?publisher ?publisherLabelEN`
	return wikidataQuery(query).then( r => r[0] )
}
