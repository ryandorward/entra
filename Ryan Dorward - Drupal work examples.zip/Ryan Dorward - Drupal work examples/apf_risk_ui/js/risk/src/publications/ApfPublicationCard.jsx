import { site, ApfSite } from '../API.js'
import './publications.less'

export function ApfPublicationCard({node, className}){
	return(
		<a className={"publication-card" + (className ? ' '+ className : '')} href={`${ApfSite}${node.path}`} target="_blank" rel="noreferrer">
			<img src={`${site}${node.imageSources.sources.jpeg['360'].path}`} alt={node.title}/>
			<div className="textual">
				<div className="meta">
					{node.typeLabel && <span className="type-label">{node.typeLabel}</span>}
					{node.posted && <span className="date">{node.posted}</span>}
				</div>
				{node.title && <h4>{node.title}</h4>}
			</div>
		</a>
	)
}