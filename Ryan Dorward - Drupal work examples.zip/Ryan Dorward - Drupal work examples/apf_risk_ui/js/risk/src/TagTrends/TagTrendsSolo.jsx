import { gql, useReactiveVar, useQuery } from '@apollo/client'
import { dateRange } from '../input/TimeSlider'
import { Spinner } from '../Spinners'
import { tagTrendEventFields } from './tagTrendsFragments.js'
import { FrequencyStreamWrapper, tagDataMapper } from './TagTrends'

const query = gql`
${tagTrendEventFields}
query (
	$startDate: String!
	$endDate: String!
	$in: [Int]
	$search: String
){ events ( after: $startDate, before: $endDate top: 50 in: $in search: $search) {
	...tagTrendEventFields }
}`

export default function ({title, jurs, search}) {
	const { start, end } = useReactiveVar(dateRange)
	const { data, loading } = useQuery(
		query, {
			variables: {
				startDate: start.toISODate(),
				endDate: end.toISODate(),
				in: jurs?.length ? jurs.map(jur => jur?.geo_id ) : null,
				search: search
			}
		}
	)
	if (loading) return <Spinner contained size={50}/>
	const tagData = tagDataMapper(data.events)
	return <FrequencyStreamWrapper title={title} data={tagData} loading={loading}/>
}