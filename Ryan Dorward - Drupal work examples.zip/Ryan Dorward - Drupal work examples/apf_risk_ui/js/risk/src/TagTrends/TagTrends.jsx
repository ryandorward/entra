import { useEffect, useState } from 'react'
import { useReactiveVar } from '@apollo/client'
import FrequencyStream from './FrequencyStream'
import { colorFromThemes } from '../events/ESG/colorFromThemes.js'
import { topWeightedEvents } from '../HomePage/Filters'
import { topWeightedEventsLoading } from '../HomePage/Filters'
import { Spinner } from '../Spinners'
import './tagTrends.less'

const title = <h2>Trending Tags</h2>

export default function TagTrends(){
	const events = useReactiveVar(topWeightedEvents)
	const loading = useReactiveVar(topWeightedEventsLoading)
	const [ tagData, setTagData ] = useState([])
	useEffect(()=>{
		if (events){
			setTagData(tagDataMapper(events))
		}
	}, [events])

	return <FrequencyStreamWrapper title={title} data={tagData} loading={loading}/>
}

export function tagDataMapper( events ){
	return events.map( event => event.tags.map( tag => {
		return {
			date: event.date,
			id: tag.id,
			name: tag.name,
			color: colorFromThemes(tag.themes)
		}
	} ) ).flat()
}

export function FrequencyStreamWrapper( { title, data, loading }){
	const linkFunction = tag =>`/timeline/events/tag/${tag.id}`
	return (
		<div className="trending-tags double-wide">
			{title}
			{
				( loading ) ?
				<Spinner contained size={50}/>
				: <FrequencyStream data={data} linkFunction={linkFunction}/>
			}
		</div>
	)
}