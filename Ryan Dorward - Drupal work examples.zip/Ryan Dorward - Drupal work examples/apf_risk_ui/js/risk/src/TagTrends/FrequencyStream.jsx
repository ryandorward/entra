import { useEffect, useState, useRef } from 'react';
import { DateTime } from 'luxon'
import {
	area, curveNatural, stack,
	stackOffsetWiggle as wiggle,
	stackOrderAppearance as appearanceOrder,
	// curveBundle
} from 'd3-shape'
import { scaleLinear } from 'd3-scale'
import { tickMaker } from '../utilities/time/breaks'
import { rankIDs } from '../utilities/frequency.js'
import { kde } from '../utilities/time/kde.js'
import FlexList from '../layouts/FlexList'
import styles from './frequency-stream.module.less'
import LinkWrapper from '../LinkWrapper'
import { currentlyHoveredTagId, listenForHover } from '../utilities/hover.js'
import { useReactiveVar } from '@apollo/client'
import { Tooltip } from 'react-tooltip'

const [width,height] = [800,200]

const X = scaleLinear().range([0,width])
const Y = scaleLinear().range([5,height-5])
const oneDay = 1*24*60*60 // 1 day of seconds
const oneMonth = 30*oneDay // "1 month" of seconds
const aCoef = 9/11
const bCoef = 2/11

export default function FrequencyStream({data,linkFunction}){
	const [ topItems, setTopItems ] = useState([])
	const [ ticks, setTicks ] = useState([])
	useEffect(()=>{
		// select top items
		const topN = rankIDs(data).slice(0,10).map( id => {
			let datum = data.find(d=>d.id==id)
			return {
				id,
				name: datum.name,
				dates: data.filter(d=>d.id==id).map(d=>d.date),
				color: datum.color ?? 'grey'
			}
		} )

		// determine range
		const [first,last] = dateRange(data.map(d=>d.date))
		const firstDate = DateTime.fromISO(first)
		const lastDate = DateTime.fromISO(last)
		setTicks( tickMaker(firstDate,lastDate,width,75) )
		X.domain([firstDate.toSeconds(),lastDate.toSeconds()])

		// set points at which to calculate the KDE (every day in the range)
		const thresholds = [];
		let timePoint = firstDate.minus({weeks:1})
		while(timePoint <= lastDate.plus({weeks:1})){
			thresholds.push(timePoint.toSeconds());
			timePoint = timePoint.plus({days:1})
		}

		const date1 = DateTime.fromISO(last)
		const date2 = DateTime.fromISO(first)

		// The following sets bandwidth = 1 day for date range < 1mo,
		// For range > 1mo, it ranges linearly to 10 days at 1 year (and on from there)
		const secondsDiff = Math.floor(date1.toSeconds()-date2.toSeconds())
		const bandwidth = oneDay*((secondsDiff < oneMonth) ? 1 : (aCoef*(secondsDiff/oneMonth) + bCoef))

		const stackData = thresholds.map(secs=>({secs}))
		topN.map( tag => {
			const vals = tag.dates.map( str => DateTime.fromISO(str).toSeconds() )
			tag.kde = kde(thresholds,vals,bandwidth)
			stackData.map( (row,i) => row[tag.id] = tag.kde[i][1] )
		})
		const theStack = stack().offset(wiggle)
			.keys(topN.map(t=>t.id)).order(appearanceOrder)(stackData)
		// add the time dimension back in
		theStack.map(data=>data.map( (d,i) => d.push(thresholds[i]) ))
		// absolute vertical range varies
		const minY = Math.min( ... theStack.map(tag=>tag.map(tp=>tp[0])).flat() )
		const maxY = Math.max( ... theStack.map(tag=>tag.map(tp=>tp[1])).flat() )
		Y.domain([minY,maxY])
		const areaGen = area().curve(curveNatural)
		// const areaGen = area().curve(curveBundle.beta(0.25))
			.y0(d=>Y(d[0])).y1(d=>Y(d[1])).x(d=>X(d[2]))
		topN.map( tag => {
			tag.d = areaGen( theStack.find(d=>d.key==tag.id) )
		} )
		setTopItems(topN)
	},[data])
	const hoveredTagId = useReactiveVar(currentlyHoveredTagId)

	if( topItems.length < 1 ) return null;

	const streamItems = [...topItems].sort((a)=>a.id==hoveredTagId?1:0)

	return (
		<div className="frequency-stream">
			<svg viewBox={`0 0 ${width} ${height}`} className={styles.trendlines}>
				{streamItems.map( tag => <SingleTagStream key={tag.id} tag={tag} linkFunction={linkFunction}/> ) }
				{ticks.map( tick => (
					<g key={tick.date.toSeconds()} className={styles.gridline}
						transform={`translate(${X(tick.date.toSeconds())},0)`}>
						<path d={`M 0 0 v ${height}`}/>
						<text x="5" y={height-5}>{tick.label}</text>
					</g>
				) )}
			</svg>
			{streamItems.map( tag => <Tip key={tag.id} tag={tag} /> ) }

			<FlexList
				list={topItems}
				nameFunc={d=>d.name}
				linkFunc={linkFunction}
				colorFunc={d=>d.color??'grey'}
				classFunc={d=>{
					// const hoveredTagId = useReactiveVar(currentlyHoveredTagId)
					return (d.id==hoveredTagId ? 'focused' : hoveredTagId ? 'unfocused' : '')
				}}
				hoverVar={currentlyHoveredTagId}
			/>
		</div>
	)
}

function SingleTagStream({tag,linkFunction}) {

	const ref = useRef()
	useEffect(()=>{
		listenForHover(ref.current,tag.id,currentlyHoveredTagId)
	},[])
	const hoveredTagId = useReactiveVar(currentlyHoveredTagId)

	let css = { stroke: tag.color, fill: tag.color }
	return (
		<LinkWrapper key={tag.id} path={linkFunction(tag)} >
			<path
				style={css} d={tag.d}
				className={hoveredTagId==tag.id?styles.focused:''}
				ref={ref}
				data-tooltip-content={tag.name}
				id={`tagtrends-tip-${tag.id}`}
			>
				{/*<title>{tag.name}</title> */}
			</path>
		</LinkWrapper>
	)

}

function dateRange(dateList){
	const sortedDates = [...dateList].sort((a,b)=>b.localeCompare(a))
	const first = sortedDates[sortedDates.length-1]
	const last = sortedDates[0]
	return [first,last]
}

function Tip({tag}) {
	return <Tooltip
		variant='dark'
		anchorId={`tagtrends-tip-${tag.id}`}
		className='react-tooltip-general tagtrends-tip'
		float={true}
		place='top'
		content={tag.title}
	/>
}