// This fragment needs to be exported from this separate file, rather than exported
// from the TagTrends component. This prevents a dependency cycle type of bug from the Filters
// that was showing up in the standalone version of TagTrends.

import { gql } from '@apollo/client'

export const tagTrendEventFields = gql`
fragment tagTrendEventFields on Event {
	id date tags ( isCanonical: true ) {
		id name
		themes {
			id color parentThemes { id parentThemes { id } }
		}
	}
}`