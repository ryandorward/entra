import { ApolloClient, InMemoryCache, createHttpLink } from '@apollo/client'
import { setContext } from '@apollo/client/link/context';
import { authenticate } from './authenticate'
import { gqlEndpoint } from './API.js'

const link = createHttpLink({ uri: gqlEndpoint });

export const clientPromise = authenticate()
	.then( token => {
		const authLink = setContext((_, { headers }) => {
			return {
				headers: {
					...headers,
					Authorization: token ? `Bearer ${token}` : '',
					'Secure': '',
				}
			}
		});
		return new ApolloClient({
			cache: new InMemoryCache({
				typePolicies: {
					EventLink: { keyFields: ['cid'] },
					Theme: { keyFields: false },
					Query: {
						fields: {
							events: {
								// Vary cache results by these arguments.
								// This function returns the list of arguments to use as cache keys.
								// it takes *all* the query's args, and returns the ones that are not in the array below
								// this is less fragile that having to remember to update an explicit list anytime any of the args change
								keyArgs: (args) => {
									return args && Object.keys(args).filter( key => !['top', 'limit', 'offset'].includes(key) )
								},
								// Concatenate the incoming list items with
								// the existing list items.
								// this is for the pagination/load more functionality.
								// may need more sophistication, check out: https://www.apollographql.com/docs/react/pagination/core-api/#improving-the-merge-function
								merge(existing = [], incoming) {
									return [...existing, ...incoming];
								},


							}
						}
					},
				}
			}),
			link: authLink.concat(link),
		})
	} )





/*
	const cache = new InMemoryCache({
		typePolicies: {
			Query: {
				fields: {
					feed: {
						// Don't cache separate results based on
						// any of this field's arguments.
						keyArgs: false,

						// Concatenate the incoming list items with
						// the existing list items.
						merge(existing = [], incoming) {
							return [...existing, ...incoming];
						},
					}
				}
			}
		}
	})
	*/