import { useState, useEffect } from 'react';
import { useParams, useLocation } from 'react-router-dom'
import Title from '../components/Title'
import graph from './graph'
import MapLink from '../maps/MapLink'
import Flag from './Flag'
import styles from './name-header.module.css'

// Note: tried doing this without so many hooks:
// tabName was calculated with each component render
// But this caused a problem downstream in the Title component
// where it was not properly updating the state of the title

export default function NameBlock(){
	const { geo_id } = useParams()
	const [ jur, setJur ] = useState(null)
	const [ tabName, setTabName ] = useState(null)
	useEffect(()=>{
		graph.lookup(geo_id).then(setJur)
	},[geo_id])
	const { pathname } = useLocation()

	useEffect(()=>{
		// this header gets rendered under three different paths:
		// /map/jurisdiction/:geo_id (jurisdiction page)
		// /map/connections/jurisdiction/:geo_id (jurisdiction connections page)
		// /map/events/jurisdiction/:geo_id (jurisdiction events page)
		// determine which tab we're on by looking at the path
		const page = pathname.split('/')[2]
		setTabName(
			(() => {
				switch (page) {
					case 'jurisdiction':
						return 'Overview'
					case 'events':
						return 'Events'
					case 'connections':
						return 'Connections'
					default:	return ''
				}
			})()
		)
	},[pathname])

	if( !jur ) return null

	return (
		<div className={styles.container}>
			<Title metaTitle={`${jur.name.en} ${tabName}`} />
			<div className={styles.flag}>
				<Flag jurisdiction={jur} directOnly width="40px"/>
			</div>
			<h1 className={styles.name}>{jur.name.en}</h1>
			<span className={styles.descriptor}>
				{ jur.parent && jur.parent != jur.administers &&
					<>
						{typeArticle(jur)} {jur.type.label.en} {preposition(jur.parent)}
						{' '}<MapLink geo_id={jur.parent.geo_id}>
							{jur.parent.name.en}
						</MapLink> { jur.administers &&
							<>and capital of <MapLink geo_id={jur.administers.geo_id}>
								{jur.administers.name.en}
							</MapLink></>
						}
					</>
				}
				{ jur.parent && jur.parent == jur.administers &&
					<>
						{jur.type.label.en} and capital of {''}
						<MapLink geo_id={jur.administers.geo_id}>
							{jur.administers.name.en}
						</MapLink>
					</>
				}
			</span>
		</div>
	)
}

// plain-text version of the above
export function jurNameExtendedRaw(jur){
	let $out = ''
	if (jur.parent) {
		if (jur.parent != jur.administers) {
			$out += `${typeArticle(jur)} ${jur.type.label.en} ${preposition(jur.parent)}`
			$out += ` ${jur.parent.name.en}`
			if (jur.administers) $out += ` and capital of ${jur.administers.name.en}`
		}
		else
			$out += `${jur.type.label.en} and capital of ${jur.administers.name.en}`
	}
	return $out
}

function typeArticle(jur){
	return /island|auto*|uninc*/i.test(jur.type.label.en) ? 'an' : 'a'
}

function preposition(jur){
	return /island/i.test(jur.type.label.en) ? 'on' : 'in'
}
