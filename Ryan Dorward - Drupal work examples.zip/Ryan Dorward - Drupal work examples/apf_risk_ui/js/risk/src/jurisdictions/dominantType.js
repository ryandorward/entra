export function dominantType(jursList){
	const types = new Map();
	jursList.map( j => {
		let label = j.type.label.en
		if(types.has(label)){ types.set(label,1+types.get(label)) }
		else{ types.set(label,1) }
	} );
	const mostCommonTypeLabels = [...types.entries()]
		.filter( entry => entry[1] == Math.max(...types.values()) )
		.map( entry => entry[0] )
	return mostCommonTypeLabels.join('/')
}
