import { useParams } from 'react-router-dom'
import Name from './NameHeader'
import Nav from './Nav'

export default function(){
	const { geo_id } = useParams()
	return geo_id ? <><Name/><Nav/></> : null
}
