import { useState, useEffect } from 'react';
import { NavLink, useParams } from 'react-router-dom'
import { gql, useQuery } from '@apollo/client'
import SelectChild from './SelectChild'
import graph from './graph'
import './nav.less'

const query = gql`
query ( $geo_id: [Int]! ) {
	events ( top: 1 in: $geo_id indirect: true ) { id }
}`

export default function(){
	const { geo_id } = useParams()
	const [ jur, setJur ] = useState(null)
	useEffect(()=>{
		graph.lookup(geo_id).then(setJur)
	},[geo_id])
	const { data } = useQuery(query,{variables:{geo_id: Number(geo_id)}})
	if(!jur) return null;
	const jpath = `jurisdiction/${geo_id}`
	return (<>
		<nav className='nav'>
			<NavLink to={`/map/${jpath}`}>Overview</NavLink>
			{data?.events.length > 0 &&
				<NavLink to={`/map/events/${jpath}`}>Events</NavLink>
			}
			<NavLink className='connections' to={`/map/connections/${jpath}`}>Connections</NavLink>
		</nav>
		<SelectChild/>
	</>)
}
