// within the geoMap context, sets focus on specified jurisdictions

import { useEffect, useContext } from 'react'
import graph from './graph'
import { assignBoundaries } from '@apfcanada/jurisdictions'
import { MapContext } from '../maps/geographic/Context'

export default function({geo_id,geo_ids,jurisdiction,jurisdictions}){
	const { focus } = useContext(MapContext)
	useEffect(()=>{
		const jurRefs = []
		if(geo_id) jurRefs.push(geo_id);
		if(geo_ids) jurRefs.push(...geo_ids);
		if(jurisdiction) jurRefs.push(jurisdiction);
		if(jurisdictions) jurRefs.push(...jurisdictions);
		if(jurRefs.length < 1) return;
		graph.lookup(jurRefs)
			.then( assignBoundaries )
			.then( jurs => {
				let geoms = {
					type: 'GeometryCollection',
					geometries: jurs.map( j => j.boundary )
				}
				focus(geoms)
			} )
	},[geo_id,geo_ids,jurisdiction,jurisdictions])
	return null;
}
