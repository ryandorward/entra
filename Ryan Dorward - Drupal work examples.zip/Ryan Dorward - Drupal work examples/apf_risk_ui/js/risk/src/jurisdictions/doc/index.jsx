import { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom'
import JurisdictionSearch from '../Search'
import graph from '../graph'
import { assignBoundaries } from '@apfcanada/jurisdictions'
import Globe, { Context as globeContext } from '../../maps/globe/Map'
import styles from '../../maps/geographic/styles/border-only.module.css'
import highlight from '../../maps/geographic/styles/highlight.module.css'
import BigNumber from '../../layouts/BigNumber'


export default function Docs(){
	const [ options, setOptions ] = useState([])
	const [ jurCount, setJurCount ] = useState(0)
	useEffect(()=>{
		graph.countries()
			.then( countries => {
				setOptions(
					countries.sort((a,b)=>a.name.en.localeCompare(b.name.en))
						.map( jur => ({jur}) )
				)
			} )
		graph.allJurisdictions().then( allJurs => setJurCount(allJurs.length) )
	},[])
	return (
		<>
			<h1>Jurisdictions</h1>
			
			<p>The <b>jurisdiction</b> is the basic geographic unit of analysis for CAST.</p>
			
			<BigNumber number={jurCount} 
				labelPlural="jurisdictions currently in our database"/>
				
			<p>You can search for any of these jurisdiction by name in English, French, or Chinese to see what we know about it.</p>

			<JurisdictionSearch defaultOptions={options}/>
			
			<h2>Definition</h2>
			
			<p>We define jurisdictions as geographically bounded, political administrative units. In Canada for example, this could include the country, a province, or a city. The main requirement is that the boundaries be more or less clearly defined, and that the unit be directly administered by some form of government. Jurisdictions may be nested within each other, but cannot overlap or share territory at the same level in the hierarchy.</p>
			
			<p>This definition <i>excludes</i> certain potential types of geographies such as:</p>
				<ul>
					<li>Regions (e.g. &ldquo;The Prairies&rdquo; doesn&apos;t have a government or a clear boundary)</li>
					<li>Census zones, per se (ditto)</li>
					<li>Many urban areas which lack regional governance</li>
					<li>Many small settlements or neighborhoods which may have no defined boundaries</li>
				</ul>
				
			<p>Of course, the types of jurisdictions we encounter vary widely from contry to contry and even from province to province. We attempt to follow the definition laid out here in selecting jurisdictions but have not always done so consistently; our database is still evolving.</p>
				
			<h2>Coverage</h2>
			
			<p>CAST looks at the Asia Pacific from the Canadian Perspective; thus we&apos;re interested in Canadian and Asian jurisdictions, especially where there is some <Link to="../connections">connection</Link> between the two. Not all jurisdictions in the world will make it into our database. Criteria for inclusion may include:</p>
			<ul>
				<li>An Asian jurisdiction has a specific, known connection to Canada (or vice versa)</li>
				<li>A jurisdiction is directly impacted by an <Link to="../events">event</Link> we&apos;re tracking.</li>
				<li>A jurisdiction is necessary for completeness</li>
				<ul>
					<li>it&apos;s the parent of another jurisdiction we&apos;re tracking</li>
					<li>most of its peers have already been added</li>
				</ul>
			</ul>
			
			<Globe>
				<GlobeContent/>
			</Globe>
			
			<p>Jurisdictions are arranged hierarchically with sovereign states at the highest level, progressing down through their subnational levels, often terminating with cities or even neighborhood districts. The degree of specificity depends on how closely we are tracking the area and what we know about it&apos;s specific <Link to="../connections">connections</Link> to Canada / Asia.</p>
			
			<h2>Data</h2>
			
			<p>All jurisdictions reference a corresponding entry in both <a href="https://www.openstreetmap.org">OpenStreetMap</a> and <a href="https://www.wikidata.org">Wikidata</a>. These sources provide the geographic boundaries and various other data associated with jurisdictions such as translated names, populations, shared borders, and so on. Any fault in these data can be corrected in, and should be attributed to, those sources.</p>
			
		</>
	)
}

function GlobeContent(){
	const [ jurs, setJurs ] = useState([])
	const [ topjurs, setTopJurs ] = useState([])
	const { pathGen, setLoading } = useContext(globeContext)
	useEffect(()=>{
		graph.countries()
			.then( jurs => jurs.map(j=>[j,...j.children]).flat())
			.then( assignBoundaries )
			.then( jurs => {
				setTopJurs(jurs.filter(j=>j.depth==0));
				setJurs(jurs.filter(j=>j.depth>0));
				setLoading(false);
			} )
	},[])

	return (
		<>
			<g>
				{jurs.map( jur => (
				<path key={jur.geo_id} 
					className={highlight.secondary}
					d={pathGen(jur.boundary)} />		
				) )}
			</g>
			<g>
				{topjurs.map( jur => (
					<path key={jur.geo_id}
						className={styles.borderonly}
						d={pathGen(jur.boundary)} />		
				) )}
			</g>
		</>
	)
	
}
