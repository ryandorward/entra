// This is a very brutal and unscalable way to do this
// could not find a programmatic way to get the mapbox id on the fly, when wikidata id is known!!!
export const wikidata_id_to_mapbox_id = {
	'Q902': 1183763, // Bangladesh
	'Q917': 1642529, // Bhutan
	'Q921': 2232348, // Brunei
	'Q424': 2494581, // Cambodia
	'Q16': 2691110, // Canada
	'Q574': 14749917, // East Timor
	'Q668': 6885481, // India
	'Q252': 6951013, // Indonesia
	'Q17': 7540850, // Japan
	'Q819': 8130686, // Laos
	'Q833': 8917150, // Malaysia
	'Q826': 8982683, // Maldives
	'Q836': 10096786, // Myanmar
	'Q837': 10293416, // Nepal
	'Q423': 10883193, // N. Korea
	'Q843': 11145394, // Pakistan
	'Q691': 11407536, // PNG
	'Q148': 3084336, // China
	'Q928': 16584881, // Philippines
	'Q334': 13242566, // Singapore
	'Q884': 13766778, // S. Korea
	'Q854': 13963394, // Sri Lanka
	'Q865': 14487780, // Taiwan
	'Q869': 14684378, // Thailand
	'Q881': 16191729, // Vietnam
}

// indexed by wikidata_id
// alpha_2 is the ISO 3166-1 alpha-2 code
export const cast_jurs = {
  'Q902':  { // Bangladesh
    mapbox_id: 1183763,
    alpha_2: 'BD',
    wikidata_id: 'Q902',
  },
  'Q917':  { // Bhutan
    mapbox_id: 1642529,
    alpha_2: 'BT',
    wikidata_id: 'Q917',
  },
  'Q921':  { // Brunei
    mapbox_id: 2232348,
    alpha_2: 'BN',
    wikidata_id: 'Q921',
  },
  'Q424':  { // Cambodia
    mapbox_id: 2494581,
    alpha_2: 'KH',
    wikidata_id: 'Q424',
  },
  'Q16':  { // Canada
    mapbox_id: 2691110,
    alpha_2: 'CA',
    wikidata_id: 'Q16',
  },
  'Q574':  { // East Timor
    mapbox_id: 14749917,
    alpha_2: 'TL',
    wikidata_id: 'Q574',
  },
  'Q668':  { // India
    mapbox_id: 6885481,
    alpha_2: 'IN',
    wikidata_id: 'Q668',
  },
  'Q252':  { // Indonesia
    mapbox_id: 6951013,
    alpha_2: 'ID',
    wikidata_id: 'Q252',
  },
  'Q17':  { // Japan
    mapbox_id: 7540850,
    alpha_2: 'JP',
    wikidata_id: 'Q17',
  },
  'Q819':  { // Laos
    mapbox_id: 8130686,
    alpha_2: 'LA',
    wikidata_id: 'Q819',
  },
  'Q833':  { // Malaysia
    mapbox_id: 8917150,
    alpha_2: 'MY',
    wikidata_id: 'Q833',
  },
  'Q826':  { // Maldives
    mapbox_id: 8982683,
    alpha_2: 'MV',
    wikidata_id: 'Q826',
  },
  'Q836':  { // Myanmar
    mapbox_id: 10096786,
    alpha_2: 'MM',
    wikidata_id: 'Q836',
  },
  'Q837':  { // Nepal
    mapbox_id: 10293416,
    alpha_2: 'NP',
    wikidata_id: 'Q837',
  },
  'Q423':  { // N. Korea
    mapbox_id: 10883193,
    alpha_2: 'KP',
    wikidata_id: 'Q423',
  },
  'Q843':  { // Pakistan
    mapbox_id: 11145394,
    alpha_2: 'PK',
    wikidata_id: 'Q843',
  },
  'Q691':  { // PNG
    mapbox_id: 11407536,
    alpha_2: 'PG',
    wikidata_id: 'Q691',
  },
  'Q148':  { // China
    mapbox_id: 3084336,
    alpha_2: 'CN',
    wikidata_id: 'Q148',
  },
  'Q928':  { // Philippines
    mapbox_id: 16584881,
    alpha_2: 'PH',
    wikidata_id: 'Q928',
  },
  'Q334':  { // Singapore
    mapbox_id: 13242566,
    alpha_2: 'SG',
    wikidata_id: 'Q334',
  },
  'Q884':  { // S. Korea
    mapbox_id: 13766778,
    alpha_2: 'KR',
    wikidata_id: 'Q884',
  },
  'Q854':  { // Sri Lanka
    mapbox_id: 13963394,
    alpha_2: 'LK',
    wikidata_id: 'Q854',
  },
  'Q865':  { // Taiwan
    mapbox_id: 14487780,
    alpha_2: 'TW',
    wikidata_id: 'Q865',
  },
  'Q869':  { // Thailand
    mapbox_id: 14684378,
    alpha_2: 'TH',
    wikidata_id: 'Q869',
  },
  'Q881':  { // Vietnam
    mapbox_id: 16191729,
    alpha_2: 'VN',
    wikidata_id: 'Q881',
  },
}

export const pseudo_centroids = {
  660: [139.8,35.8], // Tokyo
  31: [108.2, 14.8], // Vietnam
  1049: [120.2, 30.3], // Hangzhou
  71: [120.34,22.58], // Kaohsiung
  3: [101.909179688, 35.496456056584165], // China
  194: [109.63, 19.18], // Hainan
}

export const nationLabelPositions = {
	3: [107,32], // China
	4: [140.3,36.6], // Japan
	5: [128.3,35], // S. Korea
	31: [108.2,15.8], // Vietnam
	74: [104.8, 11.4], // Cambodia
	606: [108,5], // Malaysia
	917: [91.6,27], // Bhutan
	1465: [103.8,1.25], // Singapore
  291: [113.57, 22.25] // Zhuhai
}