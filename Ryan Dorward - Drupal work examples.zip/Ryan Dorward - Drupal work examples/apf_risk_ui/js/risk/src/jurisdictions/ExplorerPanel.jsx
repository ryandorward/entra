import { useState, useEffect } from 'react';
import { Spinner } from '../Spinners'
import Title from '../components/Title'
import { getNations } from '../maps/geographic/maputils.jsx'
import FlexList from '../layouts/FlexList'

export default function(){
  const [nations, setNations] = useState([])
  const [loading, setLoading] = useState(true)
	useEffect(() => {
    setLoading(true)
		getNations().then(jurs => {
			setNations(jurs)
      setLoading(false)
		})
	}, [])

	return (
		<div className="panel-explore-jurisdictions">
			<div className='title-wrap'>
				<Title>Explore Jurisdictions</Title>
			</div>
      { loading ?
        <Spinner size={50}/> :
        <FlexList list={nations}
          nameFunc={jur=>jur.name.en}
          linkFunc={jur=>`/map/events/jurisdiction/${jur.geo_id}`}
          classFunc={()=>`jurisdiction jurisdiction-link`}
        />
      }
		</div>
	)
}