import { JurisdictionGraph } from '@apfcanada/jurisdictions'
import { gql } from '@apollo/client'
import { csv } from 'd3-fetch'
import { Twinning } from '../connections/twinning/class.js'
import twinsData from '../connections/twinning/data.json'
import { Mission } from '../connections/diplomacy/mission.js'
import missionsData from '../connections/diplomacy/data/missions.json'
import { TradeAgreement } from '../connections/tradeAgreements/class.js'
import tradeAgreements from '../connections/tradeAgreements/data.json'
import { fetchGQL } from '../fetchGQL.js'
import { Business } from '../connections/business/class.js'
import { FDI } from '../connections/investment/fdi.js'
import { Publication } from '../connections/research/class.js'
import publicationsData from '../connections/research/data.csv'

const graph = new JurisdictionGraph();

graph
	.addCallback('Twinning',addTwins)
	.addCallback('Mission',addMissions)
	.addCallback('TradeAgreement',addTrade)
	.addCallback('Business',addBusiness)
	.addCallback('FDI',addFDI)
	.addCallback('Publications',addPublications)
	//.addCallback('IsoAlpha3',addIsoAlpha)
	.readyWith('Twinning','Mission','TradeAgreement') // data is already ready

export default graph

function addTrade(graph){
	tradeAgreements.forEach( agreement => {
		let { signatories, ...data } = agreement
		let jurs = signatories.split(',').map(graph.lookupNow).filter(j=>j)
		new TradeAgreement(data,...jurs).notify()
	} )
}

function addMissions(graph){
	missionsData.forEach( missionData => {
		let operator = graph.lookupNow(missionData.operatorID)
		let destination = graph.lookupNow(missionData.destID)
		if(! operator || ! destination ){
			return console.warn(
				`Mission ${missionData.missionID} missing at least one of these jurisdictions`,
				missionData.operatorID,
				missionData.destID
			)
		}
		new Mission({operator,destination,missionData}).notify()
	} )
}

function addTwins(graph){
	twinsData.forEach( pair => {
		let [A,B] = graph.lookupNow([pair.a,pair.b])
		new Twinning(A,B).notify()
	} )
}

/*
function addIsoAlpha(graph){

}
*/

async function addBusiness(graph){
	return fetchGQL(gql`query { businesses { uid location headquarters } }`)
		.then( data => {
			data.businesses.forEach( ({uid,location,headquarters}) => {
				new Business(
					graph.lookupNow(headquarters),
					graph.lookupNow(location),
					{uid}
				).notify()
			} )
		} )
}

async function addFDI(graph){
	return fetchGQL(gql`query{investments(involving:2){uid src_geo_id dst_geo_id}}`)
		.then( data => {
			return data.investments.forEach( ({uid,src_geo_id,dst_geo_id}) => {
				new FDI(
					graph.lookupNow(src_geo_id),
					graph.lookupNow(dst_geo_id),
					{uid}
				).notify()
			} )
		} )
}

async function addPublications(graph){
	return csv(publicationsData)
		.then( data => {
			return data.forEach( ({pub_id,geo_ids}) => {
				new Publication(
					{id:pub_id},
					...graph.lookupNow(geo_ids.split('/'))
				).notify()
			} )
		} )
}

