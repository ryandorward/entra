import { useContext } from 'react';

import Toggle, { LayoutContext } from '../maps/ControlVariableToggle'

import LinkItem from '../maps/legend/LinkItem'
import CircleItem from '../maps/legend/CircleItem'
import '../maps/legend.less'
import linkStyles from '../maps/network/links.module.css'

export default function Legend(){
	const { data } = useContext(LayoutContext)
	return (
		<div className="network legend">
			<CircleItem label="Canadian Jurisdiction" radius={7} className="node canadian"/>
			<CircleItem label="Asia-Pacific Jurisdiction" radius={7} className="node asian"/>
			<span className='note'>Nodes are scaled by the relative strength of their trans-pacific connection {data?.control=='population'&&<>(per capita)</>}</span>
			<Toggle/>
			<LinkItem label="Shared Border" className={linkStyles.border}/>
			<LinkItem label="Twinning Relation" className={linkStyles.twin}/>
			<LinkItem label="Direct diplomatic mission" className={linkStyles.directMission}/>
		</div>
	)
}
