import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom'
import { format } from 'd3-format'
import graph from './graph'
import getDemographics from '../wikidata/queries/demographicOverview'
import ShowOnlyTo from '../ShowOnlyTo'

import TravelSummary from '../connections/travel/PanelSummary'
import Headlines from '../events/Headlines'
import { site } from '../API.js'
const adminLink = `${site}/admin/cast/jurisdictions`

export default function(){
	const { geo_id } = useParams()
	return (
		<>
			<div>
				<Headlines top={4} sort={'date'} in={Number(geo_id)}
					withDescendants={true}/>
			</div>
			<VitalStats/>
			<TravelSummary/>
			<ShowOnlyTo minRole="analyst">
				<a href={`${adminLink}/${geo_id}`}>Jurisdiction admin tool</a>
			</ShowOnlyTo>
		</>
	)
}

function VitalStats(){
	const { geo_id } = useParams()
	const [ data, setData ] = useState({})
	useEffect(()=>{
		graph.lookup(geo_id)
			.then( jur => getDemographics(jur.wikidata) )
			.then( setData )
	},[geo_id])
	if( Object.keys(data).length == 0 ) return null;
	return ( <div>
		<table style={{width:'100%'}}>
			<tbody>
				{data?.population &&
					<tr>
						<td>Population</td>
						<td>{bigNumberFormat(data.population)}</td>
					</tr>
				}
				{data?.lifeExpectancy &&
					<tr>
						<td>Life Expectancy</td>
						<td>{format('.1f')(data.lifeExpectancy)} years</td>
					</tr>
				}
				{data?.fertility &&
					<tr>
						<td>Fertility Rate</td>
						<td>{format('.2f')(data.fertility)}</td>
					</tr>
				}
				{data?.literacy &&
					<tr>
						<td>Literacy Rate</td>
						<td>{format('.0f')(data.literacy)}%</td>
					</tr>
				}
				{data?.income &&
					<tr>
						<td>Med. Household Income</td>
						<td>{format(',.3r')(data.income)} {data.incomeIsoCode}</td>
					</tr>
				}
				{data?.GDP &&
					<tr>
						<td>Nominal GDP</td>
						<td>{bigNumberFormat(data.GDP)} {data.GDPIsoCode}</td>
					</tr>
				}
			</tbody>
		</table>
	</div>)
}

function bigNumberFormat(number){
	return format('.3s')(number)
		.replace(/G$/,' billion')
		.replace(/M$/,' million')
		.replace(/k$/,' thousand')
}
