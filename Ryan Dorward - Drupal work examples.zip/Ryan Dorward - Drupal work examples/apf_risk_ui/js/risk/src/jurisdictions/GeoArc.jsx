// geographic map arc connecting the centers of two jurisdictions

import { useState, useEffect, useContext } from 'react';
import { geoPath } from 'd3-geo'
import { MapContext } from '../maps/geographic/Context'
import styles from '../maps/geographic/styles/arc.module.css'

// pass in actual jurisdiction objects
export default function({from,to,children,...props}){
	const { projection } = useContext(MapContext)
	const [ hasGeoms, setHasGeoms ] = useState(false)
	useEffect(()=>{
		Promise.all([from.withGeom('point'),to.withGeom('point')])
			.then( () => setHasGeoms(true) )
	},[from,to])
	if(!hasGeoms) return null;
	const pathGen = geoPath(projection)
	const geometry = {
		type: 'LineString',
		coordinates: [ from.latlon, to.latlon ]
	}
	return (
		<path className={styles.arc} d={pathGen(geometry)} {...props}>
			{children}
		</path>
	)
}
