import { useNavigate, useLocation } from 'react-router-dom'
import Select from 'react-select/async'
import { succinctSearch as API } from '../API'
import graph from './graph'
import { pathExists as mapPathExists, mapPath } from '../maps/MapLink'
import styles from '../styles/select.module.css'


export default function({...props}){
	const navigate = useNavigate()
	const { pathname } = useLocation()

	return (
		<Select
			className="jurisdiction-search"
			placeholder='Search for a jurisdiction'
			loadOptions={promiseOptions}
			cacheOptions={true}
			controlShouldRenderValue={false}
			onChange={props.select || select}
			menuPlacement="auto"
			formatOptionLabel={formatOption}
			getOptionValue={({jur})=>jur.geo_id}
			noOptionsMessage={noOptions}
			isClearable
			{...props}/>
	)
	function promiseOptions(textInput){
		return fetch(`${API}?name=${textInput.trim()}`)
			.then( resp => resp.json() )
			.then(graph.lookup)
			.then( jurs => jurs.map(jur=>({jur})) )
			// passing the jurs without wrapping causes them to become disordered
			// https://github.com/JedWatson/react-select/issues/4505
	}
	// Default behaviour on select, overridable by props.select
	function select({jur}){
		let path = mapPathExists(pathname) ?
			mapPath(pathname,{geo_id:jur.geo_id}) :
			`/map/jurisdiction/${jur.geo_id}`;
		navigate(path)
	}
}

export function formatOption(option,hideDescription){
	const { jur } = option
	if(!jur.parent) return jur.name.en; // top level jurs need no introduction
	let type = jur.type.label.en
	let article = /^isl|^aut|^unin/i.test(type) ? 'an' : 'a'
	return (
		<div className="option">
			{jur.name.en}{ !hideDescription && <><br/><span className={styles.descriptor}>
				({article} {type} in {jur.parent.name.en})
			</span></>}
		</div>
	)
}

function noOptions(input){
	return input.inputValue == '' ?
		'Search in English, French, or Chinese' :
		'Sorry - no results for that search'
}
