import { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom'
import Select from 'react-select'
import { dominantType } from './dominantType.js'
import { mapPath } from '../maps/MapLink'
import graph from './graph'

export default function(){
	const { geo_id } = useParams()
	const navigate = useNavigate()
	const { pathname } = useLocation()
	const [ children, setChildren ] = useState([])
	const [ typePhrase, setTypePhrase ] = useState('child jurisdiction')
	useEffect(()=>{
		graph.lookup(geo_id).then( jur => {
			setChildren(jur.children)
			setTypePhrase(dominantType(jur.children))
		} )
	},[geo_id])
	if(children.length==0) return null;
	const options = children
		.map(jur=>({label:jur.name.en,value:jur.geo_id}))
		.sort((a,b)=>a.label.localeCompare(b.label))
	const article = /^[aeiou]/.test(typePhrase) ? 'an' : 'a';
	return (
		<Select
			value={null} // never needs to stay set
			placeholder={`Select ${article} ${typePhrase}`}
			options={options}
			onChange={select}
			menuPlacement="auto"
			className="select-child"
		/>
	)
	function select(option){
		navigate(mapPath(pathname,{geo_id:option.value}))
	}
}
