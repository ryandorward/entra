const icons = new Map([
	[2,require('../images/flag-icons/in-use/2.svg?url')],
	[3, require('../images/flag-icons/in-use/3.svg?url')],
	[4, require('../images/flag-icons/in-use/4.svg?url')],
	[5, require('../images/flag-icons/in-use/5.svg?url')],
	[6, require('../images/flag-icons/in-use/6.svg?url')],
	[7, require('../images/flag-icons/in-use/7.svg?url')],
	[8, require('../images/flag-icons/in-use/8.svg?url')],
	[9, require('../images/flag-icons/in-use/9.svg?url')],
	[10, require('../images/flag-icons/in-use/10.svg?url')],
	[12, require('../images/flag-icons/in-use/12.svg?url')],
	[13, require('../images/flag-icons/in-use/13.svg?url')],
	[18, require('../images/flag-icons/in-use/18.svg?url')],
	[30, require('../images/flag-icons/in-use/30.svg?url')],
	[31, require('../images/flag-icons/in-use/31.svg?url')],
	[32, require('../images/flag-icons/in-use/32.svg?url')],
	[33, require('../images/flag-icons/in-use/33.svg?url')],
	[34, require('../images/flag-icons/in-use/34.svg?url')],
	[35, require('../images/flag-icons/in-use/35.svg?url')],
	[36, require('../images/flag-icons/in-use/36.svg?url')],
	[38, require('../images/flag-icons/in-use/38.svg?url')],
	[75, require('../images/flag-icons/in-use/75.svg?url')],
	[76, require('../images/flag-icons/in-use/76.svg?url')],
	[78, require('../images/flag-icons/in-use/78.svg?url')],
	[92, require('../images/flag-icons/in-use/92.svg?url')],
	[96, require('../images/flag-icons/in-use/96.svg?url')],
	[236, require('../images/flag-icons/in-use/236.svg?url')],
	[423, require('../images/flag-icons/in-use/423.svg?url')],
	[606, require('../images/flag-icons/in-use/606.svg?url')],
	[607, require('../images/flag-icons/in-use/607.svg?url')],
	[709, require('../images/flag-icons/in-use/709.svg?url')],
	[1465, require('../images/flag-icons/in-use/1465.svg?url')]
])

export default function Flag({jurisdiction,geo_id,directOnly,...etc}){
	geo_id = geo_id ?? jurisdiction?.geo_id
	// does this jurisdiction have a flag?
	if( icons.has(geo_id) ){
		return <img src={icons.get(geo_id)} width="30px" {...etc}/>
	}
	// optionally stop there
	if( directOnly || ! jurisdiction ) return null;
	// or fall back to nearest ancestor
	let ancestor = jurisdiction.ancestors.find(a=>icons.has(a.geo_id))
	if(ancestor){
		return (
			<img src={icons.get(ancestor.geo_id)} width="30px" {...etc}/>
		)
	}
	// else nothing
	return null
}
