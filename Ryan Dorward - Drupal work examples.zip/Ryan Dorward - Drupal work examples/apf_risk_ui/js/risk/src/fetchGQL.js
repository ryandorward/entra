// Sends queries to GQL endpoint outside of React hooks
import { clientPromise } from './getSharedClient.js'

export async function fetchGQL(query,variables={}){
	return clientPromise.then( client => {
		return client.query({query,variables}).then(({data})=>data)
	} )
}
