import { lazy, useState, useEffect, createContext, Component } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import MediaQuery from 'react-responsive' // import useWindowDimensions from '../hooks/useWindowDimensions'
import './mapLayout.less'
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs'
import StickyBox from "react-sticky-box"

import Panel from './Panel'
import MapFrame from './MapFrame'

import { FaGlobeAsia, FaChartPie } from 'react-icons/fa'
import { BiNetworkChart, BiTimeFive } from 'react-icons/bi'
import { mapTypes } from './mapTypes.js'

const SiteHeader = lazy(()=>import('../HomePage/SiteHeader'))
const Filters = lazy(()=>import('../HomePage/Filters'))
const TagTrends = lazy(()=>import('../TagTrends/TagTrends'))
const StatsLinks = lazy(()=>import('../HomePage/StatsLinks'))
const TernaryESG = lazy(()=>import('../HomePage/TernaryESG'))
const TopThemes = lazy(()=>import('../HomePage/TopThemes'))

const Map = lazy(()=>import('./geographic/Map'))
// const TimelineSingle = lazy(()=>import('../events/TimelineSingle'))
// const TimelineCollection = lazy(()=>import('../events/TimelineCollection'))

export const Context = createContext()

export default class MapLayout extends Component{
	constructor(props){
		super(props)
		this.setSharedData = this.setSharedData.bind(this)
		this.state = {
			shared: { // arbitrarily structured data to be passed around
				data: {},
				setData: this.setSharedData
			}
		}
	}
	render(){
		return (
      <Context.Provider value={this.state.shared}>
        <Layout/>
      </Context.Provider>
		)
	}
	setSharedData(newSharedData){ // adds/modifies specified properties to shared data
		this.setState( prevState => {
			let newState = { ...prevState }
			newState.shared.data = { ...prevState.shared.data, ...newSharedData }
			return newState;
		} )
	}
}

function Layout() {
  return (
    <>
      <SiteHeader/>
      <Filters/>
      <div className='mapLayoutContainer'>
        <Panel/>
        <MediaQuery minWidth={700}>
          <StickyBox offsetTop={0} offsetBottom={0} className="double-wide sub-panel">
            <TabbedMaps/>
          </StickyBox>
        </MediaQuery>
      </div>
    </>
  )
}

const storage = window.localStorage

function TabbedMaps(){
  const location = useLocation()
  // let tabIndexStorage = (location.pathname === '/' ? 'cast.tabs_index.home': 'cast.tabs_index.default')

  let tabIndexStorage = (() => {
    if (location.pathname === '/')
      return 'cast.tabs_index.home'
    else return 'cast.tabs_index.default'
  })()

  function getTab() {
    const tabSearchValue = new URLSearchParams(window.location.search).get('tab')
    if (tabSearchValue != null && (tabSearchValue === '0' || tabSearchValue === '1')) {
      return Number(tabSearchValue)
    }
    const stored = storage.getItem(tabIndexStorage)
    return Number(JSON.parse((stored == null) ? 0 : stored)) // default: true
  }

  const [ tabIndex, setTabIndex] = useState(getTab())

  useEffect(()=>{
    setTabIndex(getTab())
	},[location])

  useEffect(()=>{
		storage.setItem(tabIndexStorage,tabIndex)
	},[tabIndex])


  // const MapComponent = () => <Map visible={tabIndex === 0}/> // for some reason when you use this, the map rerenders on every route change - breaks the magic of the flowy map

  return (
    <div className='tabbedMaps'>
      <Tabs
				selectedIndex={tabIndex}
				onSelect={(index) => {setTabParameter(index); setTabIndex(index)}}
			>
				{/*
					forceRender={true} so that when we switch tabs, we don't re-render the map.
					It would be better to not render until we need to (in case the other tab is selected first)
					and then once it's rendered, keep it alive. But this is the easy way for now. @todo: optimize by getting tab to only render once it's needed
				*/}

        {/* First Panel */}
				<TabPanel forceRender={true}>
          <Routes>
            <Route path="" element={<Map visible={tabIndex === 0}/>}>
              <Route path=""/>
              <Route path="map">
                <Route path="event/:event_id"/>
                <Route path="jurisdiction/:geo_id" />
                <Route path="events">
                  <Route path="" />
                  <Route path="tag/:tag_id"/>
                  <Route path="theme/:theme_id"/>
                  <Route path="jurisdiction/:geo_id"/>
                </Route>
              </Route>
            </Route>

            <Route path="map/connections">
              <Route path="*" element={<MapFrame mapType={mapTypes['geographic']}/>} />
            </Route>

          </Routes>
				</TabPanel>

        {/* Second Panel */}
				<TabPanel forceRender={true}>
          <Routes>
            <Route path="" element={<HomeSecondPanelContents/>}/>
            <Route path="map/connections">
              <Route path="*" element={<MapFrame mapType={mapTypes['network']}/>} />
            </Route>
            <Route path="map" element={<MapFrame mapType={mapTypes['timeline']}/>}>
              <Route path="*"/>
            </Route>
          </Routes>
				</TabPanel>

				<TabList>

          {/* First Tab */}
          <Tab>
            <FaGlobeAsia/>
          </Tab>

          {/* Second Tab */}
          <Tab>
            <Routes>
              <Route path="" element={<FaChartPie/>}/>
              <Route path="map" element={<BiTimeFive/>}>
                <Route path="event/:event_id" />
                <Route path="jurisdiction">
                  <Route path=":geo_id" />
                </Route>
                <Route path="events">
                  <Route path=""/>
                  <Route path="tag/:tag_id" />
                  <Route path="theme/:theme_id" />
                  <Route path="jurisdiction/:geo_id" />
                </Route>
              </Route>
              <Route path="map/connections/*" element={<BiNetworkChart/>}/>
              {/*  <Route path="graph/*" element={<BiNetworkChart/>}/> this route not being used anymore */}
            </Routes>
          </Tab>

				</TabList>

			</Tabs>
    </div>
  )
}

function HomeSecondPanelContents(){
  return (
    <div className='charts-sub-panel'>
      <TagTrends/>
      <TopThemes/>
      <TernaryESG/>
      <StatsLinks/>
    </div>
  )
}


function setTabParameter(val) {
  let url = window.location.href;
  // Check if the URL already has a query string
  if (url.indexOf('?') !== -1) {
    // check if it already has a tab parameter
    if (url.indexOf('tab') !== -1)
      url = url.replace(/tab=[0-9]/, 'tab=' + val)  // replace the existing tab parameter with the new one
    else url += '&tab=' + val
  }
  else // If it doesn't, we need to create a new query string
    url += '?tab=' + val
  window.history.replaceState(null, null, url) // Update the browser's URL
}