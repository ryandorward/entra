import { Link, useLocation, matchRoutes } from 'react-router-dom'
import { mapTypes } from './mapTypes.js'
import { mapContent } from './MapFrame'

const geo_idRE = /^(?<subpath>.*\/jurisdiction)\/(?<geo_id>\d+)/i

const typeSlugs = Object.values(mapTypes).map(t=>t.slug).join('|')
export const mapTypeRE = new RegExp(`^/(?<type>${typeSlugs})/(?<etc>.+)`);

export default function MapLink({geo_id,mapType,children,...etc}){
	const { pathname } = useLocation()
	return (
		<Link to={mapPath(pathname,{geo_id,mapType})} {...etc}>
			{children}
		</Link>
	)
}

// separate for use in <Navigate/>'s
export function mapPath(currentPath,{geo_id,mapType}){
	var path = currentPath
	if(geo_id && geo_idRE.test(path)){
		path = `${geo_idRE.exec(path).groups.subpath}/${geo_id}`
	}
	if(mapType && mapTypeRE.test(path)){
		path = `/${mapType}/${mapTypeRE.exec(path).groups.etc}`
	}
	return path
}

export function isCurrentPath(currentPath,{mapType}){
	return currentPath == mapPath(currentPath,{mapType})
}

export function pathExists(path){
	// console.log(path)
	if( ! mapTypeRE.test(path) ) {
		//console.log('no match')
		return false;
	}
	let { type: mapType, etc } = mapTypeRE.exec(path).groups
	if (mapType == 'map/connections')
		mapType = 'map'
	const availablePaths = Object.keys(mapContent[mapType]).map(path=>({path}))
	// console.log(matchRoutes(availablePaths,`/${etc}`))
	return matchRoutes(availablePaths,`/${etc}`)
}