// pulsing effect coming off the node
export default function CirclePulse({x,y,radius}){
	return (
		<circle cx={x} cy={y} style={{fill:'none',strokeWidth:'2px'}}>
			<animate 
				attributeName="r" values={`${radius};${radius+15}`}
				dur="2s" repeatCount="indefinite"/>
			<animate 
				attributeName="stroke" values={`#fff;#fff0`}
				dur="2s" repeatCount="indefinite"/>
		</circle>
	)
}
