import { useState, createContext } from 'react';
import { geoOrthographic, geoGraticule, geoPath } from 'd3-geo'
import { coastlines } from '../coastlines'
import './globe.less'

const width = 800 // = height
const proj = geoOrthographic().scale(400).translate([0,0]).rotate([-135,-33])
const pathGen = geoPath().projection( proj )

export const Context = createContext({});

export default function({children}){
	const [ loading, setLoading ] = useState(true)
	const classes = ['map','globe']
	if(loading) classes.push('loading')
	return (
		<svg className={classes.join(' ')}
			viewBox={`${-width/2} ${-width/2} ${width} ${width}`}>
			<defs>
				<clipPath id="space">
					<path d={pathGen({type:'Sphere'})}/>
				</clipPath>
			</defs>
			<path id="ocean" d={pathGen({type:'Sphere'})} clipPath="url(#space)"/>
			<path id="land" d={pathGen(coastlines)} clipPath="url(#space)"/>
			<g id="graticules">
				{geoGraticule().lines().map( (g,i) => {
					return <path key={i} className="graticule" d={pathGen(g)}/>
				})}
			</g>
			<Context.Provider value={{projection:proj,pathGen,setLoading}}>
				{children}
			</Context.Provider>
		</svg>
	)
}
