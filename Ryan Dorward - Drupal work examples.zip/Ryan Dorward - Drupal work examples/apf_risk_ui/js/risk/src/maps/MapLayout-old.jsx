import { createContext, Component } from 'react';
import MediaQuery from 'react-responsive'
import './mapLayout.less'

import Legend from './Legend'
import Panel from './Panel'
import MapFrame from './MapFrame'
import MapControls from './Controls'

export const Context = createContext()

export default class MapLayout extends Component{
	constructor(props){
		super(props)
		this.setSharedData = this.setSharedData.bind(this)
		this.state = {
			shared: { // arbitrarily structured data to be passed around
				data: {},
				setData: this.setSharedData
			}
		}
	}
	render(){
		return (
			<div className='mapLayoutContainer'>
				<Context.Provider value={this.state.shared}>
					<Panel/>
					<MediaQuery minWidth={700}>
						<MapFrame mapType={this.props.type}/>
						<MapControls mapType={this.props.type}/>
						<Legend mapType={this.props.type}/>
					</MediaQuery>
				</Context.Provider>
			</div>
		)
	}
	setSharedData(newSharedData){ // adds/modifies specified properties to shared data
		this.setState( prevState => {
			let newState = { ...prevState }
			newState.shared.data = { ...prevState.shared.data, ...newSharedData }
			return newState;
		} )
	}
}
