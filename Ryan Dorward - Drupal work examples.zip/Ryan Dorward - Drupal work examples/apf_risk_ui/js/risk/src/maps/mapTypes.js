import { lazy } from 'react'
import { BiNetworkChart, BiTimeFive } from 'react-icons/bi'
import { FaGlobeAsia } from 'react-icons/fa'

export const mapTypes = {

	/*
	'geographic': {
		slug: 'map',
		title: 'Geographic Map',
		icon: FaGlobeAsia,
		iconSize: 30,
		component: lazy(()=>import('./geographic/Map'))
	},*/
	'geographic': { // change this to geographic_nate and uncomment the above
		slug: 'map',
		title: 'Geographic Map',
		icon: FaGlobeAsia,
		iconSize: 30,
		component: lazy(()=>import('./geographic/NateMap'))
	},

	'network': {
		slug: 'graph',
		title: 'Network Map',
		icon: BiNetworkChart,
		iconSize: 30,
		component: lazy(()=>import('./network/Map'))
	},
	'timeline': {
		slug: 'timeline',
		title: 'Timeline',
		icon: BiTimeFive,
		iconSize: 35,
		component: lazy(()=>import('./timeline/TimelineMap'))
	}
}