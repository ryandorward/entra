import { createRef, Component } from 'react';
import { select } from 'd3-selection'
import { drag } from 'd3-drag'
import CirclePulse from './CirclePulse'
import { lighter } from '../utilities/lighter.js'

export default class Node extends Component{


	constructor(props){
		super(props)
		this.dragStart = this.dragStart.bind(this)
		this.drag = this.drag.bind(this)
		this.dragEnd = this.dragEnd.bind(this)
		this.nodeRef = createRef()
	}
	componentDidMount(){
		select(this.nodeRef.current)
			.call( drag()
				.on('start',this.dragStart)
				.on('drag',this.drag)
				.on('end',this.dragEnd)
			)
	}
	dragStart({dx,dy}){
		this.props.node.fx = this.props.node.x + dx
		this.props.node.fy = this.props.node.y + dy
		this.props.simulation.alphaTarget(0.5).restart()
	}
	drag({dx,dy}){
		this.props.node.fx += dx
		this.props.node.fy += dy
	}
	dragEnd(){
		this.props.node.fx = undefined
		this.props.node.fy = undefined
		this.props.simulation.alphaTarget(0)
	}
	/*
	<TooltipWrapper tooltipId='timeline-tip' data-tooltip-content={node.event?.title ?? node.label??node.title}>
			</TooltipWrapper>
	*/
	render(){
		const { node } = this.props
		return (
			<>
				<circle key={node.id} ref={this.nodeRef}
					className={node.classes.join(' ')}
					cx={node.x} cy={node.y}
					r={node.radius}
					fill={lighter(node.color)}
					stroke={node.color}
					data-tooltip-content={node.event?.title ?? node.label??node.title}
					id={`timeline-tip-${node.id}`}
				>
					{/* the tooltip component is in the parent Map component. See maps/timeline/Map.jsx */}
					{/* <title>{node.label??node.title}</title> */}
				</circle>

				{(node?.focused || this.props?.focused) &&
					<CirclePulse x={node.x} y={node.y} radius={node.radius}/>
				}
			</>
		)
	}
}
