import countriesTopo from './countries.json'
import { merge } from 'topojson-client'

// returns a geojson object 
export const coastlines = merge(
	countriesTopo,
	countriesTopo.objects.countries.geometries
)
