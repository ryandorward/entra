import { Component } from 'react';
import { Link as RouterLink, useLocation, useParams } from 'react-router-dom'
import {
	forceSimulation, forceCollide,
	forceManyBody, forceLink } from 'd3-force'
import forceLimit from 'd3-force-limit'
import { scalePow } from 'd3-scale'
import { JurisdictionNode } from './jurisdiction-node.js'
import Link from './link'
import { Spinner } from '../../Spinners'
import Node from '../DraggableNode'
import assignPopulations from '../../wikidata/queries/assignPopulations.js'
import nodeStyles from '../node.module.less'
import '../map.less'

import { MapContext } from './Context'
import { Context as LayoutContext } from '../MapLayout-old.jsx'

// wrapper function is a clumsy workaround to allow links modifying the geo_id
// without otherwise altering the current path
export default function Wrapper(props){
	const { pathname } = useLocation()
	const { geo_id } = useParams()
	const modPath = (new_geo_id)=> pathname.replace(geo_id,new_geo_id);
	return <NetworkMap {...{...props,modPath}}/>
}

class NetworkMap extends Component{
	static contextType = LayoutContext; // makes available as this.context
	constructor(props){
		super(props)
		this.init = this.init.bind(this)
		this.setData = this.setData.bind(this)
		this.state = {
			shared: { // passed control functions
				init: this.init,
				setNodes: this.setNodes,
				setLinks: this.setLinks,
				setData: this.setData
			},
			nodes: [],
			links: [],
			initialized: false // is the map ready to be rendered?
		}
	}
	get x0(){ return -this.props.width/2 }
	get y0(){ return -this.props.height/2 }
	get x1(){ return this.props.width/2 }
	get y1(){ return this.props.height/2 }

	componentDidMount(){
		this.simulation = forceSimulation()
			.force('collide',forceCollide().radius(n=>n.radius?1+n.radius:5))
			.force('static',forceManyBody().distanceMax(100))
			.force('bounds',
				forceLimit()
					.x0(this.x0).x1(this.x1)
					.y0(this.y0).y1(this.y1)
					.radius(n=>n.radius)
			)
			.alphaMin(0.1) // default 0.001
			.stop()
		// simply re-render on each tick
		this.simulation.on( 'tick', () => this.forceUpdate() )
	}
	componentDidUpdate({width:prevWidth,height:prevHeight}){
		const { width, height } = this.props
		if( width != prevWidth || height != prevHeight ){
			this.simulation.force('bounds',
				forceLimit().x0(this.x0).x1(this.x1).y0(this.y0).y1(this.y1)
					.radius(n=>n.radius)
			).alpha(1).restart()
		}
	}
	init(bool){
		this.setState( {initialized:Boolean(bool),nodes:[],links:[]} )
	}
	setData({jurisdictions,connections,focus}){
		// handle nodes
		const nodes = jurisdictions.map( jur => {
			let node = new JurisdictionNode(jur)
			if(jur==focus) node.focused = true
			let [lon,lat] = jur.latlon
			node.y = -lat
			node.x = (lon < 0 ? 180+lon : -180-lon) // reverse prime meridian
			return node
		} )
		assignPopulations(nodes.map(n=>n.jur))
			.then(()=>scaleNodeRadii(nodes,undefined))
		// handle links
		const linkIDs = new Set()
		const links = connections.map( ([a,b]) => {
			let aNode = nodes.find( n => n.jur == a )
			let bNode = nodes.find( n => n.jur == b )
			if( aNode && bNode ){
				let link = new Link(aNode,bNode)
				if(!linkIDs.has(link.id)){
					linkIDs.add(link.id)
					return link
				}
			}
		} ).filter(v=>v)
		// update the simulation
		this.simulation.nodes(nodes)
			.force( 'link', forceLink(links).distance(l=>l.distance) )
			.alpha(1).restart()
		// update the state to re-render
		this.setState({nodes,links,initialized:true})
	}
	render(){
		const labelLimit = 20
		const {width,height} = this.props
		return (
			<MapContext.Provider value={this.state.shared}>
				<svg className='dark map network'
					viewBox={`${this.x0} ${this.y0} ${width} ${height}`}>
					{this.props.children}
					<g id="links">
						{this.state.links.map( (link,i) => (
							<path key={i} className={link.classes.join(' ')}
								d={link.pathData} style={link?.style}/>
						) )}
					</g>
					<g id="labels">
						{this.state.nodes.slice(0,labelLimit).map( node => (
							<text key={node.id}
								className={[nodeStyles.label,...node.classes].join(' ')}
								x={2+node.x+node.radius} y={node.y}>
								{node.label}
							</text>
						) )}
					</g>
					<g id="nodes">
						{this.state.nodes.map( (node,i) => (
							<RouterLink key={node.id} to={this.props.modPath(node.jur.geo_id)}>
								<Node node={node} simulation={this.simulation}
									labelled={i<labelLimit}/>
							</RouterLink>
						) )}
					</g>
				</svg>
				{!this.state.initialized && <Spinner size={50}/>}
			</MapContext.Provider>
		)
	}
}

function scaleNodeRadii(nodes,func=node=>node.jur?.population){
	const [ minRadius, maxRadius ] = [ 4, 20 ]
	const allVals = nodes.map(func).filter(v=>!isNaN(v))
	const radius = scalePow().exponent(0.5)
		.domain( [ Math.min(...allVals), Math.max(...allVals) ] )
		.range( [ minRadius, maxRadius ] )
		.unknown( minRadius )
	nodes.map( node => {
		node.radius = radius(func(node))
	} )
}
