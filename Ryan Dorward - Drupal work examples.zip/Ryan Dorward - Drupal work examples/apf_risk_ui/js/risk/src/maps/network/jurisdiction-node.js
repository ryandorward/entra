import { ForceNode } from '../force-node.js'
import './nodes.less'

export class JurisdictionNode extends ForceNode{
	#jur
	constructor(jurisdiction){
		super()
		this.#jur = jurisdiction
	}
	get jur(){ return this.#jur }
	get id(){ return this.#jur.geo_id }
	get title(){ return this.#jur.name.en; }
	get size(){ return this.#jur.population }
	get label(){ return this.#jur.name.en }
	get classes(){
		const classNames = new Set([...super.classes])
		classNames.add( this.#jur.canadian ? `canadian` : `asian` )
		return [...classNames]
	}
}
