import { JurisdictionNode } from './jurisdiction-node.js'
import styles from './links.module.css'

export default class Link{
	#id
	#myRandomNumber = Math.random()
	#source
	#target
	#classNames = new Set([styles.link]);
	#investments = []
	constructor(source,target){
		if(! (source instanceof JurisdictionNode) || !(target instanceof JurisdictionNode)){ 
			console.warn("link's nodes are not jurisdictionNodes:",source,target)
		}else if(source==target){
			console.warn('reflexive link on',source)
		}
		this.#source = source
		this.#target = target
		this.#id = [source.id,target.id].sort((a,b)=>a-b).join('<->')
		// determine css classes / link type
		if(this.#source.jur.parent==this.#target.jur||this.#target.jur.parent==this.#source.jur){
			this.#classNames.add(styles.parentChild)
		}
		if(this.hasDirectTwinning) this.#classNames.add(styles.twin);
		if(this.isTranspacific) this.#classNames.add(styles.transpacific);
		if(this.#target.jur.borders(this.#source.jur)) this.#classNames.add(styles.border);
		if(this.touchesFocusedNode) this.#classNames.add(styles.focused);
		if(this.hasDirectMission) this.#classNames.add(styles.directMission);
	}
	get id(){ return this.#id }
	get source(){ return this.#source }
	get target(){ return this.#target }
	get classes(){ return [...this.#classNames] }
	get pathData(){
		return `M${this.source.x} ${this.source.y} L${this.target.x} ${this.target.y}`
	}
	addInvestment(investment){
		this.#investments.push(investment)
	}
	get style(){
		const css = {}
		if(this.#investments.length > 0){
			css.strokeWidth = Math.sqrt(this.#investments.length)
		}
		if(this.isTranspacific){
			css.strokeDashoffset = 10 * this.#myRandomNumber
		}
		return css
	}
	get isTranspacific(){
		return this.#source.jur.canadian != this.#target.jur.canadian
	}
	get touchesFocusedNode(){
		return this.source.focused || this.target.focused
	}
	get hasDirectTwinning(){
		return this.#source.jur.connections(/Twinning/)
			.some( conn => conn.jurisdictions.some(j=>j==this.#target.jur) )
	}
	get hasDirectMission(){
		return this.#source.jur.connections(/Mission/)
			.some( conn => conn.jurisdictions.some(j=>j==this.#target.jur) )
	}
	get distance(){
		let minDist = this.source.radius + this.target.radius
		let basicDist = this.isTranspacific ? 180 : 50
		let focusPadding = this.touchesFocusedNode ? 30 : 0
		return minDist + basicDist + focusPadding
	}
}
