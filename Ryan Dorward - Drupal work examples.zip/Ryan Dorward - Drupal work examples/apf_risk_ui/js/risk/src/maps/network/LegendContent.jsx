import LinkItem from '../legend/LinkItem'
import CircleItem from '../legend/CircleItem'
import styles from './links.module.css'
import './nodes.less'

export default function Legend(){
	return (
		<div className="legend">
			<CircleItem label="Canadian Jurisdiction" radius={7} className="node canadian"/>
			<CircleItem label="Asia-Pacific Jurisdiction" radius={7} className="node asian"/>
			<LinkItem label="Shared Border" className={styles.border}/>
			<LinkItem label="Twinning Relation" className={styles.twin}/>
			<LinkItem label="Parent-Child Relation" className={styles.parentChild}/>
			<LinkItem label="Other" className={styles.link}/>
			<LinkItem label="Transpacific Connection" className={styles.transpacific}/>
			<LinkItem label="Direct diplomatic mission" className={styles.directMission}/>
		</div>
	)
}
