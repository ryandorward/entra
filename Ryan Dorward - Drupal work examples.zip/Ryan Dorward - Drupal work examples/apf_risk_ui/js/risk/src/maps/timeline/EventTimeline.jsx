import { Link } from 'react-router-dom'
import { useReactiveVar } from '@apollo/client'
import Node from './EventNode'
import { currentlyHoveredEventId } from '../../utilities/hover.js'
import styles from './timeline.module.css'

export default function EventTimeline({simulation,nodes,links}){
	const focusedEventId = useReactiveVar(currentlyHoveredEventId)
	return (<>
		<path className={styles.timeline} d={`M 0 -2000 L 0 2000`}/>
		<g id="links">
			{links.map( link => <NodeLink key={link.id} link={link}/> )}
		</g>
		<g id="nodes">
			{nodes.map( node => (
				<Link key={node.id} to={`/map/event/${node.id}`}>
					<Node node={node}
						simulation={simulation}
						focused={node.id==focusedEventId?true:undefined}/>
				</Link>
			) )}
			{/*
			// These text labels are finnicky, but we may want to revive them down the line.
			{nodes.filter(n=>n?.label).map( node => (
				<text key={node.id} className={styles.label}
					transform={`translate(${2+node.x+node.radius} ${node.y})`}>
					{node.label.map( (text,i) =>(
						<tspan key={i} y={`${i-0.5}em`} x="0">
							{text}
						</tspan>
					))}
				</text>
					))}
			*/}
		</g>

	</>)
}

// It will be tempting to refactor the following Link component to export from a separate .jsx
// ...but for an unknown reason, this breaks Safari.
// Best leave it here unless that problem is sorted.
function NodeLink({link}){
	return (
		<path className={link.classes.join(' ')}
			d={pathGen(link.source,link.target)}/>
	)
}

function pathGen(source,target){
	let x = (source.x + target.x)/2 - Math.abs(source.y-target.y)/2
	let y = (source.y + target.y) / 2
	return `M ${source.x} ${source.y} Q ${x} ${y} ${target.x} ${target.y}`
}
