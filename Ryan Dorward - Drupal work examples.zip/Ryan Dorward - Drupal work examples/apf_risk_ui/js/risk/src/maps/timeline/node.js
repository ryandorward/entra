import { DateTime } from 'luxon'
import { ForceNode } from '../force-node.js'
import { Link } from './link'
import { colorFromThemes } from '../../events/ESG/colorFromThemes'

export class Node extends ForceNode{
	#links = { forward: new Set(), backward: new Set(), side: new Set() }
	#date
	#color
	constructor(data){
		super()
		if(data.__typename != 'Event'){
			return console.warn('Data passed to node must be an event')
		}
		this.event = data
		this.themes = this.event.themes
		this.#date = DateTime.fromISO( data.date )
		this.#color = colorFromThemes(this.themes)
	}
	get id(){ return this.event.id }
	get href(){ return `/timeline/event/${this.id}` }
	get uid(){ return this.href }
	get title(){ return this.event.title }
	get date(){ return this.#date }
	
	hasTheme(id){
		return this.themes.some( theme => theme.id == Number(id) )
	}
	acceptLink(link){
		if( link instanceof Link ){
			if( link.source == this ) return this.#links.forward.add(link)
			if( link.target == this ) return this.#links.backward.add(link)
		}
	}
	get backwardNodes(){ // nodes one link backward in time
		return [...this.#links.backward].map( link => link.source )
	}
	get forwardNodes(){ // nodes one link forward in time
		return [...this.#links.forward].map( link => link.target )
	}
	get allForwardNodes(){ // recursive forward nodes
		return [
			...this.forwardNodes,
			...this.forwardNodes.map(node=>node.allForwardNodes).flat()
		]
	}
	get allBackwardNodes(){ // recursive backward nodes
		return [
			...this.backwardNodes,
			...this.backwardNodes.map(node=>node.allBackwardNodes).flat()
		]
	}
	get allReachableNodes(){
		return [ this, ...this.allBackwardNodes, ...this.allForwardNodes ]
	}
	canReachNode(nodeTestFunc){
		return this.allReachableNodes.some(nodeTestFunc)
	}
	hasForwardNode(nodeTestFunction){
		return this.allForwardNodes.some(nodeTestFunction)
	}
	hasBackwardNode(nodeTestFunction){
		return this.allBackwardNodes.some(nodeTestFunction)
	}
	get radius(){
		return 5 + Math.min( (3*(this.event?.weight??0)), 8 ) 
	}
	get color(){ return this.#color }
	get label(){
		if(!this.focused) return undefined;
		if(this?._splitTitle) return this._splitTitle;
		return this._splitTitle = split(this.event.title)
	}
	get classes(){
		return super.classes
	}
}

// split at white space into array of two
function split(text){
	const midpoint = Math.round(text.length/2)
	const split = [...text.matchAll(/\s/g)]
		.map( match => match.index )
		.sort((a,b)=> Math.abs(midpoint-a) - Math.abs(midpoint-b) )[0]
	return [text.slice(0,split),text.slice(split+1)]
}

