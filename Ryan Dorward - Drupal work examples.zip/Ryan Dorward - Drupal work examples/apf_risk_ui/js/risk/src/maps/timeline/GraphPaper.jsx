import { memo } from 'react';
import { useReactiveVar } from '@apollo/client'
import { DateTime } from 'luxon'
import { tickMaker } from '../../utilities/time/breaks'
import { timeRange } from '../../events/timeRange.js'
import './paper.less'

export default memo(Paper);

const padding = { left: 10, right: 10 } // px

const availableLevels = ['year','month','week','day']
const classes = ['one','two','three','four']

// date variables are already luxon date objects
function Paper({yScale:Y,width}){
	const { before, after } = useReactiveVar(timeRange)

	const ticks = tickMaker(
		DateTime.fromISO(after),
		DateTime.fromISO(before),
		Math.abs(Y.range()[0]-Y.range()[1])
	)
	// establish the visual hierarchy
	let typesUsed = new Set(ticks.map(t=>t.type))
	let levels = availableLevels.filter(l=>typesUsed.has(l))
	let classMap = new Map(
		levels.map( (l,i) => {
			let k = levels.length > 2 ? i : i+1
			return [l,classes[k]]
		} )
	)
	classMap.set('today','today')
	return (
		<g id="grid-paper">
			{ticks.map( (tick,i) => (
				<g key={i} className={classMap.get(tick.type)}>
					<path d={`M ${-width/2} ${Y(tick.date.toSeconds())} l ${width} 0`}/>
					{tick?.label &&
						<text x={-width/2+padding.left} y={Y(tick.date.toSeconds())-1}>
							{tick.label}
						</text>
					}
				</g>
			) )}
		</g>
	)
}
