import CircleItem from '../legend/CircleItem'
import styles from '../node.module.less'

export default function(){
	return (
		<>
			<CircleItem label="Event" radius={7} 
				className={styles.node}
				fill='var(--red)' stroke='var(--red)' strokeWidth={2}/>
		</>
	)
}
