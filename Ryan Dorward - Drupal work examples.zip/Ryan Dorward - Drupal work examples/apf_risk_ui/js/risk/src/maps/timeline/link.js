import { Node } from './node'
import styles from './links.module.css'

export class Link {
	#source
	#target
	#data
	constructor(A,B,data){
		if( ! ( A instanceof Node && B instanceof Node ) ){
			return console.warn('link passed something other than a node',A,B)
		}
		// source is always the earlier, target later
		// this fact is relied upon elsewhere
		if(A.date.ts!=B.date.ts){
			[ this.#source, this.#target ] = A.date.ts < B.date.ts ? [A,B] : [B,A]
		}else{
			[ this.#source, this.#target ] = A.id < B.id ? [A,B] : [B,A]
		}
		A.acceptLink(this)
		B.acceptLink(this)
		this.#data = data
	}
	get source(){ return this.#source }
	get target(){ return this.#target }
	get id(){ return `${this.#source.uid}->${this.#target.uid}` }
	get type(){ return this.#data.linkType.id }
	get typeClass(){ 
		return styles?.[`type${this.#data.linkType.id}`] 
	}
	touchesNode(nodeTestFunc){
		return nodeTestFunc(this.#source) || nodeTestFunc(this.#target)
	}
	beforeNode(nodeTestFunc){
		return [this.#target,...this.#target.allForwardNodes].some(nodeTestFunc)
	}
	afterNode(nodeTestFunc){
		return [this.#source,...this.#source.allBackwardNodes].some(nodeTestFunc)
	}
	canReachNode(nodeTestFunc){
		return this.beforeNode(nodeTestFunc) || this.afterNode(nodeTestFunc)
	}
	get lengthClass(){
		let yDiff = Math.abs( this.#source.y - this.#target.y )
		if( yDiff < 50 ) return styles.short
		if( yDiff < 200 ) return styles.medium
		if( yDiff < 500 ) return styles.long
		return undefined
	}
	get focusClass(){
		if(this.touchesNode(n=>n.focused)) return styles.touchesFocus
		return undefined
	}
	get classes(){
		return [ this.typeClass, this.lengthClass, this.focusClass].filter(c=>c)
	}
}
