import { useEffect, useRef, useState } from 'react';
import { DateTime } from 'luxon'
import { select } from 'd3-selection'
import { zoom } from 'd3-zoom'
import { timeRange } from '../../events/timeRange.js'

const earliestDate = DateTime.fromISO('2021-06-01')

export default function TimeSlider({width,y}){
	const ref = useRef()
	const [ grabbing, setGrabbing ] = useState(false) // cursor
	const pxRange = { min: y.range()[0], max: y.range()[1] }
	const dateRange = { min: y.domain()[0], max: y.domain()[1] }

	useEffect(()=>{
		const limits = { // min/max in px terms, not date; date starts from bottom
			min: y( DateTime.now().plus({days:1}).toSeconds() ),
			max: y( earliestDate.toSeconds() )
		}
		const numPx = pxRange.max - pxRange.min;
		const numDays = ( dateRange.min - dateRange.max ) / 86400 // seconds in a day
		const pxPerDay = numPx / numDays // 1,25 range limits
		select(ref.current).on('.zoom',null)
		delete ref.current.__zoom // delete d3-zoom's per-element transform data
		select(ref.current).call(
			zoom()
			.scaleExtent([1/pxPerDay,30/pxPerDay])
			.extent([[null,pxRange.min],[null,pxRange.max]])
			.translateExtent([[null,limits.min],[null,limits.max]])
			.on('start',()=>setGrabbing(true))
			.on('end',({transform}) => {
				setGrabbing(false)
				let [ newBefore, newAfter ] = transform.rescaleY(y).domain()
				let range = {
					after: DateTime.fromSeconds(newAfter).toISODate(),
					before: DateTime.fromSeconds(newBefore).toISODate()
				}
				range && timeRange(range)
			} )
		)
	},[dateRange.min,dateRange.max,pxRange.min,pxRange.max])
	return ( // this rect is transparent
		<rect ref={ref} fill='#F000' x={-width/2} y={pxRange.min}
			style={{ cursor: grabbing ? 'grabbing' : 'grab' }}
			width={width} height={pxRange.max-pxRange.min} />
	)
}
