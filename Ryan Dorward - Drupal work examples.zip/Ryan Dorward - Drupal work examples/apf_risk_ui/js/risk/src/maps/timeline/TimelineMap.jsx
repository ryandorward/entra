import { Component, createContext } from 'react';
import { useReactiveVar } from '@apollo/client'
import { forceSimulation, forceCollide, forceY, forceX } from 'd3-force'
import { scaleLinear } from 'd3-scale'
import { DateTime } from 'luxon'
import EventTimeline from './EventTimeline'
import TemporalGraphPaper from './GraphPaper'
import { Spinner } from '../../Spinners'
import { forceXLink } from './forceXLink'
import { timeRange } from '../../events/timeRange.js'
// import { defaultValue as defaultTimeRange } from '../../events/timeRange.js'
import { timeRangeFromNodes } from './timeRangeFromNodes.js'
// import { nodesAreFullyOutside } from './timeRangeFromNodes.js'
// import Slider from './Slider' // Don't throw this away! We might need it again later, for zooming on the timeline.
import '../map.less'
// import { Link } from 'react-router-dom'
import { Tooltip } from 'react-tooltip'
import 'react-tooltip/dist/react-tooltip.css'
import ESG_legend from '../legend/esg-legend2.svg'
import '../legend/esg-legend.less'
import TipHeadline from '../../events/TipHeadline.jsx'

export const Context = createContext()

export default function ReactiveHOC(props){
	const { before, after } = useReactiveVar(timeRange)
	/*
	const range = useReactiveVar(timeRange)
	const before = range?.before ?? defaultTimeRange.before
	const after = range?.after ?? defaultTimeRange.after
	*/
	// const { before, after } = range
	return <TimelineMapComponent {...{...props,before,after}}/>
}

class TimelineMapComponent extends Component{
	#padding = { top: 70, bottom: 20 }
	constructor(props){
		super(props)
		this.init = this.init.bind(this)
		this.setNodes = this.setNodes.bind(this)
		this.setLinks = this.setLinks.bind(this)
		this.state = {
			shared: { // passed control functions
				init: this.init,
				setNodes: this.setNodes,
				setLinks: this.setLinks
			},
			nodes: [],
			yScale: scaleLinear()
				.range(this.yRange)
				.domain([
					DateTime.fromISO(this.props.before).toSeconds(),
					DateTime.fromISO(this.props.after).toSeconds()
				]),
			links: [],
			initialized: false // is the map ready to be rendered?
		}
	}
	componentDidMount(){
		this.simulation = forceSimulation(this.state.nodes)
			.force('collide',forceCollide().radius(n=>1.5+n.radius).iterations(2))
			.force('x',forceX().x(0).strength(0.025))
			.force(
				'time',
				forceY().y(n=>this.state.yScale(n.date.toSeconds())).strength(0.4)
			)
			.alphaMin(0.05) // default 0.001
			.stop()
		this.simulation.on('tick',()=>this.forceUpdate())
	}
	componentDidUpdate(prevProps){
		if(
			this.props.height != prevProps.height ||
			this.props.before != prevProps.before ||
			this.props.after != prevProps.after
		){
			let start = DateTime.fromISO(this.props.before).toSeconds()
			let end = DateTime.fromISO(this.props.after).toSeconds()
			// let range = start - end
			// add 10% on either side of the range
			// start += range * 0.5
			// end -= range * 0.1
			const yScale = this.state.yScale.copy()
				.range(this.yRange)
				.domain([
					start,
					end
				])
			this.setState({yScale})
			this.simulation
				.force(
					'time',
					forceY().y(n=>yScale(n.date.toSeconds())).strength(0.4)
				)
				.alpha(1).restart()
		}
	}
	init(booleanValue){
		const initialized = Boolean(booleanValue)
		if( initialized ){
			this.setState({initialized})
		}else{
			this.setState({initialized,nodes:[],links:[]})
		}
	}
	get yRange(){
		return [
			-this.props.height/2 + this.#padding.top,
			this.props.height/2 - this.#padding.bottom
		]
	}
	setNodes(nodes){

		/*
		if( nodesAreFullyOutside(nodes,this.props.before,this.props.after) ){
			timeRange(timeRangeFromNodes(nodes))
		}
		*/
		// Always set the time range to the nodes, even if they're outside the current range.
		const range = timeRangeFromNodes(nodes)
		range && timeRange(range) // be careful not to set the time range to undefined, or things break

		nodes.map( node => { if(!node?.y) {
			node.x = 0;
			node.y = this.state.yScale(node.date.toSeconds());
		} } )
		this.setState({nodes})
		this.simulation.nodes(nodes).alpha(1).restart()
	}
	setLinks(links){
		this.simulation.force('link',
			forceXLink(links).distance(10).strength(0.15)
		)
		this.setState({links})
	}
	render(){
		const { width,height } = this.props
		return (
			<>
				<Context.Provider value={this.state.shared}>
						{this.props.children}
						<Tips nodes={this.state.nodes}/>
						<svg className='dark map timeline'
							viewBox={`-${width/2} -${height/2} ${width} ${height}`}>
							{this.state.initialized &&
								<TemporalGraphPaper yScale={this.state.yScale} width={width}/>
							}
							{/*
								Note: Don't throw this away! This is how zooming is done on the timeline, and we might need it later!
								<Slider width={width} y={this.state.yScale}/>
							*/}
							<EventTimeline
								simulation={this.simulation}
								nodes={this.state.nodes}
								links={this.state.links}/>
						</svg>

					{!this.state.initialized && <Spinner size={50}/>}

				</Context.Provider>
				<ESG_legend/>
			</>
		)
	}
}

function Tips({nodes}) {
  return nodes.map( node => (
		<Tooltip
			key={`timeline-tip-${node.id}`}
			variant="dark"
			effect="solid"
			place="top"
			anchorId={`timeline-tip-${node.id}`}
			className='react-tooltip-general timeline-tip'
			clickable={true}
		>	{/*}
			<Link
				to={`/map/event/${node.event.id}`}
				className='event-link'
			>
				{node.event?.title ?? node.label??node.title}
			</Link>
		*/}
			<TipHeadline event={node.event} variant="timeline"/>
		</Tooltip>
	))
}
