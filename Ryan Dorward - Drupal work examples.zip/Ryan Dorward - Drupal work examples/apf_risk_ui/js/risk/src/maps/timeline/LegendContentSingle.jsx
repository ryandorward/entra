import { Fragment, useContext } from 'react';
import { gql, useQuery } from '@apollo/client'

// import { Context } from '../MapLayout'
import { Context } from '../MapLayout'

import Group from '../legend/Group'
import LinkItem from '../legend/LinkItem'
// import LegendNodes from './LegendNodes'
import linkStyles from './links.module.css'
import '../legend.less'

const query = gql`query { eventLinkTypes { id title description } }`

export default function Legend(){
	const { data: layoutData } = useContext(Context)
	const { data } = useQuery(query)
	const linkTypes = ( data?.eventLinkTypes ?? [] ).filter( type => (
		layoutData?.linkTypesShown?.includes(type.id)
	) )

	// Sort the linkTypes by linkType.id as follows:
	// 1 causal
	// 4 development
	// 3 recurrence
	// 5 contrast
	// 2 relation
	const idOrder = [1, 4, 3, 5, 2];
	linkTypes.sort((a, b) => idOrder.indexOf(a.id) - idOrder.indexOf(b.id));

	return linkTypes.length ? (
		<div className="timeline legend">
				<Group title="Event Links">
					{linkTypes.map( lt => (
						<Fragment key={lt.id}>
							<LinkItem label={lt.title}
								className={`${linkStyles['type'+lt.id]}`}/>
							<span className='note'>{lt.description}</span>
						</Fragment>
					) )}
				</Group>
		</div>
    ) : null
}
