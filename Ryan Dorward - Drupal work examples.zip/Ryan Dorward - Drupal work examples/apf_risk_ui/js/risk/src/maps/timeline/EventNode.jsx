import { useRef, useEffect } from 'react'
import DraggableNode from '../DraggableNode'
import { listenForHoverEvent } from '../../utilities/hover.js'

export default function EventNode(props){
	const ref = useRef()
	useEffect(()=>{
		// ref stores DraggableNode class instance, not element
		// reach in to get the actual element reference
		listenForHoverEvent(
			ref.current.nodeRef.current,
			props.node.id
		)
	},[])
	return <DraggableNode ref={ref} {...props}/>
}
