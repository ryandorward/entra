export function timeRangeFromNodes(nodes){
	if( nodes.length == 0 ) return;
	if( nodes.length == 1 ){
		let date = nodes[0].date;
		return {
			after: date.minus({weeks:2}).toISODate(),
			before: date.plus({weeks:2}).toISODate()
		}
	}
	// else multiple nodes
	const { first, last } = nodeDateRange(nodes)
	return {
		after: first.minus({weeks:0.5}).toISODate(),
		before: last.plus({weeks:0.5}).toISODate()
	}
}

export function nodesAreFullyOutside(nodes,before,after){
	if( nodes.length == 0 ) return undefined;
	const focusNode = nodes.find( n => n.focused )
	if( focusNode ){
		const focusDate = focusNode.date.toISODate()
		return focusDate > before || focusDate < after
	}
	const { first, last } = nodeDateRange(nodes)
	return last.toISODate() < after || first.toISODate() > before
}

function nodeDateRange(nodes){
	if( nodes.length == 0 ) return {}
	let sorted = [...nodes].sort((a,b)=>a.date.toSeconds()-b.date.toSeconds())
	return { first: sorted[0].date, last: sorted[sorted.length-1].date }
}
