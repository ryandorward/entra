import { useState, useContext, useEffect } from 'react';
import { Context as LayoutContext } from './MapLayout'

export { LayoutContext }

export default function ControlVariableToggle(){
	const [ checked, setChecked ] = useState(false)
	const { setData } = useContext(LayoutContext);
	useEffect(()=>{
		setData( { control: checked ? 'population' : undefined } )
	},[checked])
	return (
		<div>
			<input id="control-variable" type="checkbox"
				checked={checked} onChange={()=>setChecked(c=>!c)}/>
			<label htmlFor="control-variable"><i>per capita</i></label>
		</div>
	)
}
