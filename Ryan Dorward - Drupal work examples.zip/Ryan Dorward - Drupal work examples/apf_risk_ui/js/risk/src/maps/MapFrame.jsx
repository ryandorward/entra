import { lazy, Suspense } from 'react'
import { Routes, Route, Outlet } from 'react-router-dom'
import { withResizeDetector } from 'react-resize-detector'

import { Spinner } from '../Spinners'

import Legend from './Legend'

import './mapContainer.less'

const timelineCollection = lazy(()=>import('../events/TimelineCollection'))
// const geoMapPlural = lazy(()=>import('../events/GeoMapPlural'))


export const mapContent = {
	timeline: {
		'event/:event_id': lazy(()=>import('../events/TimelineSingle')),
		'events': timelineCollection,
		'events/tag/:tag_id': timelineCollection,
		'events/theme/:theme_id': timelineCollection,
		'events/jurisdiction/:geo_id': timelineCollection,
		'jurisdiction/:geo_id': timelineCollection
	},

	/*
	map: {

		'event/:event_id': lazy(()=>import('../events/GeoMapSingle')),
		'events': geoMapPlural,
		'events/jurisdiction/:geo_id': geoMapPlural,
		'events/theme/:theme_id': geoMapPlural,
		'events/tag/:tag_id': geoMapPlural,
		'jurisdiction/:geo_id': geoMapPlural,

	},
	*/
	map: {
		'jurisdiction/:geo_id': lazy(()=>import('../connections/density/GeoContent')), // map/connections/...
		'twinning/jurisdiction/:geo_id': lazy(()=>import('../connections/twinning/GeoMapContent')), // map/connections/...
		'business/jurisdiction/:geo_id': lazy(()=>import('../connections/business/MapContent')),
		'diplomacy/jurisdiction/:geo_id': lazy(()=>import('../connections/diplomacy/GeoMapContent')),
		'trade/jurisdiction/:geo_id': lazy(()=>import('../connections/tradeAgreements/GeoMapContent')),
	},

	graph: {
		'jurisdiction/:geo_id': lazy(()=>import('../connections/NetworkOverview')),
		'twinning/jurisdiction/:geo_id': lazy(()=>import('../connections/twinning/NetworkContent')),
		'trade/jurisdiction/:geo_id': lazy(()=>import('../connections/tradeAgreements/NetworkContent')),
		'diplomacy/jurisdiction/:geo_id': lazy(()=>import('../connections/diplomacy/NetworkContent')),
		'investment/jurisdiction/:geo_id': lazy(()=>import('../connections/investment/NetworkContent'))
	}
}

export default function ({mapType}){
	const contents = mapContent[mapType.slug]

	return (
		<>
			<Routes>
				<Route path="" element={<MapFrame Map={mapType.component}/>}>
					{Object.entries(contents).map( ([path,Component]) => (
						<Route key={path} path={path} element={<Component/>}/>
					) )}
				</Route>
			</Routes>
			<Legend mapType={mapType}/>
		</>
	)
}

const MapFrame = withResizeDetector(MapContainer);

function MapContainer({Map,width,height}){
	return (
		<div className="container">
			<Suspense fallback={<Spinner contained size={50}/>}>
				{ width && height && <Map {...{width,height}}><Outlet/></Map> }
			</Suspense>
		</div>
	)
}