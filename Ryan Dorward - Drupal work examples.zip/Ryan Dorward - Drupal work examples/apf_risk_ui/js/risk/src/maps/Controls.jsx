import { Routes, Route,  useLocation } from 'react-router-dom'
// import { Outlet } from 'react-router-dom'
// import JurisdictionSearch from '../jurisdictions/Search'
// import EventSearch from '../events/SearchBar'
import MapLink, { isCurrentPath, mapTypeRE, pathExists } from './MapLink'
import { mapTypes } from './mapTypes.js'
import './controls.less'

export default function(){
	return (
		<Routes>
			<Route path="" element={<ControlPanel/>}>
				<Route path="event/*"/>
				<Route path="events/*"/>
				<Route path="jurisdiction/*"/>
				<Route path="connections/*"/>
			</Route>
		</Routes>
	)
}

function ControlPanel(){
	return (
		<div className='controls-container'>
			<MapTypeSelector/>
		</div>
	)
}

function MapTypeSelector(){
	const { pathname } = useLocation()
	const subsequentPath = pathname.match(mapTypeRE)?.groups?.etc
	return Object.values(mapTypes)
		.filter( ({slug}) => pathExists(`/${slug}/${subsequentPath}`) )
		.map( ({icon:Icon,iconSize,slug,title}) => {
			let className = isCurrentPath(pathname,{mapType:slug}) ?
				'currentTypeSelector' : 'typeSelector';
			return (
				<MapLink key={slug} mapType={slug} title={`Switch to ${title}`} className={'map-link-' + slug}>
					<Icon size={iconSize} className={className}/>
				</MapLink>
			)
		})
}
