import { Suspense, lazy } from 'react';
import { Routes, Route, Outlet, useLocation } from 'react-router-dom'
import JurHeader from '../jurisdictions/PanelHeader'
import Headlines from '../HomePage/Headlines'
import { Spinner } from '../Spinners'
import './panel.less'

const Content = {
	jurisdictions: lazy(()=>import('../jurisdictions/ExplorerPanel')),
	jurisdiction: lazy(()=>import('../jurisdictions/Overview')),

	event: lazy(()=>import('../events/PanelContentSingle')),
	eventsBy: {
		any: lazy(()=>import('../events/PanelAllEvents')),
		tag: lazy(()=>import('../events/tags/PanelContent')),
		theme: lazy(()=>import('../events/themes/PanelContent')),
		jurisdiction: lazy(()=>import('../events/PanelGeoCollection'))
	},
	connections: lazy(()=>import('../connections/PanelContent')),
	twinning: lazy(()=>import('../connections/twinning/PanelContent')),
	business: lazy(()=>import('../connections/business/PanelContent')),
	trade: lazy(()=>import('../connections/tradeAgreements/PanelContent')),
	diplomacy: lazy(()=>import('../connections/diplomacy/PanelContent')),
	investment: lazy(()=>import('../connections/investment/PanelContent'))
}

export default function(){
	return (
		<Routes>
			<Route path="" element={<Panel/>}>
				<Route path="">
					<Route path="" element={<Headlines/>}/>
				</Route>
				{/*
				<Route path="jurisdictions">
					<Route path="" element={<Content.jurisdictions/>}/>
				</Route>
				*/}
				<Route path="map/event">
					<Route path=":event_id" element={<Content.event/>}/>
				</Route>
				<Route path="map/events">
					<Route path="" element={<Content.eventsBy.any/>}/>
					<Route path="tag/:tag_id" element={<Content.eventsBy.tag/>}/>
					<Route path="theme/:theme_id" element={<Content.eventsBy.theme/>}/>
					<Route path="jurisdiction/:geo_id" element={<Content.eventsBy.jurisdiction/>}/>
				</Route>
				<Route path="map/jurisdiction/:geo_id" element={<Content.jurisdiction/>}/>
				<Route path="map/connections"> {/* i.e. /graph/connections/... This is a bit hokey right now because it's not symetrical with the path structure of the map/events for eg */}
					<Route path="jurisdiction/:geo_id" element={<Content.connections/>}/>
					<Route path="trade/jurisdiction/:geo_id" element={<Content.trade/>}/>
					<Route path="twinning/jurisdiction/:geo_id" element={<Content.twinning/>}/>
					<Route path="business/jurisdiction/:geo_id" element={<Content.business/>}/>
					<Route path="diplomacy/jurisdiction/:geo_id" element={<Content.diplomacy/>}/>
					<Route path="investment/jurisdiction/:geo_id" element={<Content.investment/>}/>
				</Route>
				<Route path=""> {/* is this necesaary? i.e. /map/connections/... This is hokey right now because it's not symetrical with the path structure of the map/events for eg */}
					<Route path="jurisdiction/:geo_id" element={<Content.connections/>}/>
					<Route path="trade/jurisdiction/:geo_id" element={<Content.trade/>}/>
					<Route path="twinning/jurisdiction/:geo_id" element={<Content.twinning/>}/>
					<Route path="business/jurisdiction/:geo_id" element={<Content.business/>}/>
					<Route path="diplomacy/jurisdiction/:geo_id" element={<Content.diplomacy/>}/>
					<Route path="investment/jurisdiction/:geo_id" element={<Content.investment/>}/>
				</Route>
			</Route>
		</Routes>
	)
}

function Panel(){
	const location = useLocation()
	const is_single_event = location.pathname.match(/map\/event\/\d+/) // this was being used to transition to a wider panel for single events, but it causes the map to flicker and break the animation
	return (
		<div className={'panel'+ (is_single_event ? ' single-event':'')}>
			<JurHeader/>
			<Suspense fallback={<Spinner contained size={50}/>}>
				<Outlet/>
			</Suspense>
		</div>
	)
}
