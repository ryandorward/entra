import { Suspense, lazy } from 'react';
import { Routes, Route, Outlet } from 'react-router-dom'
import './legend.less'
import { mapTypes } from './mapTypes.js'

const legendContent = {
	graph: {
		'/*': lazy(()=>import('./network/LegendContent')),
		'jurisdiction/*': lazy(()=>import('../jurisdictions/NetworkOverviewLegend'))
	},
	timeline: {
		'event/:event_id': lazy(()=>import('./timeline/LegendContentSingle')),
		// 'events/*': lazy(()=>import('../events/TimelineCollectionLegend'))
	},
	map: {
		'jurisdiction/:geo_id': lazy(()=>import('../connections/density/LegendContent')), // route was: connections/jurisdiction/:geo_id
		// 'event/:event_id': lazy(()=>import('../events/GeoSingleLegend')),
		// 'events/*': lazy(()=>import('../events/GeoCollectionLegend')),
		// 'jurisdiction/:geo_id': lazy(()=>import('../events/ESG/GeoLegend'))
	}
}

export default function({mapType}){
	const contents = legendContent[mapType.slug]
	return (
		<>
		<Routes>
			<Route path="" element={<Legend mapType={mapType}/>}>
				{Object.entries(contents).map( ([path,Component]) => (
					<Route key={path} path={path} element={<Component/>}/>
				) )}
			</Route>
		</Routes>
		</>
	)
}

// function Legend(){
function Legend({mapType}){
	const legendStyle = mapType == mapTypes?.timeline ? 'dark' : 'light'
	return (
		<Suspense>
			<div className={`legend-outer ${legendStyle} open ${mapType.slug}`}>
				<Outlet/>
			</div>
		</Suspense>
	)
}

/*
function LegendOld(){
// function Legend({mapType}){
	const [ collapsed, setCollapsed ] = useState(
		// default: false
		Boolean(JSON.parse(window.localStorage.getItem('legendIsCollapsed')))
	)

	useEffect(()=>{
		window.localStorage.setItem('legendIsCollapsed',collapsed)
	},[collapsed])
	const Icon = collapsed ? BiChevronLeft : BiArrowFromLeft
	const legendStyle = mapType == mapTypes.geographic ? styles.light : styles.dark
	return (
		<div className={`legend ${styles.legend} ${legendStyle} ${collapsed?'collapsed':'open'}`}>
			<div className={collapsed ? styles.legendBox : styles.legendTitle}>
				<h4 onClick={()=>setCollapsed((currentState)=>!currentState)}>
					<Icon size={21} style={{margin:-5, padding:0}}/>&nbsp; Legend
				</h4>
			</div>
			{ collapsed || <Suspense><Outlet/></Suspense> }
		</div>
	)
}
*/
