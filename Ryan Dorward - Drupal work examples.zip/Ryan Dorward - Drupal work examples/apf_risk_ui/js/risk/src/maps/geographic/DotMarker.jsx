import { useRef, useEffect, useMemo } from 'react'
import { useParams } from 'react-router-dom'
import { useReactiveVar } from '@apollo/client'
import { Marker }  from 'react-map-gl'
import { TooltipWrapper } from 'react-tooltip'
import 'react-tooltip/dist/react-tooltip.css'
import { colorFromThemes } from '../../events/ESG/colorFromThemes.js'
import { lighter } from '../../utilities/lighter.js'
import { currentlyHoveredEventId, listenForHoverEvent } from '../../utilities/hover.js'

export default function DotMarker({dot}){
  const hoveredEventId = useReactiveVar(currentlyHoveredEventId)
  const ref = useRef()
  const { event_id } = useParams()
  useEffect(()=>{
		(ref.current && dot.events.length === 1) && listenForHoverEvent(ref.current,dot.events[0].id)
	},[])

  // if there is a hovered event, the colour of this dot for this event will come from the hovered event
  const colour = useMemo(() => {
    const themes = dot.events?.length &&
      dot.events.flatMap((event) => hoveredEventId ? event.id === hoveredEventId && event.themes : event.themes)
    return colorFromThemes(themes)
  },[dot, hoveredEventId])

  const isActive = dot.events.reduce((has, event) => { return (event.id === hoveredEventId || has)}, false ) // if the dot contains any events that match hoveredEventId, then it's hovered
  const dotClass = isActive ? ' active' : hoveredEventId ? ' faded' : ''

  const pulseColour = useMemo(() => {
    let pulseColour
    if (event_id) {
      const primaryThemes = dot.events?.length &&
        dot.events.find(event => event.id === parseInt(event_id))?.themes
      pulseColour = primaryThemes && colorFromThemes(primaryThemes)
    }
    return pulseColour ? pulseColour : '#0000'
  }, [dot])

  const isPrimary = dot.events.reduce((has, event) => { return (event.id === parseInt(event_id) || has)}, false )
  let markerInnerClass = isPrimary ? ' primary' : '' // this is for when the dot contains an event that is the primary event, as in the event we're looking at on a single event page, and not one of it's related events
  let markerInnerStyle = isPrimary ? { borderColor: pulseColour, backgroundColor: lighter(pulseColour)  } : {}
  if (event_id && hoveredEventId && parseInt(event_id) !== hoveredEventId) {
    markerInnerClass += ' faded' // when an event is active, but it's not the event of the current single event page (i.e.: when a dot for a related event gets hovered) it's faded
    markerInnerStyle = {}
  }

  return (dot.jur.geom?.point?.coordinates ? (
    <Marker
      longitude={dot.jur.geom.point.coordinates[0]}
      latitude={dot.jur.geom.point.coordinates[1]}
    >
      <div
        className={'dot-marker-inner' + markerInnerClass}
        style={markerInnerStyle}
      >
        <TooltipWrapper
          tooltipId={`home-map-tip-${dot.jur.geo_id}`}
        >
          <div
            ref={ref}
            className={'dot'+ dotClass}
            style={{
              backgroundColor: colour ? lighter(colour) : 'white',
              borderColor: colour ?? 'grey'
            }}
          />
        </TooltipWrapper>
      </div>
    </Marker>
  ) : null)
}