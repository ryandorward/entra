import { useRef, useEffect} from 'react'
import { Marker }  from 'react-map-gl'
import { wikidata_id_to_mapbox_id} from '../../jurisdictions/castJurs.js'
import { useParams, useNavigate } from 'react-router-dom'
import { currentlyHoveredEventId } from '../../utilities/hover.js'

const handleEntry = () => {
  currentlyHoveredEventId(Number.MAX_SAFE_INTEGER)
}
const handleExit = () => {
  currentlyHoveredEventId(null)
}

export default function NationMarker({nation, setBoundaryHoverState, activeWikidataId, deactiveAll, activeFeature, map, hasEvents}) {
  const coords = nation.geom.point.coordinates
  const id = wikidata_id_to_mapbox_id[nation.wikidata]
  const { geo_id } = useParams()
  const navigate = useNavigate()
  const ref = useRef()

  useEffect(()=>{
    // use max int for id to avoid collisions with DotMarkers/events
    const interactive = geo_id !== nation.geo_id.toString()

    if (interactive) { // add listeners
      ref.current.addEventListener('mouseenter',handleEntry)
      ref.current.addEventListener('mouseleave',handleExit)
    }
    else { // remove listeners, reset hovered state
      currentlyHoveredEventId(null)
      ref.current.removeEventListener('mouseenter',handleEntry)
      ref.current.removeEventListener('mouseleave',handleExit)
    }

	},[geo_id, nation.geo_id])

  // using interactivity to disable clickable nation markers when we're *on* that jurisdiction page
  const interactive = geo_id !== nation.geo_id.toString()

  let className = `jurisdiction-label geo_id-${nation.geo_id} wikidata_id-${nation.wikidata}`
  if (nation.wikidata === activeWikidataId) className += ` active`
  if (hasEvents) className += ' has-events'
  if (interactive) className += ' interactive'

  const attrs = interactive ? {
    onMouseEnter: () => {
      map.maskBoundaryHover = true
      id !== activeFeature && deactiveAll()
      setBoundaryHoverState(id, true)
    },
    onClick: (e) => {
      //  console.log("clicked nation marker", nation)
      navigate(`/map/events/jurisdiction/${nation.geo_id}`)
      e.preventDefault() // prevent the href from being hard-navigated by the browser
    },
    href: `/map/events/jurisdiction/${nation.geo_id}`
  } : {}

  return (
    <Marker
      key={nation.geo_id}
      longitude={coords[0]}
      latitude={coords[1]}
    >
      <a
        ref={ref}
        className={className}
        onMouseLeave={ () => {
          map.maskBoundaryHover = false
          setBoundaryHoverState(id, false)
        }}
        {...attrs}
      >
        {nation.name.en}
      </a>
    </Marker>
  )
}