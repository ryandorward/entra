import { useState, useEffect, useContext } from 'react';
import { geoPath } from 'd3-geo'
import { MapContext } from './Context'
import styles from './styles/focus.module.css'

export default function({
	jurisdiction, focus, centroid, title, children, r, className, ...props
}){
	const { projection } = useContext(MapContext)
	const [ jur, setJur ] = useState(null)
	useEffect(()=>{
		jurisdiction.withGeom(centroid?'point':'boundary').then(setJur)
	},[jurisdiction])
	if( ! jur ) return null;
	let titleText = title ? title : jur.name.en 
	const pathGen = geoPath( projection ).pointRadius( r ? r : 5 )
	var geom = jur.boundary
	if( centroid || pathGen.area(jur.boundary) < 25 /*px*/ ){
		geom =  { type: 'Point', coordinates: jur.latlon }
	}
	let classes = className ?? '';
	if( focus ) classes += ` ${styles.boundary}`
	return (<>
		<path d={pathGen(geom)} {...props} className={classes}>
			<title>{titleText}</title>
			{children}
		</path>
		{focus && <Pulse latLon={jur.latlon} projection={projection}/>}
	</>)
}

function Pulse({latLon,projection}){
	if( ! latLon ) return null;
	let [x,y] = projection(latLon)
	return (
		<circle className={styles.circle} cx={x} cy={y}/>
	)
}
