import { Source, Layer }  from 'react-map-gl'

export  function ExplorerBoundaries({nations}) {
  return (
    <Source
        type='vector'
        url='mapbox://mapbox.country-boundaries-v1'
        id='boundaries'
      >
        <Layer
          id='country-boundaries-fill'
          source-layer='country_boundaries'
          type='fill'
          paint={{
            'fill-color': [
              'case',
              ['boolean', ['feature-state', 'hover'], false],
              'rgba(255, 255, 255,0.33)',
              'rgba(255, 255, 255,0)',
            ],
          }}
          filter={[
            'all',
            [ // filter the boundaries to only show the nations of concern to CAST
              'any',
              ...nations.map(nation => ['==', nation.wikidata, ['get', 'wikidata_id']])
            ],
            [ // filter the boundaries to only show the US/all worldview
              "any",
              ["==", "all", ["get", "worldview"]],
              ["in", "US", ["get", "worldview"]]
            ]
          ]}
        />
      </Source>
  )
}

export function BoundaryHighlight({boundary}) {
  return boundary ? boundary.map((poly, i) => <Source
      key={i}
      id={`boundary-source-${i}`}
      type='geojson'
      data={{
        type: 'Feature',
        geometry: {
          type: 'Polygon',
          coordinates: poly
        }
      }}>
        <Layer id={`boundary-layer-${i}`} type='line' source={`boundary-source-${i}`} paint={{
          'line-color':  '#fff',
          'line-width': 10,
          'line-opacity': 0.3,
        }} />
      </Source>
    ):null
}
