import { useContext } from 'react';
import { geoGraticule, geoPath } from 'd3-geo'
import { MapContext } from './Context'
import { coastlines } from '../coastlines'
import './geo-map.less'

export default function BaseMap(){
	const { projection,  } = useContext(MapContext)
	const pathGen = geoPath().projection( projection )
	return (
		<g id="base-map">
			<path className="land" d={pathGen(coastlines)}/>
			<g id="graticules">
				{geoGraticule().lines().map( (g,i) => {
					return <path key={i} className="graticule" d={pathGen(g)}/>
				})}
			</g>
		</g>
	)
}
