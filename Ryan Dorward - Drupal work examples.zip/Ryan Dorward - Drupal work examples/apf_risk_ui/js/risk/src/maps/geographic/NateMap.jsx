import { createRef, Component } from 'react';
import { geoStereographic } from 'd3-geo'
import { select } from 'd3-selection'
import { zoom, zoomIdentity } from 'd3-zoom'
import { Spinner } from '../../Spinners'
import BaseMap from './Base'
import { fitGeometry } from './fitGeometry'
import './geo-map.less'

import { MapContext } from './Context'

export default class GeoMap extends Component{
	#zoom
	constructor(props){
		super(props)
		this.focus = this.focus.bind(this)
		this.init = this.init.bind(this)
		this.SVGref = createRef()
		this.transformProjection = this.transformProjection.bind(this)
		this.state = {
			shared: {
				projection: geoStereographic(),
				focus: this.focus, // passed control function
				init: this.init // passed control function
			},
			initialized: false // is the map ready to be rendered?
		}
	}
	componentDidMount(){
		this.#zoom = zoom().on('zoom',this.transformProjection)
		select(this.SVGref.current).call(this.#zoom)
	}
	init(boolVal){
		this.setState({initialized: Boolean(boolVal)})
	}
	transformProjection({transform}){
		this.setState(({shared}) => {
			const {x,y,k} = transform
			const projection = shared.projection.translate([x,y]).scale(k)
			return {shared:{...shared,projection}}
		} )
	}
	focus(geometry){ // geoJson structured
		let projection = fitGeometry(
			{
				projection: this.state.shared.projection,
				width: this.props.width,
				height: this.props.height
			},
			geometry
		)
		// update the zoom watcher
		let [x,y] = projection.translate()
		select(this.SVGref.current).call(
			this.#zoom.transform, // this emits a zoom event, which updates state
			zoomIdentity.translate(x,y).scale(projection.scale())
		)
		this.init(true)
	}
	render(){
		return (
			<MapContext.Provider value={this.state.shared}>
				<svg className="map geographic" ref={this.SVGref}
					viewBox={`0 0 ${this.props.width} ${this.props.height}`}>
					{this.state.initialized && <BaseMap/>}
					{this.props.children}
				</svg>
				{!this.state.initialized && <Spinner size={50}/>}
			</MapContext.Provider>
		)
	}
}
