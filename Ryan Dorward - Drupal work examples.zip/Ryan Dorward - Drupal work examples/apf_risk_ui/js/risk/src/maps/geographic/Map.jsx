import { useRef, useEffect, useState } from 'react'
import { useReactiveVar } from '@apollo/client'
import { useParams, useLocation, useNavigate } from 'react-router-dom'
import mapboxgl from '!mapbox-gl'
import 'mapbox-gl/dist/mapbox-gl.css'
import {default as MapGL }  from 'react-map-gl'
import { TooltipProvider } from 'react-tooltip'
import 'react-tooltip/dist/react-tooltip.css'

import graph from '../../jurisdictions/graph'
import { isDeveloper } from '../../getRoles'
import { sharedEvents, sharedEventsLoading } from '../../events/sharedEvents'
import { currentlyHoveredEventId } from '../../utilities/hover.js'

import DotMarker from './DotMarker'
import DotTip from './DotTip'
import NationMarker from './NationMarker'
import { ExplorerBoundaries, BoundaryHighlight} from './Boundaries'

import { cast_jurs } from '../../jurisdictions/castJurs'
import { setJurCoords, getNations, mapSpeed, zoomToDots, frameJur } from './maputils'
import ESG_legend from '../legend/esg-legend.svg'
import '../legend/esg-legend.less'
import Reset_zoom from '../../images/icons/reset-zoom.svg'
import './styles/map.less'

const accessToken = mapboxgl.accessToken = 'pk.eyJ1IjoiYXBmY2FuYWRhIiwiYSI6ImNrY3hpdzcwbzAwZzIydms3NGRtZzY2eXIifQ.E7PbT0YGmjJjLiLmyRWSuw'
const mapStyle = 'mapbox://styles/apfcanada/clefd2nds000l01t4cp1mzqe7'

let alpha_2s = []
for (var key in cast_jurs)
  alpha_2s.push(cast_jurs[key].alpha_2)

const initialZoom = 1.2 + ((window.innerWidth - 660) / (1200 - 660)) * 0.65;
const start = {
  lng: 111.5,
  lat: 18.5,
  zoom: initialZoom,
  pitch: 0,
  bearing: 0
}

export default function MapBoxMap({visible}) {
  const { event_id, geo_id, tag_id, theme_id } = useParams()
  const events = useReactiveVar(sharedEvents)
  const loading = useReactiveVar(sharedEventsLoading)
  const hoveredEventId = useReactiveVar(currentlyHoveredEventId)
  const outerRef = useRef()
  const mapRef = useRef()
  const [viewState, setViewState] = useState({
    // create a random starting point, this causes a nice little zoom animation when the map loads
    longitude: start.lng + (Math.random() * 60 - 30),
    latitude: start.lat + (Math.random() * 20 - 10),
    zoom: start.zoom - Math.random(),
    pitch: 0,
    bearing: 0
  })
  const [boundary, setBoundary] = useState(null)
  const [dots, setDots] = useState([])
  const navigate = useNavigate()
  const location = useLocation()
  const variant = location.pathname == '/jurisdictions' ? 'jurisdiction-explorer' : 'default'

  // hooks for jurisdiction explorer
  const [nations, setNations] = useState([])
  const [activeFeatureId, setActiveFeatureId] = useState() // keep track of active jurisdiction
  const [activeWikidataId, setActiveWikidataId] = useState()

  useEffect(() => {
    // kludge to fix map zooming when the map switches to become visible after being hidden
    visible && setTimeout(() => { zoom()}, 200)
  }, [visible])

  /*
  // update country label visibility depending on whether or not on the Jurisdiction Explorer
  useEffect(() => {
    const map = mapRef.current?.getMap()
    if (map?.getLayer('country-label'))
      map.setPaintProperty('country-label', 'text-opacity', variant === 'jurisdiction-explorer' ? 0 : 1)
  }, [variant, mapRef.current])
  */

  // add dots to the map
  useEffect(() => {
    if (!events?.length) return
    const dots = events?.length && events.flatMap((event) => {
      return event.impacts.map((impact) => {
        return {
          id: impact.id,
          geo_id: impact.geo_id,
          event: event,
        }
      })
    })
    let geo_ids = dots?.map((dot)=>dot.geo_id)
    geo_ids = [...new Set(geo_ids)] // make them unique
    geo_ids && graph.lookup(geo_ids).then((jurs) => {
      // give the dots their lat/long
      dots?.map((dot)=> {
        const jur = jurs.find((jur)=>jur.geo_id === dot.geo_id) // this isn't super efficient, could optimize if it matters
        setJurCoords(jur)
        dot.jur = jur
      })
      const dotMap = new Map()
      dots?.map((dot)=>dotMap.set(dot.geo_id, {
        ...dot,
        events: dotMap.get(dot.geo_id) ? [...dotMap.get(dot.geo_id).events, dot.event] : [dot.event],
      }))
      setDots([...dotMap.values()])
    })
  }, [events])

  // trigger zoom when arriving on a single event, a tag feed, or a theme feed route
  useEffect( () => {
    //console.log('zoom is triggering because of dots change')
    dots?.length && zoom()
  }, [dots])

  // trigger zoom effect when landing on the jurisdiction explorer page
  useEffect( () => {
    variant == 'jurisdiction-explorer' && zoom()
  }, [variant, nations])

  // trigger zoom for a single jurisdiction, set up boundaries
  useEffect( () => {
    if (geo_id) graph.lookup(geo_id).then((jur) => {
      zoom() // important to do this only when there is a geo_id, or we do a weird zoom when going from a jur page to non-jur page
      jur.withGeom('boundary').then((jur) => { // @todo - looking up boundaries for jur zooming too, should DRY this
        if (!jur.geom.polygon) setBoundary(null)
        else if (jur.geom.polygon.type === 'MultiPolygon') setBoundary(jur.geom.polygon.coordinates)
        else if (jur.geom.polygon.type === 'Polygon') setBoundary([jur.geom.polygon.coordinates])
      })
    })
    else setBoundary(null) // if we've moved away from a jur page, clear the boundary
  }, [geo_id])

  // the map needs to be resized when the window is resized
  useEffect( () => {
		function resizer(){
			mapRef.current?.resize()
			// window.dispatchEvent(new Event('resize')) // was hoping this would avoid the blinking but it didn't
		}
		var debounce
		const resizeObserver = new ResizeObserver(() => {
			clearTimeout(debounce)
			debounce = setTimeout(resizer(), 20)
		})
		resizeObserver.observe(outerRef.current)
		return () => resizeObserver.disconnect()
	}, [])

  return (
		<div className='map-outer double-wide' ref={outerRef}>
      { isDeveloper() && <div className='active-event-id'>{hoveredEventId}</div> }
      <TooltipProvider>
        <MapGL
          {...viewState}
          ref={mapRef}
          mapStyle={mapStyle}
          mapboxAccessToken={accessToken}
          projection='globe'
          boxZoom={false}
          doubleClickZoom={false}
          cooperativeGestures={true}
          interactiveLayerIds={variant == 'jurisdiction-explorer' ? ['country-boundaries-fill'] : []}
          onMove={e => setViewState(e.viewState) }
          onLoad={onLoadHandler}
          onClick={clickHandler}
          onMouseMove={(e) => {
            if (!e.features?.length) return // if mouse is not over a country. If we start having more interactive features on the map (i.e.: labels) we'll need to update this to check for those features
            const map = e.target
            map.getCanvas().style.cursor = 'pointer'
            e.features[0].id !== activeFeatureId && deactiveAll() // if mouse has moved from one country to another, need to turn off previous country
            if (!mapRef.current.maskBoundaryHover) {
              setActiveFeatureId(e.features[0].id)
              setActiveWikidataId(e.features[0].properties.wikidata_id)
              setBoundaryHoverState(e.features[0].id, true)
            }
          }}
          onMouseLeave={(e) => {
            const map = e.target
            map.getCanvas().style.cursor = '' // default
            deactiveAll()
          }}
        >
          { nations?.map(nation => {
              const hasEvents = events?.length && events.some((event) => {
                return event.impacts.some((impact) => {
                  return impact.geo_id === nation.geo_id
                })
              })
              return (
                <NationMarker
                  key={nation.geo_id}
                  nation={nation}
                  setBoundaryHoverState={setBoundaryHoverState}
                  activeWikidataId={activeWikidataId}
                  deactiveAll={deactiveAll}
                  activeFeature={activeFeatureId}
                  map={mapRef.current}
                  hasEvents={hasEvents}
                />
              )}
            )
          }
          {variant == 'default' && (
            <>
              <BoundaryHighlight boundary={boundary} />
              {!loading && dots?.map((dot) => <DotMarker dot={dot} key={dot.geo_id}/>)}
            </>
          )}
          {/* variant == 'jurisdiction-explorer' && <ExplorerBoundaries nations={nations} /> */}
          <ExplorerBoundaries nations={nations} />
        </MapGL>
        {/* put tooltips outisde of map container so it isn't cropped by map frame */}
        {variant == 'default' && !loading && dots?.map((dot) => <DotTip dot={dot} key={dot.geo_id}/>)}
        <ZoomButtons map={mapRef.current} zoomState={viewState.zoom} zoomFn={zoom} />
        <MapMeta viewState={viewState} />
        { variant == 'default' && <ESG_legend/>}
      </TooltipProvider>
		</div>
	)

  function onLoadHandler(e) {
    // console.log("map loaded") // keep tabs on when we're actually loading this map, billing is per load
    const map = e.target
    // Filter the country layer to only show labels that are within the set of CAST top level jurs
    const filter = [
      'all',
      map.getLayer('country-label').filter,
      [
        'match',
        ['get','iso_3166_1'], // "Text. The ISO 3166-1 alpha-2 code of the place."
        alpha_2s,
        true,
        false
      ]
    ]
    map.setFilter('country-label',filter)
    map.setLayerZoomRange('settlement-major-label', 3.2, 22)
    map.setLayerZoomRange('settlement-minor-label', 3.2, 22) // many labels that you might think are major settlements are actually in minor
    // variant !== 'jurisdiction-explorer' && map.getLayer('country-label') && map.setPaintProperty('country-label', 'text-opacity', 1) // reveal country-labels now that the filter has been set up

    getNations().then((nations) => {

      // filter place_label's down to 'country'. We may later want to make other labels clickable, but for now we only want to show the country labels
      let uniqueFeatures = {}
      map.querySourceFeatures('composite',{
        sourceLayer:'place_label',
        filter: ['==', 'class', 'country'],
      }).map((feature) => { uniqueFeatures[feature.id] = feature })
      const features = Object.values(uniqueFeatures)

      /*
      console.log("features", features)
      // sort the features alpha by name_en
      features.sort((a,b) => {
        if (a.properties.name_en < b.properties.name_en) return -1
        if (a.properties.name_en > b.properties.name_en) return 1
        return 0
      })
      features.map((feature) => {
        console.log(feature.properties.name_en, feature)
      })
      */

      nations.map((nation) => {
        // search through the features to find the one that matches the nation's .name.en
        // so find a match between nation.name.en and feature.properties.name
        // then set the nation's .geom.point.coordinates to the feature's geometry.coordinates
        const feature = features.find((feature) => feature.properties.name_en == nation.name.en)
        if (feature)
          nation.geom.point.coordinates = feature.geometry.coordinates
        else
          console.warn("using CAST coords for " + nation.name.en + " label")
      })

      setNations(nations)

    })

  }

  function clickHandler(e) {
    /*
    // The following code is for making a label clickable.
    // The layer would need to be added to the interactiveLayerIds property of the MapGL component for this to work.
    // Keep this around for a bit in case we need to make labels clickable.

    // maybe we can check e.features instead of querying the map! Try this if reviving this code
    var features = map.queryRenderedFeatures(e.point, {
      layers: ['settlement-minor-label']
    });
    if (features.length > 0) {
      // a label was clicked
      var label = features[0];
      console.log('Label clicked:', label);
    }
    */
    e.features.forEach((feature) => {
      if (feature.layer.id === 'country-boundaries-fill') {
        // if so, navigate to the nation page. Find the geo_id of the nation
        for (const nation of nations) {
          if (nation.wikidata === feature.properties.wikidata_id) {
            navigate(`/map/events/jurisdiction/${nation.geo_id}`)
            break
          }
        }
      }
    })
  }

  function setBoundaryHoverState(id, state) {
    // boundaries source only exists in the jurisdiction-explorer variant
		mapRef.current.getSource('boundaries') && mapRef.current.setFeatureState(
			{
				source: 'boundaries',
				sourceLayer: 'country_boundaries',
				id: id
			},
			{ hover: state }
		)
	}

	function deactiveAll() {
		if (activeFeatureId) {
			setBoundaryHoverState(activeFeatureId, null)
		}
		setActiveFeatureId(null)
		setActiveWikidataId(null)
	}

  function zoom() {
    const map = mapRef.current
    if (!map) return // can't zoom a map that isn't
    if (geo_id) {
      //console.log('zooming to geo_id', geo_id)
      graph.lookup(geo_id).then( (jur) => frameJur(jur, map))
    }
    else if (event_id || tag_id || theme_id ) {
      //console.log('zooming to event_id, theme_id, or tag_id', event_id, theme_id, tag_id, dots)
      dots && zoomToDots(dots, map)
    }
    else {  // none of: single event page, tag feed, theme feed, jur page, so we're going to fly to the start location
      map.flyTo({
        ...start,
        center: [start.lng, start.lat],
        speed: mapSpeed,
        curve: 1,
      })
    }
  }

}

function ZoomButtons ({zoomState, map, zoomFn}) {
  function zoomFlow(zoom) {
    map.flyTo({
      zoom: zoom,
      speed: mapSpeed,
      curve: 1,
    })
  }
  const zoomNotch = 1
  return (
    <div className='zoomButtons'>
      <button onClick={() => { zoomFlow(parseFloat(zoomState)+zoomNotch) }}>+</button>
      <button onClick={() => { zoomFn() }}>
        <Reset_zoom className='reset-zoom'/>
      </button>
      <button onClick={() => { zoomFlow(parseFloat(zoomState)-zoomNotch) }}>−</button>
    </div>
  )
}

function MapMeta({viewState}) {
  return isDeveloper() ? (
    <div className='map-meta'>
      Longitude: {viewState.longitude.toFixed(2)}
      | Latitude: {viewState.latitude.toFixed(2)}
      | Zoom: {viewState.zoom.toFixed(2)}
    </div>
  ):null
}