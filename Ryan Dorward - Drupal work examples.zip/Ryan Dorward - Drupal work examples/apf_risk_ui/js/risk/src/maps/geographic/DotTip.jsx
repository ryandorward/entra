import { Tooltip } from 'react-tooltip'
import { Link } from 'react-router-dom'
import { jurNameExtendedRaw } from '../../jurisdictions/NameHeader'
import TipHeadline from '../../events/TipHeadline.jsx'

export default function DotTip({dot}) {
  return (dot.jur.geom?.point?.coordinates ? (
    <Tooltip
      variant='dark'
      id={`home-map-tip-${dot.jur.geo_id}`}
      clickable={true}
      className='react-tooltip-general map-tip general-map-tip'
    >
      <div className='map-tip-inner'>
        <Link
          to={`/map/events/jurisdiction/${dot.jur.geo_id}`}
        >
          <h3 title={jurNameExtendedRaw(dot.jur)}>{dot.jur.name.en}</h3>
        </Link>
        { dot.events.length > 1 ?
          <ul>
            { dot.events.map((event) =>
              <li key={event.id}>
                <TipHeadline event={event}/>
              </li>
            )}
          </ul> :
          dot.events.map((event) => <TipHeadline key={event.id} event={event}/> )
        }
      </div>
    </Tooltip>
  ) : null)
}