
// fit a d3-geo projection to a geojson geometry, returning the new projection

import { geoCentroid, geoPath, geoBounds } from 'd3-geo'

export const [ minScale, maxScale ] = [ 300, 20000 ]
export const padding = 50 // px

export function fitGeometry({projection,width,height},geometry){
	let hadRotationSet = projection.rotate().some( v => v != 0 )
	// update the projection to center/focus on the geometry centroid 
	// without translating relative to that point
	let [lon,lat] = geoCentroid(geometry)
	let [x,y] = projection([lon,lat])
	projection.rotate([-lon,-lat]).translate([x,y])
	// if that centroid is off the map, translate to map center
	let pathGen = geoPath().projection(projection)
	if(
		( ! hadRotationSet ) ||
		// reset if center is off-screen
		0 > x || width < x || 0 > y || height < y ||
		// reset if geometry covers only a thousandth of the screen
		( ( ! /point/i.test(geometry.type) ) && 
			pathGen.area(geometry) < (1/1000)*(width*height) )
	){
		let p = padding
		// this complicated check for point geometry allows a point to be passed 
		// as part of a geometry collection without problems
		let isPoint = (new Set(geoBounds(geometry).flat())).size == 2
		if( isPoint ){
			projection.translate([width/2,height/2]).scale(maxScale)
		}else{
			projection.fitExtent([[p,p],[width-p,height-p]],geometry)
		}
		if( projection.scale() > maxScale ){
			// don't zoom in too far for tiny areas
			projection.scale(maxScale)
		}
	}
	return projection
}
