import { useState, useEffect, useContext } from 'react'
import { Link } from 'react-router-dom'
import { rgb, lab } from 'd3-color'
import { assignBoundaries } from '@apfcanada/jurisdictions'
import { MapContext } from './Context'
import Boundary from './Boundary'
import Focus from '../../jurisdictions/Focus'
import aStyles from './styles/ancestor.module.css'
import cStyles from './styles/choropleth.module.css'

// choropleth of a jurisdiction in the context of its peers
export default function Choropleth({jurisdiction,colorFunc,linkFunc}){
	const [ jurs, setJurs ] = useState([])
	const { init } = useContext(MapContext)
	useEffect(()=>{
		let sibs = [...jurisdiction.siblings].sort( (a,b) => {
			return lab(colorFunc(b)).l - lab(colorFunc(a)).l
		} )
		assignBoundaries([...sibs,jurisdiction])
			.then(setJurs)
			.then(()=>init(true))
	},[jurisdiction,colorFunc])
	return (
		<g className="choropleth">
			<Focus jurisdiction={jurisdiction.parent ?? jurisdiction}/>
			{[...jurisdiction.ancestors].reverse().map( ancestor => (
				<Boundary key={ancestor.geo_id} 
					jurisdiction={ancestor} 
					className={aStyles.ancestor}/>
			) ) }
			{jurs.map( jur => (
				<Link key={jur.geo_id} to={linkFunc(jur)}>
					<Boundary jurisdiction={jur} focus={jur==jurisdiction}
						className={cStyles.choropleth} 
						style={style(jur,colorFunc)}/>
				</Link>
			) ) }
		</g>
	)
}

function style(jur,colorFunc){
	let fill = colorFunc(jur)
	let stroke = rgb(fill).darker().formatHex() 
	return { fill, stroke }
}
