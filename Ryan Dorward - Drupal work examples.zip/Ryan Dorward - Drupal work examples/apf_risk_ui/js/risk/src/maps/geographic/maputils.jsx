import mapboxgl from '!mapbox-gl'
import { pseudo_centroids } from '../../jurisdictions/castJurs'
import graph from '../../jurisdictions/graph'

const padding = 80
export const mapSpeed = 1

export function extendBoundsFromPoly(poly, bounds) {
  // poly can be composed of a set of polygons, or a single polygon
  switch (poly?.type) {
    case 'MultiPolygon':
      poly.coordinates.forEach(polygon => {
        polygon.forEach(ring => {
          extendBoundsFromRing(ring, bounds);
        });
      });
      break;
    case 'Polygon':
      poly.coordinates.forEach(ring => {
        extendBoundsFromRing(ring, bounds);
      });
      break;
    default:
      break;
  }
}

function extendBoundsFromRing(ring, bounds) {
  ring.forEach(point => {
    point && bounds.extend(point);
  });
}

 // frame map around the set of dots
export function zoomToDots(dots, map) {
  if (dots.length === 0) return
  const bounds = new mapboxgl.LngLatBounds()

  // quick + dirty filter out anything not in our area of interest.
  // Check if each dot falls inside a rectangle that encloses the part of asia we cover
  const filtered = dots.filter((dot) => {
    const jur = dot.jur
    if (jur?.geom?.point?.coordinates) {
      const coord = jur.geom.point.coordinates
      return (coord[0] < 160 && coord[0] > 50 && coord[1] > -16 && coord[1] < 45)
    }
  })
  dots = filtered.length > 0  ? filtered : dots // if there are no dots withing our area of interest, don't filter

  if (dots.length === 1) {
    dots[0].jur.withGeom('boundary').then((jur) => {
      const poly = jur.geom.polygon
      extendBoundsFromPoly(poly, bounds)
      map.fitBounds(bounds, {
        padding: padding,
      })
    })
  }
  else {
    dots.forEach((dot) => {
      const jur = dot.jur
      jur?.geom?.point?.coordinates && bounds.extend(jur.geom.point.coordinates)
    })
    map.fitBounds(bounds, {
      padding: padding,
    })
  }
}

export function frameJur(jur, map) {
  jur.withGeom('boundary').then((jur) => {
    const bounds = new mapboxgl.LngLatBounds()
    if (jur.geom.polygon) { // some jurs don't have polygon boundary, e.g. cities are just points
      extendBoundsFromPoly(jur.geom.polygon, bounds)
      map.fitBounds(bounds, {
        padding: padding,
        duration: 1500
      })
    }
    else if (jur.parent) { // if there is no polygon, try to zoom to the parent
      frameJur(jur.parent, map)
    }
    else if (jur.geom.point) { // if all there is is a point with no parent, zoom to it at a fixed zoom level. This probably never happens.
      map.flyTo({
        center: jur.geom.point.coordinates,
        zoom: 11,
        speed: mapSpeed,
        curve: 1,
      })
    }
  })
}

// gets jur coordinate overrides and if a jur is missing coordinates, tries to get them from the parent
function getJurCoords(jur) {
  if (!jur?.geom.point?.coordinates) {
    console.warn("no coordinates for", jur.geo_id, jur.name.en) // if this happens, it's probably because jurisdiction data needs to be updated
    if ((jur.parent) && (jur.parent.geo_id !== jur.geo_id)) {
      console.warn("trying to use parent", jur.parent.geo_id, jur.parent.name.en)
      return getJurCoords(jur.parent)
    }
    else {
      console.warn("no parent for", jur.geo_id, jur.name.en)
      return null
    }
  }
  return pseudo_centroids[jur.geo_id] || jur.geom.point.coordinates // re-map some centroids - there are some weird natural centroids like vietnam
}

// sets a jurs coordinates to the override or the parent's coordinates
export function setJurCoords(jur) {
  if (! jur.geom.point) jur.geom.point = {}
  jur.geom.point.coordinates = getJurCoords(jur)
}

// get national level jurisdictions, formatted as mapbox features
export async function getNations(){
	const jursExclude = [ // this is repeated in jur picker, could centralize
		6, // Australia
		8, // new zealand
		35 // Mongolia
	]
	return graph.countries().then((jurs) => {
		jurs = jurs
			.filter(jur => !jursExclude.includes(jur.geo_id))
			.sort((a,b)=>a.name.en.localeCompare(b.name.en))
		return jurs
	})
}