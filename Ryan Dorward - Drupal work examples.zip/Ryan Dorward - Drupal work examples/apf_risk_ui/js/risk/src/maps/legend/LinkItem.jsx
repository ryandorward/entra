import LegendItem from './Item'

const width = 20

export default function({label,className,...styleOptions}){
	return (
		<LegendItem label={label}>
			<svg width={width} height="10" className="icon">
				<path d={`M0,5L${width},5`}
					style={styleOptions}
					className={className ? className : 'link' }/>
			</svg>
		</LegendItem>
	)
}
