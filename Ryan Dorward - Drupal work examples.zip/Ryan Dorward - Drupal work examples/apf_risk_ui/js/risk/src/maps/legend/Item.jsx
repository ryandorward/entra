import '../legend.less'

export default function({children,label}){
	return (
		<div className='item'>
			{children}
			<span className='label'>{label}</span>
		</div>
	)
}
