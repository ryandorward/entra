import LegendItem from './Item'

export default function({label,radius,className,...etc}){
	const styleOptions = {
		strokeWidth: 1,
		...etc
	} 
	const totalRadius = radius + styleOptions.strokeWidth / 2
	return (
		<LegendItem label={label}>
			<svg width={2*totalRadius} height={2*totalRadius}>
				<circle className={className}
					cx={totalRadius}
					cy={totalRadius} 
					r={radius}
					style={styleOptions}/>
			</svg>
		</LegendItem>
	)
}
