// grouping element to provide a heading to a set of legend items

export default function({title,children}) {
	return (
		<div className="group">
			<h4>{title}</h4>
			{children}
		</div>
	)
}
