import LegendItem from './Item'

export default function({label,className,...etc}){
	return (
		<LegendItem label={label}>
			<svg className="icon" width={36} height={26}>
				<path d="M3 3 l30 0 l0 20 l-30 0 Z"
					style={etc} className={className}/>
			</svg>
		</LegendItem>
	)
}
