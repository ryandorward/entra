import { color as d3color } from 'd3-color'
import './color-range.less'

const [ width, height ] = [ 150, 20 ]
const fillOpacity = 0.6
const strokeWidth = 1.5
const rx = 3

export default function({colors,lowerLabel,upperLabel}){
	const swatchWidth = width/colors.length
	return (
		<div className="color-range">
			<svg width={width} height={height}>
				{colors.map( (color,i) => {
					let fill = color
					let stroke = d3color(color).darker().formatHex()
					return (
						<rect key={color}
							style={{fill,stroke,fillOpacity,strokeWidth,rx}}
							height={height-strokeWidth} y={strokeWidth/2}
							width={swatchWidth} x={i*swatchWidth}/>
					)
				} )}
			</svg>
			<div className="labels" style={{width: width}}>
				<span>{lowerLabel}</span><span>{upperLabel}</span>
			</div>
		</div>
	)
}
