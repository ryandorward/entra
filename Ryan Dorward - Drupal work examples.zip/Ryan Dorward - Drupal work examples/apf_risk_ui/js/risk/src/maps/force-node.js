import styles from './node.module.less'

export class ForceNode{
	#x = undefined; // position
	#y = undefined; 
	#fx = undefined; // fixed position (e.g. during drag)
	#fy = undefined;
	#vx = 0; // velocity
	#vy = 0;
	#radius = 6;
	#focused = false;
	
	set x(val){ this.#x = val }
	get x(){ return this.#x }
	set y(val){ this.#y = val }
	get y(){ return this.#y }

	set fx(val){ this.#fx = val }
	get fx(){ return this.#fx }
	set fy(val){ this.#fy = val }
	get fy(){ return this.#fy }

	set vx(val){ this.#vx = val }
	get vx(){ return this.#vx }
	set vy(val){ this.#vy = val }
	get vy(){ return this.#vy }

	get radius(){ return this.#radius }
	set radius(val){ this.#radius = Number(val) }

	get focused(){ return this.#focused }
	set focused(val){ this.#focused = Boolean(val) }
	
	get classes(){ 
		return this.fx || this.fy ? [styles.fixed] : [styles.node] 
	}
}
