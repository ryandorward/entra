import styles from './construction-tape.module.css'

export default function({message,children}){
	return (
		<div className={styles.container}>
			<div className={styles.title}>This section is under construction</div>
			{message || children && 
				<div className={styles.message}>
					{message} {children}
				</div>
			}
		</div>	
	)
}
