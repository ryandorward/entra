import { useState, useRef, useEffect } from 'react'
import { lighter } from '../utilities/lighter.js'
import './flex-list.less'
import LinkWrapper from '../LinkWrapper'
import { useReactiveVar } from '@apollo/client'
import { listenForHover } from '../utilities/hover.js'

export default function({list, limit, ...params}){
	const [ expanded, setExpanded ] = useState(false)
	const displayList = limit && ! expanded ? list.slice(0,limit) : list
	return (
		<div className="flexList">
			{displayList.map( (item, i) => {
				return <FlexListItem key={i} {...{item, ...params}} />
			} )} {!expanded && displayList.length != list.length &&
				<a onClick={()=>setExpanded(true)} className="ellipsis">...</a>
			}
		</div>
	)
}

function FlexListItem ({item, nameFunc, linkFunc, colorFunc, classFunc, hoverVar}) {

	let hoveredId
	const ref = useRef()

	// wrapping this hook in a conditional seems like it shouldn't work
	// but it does, because per context, this conditional is constant
	if( hoverVar ){
		useEffect(()=>{
			listenForHover(ref.current,item.id,hoverVar)
		},[])
		hoveredId = useReactiveVar(hoverVar)
	}

	let css, classes, colour, backgroundColor
	classFunc && (classes = classFunc(item))
	if(colorFunc){
		colour = colorFunc(item)
		if(colour){
			classes = classes ? `${classes} colored` : `colored`
			backgroundColor = lighter(colour)
			css = { backgroundColor }
		}
	}
	if (hoveredId && hoveredId == item.id)
		classes = classes ? `${classes} focused` : `focused`

	var text = <span>{nameFunc(item)}</span>

	return linkFunc ? (
		<LinkWrapper path={linkFunc(item)} style={css} className={classes} innerRef={ref}>
			{text}
		</LinkWrapper>
	) : (
		<div style={css} className={classes} ref={ref}>
			{text}
		</div>
	)
}