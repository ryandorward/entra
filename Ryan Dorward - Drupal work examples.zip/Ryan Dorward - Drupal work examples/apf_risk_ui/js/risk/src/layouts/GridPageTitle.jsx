import Title  from '../components/Title'

export default function({children, metaTitle}){
	return (
		<div className="titlebar">
			<Title metaTitle={metaTitle}>
				{children}
			</Title>
		</div>
	)
}

/*
import { useEffect } from 'react'
import { Helmet } from 'react-helmet'
import { title } from '../utilities/title.js'

export default function ({children, metaTitle, useMetaSuffix=true, inputRef}) {

  useEffect(() => {
    console.log("setting title",metaTitle)
    title(metaTitle || children)
  }, [metaTitle, children ])

  return (
    <>
      {
        (metaTitle || children) ?
          <Helmet>
            <title>
              { metaTitle || children }{(useMetaSuffix ? ` | CAST`:'') }
            </title>
          </Helmet>
        : null
      }
      {children ? <h1 ref={inputRef}>{children}</h1> : null }
    </>
  )
}

*/