import { useEffect } from 'react'
import { Outlet } from 'react-router-dom'
import { scrollToAnchor } from '../utilities/scroll.js'
import  './prose-page.less'

export default function(){
	useEffect(() => {
		scrollToAnchor()
	},[window.location.hash])

	return <div className="prose-page-container"><Outlet/></div>
}