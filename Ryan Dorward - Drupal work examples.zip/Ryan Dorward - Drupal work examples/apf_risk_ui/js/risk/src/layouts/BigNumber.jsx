import { Link } from 'react-router-dom'
import { format } from 'd3-format'
import styles from './big-number.module.css'

export default function BigNumber({number,linkPath,labelSingle,labelPlural}){
	if( ! number ) return null;
	const contents = ( <>
		<div className={styles.number}>
			{number >= 10000 ? formatBigNumber(number) : format(',')(number)}
		</div>
		<div className={styles.label}>{number == 1 ? labelSingle : labelPlural}</div>
	</> )
	return linkPath ? 
		<Link to={linkPath} className={styles.container}>{contents}</Link>:
		<div className={styles.container}>{contents}</div>
}

function formatBigNumber(number){
	return format('.3s')(number).replace(/G$/,'B')
}
