import { Outlet } from 'react-router-dom'
import './grid-page.less'

export default function({children}){
	return <div className="grid-page"><Outlet/>{children}</div>
}
