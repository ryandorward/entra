// determine a color for text on a given background color

// @todo: probably not using this anywhere anymore, but the idea is nice. DELETE?
import { lab } from 'd3-color';
import styles from './contrast-text.module.less'

export default function ContrastText({againstColor,children}){
	if(!againstColor) return children;
	const color = lab(againstColor)
	const className = color.l > 65 ?
		styles.lightBackground : styles.darkBackground;
	return <span className={className}>{children}</span>
}
