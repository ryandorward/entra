import { useState, Suspense, useEffect } from 'react';
import { Spinner } from '../Spinners'
import { Link, Outlet } from 'react-router-dom'
// import { useReactiveVar } from '@apollo/client'
import BiArrowToRight from '../images/icons/BiArrowToRight.svg'
import Logo from '../images/CAST-logo.svg'
import ApfLogo from '../images/APF-logo-mark-v1.svg'
import './app-menu-layout.less'
import '../styles/main.less'
// import { MdOutlineSpaceDashboard } from 'react-icons/md'
import { BsGlobe } from 'react-icons/bs'
import { CgFileDocument } from 'react-icons/cg'

// import { titleVar } from '../components/Title'

export default function(){

	// const title = useReactiveVar(titleVar)

	return (
		<>
		{/* <div className="title-thing">titleVal: {title}</div> */}
		<div className="menu-context-container">
			<div className='main-menu-placeholder'></div>
			<Suspense fallback={<Spinner/>}>
				<div className="content-adjacent-to-menu">
					<Outlet/>
				</div>
			</Suspense>
			<Menu/>
		</div>
		</>
	)
}
const storage = window.localStorage

// defaults to closed, but stores state in localStorage
function Menu(){
	// var dynamicHeight = (useWindowDimensions().height -50) +'px'
	const [ collapsed, setCollapsed ] = useState( true
		// Boolean(JSON.parse(storage.getItem('menuIsCollapsed')=== null ? true:storage.getItem('menuIsCollapsed') )) // default: true
	)

	useEffect(()=>{
		storage.setItem('menuIsCollapsed',collapsed)
	},[collapsed])
	return (
		<div className={`main-menu ${collapsed?'collapsed':'open'}`}
			onClick={()=>setCollapsed(bool=>!bool)}>
			<div className="sticky-content">
				<Link to="/" onClick={e=>e.stopPropagation()} className="logo-block">
					<Logo className="logo cast" />
					<div className="text">
						<div className="en">
							<strong>CAST</strong><br/>
							Canada-Asia <br/>Sustainability <br/>Tracker
						</div>
						<div className="fr">
							<strong>CASD</strong><br/>
							Suivi de la <br/>durabilité <br/>Canada-Asie
						</div>
					</div>
				</Link>
				<div className="menu">
					{/*
					<MenuItem label="Dashboard" linkTo="/" Icon={MdOutlineSpaceDashboard} onClick={setCollapsed}/>
					<MenuItem label="Jurisdictions" linkTo="/jurisdictions" Icon={BsGlobe} onClick={setCollapsed}/>
					*/}
					<MenuItem label="Dashboard" linkTo="/" Icon={BsGlobe} onClick={setCollapsed}/>
					<MenuItem label="Publications" linkTo="/insights" Icon={CgFileDocument} onClick={setCollapsed}/>

					{/* turn off tour for now
					<Suspense fallback={null}>
						<TakeATourSometimesMaybe/>
					</Suspense>
					*/}
				</div>

				<div className="menu menu-bottom">
					<MenuItem label="About" linkTo="/about/"/>
					<MenuItem label="Methodology" linkTo="/about/methodology"/>
					<MenuItem label="Contact Us" linkTo="/contact" target="_blank" />
					<MenuItem label="Terms of Use" linkTo="/about/cast-terms-of-use" />
					<MenuItem label="Privacy" linkTo="/about/cast-terms-of-use#3" />
					<a href="https://www.asiapacific.ca/"
						className="logo-block apf"
						onClick={e=>e.stopPropagation()}
					>
						<ApfLogo className="logo" />
						<div className="text">
							<div className="left site-name" rel="home">
								Asia Pacific<br/>Foundation<br/>of Canada!
							</div>
							<div className="right">
								Fondation<br/>Asie Pacifique<br/>du Canada
							</div>
						</div>
					</a>
				</div>

				<div
					className="menu-collapse-icon"
				>
					<BiArrowToRight
						size="25px"
						color="white"
						title={collapsed ?"open menu" : "collapse menu"}
					/>
				</div>
			</div>

		</div>
	)
}


export function MenuItem({Icon,label,linkTo,onClick,className}){
	const contents = (<>
		{Icon && (<Icon className="icon" size='25px' title={label}/>)}
		<span className="label"> {label}</span>
	</>)
	const clickFunc = e => {
		e.stopPropagation()
		if(onClick) onClick(e)
	}

	const extUrlPattern = /^((http|https|ftp):\/\/)/

	return (
		<div className={'item '+(className??'')}>
			{ linkTo ? (
				extUrlPattern.test(linkTo) ? (
					<a href={linkTo} className={'item '+(className??'')} onClick={clickFunc} target="_blank" rel="noreferrer">
						{contents}
					</a>
				) : (
					<Link to={linkTo} onClick={clickFunc}>
						{contents}
					</Link>
				)
			) : (
				<a  onClick={clickFunc}>
					{contents}
				</a>
			)}
		</div>
	)

}