import './headerbox.less'

export default function({title,children}){
	return (
		<div className="header-box">
			{title && <title>{title}</title>}
			{children}
		</div>
	)
}
