import { Outlet } from 'react-router-dom'
import styles from './visPage.module.css'

export default function(){
	return <div className={styles.container}><Outlet/></div>
}
