import { useContext, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { ShepherdTour, ShepherdTourContext } from 'react-shepherd'
import { FaQuestionCircle as Help } from 'react-icons/fa'
import { MenuItem } from '../layouts/AppMenuLayout'
import "./shepherd.css";
import "./tour.css";

import eventSteps from './steps/event'

const tourOptions = {
	defaultStepOptions: { cancelIcon: { enabled: true } },
	useModalOverlay: true
}

const tours = {
	event: { name: 'event', steps: eventSteps }
}

// sits in the main menu and renders an icon for available tours
export default function TourMenuElement(){
	return (
		<Routes>
			<Route path="/map/event/*" element={<Tour tour={tours.event}/>}/>
			<Route path="/map/event/*" element={<Tour tour={tours.event}/>}/>
			<Route path="/*" element={null}/>
		</Routes>
	)
}

function Tour({tour}) {
	const storageVar = `${tour.name}-tour-complete`
	const tourIsComplete = localStorage.getItem(storageVar) // stored when complete
	return (
		<ShepherdTour
			steps={tour.steps(tourIsComplete?undefined:storageVar)}
			tourOptions={tourOptions}>
			{!tourIsComplete && <TourAuto/>}
			<TourButton/>
		</ShepherdTour>
	)
}

function TourButton() {
	const tour = useContext(ShepherdTourContext)
	return (
		<MenuItem Icon={Help} label="Start Tour"
			onClick={()=>tour.start()} className="tour-button"/>
	)
}

// Automatically triggered tour, for first visit to an Event page
function TourAuto() {
	const tour = useContext(ShepherdTourContext)
	useEffect(() => {
		tour.start()
	},[])
}
