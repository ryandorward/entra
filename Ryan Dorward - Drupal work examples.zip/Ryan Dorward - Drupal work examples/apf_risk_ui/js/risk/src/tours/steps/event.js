import { mapTypeRE } from '../../maps/MapLink'

function getMapType() {
	const currentPath = window.location.pathname
	if(mapTypeRE.test(currentPath)){
		return mapTypeRE.exec(currentPath).groups.type
	}
}

const nextButton = {
	classes: "shepherd-button-primary",
	text: "Next",
	type: "next"
}
const exitButton = {
	classes: "shepherd-button-secondary",
	text: "Exit",
	type: "cancel"
}
const backButton = {
	classes: "btn btn-info",
	text: "Back",
	type: "back"
}
const acceptButton = {
	classes: "shepherd-button-primary",
	text: "Got it",
	type: "cancel"
}

const helpButtonMessage = "You can click the help button at any time if you'd like to take the tour again"

function markTourFinished(storageName){
	localStorage.setItem(storageName,true)
}

export default function eventTourSteps(storageName){
	const defaultStep = {
		beforeShowPromise: ()=>{ // give a tiny pause between steps
			return new Promise((resolve)=>{
				setTimeout(()=>{window.scrollTo(0,0);resolve()},150)
			})
		},
		buttons: [ exitButton, backButton, nextButton ],
		highlightClass: "highlight",
		showCancelLink: true,
		cancelIcon: { enabled: true },
		scrollTo: true,
		canClickTarget: false
	}
	var introButtons = [ exitButton, nextButton ]
	if (storageName) { // flags that this tour was automatically initiated
		const dontShowButton = {
			classes: "shepherd-button-secondary",
			text: "Don't show me this again",
			action: function(){ // don't use arrow function here
				markTourFinished(storageName)
				return this.show('finish-auto')
			}
		}
		introButtons = [ dontShowButton, ...introButtons ]
	}
	const steps = [
		{
			id: "intro",
			buttons: introButtons,
			title: 'Welcome',
			text: "This tour will guide you through some of the features of an event in CAST.",
			beforeShowPromise: null,
		},{
			id: "left-panel",
			attachTo: {element:'.map-panel',on:'left'},
			title: 'Side Panel',
			text: "The side panel gives a written description of the event. You can scroll down to see more details, including the themes, tags, jurisdictions impacted, and related events.",
			canClickTarget: true
		},{
			id: "right-panel",
			attachTo: {element:'.map-container',on:'right'},
			title: () => getMapType() === 'timeline' ? 'Timeline' : 'Map',
			text: () => {
				return getMapType() === 'timeline' ?
					"The display on the right visualises the event on a timeline, with links to any related events. You can click on related events to see more about them."
					: "The map on the right shows the location of the event's impacts."
			}
		},{
			id: "map-switcher",
			attachTo: { element: ()=>`.map-link-${getMapType()=='timeline'?'map':'timeline'}`,on: "bottom-end"},
			title: 'Switch Views',
			text: () => {
				let type = getMapType()
				return `You can switch to a ${type=='timeline'?'geographic map':'timeline'} view by clicking on the ${type=='timeline'?'globe':'clock'} icon. Try clicking it now!`
			},
			canClickTarget: true,
			modalOverlayOpeningPadding: 4,
			modalOverlayOpeningRadius: 7
		},{
			id: "finish",
			attachTo: {element:".tour-button.item",on:"right-start"},
			title: 'All Done',
			text: `You've finished the tour! We hope this was a useful intro to CAST events. ${helpButtonMessage}`,
			buttons: [
				backButton,
				{
					classes: "shepherd-button-primary",
					text: "Finish",
					action: function() { // don't use arrow function here
						markTourFinished(storageName)
						return this.cancel()
					}
				},
			],
			modalOverlayOpeningPadding: 4,
		},{
			id: "finish-auto",
			attachTo: {element:'.tour-button.item',on:'right'},
			text: `OK! ${helpButtonMessage}`,
			buttons: [ acceptButton ]
		}
	]
	return steps.map(step => {return {...defaultStep,...step}})
}
