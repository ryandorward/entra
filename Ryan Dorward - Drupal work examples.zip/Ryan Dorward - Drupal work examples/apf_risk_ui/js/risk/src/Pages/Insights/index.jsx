import { useState } from 'react'
import { drupalVars } from '../../API.js'
import { ApfPublicationCard } from '../../publications/ApfPublicationCard'
import './insights.less'
import Title from '../../components/Title'

const regions = [
  { id: 'greater-china', label: 'Greater China' },
  { id: 'northeast-asia', label: 'Northeast Asia' },
  { id: 'south-asia', label: 'South Asia' },
  { id: 'southeast-asia', label: 'Southeast Asia' },
]

export default function Insights() {
  const [activeRegions, setActiveRegions] = useState([])
  let insights = drupalVars?.insights
  /*
  insights = insights?.filter( (insight) => {
    if (activeRegions.length === 0) return true
    return activeRegions.includes(insight.region)
  })
  */

  return insights && (
    <div className="insights">
      <Title>Insights</Title>
      <div className="filters">
        <h3>Filter by Region:</h3>
        { regions.map( (region) => {
          return (
            <button
              key={region.id}
              className={
                'region-filter'
                + (activeRegions.includes(region.id) ? ' active' : '')
              }
              onClick={() => {
                if (activeRegions.includes(region.id)) {
                  setActiveRegions(activeRegions.filter( (activeRegion) => activeRegion !== region.id))
                } else {
                  setActiveRegions([...activeRegions, region.id])
                }
              }}
            >
              {region.label}
            </button>
          )
        })}
      </div>
      <div className="list">
      {/* insights?.map( (insight) => <Insight key={insight.id} {...insight} /> ) */}
      { insights?.map( (insight) => <ApfPublicationCard
        key={insight.id}
        node={insight}
        className={
          ((activeRegions.length === 0) || activeRegions.includes(insight.region)) ? '' : 'hidden'
        }/> )
      }
      </div>
    </div>
  )
}