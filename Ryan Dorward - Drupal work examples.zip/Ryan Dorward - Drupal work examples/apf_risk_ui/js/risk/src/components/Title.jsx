import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { Helmet } from 'react-helmet'

import { makeVar } from '@apollo/client'

export const titleVar = makeVar(null)

export default function ({children, metaTitle, useMetaSuffix=true, inputRef}) {

  const { pathname } = useLocation()
  const headTitle = metaTitle || children

  useEffect(() => {
    titleVar(headTitle)
  }, [headTitle, pathname])

  return (
    <>
      {
        (headTitle) ?
          <Helmet>
            <title>
              { headTitle }{(useMetaSuffix ? ` | CAST`:'') }
            </title>
          </Helmet>
        : null
      }
      {children ? <h1 ref={inputRef}>{children}</h1> : null }
    </>
  )
}