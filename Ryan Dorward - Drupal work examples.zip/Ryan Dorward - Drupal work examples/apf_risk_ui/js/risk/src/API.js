export const site = 'https://cast.asiapacific.ca'
export const ApfSite = 'https://www.asiapacific.ca'
const localSite = 'http://asiapacific.local'

const pgapi = `${site}/pgapi/public`

export const topoGeometry =    `${pgapi}/jurisdictionGeometryTopo.php`
export const succinctSearch =  `${pgapi}/succinctSearch.php`
export const advisories =      `${pgapi}/getTravelAdvisories.php`

const useDevEndpoint = false && (process.env.NODE_ENV && process.env.NODE_ENV == 'development')

export const gqlEndpoint = useDevEndpoint ? `${localSite}/gql/risk` : `${site}/gql/cast/public`

export const userToken = `${site}/user/login`

export const drupalVars = window.drupalSettings?.apfRiskUi

// console.log("process.env.NODE_ENV? ", process.env.NODE_ENV)