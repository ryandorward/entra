Iconset: International Circle Flags (https://www.iconfinder.com/iconsets/international-circle-flags)
Author: amoghdesign (https://www.iconfinder.com/amoghdesign)
License: Basic license (https://support.iconfinder.com/en/articles/18231-license-basic)
Download date: 2021-11-16