import { lazy, Suspense, useEffect } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import ReactGA from 'react-ga4'
import { Spinner } from '../Spinners'
import { TooltipProvider } from 'react-tooltip'

const cast_ga_id = "G-CPGRVDRC70" // CAST measurement ID

const ApolloProvider = lazy(()=>import('../ApolloProvider'))
const MainAppRouter = lazy(()=>import('../Routes'))

const container = document.querySelector('#root')
const root = createRoot(container)
root.render(<App/>)

function App(){

	useEffect(() => {
		ReactGA.initialize(cast_ga_id,{
			debug: true,
			// titleCase: false,
		})
	}, [])

  return (
		<BrowserRouter>
			<ApolloProvider>
				<Suspense fallback={<Spinner/>}>
					<TooltipProvider>
						<MainAppRouter/>
					</TooltipProvider>
				</Suspense>
			</ApolloProvider>
		</BrowserRouter>
  )
}