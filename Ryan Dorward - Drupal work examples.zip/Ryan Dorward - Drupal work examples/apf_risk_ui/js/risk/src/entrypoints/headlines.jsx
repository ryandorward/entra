//import { lazy } from 'react'
import { createRoot } from 'react-dom/client'
import ApolloProvider from '../ApolloProvider'
import Headlines from '../events/Headlines'

// const ApolloProvider = lazy(()=>import('../ApolloProvider'))
// const Headlines = lazy(()=>import('../events/Headlines'))

const container = document.querySelector('#CAST-headlines')
const root = createRoot(container)
root.render(<HeadlinesComponent/>)

function HeadlinesComponent(){
	return (
		<ApolloProvider>
			<div><Headlines top={10} sort="date"/></div>
		</ApolloProvider>
	)
}
