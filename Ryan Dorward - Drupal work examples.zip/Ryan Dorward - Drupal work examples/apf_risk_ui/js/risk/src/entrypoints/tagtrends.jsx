import { lazy } from 'react'
import { createRoot } from 'react-dom/client'
import ApolloProvider from '../ApolloProvider'

const TagTrendsSolo = lazy(()=>import('../TagTrends/TagTrendsSolo'))
// const ApolloProvider = lazy(()=>import('../ApolloProvider'))

const container = document.querySelector('#CAST-tagtrends')
const root = createRoot(container)
root.render(<TagTrendsComponent/>)

function TagTrendsComponent(){
	return (
		<ApolloProvider>
			<TagTrendsSolo/>
		</ApolloProvider>
	)
}