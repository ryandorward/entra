import { useEffect } from 'react';
import { Link } from 'react-router-dom'
import SearchEvents from '../SearchBar'
import ShowOnlyTo from '../../ShowOnlyTo'

import DateDocs from './fields/Date'
import EventTypeDocs from './fields/EventType'
import ActorsDocs from './fields/Actors'
import TagsDocs from '../tags/doc'
import SourcesDocs from '../sources/doc'
import LinksDocs from './fields/Links'
import ImpactsDocs from './fields/Impacts'
import ThemesDocs from '../themes/doc'

import { scrollToAnchor } from '../../utilities/scroll'

export default function(){
	useEffect(()=>scrollToAnchor(),[]);
	return (
		<>
			<h1>Event Tracking</h1>
			
			<p>As part of their daily work at the Foundation our staff reads a wide range of reporting on Asian and Canadian current events. Some of this may be national-level mainstream media, though many also focus quite deeply on their own regional or topical specialty. Since many of our staff are fluent in Asian languages they are able, by following local news sources and paying particular attention to stories unfolding at the sub-national level, to see a much more nuanced and up-to-date state of affairs in Asia than is typically covered in the Anglophone media available to most Canadians.</p>
			
			<ShowOnlyTo minRole="jrAnalyst">
				<Link to="finding-sources">Where should you start reading?</Link>
			</ShowOnlyTo>
			
			<p>This is a big part of the reason we’re able to offer nuanced and in-depth analysis in our various reports, dispatches, and other publications. What CAST does in this context is help to serve as a bridge between regions, languages, and specialties within our staff. When we find events that we think are worth following, they enter the CAST reporting workflow and are documented in a variety of ways which will be explained in more detail below.</p>
			
			<h2>What is an <i>event</i>?</h2>
			<p>An event is something that happens at a more or less discrete moment in time, which our analysts believe may have an impact on the status quo within one or more Asian <Link to="../../jurisdictions">jurisdictions</Link>. In particular, we define impact along the lines laid out in our <Link to="./ESG">Environmental, Social, & Governance (ESG) framework</Link>.</p>
			<p>An event on CAST has the following characteristics:</p>
			<ul>
				<li>An event can be an action or a measure taken by an individual, a government, or an organization; an announcement or a policy issued by a government, a company, or an organization; a natural disaster; or a planned public or private occasion;</li>
				<li>An event occurs at or impacts a particular place in the Asia Pacific at a specific point in time, rather than representing a general trend;</li>
				<li>It potentially leads to or signals a disruption (change) of the operating environment in one or more Asian <Link to="../../jurisdictions">jurisdictions</Link>, or has a high probability of doing so;</li>
				<li>It has implications for the subnational level and is related to our <Link to="./ESG">Environmental, Social, & Governance (ESG) framework</Link>.</li>
			</ul>
			
			<p>To understand what we consider to be an event, it may be easiest to just have a look through our database of past events.</p>
			<SearchEvents placeholder="Search events by keyword"/>
			
			<p>While the positive definition of an “event” can be fairly broad, there are a few things an event is <i>not</i>. There is a great deal of daily reporting on things that are expected to happen every once in a while in any society without really changing the status quo. We try not to report on fluctuations, but rather on actual (or potential) changes in the status quo. The stock market goes up or down a bit, a celebrity dies, it is very rainy: these are not events we would track. The concrete changes we want to track would be <i>“power outages have swept the province”</i>, or a statistic report on changes that have quietly been building for some time, e.g. <i>“a new census reports birth rates are at record low”</i>.</p>
			
			<p>An event also should not be too big or broad. A war for example would never be an event. An update on China’s push to reduce emissions is not an event; but a new policy targeting coal plants might be. The guiding idea here is that an event should be something that takes place at a discrete time and is more or less complete and encapsulated at the time we record it. We don’t want to be going back and updating events all the time with new information. Instead, a long <i>process</i> such as a pandemic may be represented as a series of events, which we can then group together.</p>
			
			<h2>So what do we actually track?</h2>
			
			<p>For each event we provide a write-up of what happened, why it matters to a Canadian audience, and some additional information on the context. Events are then categorized, connected, and organized on a timeline allowing you to explore any patterns and relations among them.</p>

			<ShowOnlyTo minRole="jrAnalyst">
				<h3 id="title">Title</h3>
				<ul>
					<li>Event titles should be in news-writing style, concise, and kept within 88 characters (i.e. no more than 4 lines on the front-end)</li>
					<li>Titles should be kept to the point and covers the “what”, “where” and “who”</li>
					<li>When coming up the title, be sure to verify the proper nouns so that they are consistent with what’s commonly used in English language reporting/mentioning of the same event or context</li>
					<li>Only capitalize the first letter of the first word, and letters/words that would normally be capitalized in a sentence</li>
				</ul>
			</ShowOnlyTo>
			
			<ShowOnlyTo minRole="jrAnalyst">
				<h3 id="description">Description (“What’s New?”)</h3>
				<p>Write a short summary based on key information provided in the original news source, in particular the news lead and/or the first paragraph where the basic what/who/where/when information can usually be found. Aim to do it within one sentence and avoid jargon and unecessary complexity. There is no need for a detailed enumeration of the <i>where</i> and <i>when</i> if these are covered in the <i>impacted jurisdictions</i> and <i>date</i> fields.</p>
				<p>When in doubt about spelling or format, refer to the Canadian Press style guide.</p>
			</ShowOnlyTo>
			
			<ShowOnlyTo minRole="jrAnalyst">
				<h3 id="analysis">Analysis (“Why does it matter?”)</h3>
				<p>Write a 1 to 2-sentence analysis on the why/how parts of the story – what kind of anticipated implications does this event have? Focus on why it matters to operations on the ground.</p>
			</ShowOnlyTo>
			
			<ShowOnlyTo minRole="jrAnalyst">
			<h3 id="readmore">Additional Information (“Read more”)</h3>
			<p>This is an expandable space for any additional information about the event’s context and background stories that we want to include to aid readers’ understanding. Press “enter” to divide your sentences into bullet points, usually no more than 5.</p>
			</ShowOnlyTo>
				
			<SourcesDocs/>
			
			<DateDocs/>

			<h3 id="involvement">Canadian involvement</h3>
			<p>We see an event as having “Canadian involvement” when there is identifiable, direct involvement of individuals, groups, and/or entities perceived as Canadian.</p>

			<EventTypeDocs/>
	
			<ActorsDocs/>

			<TagsDocs/>
			
			<ThemesDocs/>
			
			<ImpactsDocs/>
			
			<LinksDocs/>
			
		</>
	)
}
