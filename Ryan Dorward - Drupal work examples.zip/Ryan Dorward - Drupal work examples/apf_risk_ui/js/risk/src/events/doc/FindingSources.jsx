import { Link } from 'react-router-dom'

export default function(){
	return (<>
		<h1>Finding regional news sources</h1>
		<p>Analysts involved in media scanning efforts on CAST will be provided with, and may contribute to, a list of recommended media sources for each region we cover. While it is not possible to check each of the recommended media outlets daily, analysts are encouraged to browse both national/general news sites and use provincial-/city-level media for specific follow-ups on local events.</p>
		<p>There is no absolute preference of prominent, established hard-news agencies over smaller editorial projects or blog-type news sources, if the latter’s content is of high quality and does a robust compilation of the different facets of and opinions around a certain event.</p>
		<p>Such scanning process should also be complemented by checking out trending topics on social media platforms for events not yet captured by formal news reporting. Trending sections on these social platforms, such as the “hot search” chart on Weibo, can be leveraged as a shortcut to obtain popular, legitimate news content, after discarding the “noise” from popular sport or celebrity-related search terms that were sometimes made artificually popular with paid advertisements.</p>
		
		<Link to="/about/events/stats/sources-known">Search known media sources by jurisdiction</Link>
	</>)
}
