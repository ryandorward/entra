// import { useState, useEffect } from 'react'

export default function ReadMore({ context }) {

	/*
	// disable readmore funcitonality for now
	const [readMore, setReadMore] = useState(
		Boolean(JSON.parse(window.localStorage.getItem('IwantToReadMore'))) // default: false
	)
	useEffect(() => {
		window.localStorage.setItem('IwantToReadMore',readMore)
	}, [readMore])

	if( ! readMore ){
		return (
			<div onClick={()=>setReadMore(true)} className={styles.readMoreButton}>
				...read more
			</div>
		)
	}
	*/
	return (
		<>
			<h3>More on the issue:</h3>
			{context.split(/\n+/)
				.filter( sentence => sentence.trim() != '' )
				.map( (sentence, i) => {
					return <p key={i}>&bull; {sentence.trim()}</p>
				} )
			}
			{/*
			<div onClick={() => setReadMore(false)}
				className={styles.readMoreButton}>
				show less
			</div>
			*/}
		</>
	)


}
