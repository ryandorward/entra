import { useState, useEffect, useContext } from 'react';
import { useParams } from 'react-router-dom'
import { useQuery, gql } from '@apollo/client'
import graph from '../jurisdictions/graph'
import { assignBoundaries } from '@apfcanada/jurisdictions'
import { MapContext } from '../maps/geographic/Context'
import Boundary from '../maps/geographic/Boundary'
import FocusOn from '../jurisdictions/Focus'
import highlight from '../maps/geographic/styles/highlight.module.css'

const query = gql`
query eventMap ( $id: Int! ) {
	event ( id: $id ) { id
		impacts { id geo_id }
		links ( type: [1,4] ) { cid event { id impacts { id geo_id } } }
	}
}` // [1,4] causal and development links only

export default function(){
	const { event_id } = useParams()
	const { init } = useContext(MapContext)
	const { data } = useQuery( query, { variables: {id: parseInt(event_id)} } )
	const [ jurs, setJurs ] = useState([])
	const [ classMap, setClassMap ] = useState(new Map())
	useEffect(()=>{
		if(!data) return;
		const jurClasses = new Map() // keyed by geo_id
		data.event.impacts.map( impact => {
			if( ! jurClasses.has(impact.geo_id) ){
				jurClasses.set(impact.geo_id,highlight.primary)
			}
		})
		data.event.links.map(l=>l.event.impacts).flat().map( impact => {
			if( ! jurClasses.has(impact.geo_id) ){
				jurClasses.set(impact.geo_id,highlight.secondary)
			}
		} )
		graph.lookup([...jurClasses.keys()])
			.then( jurs => {
				//console.log(jurs)
				const ancestors = jurs.map(j=>j.ancestors).flat()
				ancestors.map( jur => {
					if( ! jurClasses.has(jur.geo_id) ){
						jurClasses.set(jur.geo_id,highlight.tertiary)
					}
				} )
				return [...new Set([...jurs,...ancestors])]
			})
			.then(assignBoundaries)
			.then( jurs => setJurs( [...jurs].sort((A,B)=>A.depth-B.depth) ) )
		setClassMap(jurClasses)
		init( data ? true : false )
	},[data])
	return (<>
		{jurs.map( jur => (
			<Boundary key={jur.geo_id}
				className={classMap.get(jur.geo_id)}
				jurisdiction={jur}/>
		) )}
		<FocusOn jurisdictions={jurs}/>
	</>)
}
