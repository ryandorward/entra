import { useEffect, useContext } from 'react'
/*
import { useParams } from 'react-router-dom'
import { useApolloClient, gql } from '@apollo/client'
import { indirectQuery } from './QueryOptions'
*/
import { useReactiveVar } from '@apollo/client'
import { Node } from '../maps/timeline/node'
import { Context } from '../maps/timeline/TimelineMap'

/*
import { eventThemes } from './ESG/themesFragments.js'
import { timeRange } from './timeRange.js'
*/

import { sharedEvents } from './sharedEvents'

// stores state between renders
const eventNodes = new Map()

/*
This component is used for routes like:
- /timeline/events/
- /timeline/events/theme/:theme_id
- /timeline/events/tag/:tag_id
- /timeline/events/geo/:geo_id
*/

/*
export const query = gql`
${eventThemes}
query timelineCollection (
	$in: [Int] $indirect: Boolean
	$themes: [Int] $tags: [Int]
	$beforeDate: String $afterDate: String
) {
	events (
		top: 100 sort: "weight"
		before: $beforeDate after: $afterDate
		in: $in indirect: $indirect
		themes: $themes tags: $tags
	) { id date title weight ...eventThemes }
}`
*/

export default function(){
	/*
	const client = useApolloClient()
	const { before, after } = useReactiveVar(timeRange)
	const indirect = useReactiveVar(indirectQuery)
	const { theme_id, geo_id, tag_id } = useParams()
	*/

	const events = useReactiveVar(sharedEvents)
	const { setNodes, setLinks, init } = useContext(Context)

	useEffect(()=>{
		const nodes = events.map( event => {
			if( ! eventNodes.has(event.id) ){
				let node = new Node(event)
				eventNodes.set( event.id, node )
			}
			return eventNodes.get(event.id)
		} )
		setNodes(nodes)
		setLinks([])
		init(true)
	},[events])


	return null

	/*

	useEffect(()=>{
		const variables = {
			beforeDate: before,
			afterDate: after,
			indirect, in: Number(geo_id) ?? undefined,
			themes: Number(theme_id) ?? undefined,
			tags: Number(tag_id) ?? undefined
		}
		client.query({query,variables}).then( response => {
			const nodes = response.data.events.map( event => {
				if( ! eventNodes.has(event.id) ){
					let node = new Node(event)
					eventNodes.set( event.id, node )
				}
				return eventNodes.get(event.id)
			} )
			setNodes(nodes)
			setLinks([])
			init(true)
		} )
	},[theme_id,geo_id,tag_id,indirect,before,after])

	return null;
	*/
}
