import { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom'
import { useQuery, gql } from '@apollo/client'
import { Spinner } from '../Spinners'
import { reformat } from '../utilities/time/format'
import ArchiveLinks from './sources/ArchiveLinks'
import graph from '../jurisdictions/graph'
import Headline from './Headline'
import FlexList from '../layouts/FlexList'
import ReadMoreSection from './ReadMore'
import { connectionPoints } from '../connections/pointScore.js'
import { colorFromThemes } from './ESG/colorFromThemes.js'
import { roles } from '../getRoles.js'
import Flag from '../jurisdictions/Flag'
import { eventHeadlineData } from './headlineDataFragment.js'
import { tagThemes } from './ESG/themesFragments.js'
import { ApfPublicationCard } from '../publications/ApfPublicationCard'
import { currentlyHoveredEventId, listenForHoverEvent } from '../utilities/hover.js'
import './panel.less'
import Title from '../components/Title'
import { sharedEvents, sharedEventsLoading } from './sharedEvents'

// import { timeRange } from './timeRange.js'

import ShowOnlyTo from '../ShowOnlyTo'

const query = gql`
${eventHeadlineData}
${tagThemes}
query singleEvent ( $id: Int! $canonTags: Boolean! ) {
	event ( id: $id ) {
		id title date archive_links description justification context
		impacts { id geo_id  }
		canadianInvolvement
		links {
			cid
			event { ...eventHeadlineData }
			linkType { id referenceFromPast referenceFromFuture }
		}
		tags ( isCanonical: $canonTags ) {
			id name isCanonical ...tagThemes
		}
		themes { id name color tagIntersectionWeight isMeta parentThemes {id}}
		relatedContent { id title path typeLabel posted imageSources}
	}
}`

export default function(){
	const { event_id } = useParams()
	const [ jursAffected, setJursAffected ] = useState([])
	const { data, error, loading } = useQuery(
		query, { variables: {
			id: parseInt(event_id),
			canonTags: roles().includes('jrAnalyst') ? false : true
		} }
	)
	// const { before, after } = useReactiveVar(timeRange)

	// console.log('before',before,'after',after)
	useEffect(()=> {
		currentlyHoveredEventId(null) // reset the hover state when this page first loads
	})
	useEffect(()=>{
		if( (!data) || data.event === null ) return;

		graph.lookup(data.event.impacts.map(a=>a.geo_id))
			.then(jurs=>{
				jurs.sort((a,b)=>connectionPoints(b)-connectionPoints(a))
				setJursAffected(jurs)
			})
	},[data])
	const event = data?.event
	useEffect ( () => {
		if (!event) return
		// get all the events from the links
		let allEvents = [...event.links.map(l=>l.event), event]
		sharedEvents(allEvents) // this is how the map and timeline get their events

	}, [event])
	useEffect ( () => {
		sharedEventsLoading(loading)
	}, [loading])

	const ref = useRef()
	useEffect(()=>{
		ref.current && listenForHoverEvent(ref.current,Number(event_id))
		// console.log('listening for hover event',event_id, ref)
	},[ref.current])

	if ( loading || !event ){ return <Spinner size={50}/> }
	if ( error || data?.event === null ) {
		console.log(error)
		// return <Navigate to="/timeline/events"/>
	}

	return (
		<div className="panel-single-event">
			<div className='title-wrap' ref={ref}>
				<Title>{event.title}</Title>
			</div>
			<div className="basics">
				<span className="date">{reformat(event.date)}</span>
				<ArchiveLinks archive_links={event.archive_links}/>
			</div>

			{event.description && <>
				<h3 data-tip data-for="title-tip">What’s new?</h3>
				<p className="description">{event.description}</p>
			</>}
			{event.justification && <>
				<h3>Why does it matter?</h3>
				<p className="analysis">{event.justification}</p>
			</>}
			{event.context && <ReadMoreSection context={event.context}/>}
			{jursAffected.length &&
				<div className="jurisdictions">
					<h3>Where does this event impact?</h3>
					<FlexList list={jursAffected} limit={10}
						nameFunc={jur=>jur.name.en}
						linkFunc={jur=>`/map/events/jurisdiction/${jur.geo_id}`}
						classFunc={()=>`jurisdiction`}
					/>
				</div>
		}
			{event.themes.length > 0 &&
				<div className="themes">
					<h3>Topics</h3>
					<FlexList
						list={[...event.themes
							.filter(t=>t.tagIntersectionWeight>0)
							// .sort((a,b)=>b.isCanonical-a.isCanonical)
							.slice(0,3)]}
						limit={3}
						nameFunc={theme=>theme.name}
						linkFunc={theme=>`/map/events/theme/${theme.id}`}
						colorFunc={theme=>theme.color}
						classFunc={()=>"theme"}
					/>
					{/*event.themes
						.filter(t=>t.tagIntersectionWeight>0)
						.slice(0,3)
						.map( theme => (
							<ThemeTitle key={theme.id} id={theme.id}
								title={theme.name} color={theme.color}/>
						) )
						*/}
				</div>
			}
			{event.tags.length > 0 &&
				<div className="tags">
					<h3>Tags</h3>
					<FlexList
						list={[...event.tags].sort((a,b)=>b.isCanonical-a.isCanonical)}
						limit={10}
						nameFunc={tag=>tag.name}
						linkFunc={tag=>`/map/events/tag/${tag.id}`}
						colorFunc={tag=>colorFromThemes(tag.themes)}
						classFunc={tag=>tag.isCanonical ? "tag canonical" : "tag"}
					/>
				</div>
			}
			{event.links.length > 0 &&
				<div className="related-events">
					<h3>Related Events</h3>
					{[...event.links]
					.sort((a,b)=>b.event.date.localeCompare(a.event.date))
					.map( link => {
						var relation = link.linkType.referenceFromFuture
						if( (event.date < link.event.date) ||
							(event.date == link.event.date && event.id < link.event.id)
						){ relation = link.linkType.referenceFromPast }
						return(
							<Headline key={link.event.id}
								id={link.event.id}
								title={link.event.title}
								date={link.event.date}
								themes={link.event.themes}
								geo_ids={link.event.impacts.map(i=>i.geo_id)}
								relation={relation}
							/>
						)
					} ) }
				</div>
			}
			{event.relatedContent.length > 0 &&
				<div className="related-content">
					<h3>Related Publications</h3>
					{event.relatedContent.map(content=><ApfPublicationCard key={content.id} node={content}/>)}
				</div>
			}
			<ShowOnlyTo minRole="jrAnalyst">
				{event.canadianInvolvement &&
					<div className="metadata">
						<Flag geo_id={2} title="direct Canadian involvement"/>
					</div>
				}
				<EditLink event_id={event.id}/>
			</ShowOnlyTo>
		</div>
	)
}

import { site } from '../API.js'
function EditLink({event_id}){
	const url = `${site}/admin/cast/management/event/${event_id}`;
	return <a href={url}>Edit</a>
}

