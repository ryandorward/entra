import { eventThemes } from './ESG/themesFragments.js'
import { gql } from '@apollo/client'

export const eventHeadlineData = gql`
${eventThemes}
fragment eventHeadlineData on Event {
	id title date ...eventThemes impacts { id geo_id } weight
}`
