import { useRef, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { colorFromThemes } from './ESG/colorFromThemes.js'
import { timeAgo } from '../utilities/time/format'
import { lighter } from '../utilities/lighter.js'
import { listenForHoverEvent } from '../utilities/hover.js'
import graph from '../jurisdictions/graph'
import { regionLabel } from '@apfcanada/jurisdictions'
import './tip-headline.less'

export default function TipHeadline({event, variant}){
	const [ region, setRegion ] = useState(undefined)
  const ref = useRef()
  const geo_ids= event.impacts?.map(i=>i.geo_id)
  const colour = colorFromThemes(event.themes)
  useEffect(()=>{
		ref.current && listenForHoverEvent(ref.current,event.id)
	},[])
  useEffect(()=>{
		variant === 'timeline' && geo_ids &&
			graph.lookup(geo_ids).then( jurs => setRegion( regionLabel(jurs) ) )
	},[geo_ids])

	return (
    <Link
      ref={ref}
      key={event.id}
      to={`/map/event/${event.id}`}
      className={`event-link event-${event.id} event-tip-headline`}
    >
      <span
        className='themeDot'
        style={{
          backgroundColor: colour ? lighter(colour) : 'white',
          borderColor: colour ?? 'grey'
        }}
      />
      <span className='age'>{timeAgo(event.date)}</span>
      {region && <div className='region-label'>{region}</div> }
      <span className='event-title'>{event.title}</span>
    </Link>
	)
}

