import { useNavigate } from 'react-router-dom'
import { useApolloClient, gql } from '@apollo/client'
import AsyncSelect from 'react-select/async'
import styles from '../styles/select.module.css'

const query = gql`
query ( $text: String! ) {
  events ( search: $text top: 10 ) {
    id date label: title
  }
}`

export default function(props){
	const client = useApolloClient()
	const navigate = useNavigate()
	return (
		<AsyncSelect
			placeholder="Search events"
			loadOptions={promiseOptions}
			cacheOptions={true}
			controlShouldRenderValue={false}
			onChange={select}
			menuPlacement="auto"
			formatOptionLabel={formatOption}
			getOptionValue={(event)=>event.id}
			noOptionsMessage={noOptions}
			{...props}
		/>
	)
	function promiseOptions(input){
		return client.query({query,variables:{text:input}})
			.then(({data})=>data.events)
	}
	function select(option){
		navigate(`/map/event/${option.id}`)
	}
}
function formatOption(event){
	return (
		<div className="option">
			{event.label}<br/><span className={styles.descriptor}>
				({event.date})
			</span>
		</div>
	)
}

function noOptions(input){
	return input.inputValue == '' ?
		'Search for keywords in events' :
		'Sorry - no results for that search'
}
