import { useNavigate } from 'react-router-dom'
import { gql, useQuery } from '@apollo/client'
import Select from 'react-select'

const query = gql`query { themes { id name } }`

export default function(){
	const { data } = useQuery(query)
	const navigate = useNavigate()
	const options = data ? 
		data.themes.map(theme=>({label:theme.name,value:theme.id})) : 
		[] 
	return (
		<Select placeholder={`View events organized by theme`} 
			options={options} onChange={selectTheme}
			menuPlacement="auto"/>
	)
	function selectTheme(option){ 
		navigate(`/timeline/events/theme/${option.value}`)
	}
}
