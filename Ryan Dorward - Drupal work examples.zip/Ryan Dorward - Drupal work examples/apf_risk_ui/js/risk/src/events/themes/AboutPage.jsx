import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom'
import { gql, useApolloClient } from '@apollo/client'
import { roles } from '../../getRoles.js'
import { rankIDs } from '../../utilities/frequency.js'
import HeaderBox from '../../layouts/HeaderBox'
import graph from '../../jurisdictions/graph'
import ShowOnlyTo from '../../ShowOnlyTo'
import BigNumber from '../../layouts/BigNumber'
import FlexList from '../../layouts/FlexList'
import TitleBox from './TitleBox'

const isAnalyst = roles().includes('jrAnalyst')

const query = gql`
query ($id: Int) { 
	theme ( id: $id ) { 
		id name color description geo_ids
		parentThemes { id name color } 
		childThemes { id name color }
		tags { id name } 
		events { id tags { id } }
	}
}`

const relatedTagsQuery = gql`
query ( $ids: [Int]! ) {
	tags ( id: $ids ) { id name }
}`

export default function (){
	const { theme_id } = useParams()
	const client = useApolloClient()
	const [ jurs, setJurs ] = useState([])
	const [ theme, setTheme ] = useState({})
	const [ themeTags, setThemeTags ] = useState([])
	const [ relatedTagIDs, setRelatedTagIDs ] = useState([])
	const [ relatedTags, setRelatedTags ] = useState([])
	const [ eventCount, setEventCount ] = useState([])
	useEffect(()=>{
		client.query({query,variables:{id:Number(theme_id)}})
			.then( ({data}) => {
				let { theme } = data
				setTheme( theme )
				setEventCount(theme.events.length)
				if( theme.geo_ids.length > 0 ){
					graph.lookup(theme.geo_ids).then(setJurs)
				}
				// calculate tag frequency
				let usedTags = rankIDs(theme.events.map(e=>e.tags).flat())
				let usedThemeTags = usedTags // keeps rank order
					.map( id => theme.tags.find( tag => tag.id == id ) )
					.filter( tag => tag ) // was found
				if( isAnalyst ){ // show unused tags to analyst
					setThemeTags([
						...usedThemeTags,
						...theme.tags.filter(t=>!usedTags.includes(t.id))
					])
				}else{ // only used tags for user
					setThemeTags(usedThemeTags)
				}
				let otherTags = usedTags
					.filter( id => ! theme.tags.map(t=>t.id).includes(id) )
				setRelatedTagIDs( otherTags.slice(0,isAnalyst?50:25) )
			} )
	},[theme_id])
	useEffect(()=>{
		if( relatedTagIDs.length == 0 ) return;
		client.query({
			query: relatedTagsQuery,
			variables:{ids:relatedTagIDs}
		}).then( response => {
			setRelatedTags(response.data.tags)
		} )
	},[relatedTagIDs])
	if( !theme?.id ) return null;	
	return (<>
		<TitleBox big
			id={theme.id}
			title={theme.name}
			color={theme.color}
		/>
		<BigNumber number={eventCount} 
			linkPath={`/timeline/events/theme/${theme.id}`} 
			labelPlural={"Events in this theme"}
			labelSingle={"Event in this theme"}
		/>
		{theme.description && <p>{theme.description}</p>}
		{theme.parentThemes.length > 0 && 
			<HeaderBox title="Sub-Theme of">
				{theme.parentThemes.map( theme => (
					<TitleBox key={theme.id} id={theme.id} title={theme.name} 
						color={theme.color}/>
				) )}
			</HeaderBox>
		}
		{theme.childThemes.length > 0 && 
			<HeaderBox title="Includes sub-Themes">
				{theme.childThemes.map( theme => (
					<TitleBox key={theme.id} id={theme.id} title={theme.name} 
						color={theme.color}/>
				) )}
			</HeaderBox>
		}
		{jurs.length > 0 && 
			<HeaderBox title="Applies within jurisdictions">
				<FlexList list={jurs} limit={10}
					nameFunc={jur=>jur.name.en}
					linkFunc={jur=>`/timeline/events/jurisdiction/${jur.geo_id}`}
				/>
			</HeaderBox>
		}
		{themeTags.length > 0 &&
			<HeaderBox title="Applies to events tagged">
				<FlexList list={themeTags} limit={15}
					nameFunc={tag=>tag.name}
					linkFunc={tag=>`/timeline/events/tag/${tag.id}`}
				/>
			</HeaderBox>
		}
		{relatedTags.length > 0 &&
			<HeaderBox title="Related tags in other themes">
				<FlexList list={relatedTags} limit={10}
					nameFunc={tag=>tag.name}
					linkFunc={tag=>`/timeline/events/tag/${tag.id}`}
				/>
			</HeaderBox>
		}
		<ShowOnlyTo minRole="jrAnalyst">
			<Link to="/about/events/stats/themes">Theme stats</Link>
		</ShowOnlyTo>
		<ShowOnlyTo minRole="analyst">
			<a href={`https://www.asiapacific.ca/admin/risk/event-theme/${theme.id}/edit`}>Edit this theme</a>
		</ShowOnlyTo>
	</>)
}
