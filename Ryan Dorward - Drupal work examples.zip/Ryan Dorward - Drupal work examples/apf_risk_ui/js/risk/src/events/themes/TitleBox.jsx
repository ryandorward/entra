import { Link, useLocation } from 'react-router-dom'
import ContrastText from '../../layouts/ContrastText'
import { lighter } from '../../utilities/lighter.js'
import styles from './title-box.module.css'

const knownPaths = ['/about/events/theme','/timeline/events/theme']

export default function({id,title,color,big}){
	const { pathname } = useLocation()
	let linkPath = `/timeline/events/theme/${id}`
	const pathMatch = (/^(?<path>.*)\/(?<id>\d+)/i).exec(pathname).groups
	if( id == Number(pathMatch.id) ){
		if( knownPaths.includes(pathMatch.path) ){
			let otherPath = knownPaths.find(p=>p!=pathMatch.path)
			linkPath = `${otherPath}/${id}`
		}
	}else{ // not the ID in the current path
		if( knownPaths.includes(pathMatch.path) ){
			linkPath = `${pathMatch.path}/${id}`
		}
	}
	const lighterColor = lighter(color)
	return (
		<div className={styles.container} 
			style={{backgroundColor:lighterColor,border:`1px solid ${color}`}}>
			<ContrastText againstColor={lighterColor}>
				<Link to={linkPath}>
					{big ? <span style={{fontSize:'1.4em'}}>{title}</span> : title}
				</Link>
			</ContrastText>
		</div>
	)
}
