// import { Link } from 'react-router-dom'
import { useParams } from 'react-router-dom'
// import { useQuery } from '@apollo/client'
import { useQuery, gql } from '@apollo/client'
// import { Helmet } from 'react-helmet'
// import { timeRange } from '../timeRange.js'
import { rankIDs } from '../../utilities/frequency.js'
// import { EventsMapper } from '../Headlines'
import Headlines from '../Headlines'
import { eventHeadlineData } from '../headlineDataFragment.js'
import ShowOnlyTo from '../../ShowOnlyTo'
import FlexList from '../../layouts/FlexList'
import '../panel.less'
import { Spinner } from '../../Spinners'
import { lighter } from '../../utilities/lighter.js'
import Title from '../../components/Title'
import { colorFromThemes } from '../ESG/colorFromThemes.js'

const query = gql`
	${eventHeadlineData}
	query ( $theme: Int ){
		theme ( id: $theme ) {
			id name color
			events ( top: 75 sort: "date" ) {
				...eventHeadlineData
				weight
			}
			tags { id name themes {id color} }
		}
		themes { id name color }
	}`

export default function(){
	const { theme_id } = useParams()
	// const { before, after } = useReactiveVar(timeRange) // @todo: query by this date range that is centrally controlled
	const { loading, data } = useQuery( query, {variables:{theme:Number(theme_id)}} )
	const theme = data?.theme
	const events = theme?.events

	const topRelatedThemes = rankIDs(
		(events??[]).map(e=>e.themes).flat()
			.filter( theme=> (theme.id != Number(theme_id)) && !theme.isMeta ),
		theme => theme.tagIntersectionWeight
	).slice(0,5)

	if( loading ) return <Spinner contained size={50}/>

	const themes = topRelatedThemes.map( themeID => {
		return data.themes.find(t=>t.id==themeID)
	} )

	const color = theme?.color
	const dotStyle = {
		backgroundColor: color ? lighter(color) : 'white',
		borderColor: color ?? 'grey'
	}

	return (
		<>
			{theme && <div className="event-theme-header header" style={{marginTop:'15px'}}>
				{ color && <div className="theme-dot" style={dotStyle}/> }
				<Title metaTitle = {theme?.name ? `"${theme.name}" Topic`:`Events`}>
					{`What's happening in Topic "${theme.name}"`}
				</Title>
				{/*
				// @todo: make sure this is working before re-opening
				<Link to={`/about/events/theme/${theme.id}`}>
					Learn more about this theme
				</Link> */}
			</div>}
			<div>
				{/* events && <EventsMapper events={events}/> */}
				<Headlines top={50} sort="date"
					themes={Number(theme_id)}
				/>
			</div>
			{themes.length > 0 &&
				<div className="themes">
					<h3>{`Topics related to "${theme.name}":`}</h3>
					<FlexList
						list={themes}
						nameFunc={theme=>theme.name}
						linkFunc={theme=>`/map/events/theme/${theme.id}`}
						colorFunc={theme=>theme.color}
						classFunc={()=>`theme`}
					/>
					<h3>{`Tags within "${theme.name}":`}</h3>
					<FlexList
						list={theme.tags}
						nameFunc={tag=>tag.name}
						limit={10}
						linkFunc={tag=>`/map/events/tag/${tag.id}`}
						colorFunc={tag=>colorFromThemes(tag.themes)}
						classFunc={()=>"tag canonical"}
					/>
					{
					/*
					{topRelatedThemes.map( themeID => {
						let theme = data.themes.find(t=>t.id==themeID)
						return (
							<ThemeTitle key={theme.id} id={theme.id}
								title={theme.name} color={theme.color}/>
						)
					} )}
					*/}
				</div>
			}
			<ShowOnlyTo minRole="analyst">
				<a href={`https://www.asiapacific.ca/admin/risk/event-theme/${theme.id}/edit`}
					target="_blank" rel="noreferrer">Edit this theme (topic)</a>
			</ShowOnlyTo>
		</>
	)
}