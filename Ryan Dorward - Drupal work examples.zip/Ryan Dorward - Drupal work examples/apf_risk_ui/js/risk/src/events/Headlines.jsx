import {useState, useEffect} from 'react'
import Headline from '../events/Headline'
import { gql, useQuery } from '@apollo/client'
// import { timeRange } from './timeRange.js'
import { eventHeadlineData } from './headlineDataFragment.js'
import { Spinner } from '../Spinners'
import './headlines.less'
import { sharedEvents, sharedEventsLoading } from './sharedEvents'

const query = gql`
${eventHeadlineData}
query eventHeadlines (
	$before: String $after: String
	$top: Int $sort: String $tags: [Int] $themes: [Int]
	$in: [Int] $withDescendants: Boolean $ids: [Int] $indirect: Boolean
	$search: String $offset: Int
) {
	events(
		ids: $ids before: $before after: $after
		tags: $tags themes: $themes top: $top offset: $offset sort: $sort
		in: $in withDescendants: $withDescendants indirect: $indirect search: $search
	) {
		...eventHeadlineData
	}
}`

export default function({...args}){
	const [pageCnt, setPageCnt] = useState(1)
	const { data, loading, fetchMore } = useQuery(query,{variables:args, notifyOnNetworkStatusChange:true})
	let events = data?.events ?? []
	let more

	useEffect ( () => {
		sharedEvents(events) // this is how the map and timeline get their events
		if (events.length === 0) return
		// set the date range to the first and last events
		// this is used to set the date range for the timeline
		// const start = new Date(events[0].date)
		// const end = new Date(events[events.length-1].date)

		/*
		timeRange({
			before: start.toISOString(),
			after: end.toISOString()
		})
		*/
	}, [events])
	useEffect ( () => {
		sharedEventsLoading(loading)
	}, [loading])

	useEffect ( () => {
		setPageCnt(1) // this has the side effect of throwing away "more" results if we switch filter criteria and then switch back
	}, [args.in, args.themes, args.tags, args.search, args.before, args.after])

	if (args.top) {
		// slice events into two arrays: one for top-1 events, and one for the rest (more)
		const total=(args.top)*pageCnt
		more = events.slice(total-1,total)
		events = events.slice(0, total-1)
	}

	// make events unique @todo remove this kludggery
	events = [...new Set(events)] // this is a kludge to make sure the events are unique. Should be able to address this without this kludge.

	return (
		<div className="events-mapper">
			<EventsMapper events={events} loading={loading}/>
			{ more.length ? <button className="load-more blue-ghost ghost" onClick={
					() => {
						setPageCnt(pageCnt+1)
						fetchMore({
							variables: { offset: pageCnt*args.top-1 }
						})
					}
				}>Load more +</button> : null }
			{ loading && <Spinner size={50}/>}
		</div>
	)
}

export function EventsMapper({events, loading}) {
	return events.length == 0 && !loading ?
		<><i>No events found.</i><br/>Try widening the filter criteria (date range, jurisdictions, keywords )</> :
		events.map( event => (
			<Headline key={event.id} id={event.id}
				title={event.title} date={event.date} themes={event.themes}
				geo_ids={event.impacts.map(i=>i.geo_id)}
			/>
		) )
}