import BoundaryItem from '../maps/legend/BoundaryItem'
import highlight from '../maps/geographic/styles/highlight.module.css'

export default function(){
	return (
		<BoundaryItem className={highlight.primary} label="Total geographic scope of these events"/>
	)
}
