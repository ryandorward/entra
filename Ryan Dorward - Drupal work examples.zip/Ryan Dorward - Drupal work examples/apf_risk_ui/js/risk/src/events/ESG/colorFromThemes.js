import { color } from '../ESG/scale.js'
import { reduceThemesToESG } from '../ESG/reduceThemesToESG.js'

// accepts a tag object as argument
export function colorFromThemes(themes, dbug){
	if (dbug == 1691) console.log("colorFromThemes", themes, dbug)
	if( themes?.length < 1 ){
		return undefined
	}
	dbug && console.log("colorFromThemes: themes",themes, dbug)
	if( themes?.length == 1 && themes[0].color ){
		dbug && console.log("themes?.length == 1")
		return themes[0].color
	}
	if(themes?.length > 1){
		dbug && console.log("themes?.length > 1", reduceThemesToESG(themes))
		return color( reduceThemesToESG(themes) )
	}
	return color({E:1,S:1,G:1})
}
