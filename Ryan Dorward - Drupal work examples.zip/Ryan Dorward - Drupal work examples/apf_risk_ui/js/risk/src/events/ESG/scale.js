import { barycentric } from 'd3-ternary'
import { Delaunay } from 'd3-delaunay'

export const bins = Object.freeze([ 
	{ // center
		E:1, S:1, G:1,
		color:'#777'
	},{ // E,
		label: 'Environment',
		E:1, S:0.25, G:0.25,
		color:'#20ad57'
	},{ // S
		label: 'Social',
		E:0.25, S:1, G:0.25,
		color:'#2a40c7'
	},{ // G
		label: 'Governance',
		E:0.25, S:0.25, G:1,
		color:'#e45317'
	},{ // E / S
		E:1, S:1, G:0,
		color:'#25bfc4'
	},{ // E / G
		E:1, S:0, G:1,
		color:'#d2d514'
	},{ // G / S
		E:0, S:1, G:1,
		color:'#a586e8'
	}
])

export const barycentricScale = barycentric()
	.a( d => d.E )
	.b( d => d.S )
	.c( d => d.G )
	
const delaunay = Delaunay.from( bins.map( bin => barycentricScale(bin) ) )
	
export function color(ESGobj){
	let i = delaunay.find( ... barycentricScale(ESGobj) )
	return bins[i].color
}
