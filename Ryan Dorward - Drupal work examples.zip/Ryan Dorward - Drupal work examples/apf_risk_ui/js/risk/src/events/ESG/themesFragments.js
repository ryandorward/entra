import { gql } from '@apollo/client'

export const eventThemes = gql`
fragment eventThemes on Event {
	themes {
		id color tagIntersectionWeight isMeta
		parentThemes {
			id
			parentThemes
			{ id }
		}
	}
}`

export const tagThemes = gql`
fragment tagThemes on Tag {
	themes { id color parentThemes { id parentThemes { id } } }
}`
