import Triangle from './Triangle'
import { Link } from 'react-router-dom'
import styles from '../../maps/legend/note.module.css'

export default function(){
	return (
		<>
			<div className={styles.note}><b>Color</b> corresponds to <Link to="/about/methodology/events/ESG">ESG</Link> balance of recent events. <b>Opacity</b> corresponds to the relative frequency/impact of recent events.</div>
			<Triangle/>
		</>
	)
}
