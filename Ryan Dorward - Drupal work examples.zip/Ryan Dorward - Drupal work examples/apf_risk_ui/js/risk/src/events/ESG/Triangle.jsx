import { ternaryPlot } from 'd3-ternary'
import { Delaunay } from 'd3-delaunay'
import { bins, barycentricScale } from './scale.js'
import { lighter } from '../../utilities/lighter.js'
import styles from './scale.module.css'

const [width,height,padding] = [200,200,10]

const tp = ternaryPlot(barycentricScale)
	.radius(width/2-padding)
	.labels(['Environment','Social','Govern.'])
	.labelOffsets([10,10,10])

// get triangle point coordinates
let displayBins = bins.map( bin => {
	let [x,y] = tp(bin);
	return { x, y, ...bin }
} )
// get bin coordinates
let tesselation = Delaunay.from(displayBins.map(d=>[d.x,d.y]))
	.voronoi([-width/2,-height/2-20,width/2,height/2])

displayBins.forEach( (d,i) => d.pathData = tesselation.renderCell(i) )

export default function(){
	return (
		<svg width={width} height={height}
			viewBox={`${-width/2} ${-height/2-20} ${width} ${height}`}>
			<defs>
				<clipPath id="triangle"><path d={tp.triangle()}/></clipPath>
			</defs>
			<g clipPath="url(#triangle)">
				{displayBins.map( (d,i) => (
					<path key={i} className={styles.voronoiBin}
						d={d.pathData} style={{fill:lighter(d.color)}}/>
				) )}
			</g>
			<path d={tp.triangle()} className={styles.outerTriangle}/>
			{tp.axisLabels().map( ({position:[x,y],angle,label}) => {
				return (
				<text key={label} style ={{fontWeight: "bold"}}
					transform={`translate(${x},${y}) rotate(${angle})`}
					textAnchor="middle">
					{label}
				</text>
			) } )}
		</svg>
	)
}
