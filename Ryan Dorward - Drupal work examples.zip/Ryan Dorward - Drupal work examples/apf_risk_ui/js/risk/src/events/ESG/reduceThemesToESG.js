const metaThemes = new Map([[12,'E'],[13,'S'],[14,'G']])

export function reduceThemesToESG(themesList){
	return themesList.reduce( (obj,theme) => {
		Object.keys(getESG(theme)).forEach( letter => {
			obj[letter] += themeWeight(theme)
		} )
		return obj
	}, {E:0,S:0,G:0} )
}

function themeWeight(theme){
	return theme?.tagIntersectionWeight ?? 1
}

function getESG(theme){
	if( metaThemes.has(theme.id) ){
		let letter = metaThemes.get(theme.id)
		return { [letter]: 1 }
	}
	if( theme?.parentThemes ){
		return theme.parentThemes.reduce( (ESG,parentTheme) => {
			return { ... ESG, ... getESG(parentTheme) }
		}, {} )
	}
	return {}
}