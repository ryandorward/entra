import { Link } from 'react-router-dom'
import note from '../maps/legend/note.module.css'
import Triangle from './ESG/Triangle'

export default function Legend(){
	return (<>
		<span className={note.note}>
			Events are colored according to their location within our <Link to="/about/methodology/events/ESG">ESG framework</Link>
		</span>
		<Triangle/>
	</>)
}
