// import { useReactiveVar } from '@apollo/client'
// import { Helmet } from 'react-helmet'
import Headlines from './Headlines'
import Title from '../components/Title'
//import { timeRange } from './timeRange.js'

export default function AllTheHeadlines(){
	// const { before, after } = useReactiveVar(timeRange)
	return (
		<div>
			<Title metaTitle='Recent Events'>All Events</Title>
			{/*<Headlines top={75} sort="date"
				before={before} after={after}/> */}
			<Headlines top={75} sort="date"/>
		</div>
	)
}
