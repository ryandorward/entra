import Group from '../maps/legend/Group'
import BoundaryItem from '../maps/legend/BoundaryItem'
import highlight from '../maps/geographic/styles/highlight.module.css'

export default function(){
	return (
		<Group title="Event impacts and context">
			<BoundaryItem className={highlight.primary} label="Direct"/>
			<BoundaryItem className={highlight.secondary} label="Secondary"/>
		</Group>
	)
}
