import { useState } from 'react';
import { Source } from './source.js'

export default function({archive_links}){
	const [ collapsed, setCollapsed ] = useState(archive_links.length > 1)
	if(collapsed){
		let num = archive_links.length
		return (
			<a onClick={()=>setCollapsed(false)} className="source-links">
				{num > 1 ? `${num} Sources +` : `Source +`}
			</a>
		)
	}
	return (
		<div className="source-links">
			{archive_links.map( link => {
				let source = new Source(link)
				return <SourceComp key={link} source={source}/>
			} ) }
		</div>
	)
}

function SourceComp({source}){
	// console.log(source.publisher.owner.icon)
	return (
		<div className="source">
			<a href={source.directLink} target="_blank" rel="noreferrer">
				{source.publisher?.name ?? 'Source'}
			</a> {source.publisher?.owner &&
				<img src={source.publisher.owner.icon} height="10px" title={`Source is directly owned/controlled by ${source.publisher.owner.name}`}/>
			} {source.isArchived && <>(<a href={source.archiveLink} target="_blank"
				title={`archived on ${source.dateArchived}`} rel="noreferrer">
				archived
			</a>)</>}
		</div>
	)
}
