import { publishers } from './publishers.js'

const domain = /(?<protocol>https?:\/{1,2}(www\.)?)(?<domain>[^/]+)/i

const supportedArchives = [
	{ 
		name: 'Wayback Machine', 
		re: /^https?:\/\/web\.archive\.org\/web\/(?<year>\d{4})(?<month>\d{2})(?<day>\d{2})(?<time>\d{6})\/(?<directLink>http.+)/i
	},{ 
		name: 'Archive.today', 
		re: /^https?:\/\/archive\.today\/(?<year>\d{4})\.(?<month>\d{2})\.(?<day>\d{2})-(?<time>\d{6})\/(?<directLink>http.+)/i
	}
]

export class Source{
	#URL
	#publisher
	constructor(URL){
		this.#URL = URL
		this.#publisher = publishers.find(src=>URL.match(src.re))
	}
	get isArchived(){
		return supportedArchives.some( archive => archive.re.test(this.#URL) )
	}
	#archive(){
		return supportedArchives.find( archive => archive.re.test(this.#URL) )
	}
	get dateArchived(){
		if( ! this.isArchived ) return undefined;
		let parts = this.#archive().re.exec(this.#URL).groups;
		return `${parts.year}-${parts.month}-${parts.day}`
	}
	get directLink(){
		return this.isArchived ? 
			this.#archive().re.exec(this.#URL).groups.directLink :
			this.#URL; 
	}
	get archiveLink(){
		return this.isArchived ? this.#URL : undefined
	}
	get publisher(){
		return this.#publisher
	}
	get domain(){
		return this.directLink.match(domain).groups.domain
	}
}
