import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom'
import getMediaSource from '../../wikidata/queries/mediaSource.js'
import FlexList from '../../layouts/FlexList'
import graph from '../../jurisdictions/graph'

export default function(){
	const { source_id } = useParams()
	
	const [ labels, setLabels ] = useState({})
	const [ types, setTypes ] = useState([])
	const [ languages, setLanguages ] = useState([])
	const [ websites, setWebsites ] = useState([])
	const [ jurs, setJurs ] = useState([])
	const [ hqJurs, setHQjurs ] = useState([])
	const [ biases, setBiases ] = useState([])
	
	useEffect(()=>{
		getMediaSource(source_id).then( data => {
			const { label,types,websites,HQs,languages,biases,jursCovered } = data
			setLabels( { en: label.value } )
			
			setLanguages( languages?.value?.split(' / ')?.filter(v=>v)??[] )
			setWebsites( websites?.value?.split(' | ')?.filter(v=>v)??[] )
			setTypes( types?.value?.split('/')?.filter(v=>v)??[] )
			setBiases( biases?.value?.split('/')?.filter(v=>v)??[] )
			
			if(jursCovered){
				const jurIds = jursCovered.value.split('/').filter(v=>v)
				graph.lookup(jurIds).then( jurs => setJurs( jurs.filter(j=>j) ) )
			}
			if(HQs){
				const HQjurIds = HQs.value.split(',').filter(v=>v)
				graph.lookup(HQjurIds).then( jurs => setHQjurs(jurs.filter(j=>j)) )
			}
		} )
	},[source_id])
	
	return (<>
		<h1>Media source</h1>
		<h2>Wikidata ID</h2>
		{source_id && 
			<a href={`https://www.wikidata.org/wiki/${source_id}`}>{source_id}</a>}
		<h2>English Name</h2>
		{labels?.en}
		{types.length > 0 && <>
			<h2>Instance of</h2>
			<FlexList list={types} nameFunc={v=>v}/>
		</>}
		{languages.length > 0 && <>
			<h2>Languages</h2>
			<FlexList list={languages} nameFunc={v=>v}/>
		</>}
		{websites.length > 0 && <>
			<h2>Websites</h2>
			<FlexList list={websites} nameFunc={v=>v}/>
		</>}
		{hqJurs.length > 0 && <>
			<h2>Headquarters</h2>
			<FlexList list={hqJurs} nameFunc={j=>j.name.en}/>
		</>}
		{jurs.length > 0 && <>
			<h2>Jurisdictions Covered/Served</h2>
			<FlexList list={jurs} 
				nameFunc={j=>j.name.en}
				linkFunc={j=>`/map/jurisdiction/${j.geo_id}`}
			/>
		</>}
		{biases.length > 0 && <>
			<h2>Known Biases</h2>
			<FlexList list={biases} nameFunc={v=>v}/>
		</>}
	</>)
}
