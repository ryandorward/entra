const CCP = {
	name: 'the Communist Party of China',
	icon: require('../../images/CCP-icon.svg?url')
}
const CCPLocalCommittee = {
	name: 'a regional Communist Party committee',
	icon: require('../../images/CCP-committee-icon.svg?url')
}

export const publishers = [
	{
		name: 'Sina',
		re: /sina\.com\.cn/i,
		qid: 'Q2288676'
	},{
		name: 'China News Service',
		re: /chinanews\.com/i,
		qid: 'Q969272',
		owner: CCP
	},{
		name: 'Sohu',
		re: /sohu\.com/i,
		qid: 'Q965133'
	},{
		name: 'Huanqiu Shibao',
		re: /(huanqiu\.com|globaltimes\.cn|biz=MTQzMTE0MjcyMQ)/i, // biz = wechat biz ID
		qid: 'Q970443',
		owner: CCP
	},{
		name: 'The Paper',
		re: /thepaper\.cn/i,
		qid: 'Q17499997',
		owner: CCPLocalCommittee
	},{
		name: 'National Business Daily',
		re: /nbd\.com\.cn/i,
		qid: 'Q66436069',
		owner: CCPLocalCommittee
	},{
		name: 'Xinhua News Agency',
		re: /[^\w]+news\.cn([^\w]+|$)|xinhuanet\.com/i,
		qid: 'Q204839',
		owner: CCP
	},{
		name: 'Jiemian News',
		re: /jiemian\.com/i,
		qid: 'Q20688847',
		owner: CCPLocalCommittee
	},{
		name: 'Lianhe Zaobao',
		re: /zaobao\.com\.sg/i,
		qid: 'Q3273611'
	},{
		name: 'United Daily News',
		re: /udn\.com/i,
		qid: 'Q697153'
	},{
		re: /cctv\.com/i,
		name: 'China Central Television',
		qid: 'Q207936',
		owner: CCP
	},{
		name: 'Guancha',
		re: /guancha\.cn/i,
		qid: 'Q17500632'
	},{
		name: 'East Money Information',
		re: /eastmoney\.com/i,
		qid: 'Q24836492'
	},{
		name: 'Reuters',
		re: /reuters\.com/i,
		qid: 'Q130879'
	},{
		name: 'Shanghai Observer',
		re: /jfdaily\.com|shobserver\.com/i,
		qid: 'Q53700471'
	},{
		name: 'Phoenix Television',
		re: /ifeng\.com/i,
		qid: 'Q724186'
	},{
		name: 'NetEase',
		re: /163\.com/i,
		qid: 'Q196259'
	},{
		name: 'Central News Agency',
		re: /cna\.com\.tw/i,
		qid: 'Q697130'
	},{
		name: 'Beijing News',
		re: /bjnews\.com\.cn/i,
		qid: 'Q11081053',
		owner: CCPLocalCommittee
	},{
		name: 'HK01',
		re: /hk01\.com/i,
		qid: 'Q22774484'
	},{
		name: 'China Times',
		re: /chinatimes\.com/i,
		qid: 'Q697429'
	},{
		name: 'Yicai',
		re: /yicai\.com/i,
		qid: 'Q15911769',
		owner: CCPLocalCommittee
	},{
		name: "People's Daily",
		re: /people\.com\.cn/i,
		qid: 'Q54340',
		owner: CCP
	},{
		name: "Oriental Daily News",
		re: /hk\.on\.cc/i,
		qid: 'Q1507352'
	},{
		name: "All About Macau",
		re: /aamacau\.com/i,
		qid: 'Q16926790'
	},{
		name: "Xi'an Daily",
		re: /xiancn\.com/i,
		qid: 'Q108304134',
		owner: CCPLocalCommittee
	},{
		name: "Ministry of Defense",
		re: /www\.mod\.gov\.cn/i,
		qid: 'Q1332463',
		owner: CCP
	},{
		name: "Ministry of Emergency Management",
		re: /www\.mem\.gov\.cn/i,
		qid: 'Q65042431',
		owner: CCP
	},{
		name: "CAAC",
		re: /(www\.caac\.gov\.cn|caacnews\.com\.cn)/i,
		qid: 'Q1329619',
		owner: CCP
	},{
		name: "Caixin",
		re: /caixin\.(cn|com)/i,
		qid: 'Q5017958'
	},{
		name: "Wen Wei Po",
		re: /wenweipo\.com/i,
		qid: 'Q844490'
	},{
		name: "Liberty Times",
		re: /ltn\.com\.tw/i,
		qid: 'Q697462'
	},{
		name: "Yahoo! Kimo",
		re: /tw\.news\.yahoo\.com/i,
		qid: 'Q10863587'
	},{
		name: "Stand News",
		re: /www\.thestandnews\.com/i,
		qid: 'Q19854443'
	},{
		name: "Science and Technology Daily",
		re: /stdaily\.com/i,
		qid: 'Q7433637',
		owner: CCP
	},{
		name: "Government of Hong Kong SAR",
		re: /www\.news\.gov\.hk/i,
		qid: 'Q15164'
	},{
		name: "Epoch Times",
		re: /epochtimes\.com/i,
		qid: 'Q584472'
	},{
		name: "BBC",
		re: /www\.bbc\.com/i,
		qid: 'Q747860'
	},{
		name: "Sing Tao Daily",
		re: /std\.stheadline\.com/i,
		qid: 'Q5241255'
	},{
		name: "Ming Pao",
		re: /news\.mingpao\.com/i,
		qid: 'Q1674139'
	},{
		name: "Taiwan News",
		re: /taiwannews\.com\.tw/i,
		qid: 'Q697286'
	},{
		name: "In-media",
		re: /www\.inmediahk\.net/i,
		qid: 'Q13164959'
	},{
		name: "Securities Daily",
		re: /www\.zqrb\.cn/i,
		qid: 'Q106578050',
		owner: CCP
	},{
		name: "21 Jingji",
		re: /www\.21jingji\.com/i,
		qid: 'Q10845999',
		owner: CCPLocalCommittee
	},{
		name: "Securities Times",
		re: /stcn\.com/i,
		qid: 'Q30944696',
		owner: CCP
	},{
		name: "China Internet Information Center",
		re: /(news|cppcc)\.china\.com\.cn/i,
		qid: 'Q907111',
		owner: CCP
	},{
		name: 'ETtoday',
		re: /ettoday\.net/i,
		qid: 'Q10847025'
	},{
		name: 'Newtalk',
		re: /newtalk\.tw/i,
		qid: 'Q11084535'
	},{
		name: 'Economic View',
		re: /jwview\.com/i,
		owner: CCP,
		qid: 'Q108474004'
	},{
		name: 'Beijing Daily',
		re: /bjd\.com\.cn/i,
		owner: CCPLocalCommittee,
		qid: 'Q86730993'
	},{
		name: 'Guangxi News',
		re: /gxnews\.com\.cn/i,
		qid: 'Q60994910',
		owner: CCPLocalCommittee
	},{
		name: 'Guangming Online',
		re: /gmw\.cn/i,
		owner: CCP,
		qid: 'Q17018623'
	},{
		name: 'Zhejiang Online',
		re: /zjol\.com\.cn/i,
		qid: 'Q15942435',
		owner: CCPLocalCommittee
	},{
		name: 'Apple Daily (Taiwan)',
		re: /appledaily\.com\.tw/i,
		qid: 'Q699499'
	},{
		name: "Government of PRC",
		re: /.+\.gov\.cn/i, // catchall for unspecified ministry subdomains
		owner: CCP,
		qid: 'Q59261'
	},{
		name: 'Jimu News',
		re: /ctdsb\.net/i,
		owner: CCPLocalCommittee,
		qid: 'Q111875341'
	},{
		name: 'China Daily',
		re: /chinadaily\.com\.cn/i,
		owner: CCP,
		qid: 'Q851422'
	},{
		name: 'Centers for Disease Control',
		re: /cdc\.gov\.tw/i,
		qid: 'Q17280566'
	},{
		name: 'Initium',
		re: /theinitium\.com/i,
		qid: 'Q22100888'
	},{
		name: 'Ta Kung Pao',
		re: /takungpao\.com/i,
		qid: 'Q666349'
	},{
		name: 'Antara',
		re: /antaranews\.com/i,
		qid: 'Q571116'
	},{
		name: 'CNA',
		re: /channelnewsasia\.com/i,
		qid: 'Q40238'
	},{
		name: 'Nikkei Asia',
		re: /asia\.nikkei\.com/i,
		qid: 'Q17216388'
	},{
		name: 'Washington Post',
		re: /washingtonpost\.com/i,
		qid: 'Q166032'
	},{
		name: 'Hindustan Times',
		re: /hindustantimes\.com/i,
		qid: 'Q41595'
	},{
		name: 'The Hindu',
		re: /thehindu\.com/i,
		qid: 'Q926175'
	},{
		name: 'Sing Pao Daily News',
		re: /singpao\.com\.hk/i,
		qid: 'Q7522698'
	},{
		name: 'Headline News',
		re: /hd\.stheadline\.com/i,
		qid: 'Q2113001'
	},{
		name: 'Shanghai Securities News',
		re: /cnstock\.com/i,
		qid: 'Q67937048',
		owner: CCP
	},{
		name: 'China Youth Online',
		re: /cyol\.com/i,
		qid: 'Q739728',
		owner: CCP
	},{
		name: 'SouthCN',
		re: /southcn\.com/i,
		qid: 'Q392819',
		owner: CCPLocalCommittee
	},{
		name: 'China Youth Net',
		re: /youth\.cn/i,
		qid: 'Q107529631',
		owner: CCP
	},{
		name: 'QQ.com',
		re: /(new|xw)\.qq.com/i,
		qid: 'Q15912288'
	},{
		name: 'The Jakarta Post',
		re: /thejakartapost\.com/i,
		qid: 'Q2136977'
	},{
		name: 'Al Jazeera',
		re: /aljazeera\.com/i,
		qid: 'Q4727585'
	},{
		name: 'Setkab',
		re: /setkab\.go\.id/i,
		qid: 'Q12513161'
	},{
		name: 'National Energy Council',
		re: /den\.go\.id/i,
		qid: 'Q25454646'
	},{
		name: 'Hong Kong Free Press',
		re: /hongkongfp\.com/i,
		qid: 'Q20720631'
	},{
		name: 'The Guardian',
		re: /theguardian\.com/i,
		qid: 'Q11148'
	},{
		name: 'South China Morning Post',
		re: /scmp\.com/i,
		qid: 'Q1198574'
	},{
		name: 'The Straits Times',
		re: /straitstimes\.com/i,
		qid: 'Q498921'
	},{
		name: 'The New York Times',
		re: /nytimes\.com/i,
		qid: 'Q9684'
	},{
		name: 'The Diplomat',
		re: /thediplomat\.com/i,
		qid: 'Q7730237'
	},{
		name: 'The Japan Times',
		re: /japantimes\.co\.jp/i,
		qid: 'Q1190886'
	},{
		name: 'Financial Times',
		re: /ft\.com/i,
		qid: 'Q183399'
	},{
		name: 'The Telegraph',
		re: /telegraphindia\.com/i,
		qid: 'Q1954990'
	},{
		name: 'Citizen Daily',
		re: /shimindaily\.net/i,
		qid: 'Q6112939'
	},{
		name: 'NHK',
		re: /nhk\.or\.jp/i,
		qid: 'Q212128'
	},{
		name: 'Japan Ministry of Foreign Affairs',
		re: /mofa\.go\.jp/i,
		qid: 'Q222241'
	},{
		name: 'Storm Media Group',
		re: /storm\.mg/i,
		qid: 'Q16927004'
	},{
		name: 'World Economic Forum',
		re: /weforum\.org/i,
		qid: 'Q170418'
	},{
		name: 'Mirror Media',
		re: /mirrormedia\.mg/i,
		qid: 'Q52089378'
	},{
		name: 'IPCC',
		re: /ipcc\.ch/i,
		qid: 'Q171183'
	},{
		name: 'Bloomberg',
		re: /bloomberg\.com/i,
		qid: 'Q13977'
	},{
		name: 'The Times of India',
		re: /indiatimes\.com/i,
		qid: 'Q46807'
	},{
		name: 'Beijing Business Today',
		re: /bbtnews\.com\.cn/i,
		qid: 'Q67934995',
		owner: CCPLocalCommittee
	},{
		name: 'Kyodo News',
		re: /kyodonews\.net/i,
		qid: 'Q779730'
	},{
		name: 'China Digital Times',
		re: /chinadigitaltimes\.net/i,
		qid: 'Q2526385'
	},{
		name: 'Lowy Institute',
		re: /lowyinstitute\.org/i,
		qid: 'Q11145901'
	},{
		name: 'WWF',
		re: /worldwildlife\.org/i,
		qid: 'Q117892'
	},{
		name: 'VnExpress',
		re: /vnexpress\.net/i,
		qid: 'Q10832925'
	},{
		name: 'Firstpost',
		re: /firstpost\.com/i,
		qid: 'Q5453524'
	},{
		name: 'The Wall Street Journal',
		re: /wsj\.com/i,
		qid: 'Q164746'
	},{
		name: 'Asahi Shimbun',
		re: /asahi\.com/i,
		qid: 'Q720503'
	},{
		name: 'The Korea Herald',
		re: /koreaherald\.com/i,
		qid: 'Q562824'
	},{
		name: 'Hong Kong Commercial Daily',
		re: /hkcd\.com/i,
		qid: 'Q6113238'
	},{
		name: 'CNBC',
		re: /cnbc\.com/i,
		qid: 'Q1023912'
	},{
		name: 'Ministry of Finance',
		re: /kemenkeu\.go\.id/i,
		qid: 'Q12490741'
	},{
		name: 'OHCHR',
		re: /ohchr\.org/i,
		qid: 'Q656812'
	},{
		name: 'Shenzhen Xinwen Wang',
		re: /sznews\.com/i,
		qid: 'Q109768663'
	},{
		name: 'NDTV',
		re: /ndtv\.com/i,
		qid: 'Q2985356'
	},{
		name: 'Mainichi Shinbun',
		re: /mainichi\.jp/i,
		qid: 'Q1136866'
	},{
		name: 'Hokkaido Shimbun',
		re: /hokkaido-np\.co\.jp/i,
		qid: 'Q907792'
	},{
		name: 'Tokyo Shimbun',
		re: /tokyo-np\.co\.jp/i,
		qid: 'Q766032'
	},{
		name: 'Business News Network',
		re: /bnnbloomberg\.ca/i,
		qid: 'Q1017576'
	},{
		name: 'The Indian Express',
		re: /indianexpress\.com/i,
		qid: 'Q1954843'
	},{
		name: 'Financial Express',
		re: /financialexpress\.com/i,
		qid: 'Q1332561'
	},{
		name: 'CSIS',
		re: /csis\.org/i,
		qid: 'Q1053614'
	},{
		name: 'Business Standard',
		re: /business-standard\.com/i,
		qid: 'Q2307816'
	},{
		name: 'Yahoo! Hong Kong',
		re: /hk\.news\.yahoo\.com/i,
		qid: 'Q22099769'
	},{
		name: 'Mint',
		re: /livemint\.com/i,
		qid: 'Q2271133'
	},{
		name: 'The Wire',
		re: /thewire\.in/i,
		qid: 'Q39070361'
	},{
		name: 'ThePrint',
		re: /theprint\.in/i,
		qid: 'Q85806279'
	},{
		name: 'India Today',
		re: /indiatoday\.in/i,
		qid: 'Q1661219'
	},{
		name: 'Macao SAR Government Information Bureau',
		re: /gcs\.gov\.mo/i,
		qid: 'Q15933563'
	},{
		name: 'Taiwan Ministry of Foreign Affairs',
		re: /mofa\.gov\.tw/i,
		qid: 'Q697158'
	},{
		name: 'Taiwan Office of the President',
		re: /president\.gov\.tw/i,
		qid: 'Q55601'
	},{
		name: 'TMTPost',
		re: /tmtpost\.com/i,
		qid: 'Q113656239'
	},{
		name: 'Sichuan Online',
		re: /cbgc\.scol\.com\.cn/i,
		qid: 'Q113656259'
	},{
		name: 'Cailianshe',
		re: /cls\.cn/i,
		qid: 'Q113656300'
	},{
		name: 'Cover News',
		re: /thecover\.cn/i,
		qid: 'Q113656335'
	} ,{
		name: 'scroll.in',
		re: /scroll\.in/i,
		qid: 'Q19896243'
	},{
		name: 'China Times',
		re: /chinatimes\.net\.cn/i,
		qid: 'Q10905643'
	},{
		name: 'CNN',
		re: /cnn\.com/i,
		qid: 'Q48340'
	},{
		name: 'The News Minute',
		re: /thenewsminute\.com/i,
		qid: 'Q24590066'
	},{
		name: 'Deccan Herald',
		re: /deccanherald\.com/i,
		qid: 'Q1181753'
	},{
		name: 'Canada Office of the Prime Minister',
		re: /pm\.gc\.ca/i,
		qid: 'Q24569'
	},{
		name: 'Voice of Indonesia',
		re: /voi\.id/i,
		qid: 'Q1063351'
	},{
		name: 'Greenpeace',
		re: /greenpeace\.org/i,
		qid: 'Q81307'
	},{
		name: 'United Nations',
		re: /news\.un\.org/i,
		qid: 'Q1065'
	},{
		name: 'Amnesty International',
		re: /amnesty\.org/i,
		qid: 'Q42970'
	},{
		name: 'Randstad Singapore',
		re: /randstad\.com\.sg/i,
		qid: 'Q113867319'
	},{
		name: 'Singapore National Environment Agency',
		re: /nea\.gov\.sg/i,
		qid: 'Q6972471'
	},{
		name: 'Singapore Ministry of Health',
		re: /moh\.gov\.sg/i,
		qid: 'Q4383964'
	},{
		name: 'Hong Kong Business Times',
		re: /businesstimes\.com\.hk/i,
		qid: 'Q113867337'
	},{
		name: 'Hong Kong Stock Exchange',
		re: /hkex\.com\.hk/i,
		qid: 'Q496672'
	},{
		name: 'Asia News Network',
		re: /asianews\.network/i,
		qid: 'Q2866605'
	},{
		name: 'Outlook',
		re: /outlookindia\.com/i,
		qid: 'Q1955600'
	},{
		name: 'Today',
		re: /todayonline\.com/i,
		qid: 'Q83709164'
	},{
		name: 'Nikkei',
		re: /nikkei\.com/i,
		qid: 'Q1077694'
	},{
		name: 'Yahoo! Finance Hong Kong',
		re: /hk\.finance\.yahoo\.com/i,
		qid: 'Q113867518'
	},{
		name: '36Kr',
		re: /36kr\.com/i,
		qid: 'Q10846071'
	},{
		name: 'Newsis',
		re: /newsis\.com/i,
		qid: 'Q12590695'
	},{
		name: 'Korea JoongAng Daily',
		re: /koreajoongangdaily\.joins\.com/i,
		qid: 'Q489520'
	},{
		name: 'Minami-Nippon Shimbun',
		re: /373news\.com/i,
		qid: 'Q11407895'
	},{
		name: 'Associated Press',
		re: /apnews\.com/i,
		qid: 'Q40469'
	},{
		name: 'Hou Kong Daily',
		re: /houkongdailynews\.com/i,
		qid: 'Q16926635'
	},{
		name: 'Pikiran Rakyat',
		re: /pikiran-rakyat\.com/i,
		qid: 'Q2727002'
	},{
		name: 'Free Malaysia Today',
		re: /freemalaysiatoday\.com/i,
		qid: 'Q5499915'
	},{
		name: 'Life Week',
		re: /lifeweek\.com\.cn/i,
		qid: 'Q60994641'
	},{
		name: 'China National Radio',
		re: /cnr\.cn/i,
		qid: 'Q1072025'
	},{
		name: 'The Week',
		re: /theweek\.in/i,
		qid: 'Q3523335'
	},{
		name: 'Government of Macao SAR',
		re: /gov\.mo/i,
		qid: 'Q1057992'
	},{
		name: 'JTB Tourism Research & Consulting',
		re: /tourism\.jp/i,
		qid: 'Q113867750'
	},{
		name: 'Fuji News Network',
		re: /fnn\.jp/i,
		qid: 'Q843791'
	},{
		name: 'TV Asahi',
		re: /news\.tv-asahi\.co\.jp/i,
		qid: 'Q908436'
	},{
		name: 'The Japan News',
		re: /japannews\.yomiuri\.co\.jp/i,
		qid: 'Q11306616'
	},{
		name: 'Radio France Internationale',
		re: /rfi\.fp/i,
		qid: 'Q19912'
	},{
		name: 'Yonhap News Agency',
		re: /yna\.co\.kr/i,
		qid: 'Q333206'
	},{
		name: 'JoongAng Ilbo',
		re: /joongang\.co\.kr/i,
		qid: 'Q483903'
	},{
		name: 'The Hankyoreh',
		re: /hani\.co\.kr/i,
		qid: 'Q486314'
	},{
		name: 'TVBS Media',
		re: /news\.tvbs\.com\.tw/i,
		qid: 'Q707252'
	},{
		name: 'CommonWealth Magazine',
		re: /cw\.com\.tw/i,
		qid: 'Q10938810'
	},{
		name: 'The Star',
		re: /thestar\.com\.my/i,
		qid: 'Q3522843'
	},{
		name: 'Human Rights Watch',
		re: /hrw\.org/i,
		qid: 'Q187052'
	},{
		name: 'Singapore Ministry of Manpower',
		re: /mom\.gov\.sg/i,
		qid: 'Q4294769'
	},{
		name: 'Hong Kong Journalists Association',
		re: /hkja\.org\.hk/i,
		qid: 'Q5894805'
	},{
		name: 'Radio Television Hong Kong',
		re: /news\.rthk\.hk/i,
		qid: 'Q1153480'
	},{
		name: 'Daily FT',
		re: /ft\.lk/i,
		qid: 'Q5209255'
	},{
		name: 'News18',
		re: /news18\.com/i,
		qid: 'Q1023924'
	},{
		name: 'Deccan Chronicle',
		re: /deccanchronicle\.com/i,
		qid: 'Q1975835'
	},{
		name: 'Newslaundry',
		re: /newslaundry\.com/i,
		qid: 'Q99844616'
	},{
		name: 'Japan Ministry of Health, Labour and Welfare',
		re: /mhlw\.go\.jp/i,
		qid: 'Q1191238'
	},{
		name: 'Radio France Internationale',
		re: /rfi\.fr/i,
		qid: 'Q19912'
	},{
		name: 'The Daily Star',
		re: /thedailystar\.net/i,
		qid: 'Q1586163'
	},{
		name: 'China Daily News',
		re: /cdns\.com\.tw/i,
		qid: 'Q697337'
	},{
		name: 'Myanmar NOW',
		re: /myanmar-now\.org/i,
		qid: 'Q105548053'
	},{
		name: 'Seoul Shinmun',
		re: /seoul\.co\.kr/i,
		qid: 'Q482744'
	},{
		name: 'Kyunghyang Shinmun',
		re: /khan\.co\.kr/i,
		qid: 'Q497170'
	},{
		name: 'News1',
		re: /news1\.kr/i,
		qid: 'Q16162804'
	},{
		name: 'Maeil Business Newspaper',
		re: /mk\.co\.kr/i,
		qid: 'Q625035'
	},{
		name: "Singapore Prime Minister's Office",
		re: /pmo\.gov\.sg/i,
		qid: 'Q7243282'
	},{
		name: 'The Dong-a Ilbo',
		re: /donga\.com/i,
		qid: 'Q486086'
	},{
		name: 'Busan Ilbo',
		re: /busan\.com/i,
		qid: 'Q608410'
	},{
		name: 'Hankook Ilbo',
		re: /hankookilbo\.com/i,
		qid: 'Q489308'
	},{
		name: 'Yahoo! JAPAN',
		re: /news\.yahoo\.co\.jp/i,
		qid: 'Q24887755'
	},{
		name: 'KBS News',
		re: /news\.kbs\.co\.kr/i,
		qid: 'Q85971429'
	},{
		name: 'The Kukmin Daily',
		re: /kmib\.co\.kr/i,
		qid: 'Q10855572'
	},{
		name: 'Radio Free Asia',
		re: /rfa\.org/i,
		qid: 'Q40322'
	},{
		name: 'Segye Ilbo',
		re: /segye\.com/i,
		qid: 'Q624291'
	},{
		name: 'Maeil Sinbo',
		re: /news\.imaeil\.com/i,
		qid: 'Q4309793'
	},{
		name: 'Laotian Times',
		re: /laotiantimes\.com/i,
		qid: 'Q114457330'
	},{
		name: 'Tianshannet',
		re: /ts\.cn/i,
		qid: 'Q48935871'
	},{
		name: 'TBS NEWS DIG',
		re: /newsdig\.tbs\.co\.jp/i,
		qid: 'Q16143608'
	},{
		name: 'Yonhap Television News',
		re: /ytn\.co\.kr/i,
		qid: 'Q487590'
	},{
		name: 'bdnews24.com',
		re: /bdnews24\.com/i,
		qid: 'Q4875421'
	},{
		name: 'Munhwa Ilbo',
		re: /munhwa\.com/i,
		qid: 'Q624791'
	},{
		name: 'Dhaka Tribune',
		re: /dhakatribune\.com/i,
		qid: 'Q17064633'
	},{
		name: 'Jiji Press',
		re: /jiji\.com/i,
		qid: 'Q1688974'
	},{
		name: 'República',
		re: /myrepublica\.nagariknetwork\.com/i,
		qid: 'Q7314771'
	},{
		name: 'Sisa Journal',
		re: /sisajournal\.com/i,
		qid: 'Q3485312'
	},{
		name: 'The Chosun Ilbo',
		re: /chosun\.com/i,
		qid: 'Q483924'
	},{
		name: 'TravelDaily China',
		re: /traveldaily\.cn/i,
		qid: 'Q114742833'
	},{
		name: 'Yomiuri Shimbun',
		re: /yomiuri\.co\.jp/i,
		qid: 'Q645218'
	},{
		name: 'The Business Standard',
		re: /tbsnews\.net/i,
		qid: 'Q113456448'
	},{
		name: 'Singapore National Population and Talent Division',
		re: /population\.gov\.sg/i,
		qid: 'Q114893917'
	},{
		name: 'China Briefing',
		re: /china-briefing\.com/i,
		qid: 'Q114893933'
	},{
		name: 'Time Finance',
		re: /tfcaijing\.com/i,
		qid: 'Q114893948'
	},{
		name: 'Korea Economic Daily',
		re: /hankyung\.com/i,
		qid: 'Q626241'
	},{
		name: 'Asia Times',
		re: /asiatimes\.com/i,
		qid: 'Q727162'
	},{
		name: 'Hong Kong Economic Times',
		re: /inews\.hket\.com/i,
		qid: 'Q5238688'
	},{
		name: 'Kathmandu Post',
		re: /kathmandupost\.com/i,
		qid: 'Q111274238'
	},{
		name: 'Tempo.co',
		re: /en\.tempo\.co/i,
		qid: 'Q25453720'
	},{
		name: 'SBS News',
		re: /news\.sbs\.co\.kr/i,
		qid: 'Q12581797'
	},{
		name: 'The Korea Times',
		re: /koreatimes\.co\.kr/i,
		qid: 'Q486950'
	},{
		name: 'China Dialogue',
		re: /chinadialogue\.net/i,
		qid: 'Q5100082'
	},{
		name: 'Global Views Monthly',
		re: /gvm\.com\.tw/i,
		qid: 'Q17059858'
	},{
		name: 'Zijin Mining Group',
		re: /zjky\.cn/i,
		qid: 'Q202841'
	},{
		name: 'Sinopec',
		re: /sinopecnews\.com\.cn/i,
		qid: 'Q831445'
	},{
		name: 'The Economic Observer',
		re: /eeo\.com\.cn/i,
		qid: 'Q7731522'
	},{
		name: 'Sichuan Online',
		re: /sichuan\.scol\.com\.cn/i,
		qid: 'Q113656259'
	},{
		name: 'Yangcheng Evening News',
		re: /news\.ycwb\.com/i,
		qid: 'Q8048552'
	},{
		name: 'Government of Hong Kong SAR',
		re: /info\.gov\.hk/i,
		qid: 'Q15164'
	},{
		name: 'The Hindu Business Line',
		re: /thehindubusinessline\.com/i,
		qid: 'Q279739'
	},{
		name: 'Chongqing Morning Post',
		re: /cqcb\.com/i,
		qid: 'Q100964991'
	},{
		name: 'Chengdu Economic Daily',
		re: /static\.cdsb\.com/i,
		qid: 'Q11074643'
	},{
		name: 'Hong Kong Economic Journal',
		re: /hkej\.com/i,
		qid: 'Q5894514'
	},{
		name: 'Xinhua Finance',
		re: /cnfin\.com/i,
		qid: 'Q8044591'
	},{
		name: 'EastMojo',
		re: /eastmojo\.com/i,
		qid: 'Q115267645'
	},{
		name: 'Herald Corporation',
		re: /news\.heraldcorp\.com/i,
		qid: 'Q5732646'
	},{
		name: 'Herald Business',
		re: /biz\.heraldcorp\.com/i,
		qid: 'Q5732646'
	},{
		name: 'EconomyNext',
		re: /economynext\.com/i,
		qid: 'Q115267701'
	},{
		name: 'Mongabay-India',
		re: /india\.mongabay\.com/i,
		qid: 'Q1944430'
	},{
		name: 'Mongabay',
		re: /news\.mongabay\.com/i,
		qid: 'Q1944430'
	},{
		name: 'Techweb',
		re: /techweb\.com\.cn/i,
		qid: 'Q115267796'
	},{
		name: 'Beijixing Electric Power Online',
		re: /news\.bjx\.com\.cn/i,
		qid: 'Q115130385'
	},{
		name: 'Northeast Now',
		re: /nenow\.in/i,
		qid: 'Q115267883'
	},{
		name: 'The Asia Business Daily',
		re: /view\.asiae\.co\.kr/i,
		qid: 'Q12605302'
	},{
		name: 'South Korea Ministry of Trade, Industry and Energy',
		re: /english\.motie\.go\.kr/i,
		qid: 'Q491047'
	},{
		name: 'Prime Minister of Australia',
		re: /pm\.gov\.au/i,
		qid: 'Q85794501'
	},{
		name: 'The White House',
		re: /whitehouse\.gov/i,
		qid: 'Q35525'
	},{
		name: 'Government of Canada',
		re: /canada\.ca/i,
		qid: 'Q422404'
	},{
		name: 'Canadian Broadcasting Corporation',
		re: /cbc\.ca/i,
		qid: 'Q461761'
	},{
		name: 'Kuensel',
		re: /kuenselonline\.com/i,
		qid: 'Q2336154'
	},{
		name: 'The Globe and Mail',
		re: /theglobeandmail\.com/i,
		qid: 'Q604525'
	},{
		name: 'Dawn',
		re: /dawn\.com/i,
		qid: 'Q1178770'
	},{
		name: 'Prothom Alo',
		re: /en\.prothomalo\.com/i,
		qid: 'Q2156338'
	},{
		name: 'Guangzhou Daily',
		re: /news\.dayoo\.com/i,
		qid: 'Q842367'
	},{
		name: 'Global Economic News',
		re: /news\.g-enews\.com/i,
		qid: 'Q106149765'
	},{
		name: 'Hohhot News',
		re: /hmcc\.hhhtnews\.com/i,
		qid: 'Q115509964'
	},{
		name: 'Hong Kong Economic Times',
		re: /topick\.hket\.com/i,
		qid: 'Q5238688'
	},{
		name: 'The Quint',
		re: /thequint\.com/i,
		qid: 'Q48734478'
	},{
		name: 'China Internet Information Center',
		re: /finance\.china\.com\.cn/i,
		qid: 'Q907111'
	},{
		name: 'Fuzhou News Network',
		re: /mag\.fznews\.com\.cn/i,
		qid: 'Q115510437'
	},{
		name: 'Bhutan Times',
		re: /bhutantimes\.bt/i,
		qid: 'Q2635013'
	},{
		name: 'New Age',
		re: /newagebd\.net/i,
		qid: 'Q16764706'
	},{
		name: 'World Health Organization',
		re: /who\.int/i,
		qid: 'Q7817'
	},{
		name: 'Jakarta Globe',
		re: /jakartaglobe\.id/i,
		qid: 'Q367157'
	},{
		name: 'Medcom.id',
		re: /medcom\.id/i,
		qid: 'Q56416498'
	},{
		name: 'Observer Research Foundation',
		re: /orfonline\.org/i,
		qid: 'Q10860333'
	},{
		name: 'International Labour Organization',
		re: /ilo\.org/i,
		qid: 'Q54129'
	},{
		name: 'Carnegie Endowment for International Peace',
		re: /carnegieendowment\.org/i,
		qid: 'Q1153595'
	},{
		name: 'The Tribune',
		re: /tribuneindia\.com/i,
		qid: 'Q1922367'
	},{
		name: 'Munhwa Broadcasting Corporation',
		re: /imnews\.imbc\.com/i,
		qid: 'Q482607'
	},{
		name: 'chnfund.com',
		re: /chnfund\.com/i,
		qid: 'Q115729334'
	},{
		name: 'Sixth Tone',
		re: /sixthtone\.com/i,
		qid: 'Q64827433'
	},{
		name: 'Investing.com',
		re: /investing\.com/i,
		qid: 'Q16849546'
	},{
		name: 'Foxconn',
		re: /honhai\.com/i,
		qid: 'Q463094'
	},{
		name: 'S&P Global',
		re: /spglobal\.com/i,
		qid: 'Q868587'
	},{
		name: 'VFS Global',
		re: /visa\.vfsglobal\.com/i,
		qid: 'Q7906873'
	},{
		name: 'Moneycontrol',
		re: /moneycontrol\.com/i,
		qid: 'Q19573046'
	},{
		name: 'Lok Sujag',
		re: /loksujag\.com/i,
		qid: 'Q115987705'
	},{
		name: 'Dailypharm',
		re: /dailypharm\.com/i,
		qid: 'Q115987713'
	},{
		name: 'The Logical Indian',
		re: /thelogicalindian\.com/i,
		qid: 'Q115987727'
	},{
		name: 'Nippon.com',
		re: /nippon\.com/i,
		qid: 'Q37630066'
	},{
		name: 'Exmoo News',
		re: /exmoo\.com/i,
		qid: 'Q10900644'
	},{
		name: 'Dainik Bhaskar',
		re: /bhaskar\.com/i,
		qid: 'Q1872524'
	},{
		name: 'Online Khabar',
		re: /english\.onlinekhabar\.com/i,
		qid: 'Q107007788'
	},{
		name: 'Rappler',
		re: /rappler\.com/i,
		qid: 'Q14903716'
	},{
		name: 'Taipei Times',
		re: /taipeitimes\.com/i,
		qid: 'Q714427'
	},{
		name: 'The Financial News',
		re: /fnnews\.com/i,
		qid: 'Q113663680'
	},{
		name: 'National Post',
		re: /nationalpost\.com/i,
		qid: 'Q1812075'
	},{
		name: 'The Times of Addu',
		re: /timesofaddu\.com/i,
		qid: 'Q115987840'
	},{
		name: 'Foreign Policy',
		re: /foreignpolicy\.com/i,
		qid: 'Q1063573'
	},{
		name: 'The Seoul Economic Daily',
		re: /sedaily\.com/i,
		qid: 'Q12601146'
	},{
		name: 'Economic Information Daily',
		re: /jjckb\.cn/i,
		qid: 'Q10473364'
	},{
		name: 'China News Weekly',
		re: /inewsweek\.cn/i,
		qid: 'Q10873813'
	},{
		name: 'Hainan Daily',
		re: /hndaily\.cn/i,
		qid: 'Q5639358'
	},{
		name: 'Supreme Court Observer',
		re: /scobserver\.in/i,
		qid: 'Q115988068'
	},{
		name: 'Northeast Today',
		re: /northeasttoday\.in/i,
		qid: 'Q115988074'
	},{
		name: 'VietnamPlus',
		re: /en\.vietnamplus\.vn/i,
		qid: 'Q98965362'
	},{
		name: 'Ryūkyū Shimpō',
		re: /ryukyushimpo\.jp/i,
		qid: 'Q4539663'
	},{
		name: 'Money Today',
		re: /news\.mt\.co\.kr/i,
		qid: 'Q12595017'
	},{
		name: 'Anadolu Agency',
		re: /aa\.com\.tr/i,
		qid: 'Q477436'
	},{
		name: 'Xinhua Daily',
		re: /xhby\.net/i,
		qid: 'Q3428963'
	},{
		name: 'Australian Broadcasting Corporation',
		re: /abc\.net\.au/i,
		qid: 'Q781365'
	},{
		name: 'Executive Yuan',
		re: /ey\.gov\.tw/i,
		qid: 'Q715055'
	},{
		name: 'Statista',
		re: /statista\.com/i,
		qid: 'Q2333891'
	},{
		name: 'Sankei Shimbun',
		re: /sankei\.com/i,
		qid: 'Q1197261'
	},{
		name: 'The Statesman',
		re: /thestatesman\.com/i,
		qid: 'Q372096'
	},{
		name: 'The News Lens',
		re: /thenewslens\.com/i,
		qid: 'Q24850576'
	},{
		name: 'Jawa Pos',
		re: /jawapos\.com/i,
		qid: 'Q7355586'
	},{
		name: 'OhmyNews',
		re: /ohmynews\.com/i,
		qid: 'Q176542'
	},{
		name: 'South First',
		re: /thesouthfirst\.com/i,
		qid: 'Q116269909'
	},{
		name: 'Deutsche Welle',
		re: /dw\.com/i,
		qid: 'Q153770'
	},{
		name: 'The Irrawaddy',
		re: /irrawaddy\.com/i,
		qid: 'Q1429506'
	},{
		name: 'Economic Daily',
		re: /ce\.cn/i,
		qid: 'Q15900092'
	},{
		name: 'Kyoto Shimbun',
		re: /kyoto-np\.co\.jp/i,
		qid: 'Q6452210'
	},{
		name: 'EDAILY',
		re: /edaily\.co\.kr/i,
		qid: 'Q116270036'
	},{
		name: 'Korean Statistical Information Service',
		re: /kosis\.kr/i,
		qid: 'Q65819793'
	},{
		name: 'Central News Agency',
		re: /focustaiwan\.tw/i,
		qid: 'Q697130'
	},{
		name: 'UP Media',
		re: /upmedia\.mg/i,
		qid: 'Q28410418'
	},{
		name: 'Atlantic Council',
		re: /atlanticcouncil\.org/i,
		qid: 'Q756373'
	},{
		name: 'TAPCPR',
		re: /tapcpr\.org/i,
		qid: 'Q17013197'
	},{
		name: 'The Express Tribune',
		re: /tribune\.com\.pk/i,
		qid: 'Q7732865'
	},{
		name: 'ABP News',
		re: /news\.abplive\.com/i,
		qid: 'Q3630156'
	},{
		name: 'Khmer Times',
		re: /khmertimeskh\.com/i,
		qid: 'Q55615930'
	},{
		name: 'Malay Mail',
		re: /malaymail\.com/i,
		qid: 'Q4808924'
	},{
		name: 'The Sentinel',
		re: /sentinelassam\.com/i,
		qid: 'Q2543939'
	},{
		name: 'The Meghalayan',
		re: /themeghalayan\.com/i,
		qid: 'Q116715040'
	},{
		name: 'Sina Weibo',
		re: /weibo\.com/i,
		qid: 'Q92526'
	},{
		name: 'Incheon Ilbo',
		re: /incheonilbo\.com/i,
		qid: 'Q116717288'
	},{
		name: 'The Philippine Star',
		re: /philstar\.com/i,
		qid: 'Q6489289'
	},{
		name: 'Twitter',
		re: /twitter\.com/i,
		qid: 'Q918'
	},{
		name: 'Nepali Times',
		re: /nepalitimes\.com/i,
		qid: 'Q6994521'
	},{
		name: 'CNN Philippines',
		re: /cnnphilippines\.com/i,
		qid: 'Q7679675'
	},{
		name: 'The Phnom Penh Post',
		re: /phnompenhpost\.com/i,
		qid: 'Q921095'
	},{
		name: 'Bangkok Post',
		re: /bangkokpost\.com/i,
		qid: 'Q806491'
	},{
		name: 'Chinese Center for Disease Control and Prevention',
		re: /chinacdc\.cn/i,
		qid: 'Q5100405'
	},{
		name: 'Life Times',
		re: /lifetimes\.cn/i,
		qid: 'Q48904327'
	},{
		name: 'Imphal Free Press',
		re: /ifp\.co\.in/i,
		qid: 'Q6007128'
	},{
		name: 'The Leaflet',
		re: /theleaflet\.in/i,
		qid: 'Q116719915'
	},{
		name: 'Tuổi Trẻ',
		re: /tuoitrenews\.vn/i,
		qid: 'Q7853413'
	},{
		name: 'Việt Nam News',
		re: /vietnamnews\.vn/i,
		qid: 'Q7938092'
	},{
		name: 'Philippine Daily Inquirer',
		re: /newsinfo\.inquirer\.net/i,
		qid: 'Q1831242'
	},{
		name: 'The Edition',
		re: /edition\.mv/i,
		qid: 'Q116720090'
	},{
		name: 'United States Bureau of Industry and Security',
		re: /bis\.doc\.gov/i,
		qid: 'Q455289'
	},{
		name: 'United States Department of State',
		re: /state\.gov/i,
		qid: 'Q789915'
	},{
		name: 'Commercial Times',
		re: /ctee\.com\.tw/i,
		qid: 'Q5152534'
	},{
		name: 'Taiwan Ministry of Economic Affairs',
		re: /moea\.gov\.tw/i,
		qid: 'Q697113'
	},{
		name: 'Taiwan Judicial Yuan',
		re: /judicial\.gov\.tw/i,
		qid: 'Q31041'
	},{
		name: 'Taiwan Directorate-General of Budget, Accounting and Statistics',
		re: /ws\.dgbas\.gov\.tw/i,
		qid: 'Q5280609'
	},{
		name: 'New Straits Times',
		re: /nst\.com\.my/i,
		qid: 'Q1953092'
	},{
		name: 'Government of Alberta',
		re: /alberta\.ca/i,
		qid: 'Q33121932'
	},{
		name: 'Sing Tao Daily',
		re: /singtao\.ca/i,
		qid: 'Q7522711'
	},{
		name: 'CTV News',
		re: /ctvnews\.ca/i,
		qid: 'Q5014635'
	},{
		name: 'The Observatory of Economic Complexity',
		re: /oec\.world/i,
		qid: 'Q7754641'
	},{
		name: 'American Chamber of Commerce in China',
		re: /amchamchina\.org/i,
		qid: 'Q25048224'
	},{
		name: 'UNICEF',
		re: /unicef\.org/i,
		qid: 'Q740308'
	},{
		name: 'The Business Times',
		re: /businesstimes\.com\.sg/i,
		qid: 'Q2928751'
	},{
		name: 'Mothership.sg',
		re: /mothership\.sg/i,
		qid: 'Q113645786'
	},{
		name: 'am730',
		re: /am730\.com\.hk/i,
		qid: 'Q307801'
	},{
		name: 'Hong Kong Education Bureau',
		re: /edb\.gov\.hk/i,
		qid: 'Q2301502'
	},{
		name: 'Hong Kong Census and Statistics Department',
		re: /censtatd\.gov\.hk/i,
		qid: 'Q839897'
	},{
		name: 'Tatoli',
		re: /id\.tatoli\.tl/i,
		qid: 'Q26794434'
	},{
		name: 'Tatoli',
		re: /en\.tatoli\.tl/i,
		qid: 'Q26794434'
	},{
		name: 'Article14',
		re: /article-14\.com/i,
		qid: 'Q116780439'
	},{
		name: 'Daily Janakantha',
		re: /dailyjanakantha\.com/i,
		qid: 'Q6150696'
	},{
		name: 'Daily News and Analysis',
		re: /dnaindia\.com/i,
		qid: 'Q1954041'
	},{
		name: 'Forbes India',
		re: /forbesindia\.com/i,
		qid: 'Q17053070'
	},{
		name: 'CNN Indonesia',
		re: /cnnindonesia\.com/i,
		qid: 'Q18148009'
	},{
		name: 'Bernama',
		re: /bernama\.com/i,
		qid: 'Q822202'
	},{
		name: 'The Daily Observer',
		re: /observerbd\.com/i,
		qid: 'Q42406042'
	},{
		name: 'Bangla Tribune',
		re: /banglatribune\.com/i,
		qid: 'Q28126618'
	},{
		name: 'Facebook',
		re: /facebook\.com/i,
		qid: 'Q355'
	},{
		name: 'GMA Network',
		re: /gmanetwork\.com/i,
		qid: 'Q399643'
	},{
		name: 'Nippon Steel Corporation',
		re: /nipponsteel\.com/i,
		qid: 'Q1151693'
	},{
		name: 'ABC News',
		re: /abcbews\.go\.com/i,
		qid: 'Q287171'
	},{
		name: 'The Daily Prothom Alo ',
		re: /prothomalo\.com/i,
		qid: 'Q2156338'
	},{
		name: 'Kompas',
		re: /.+\.kompas\.com/i,
		qid: 'Q4405665'
	},{
		name: 'The Himalayan Times',
		re: /thehimalayantimes\.com/i,
		qid: 'Q7739720'
	},{
		name: 'CBS News',
		re: /cbsnews\.com/i,
		qid: 'Q861764'
	},{
		name: 'NOWnews',
		re: /nownews\.com/i,
		qid: 'Q10883984'
	},{
		name: 'Times Now',
		re: /timesnownews\.com/i,
		qid: 'Q7806547'
	},{
		name: 'ZDNET',
		re: /japan\.zdnet\.com/i,
		qid: 'Q2457578'
	},{
		name: 'Ynet',
		re: /news\.ynet\.com/i,
		qid: 'Q2738307'
	},{
		name: 'Dazhong Daily',
		re: /w\.dzwww\.com/i,
		qid: 'Q10933526'
	},{
		name: 'China Womens News',
		re: /cnwomen\.com\.cn/i,
		qid: 'Q10873573'
	},{
		name: 'The Caravan',
		re: /caravanmagazin\.in/i,
		qid: 'Q7721321'
	},{
		name: 'Tempo',
		re: /nasional\.tempo\.co/i,
		qid: 'Q3517741'
	},{
		name: 'Tempo',
		re: /bisnis\.tempo\.co/i,
		qid: 'Q3517741'
	},{
		name: 'The Okinawa Times',
		re: /okinawatimes\.co\.jp/i,
		qid: 'Q4539628'
	},{
		name: 'Japan International Cooperation Agency',
		re: /jica\.go\.jp/i,
		qid: 'Q958590'
	},{
		name: 'Government of South Korea',
		re: /korea\.kr/i,
		qid: 'Q626814'
	},{
		name: 'Yonhap News TV',
		re: /yonhapnewstv\.co\.kr/i,
		qid: 'Q16162835'
	},{
		name: 'South Korea Ministry of Foreign Affairs',
		re: /mofa\.go\.kr/i,
		qid: 'Q9405654'
	},{
		name: 'The Manila Times',
		re: /manilatimes\.net/i,
		qid: 'Q1573100'
	},{
		name: 'ReliefWeb',
		re: /reliefweb\.int/i,
		qid: 'Q11348577'
	},{
		name: 'Avas',
		re: /avas\.mv/i,
		qid: 'Q116780479'
	},{
		name: 'Federal Register',
		re: /federalregister\.gov/i,
		qid: 'Q5440362'
	},{
		name: 'Radio Taiwan International',
		re: /rti\.org\.tw/i,
		qid: 'Q698884'
	},{
		name: 'Mainland Affairs Council',
		re: /mac\.gov\.tw/i,
		qid: 'Q705141'
	},{
		name: 'National Development Council',
		re: /ndc\.gov\.tw/i,
		qid: 'Q15637493'
	},{
		name: 'East Asia Forum',
		re: /eastasiaforum\.org/i,
		qid: 'Q5327731'
	},{
		name: 'BenarNews',
		re: /benarnews\.org/i,
		qid: 'Q117193892'
	},{
		name: 'Manila Bulletin',
		re: /mb\.com\.ph/i,
		qid: 'Q1858373'
	},{
		name: 'oeeee.com',
		re: /m\.mp\.oeeee\.com/i,
		qid: 'Q117193904'
	},{
		name: 'India Briefing',
		re: /india-briefing\.com/i,
		qid: 'Q117193919'
	},{
		name: 'detikcom',
		re: /news\.detik\.com/i,
		qid: 'Q12481355'
	},{
		name: 'ABC News',
		re: /abcnews\.go\.com/i,
		qid: 'Q287171'
	},{
		name: 'Yahoo! Canada',
		re: /ca\.news\.yahoo\.com/i,
		qid: 'Q117193928'
	},{
		name: 'The Thaiger',
		re: /thethaiger\.com/i,
		qid: 'Q117193932'
	},{
		name: 'Ynet',
		re: /epaper\.ynet\.com/i,
		qid: 'Q2738307'
	},{
		name: 'Xin Kuaibao',
		re: /epaper\.xkb\.com\.cn/i,
		qid: 'Q11082773'
	},{
		name: 'The Caravan',
		re: /caravanmagazine\.in/i,
		qid: 'Q7721321'
	},{
		name: 'Chungnam Ilbo',
		re: /chungnamilbo\.co\.kr/i,
		qid: 'Q117193961'
	},{
		name: 'The Guru',
		re: /theguru\.co\.kr/i,
		qid: 'Q117193964'
	},{
		name: 'Korea Economy TV',
		re: /wowtv\.co\.kr/i,
		qid: 'Q16181296'
	},{
		name: 'Kahoku Shimpo',
		re: /kahoku\.news/i,
		qid: 'Q639774'
	},{
		name: 'Philippine Daily Inquirer',
		re: /globalnation\.inquirer\.net/i,
		qid: 'Q1831242'
	},{
		name: 'Sing Tao Daily',
		re: /stheadline\.com/i,
		qid: 'Q5241255'
	},{
		name: 'MSN',
		re: /msn\.com/i,
		qid: 'Q192845'
	},{
		name: 'Blue Whale Finance',
		re: /lanjinger\.com/i,
		qid: 'Q117288654'
	},{
		name: 'Shizuoka Shimbun',
		re: /at-s\.com/i,
		qid: 'Q904670'
	},{
		name: 'Caijing',
		re: /tech\.caijing\.com\.cn/i,
		qid: 'Q13631036'
	},{
		name: 'Asian News International',
		re: /aninews\.in/i,
		qid: 'Q2613165'
	},{
		name: 'Kang Won Ilbo',
		re: /kwnews\.co\.kr/i,
		qid: 'Q12583033'
	},{
		name: 'United News of Bangladesh',
		re: /unb\.com\.bd/i,
		qid: 'Q7888991'
	},{
		name: 'Kyeonggi Ilbo',
		re: /kyeonggi\.com/i,
		qid: 'Q12583561'
	},{
		name: 'Dhaka Post',
		re: /dhakapost\.com/i,
		qid: 'Q110078778'
	},{
		name: 'China Will Registration Center',
		re: /will\.org\.cn/i,
		qid: 'Q117319653'
	},{
		name: 'Parliament of Canada',
		re: /parl\.ca/i,
		qid: 'Q475689'
	},{
		name: 'Oriental Daily News',
		re: /orientaldaily\.on\.cc/i,
		qid: 'Q1507352'
	},{
		name: 'ASEAN Indonesia 2023',
		re: /asean2023\.id/i,
		qid: 'Q4654196'
	},{
		name: 'Association of Southeast Asian Nations',
		re: /asean\.org/i,
		qid: 'Q7768'
	},{
		name: 'Government of Timor-Leste',
		re: /timor-leste\.gov\.tl/i,
		qid: 'Q18630090'
	},{
		name: 'Voice of America',
		re: /voakorea\.com/i,
		qid: 'Q228389'
	},{
		name: 'Zee News',
		re: /zeenews\.india\.com/i,
		qid: 'Q5287969'
	},{
		name: 'The Morung Express',
		re: /morungexpress\.com/i,
		qid: 'Q1811512'
	},{
		name: 'Business Today',
		re: /businesstoday\.in/i,
		qid: 'Q5001804'
	},{
		name: 'United States Agency for International Development',
		re: /usaid\.gov/i,
		qid: 'Q217072'
	},{
		name: 'Public Television Service',
		re: /news\.pts\.org\.tw/i,
		qid: 'Q712020'
	},{
		name: 'Taiwan Television',
		re: /news\.ttv\.com\.tw/i,
		qid: 'Q700932'
	},{
		name: 'Aichi Prefectural Government',
		re: /pref\.aichi\.jp/i,
		qid: 'Q11494124'
	},{
		name: 'National Herald',
		re: /nationalheraldindia\.com/i,
		qid: 'Q12436127'
	},{
		name: 'Think Hong Kong',
		re: /thinkhk\.com/i,
		qid: 'Q117621516'
	},{
		name: 'The Federal',
		re: /thefederal\.com/i,
		qid: 'Q117621614'
	},{
		name: 'WION',
		re: /wionews\.com/i,
		qid: 'Q23058781'
	},{
		name: 'Government of Taiwan',
		re: /.+\.gov\.tw/i,
		qid: 'Q5589404'
	},{
		name: 'World Bank Open Data',
		re: /data\.worldbank\.org/i,
		qid: 'Q21540096'
	},{
		name: 'Jamestown Foundation',
		re: /jamestown\.org/i,
		qid: 'Q2090146'
	},{
		name: 'Apple',
		re: /apple\.com/i,
		qid: 'Q312'
	},{
		name: 'Mathrubhumi',
		re: /.+\.mathrubhumi\.com/i,
		qid: 'Q734491'
	},{
		name: 'SET News',
		re: /setn\.com/i,
		qid: 'Q7389900'
	},{
		name: 'Kaler Kantho',
		re: /kalerkantho\.com/i,
		qid: 'Q6352152'
	},{
		name: 'The Cambodia Daily',
		re: /.+\.cambodiadaily\.com/i,
		qid: 'Q3057820'
	},{
		name: 'Vietnam Insider',
		re: /vietnaminsider\.vn/i,
		qid: 'Q117804897'
	},{
		name: 'VietnamNet',
		re: /vietnamnet\.vn/i,
		qid: 'Q10832589'
	},{
		name: 'Kompas',
		re: /kompas\.id/i,
		qid: 'Q4405665'
	},{
		name: 'United Nations',
		re: /un\.org/i,
		qid: 'Q1065'
	},{
		name: 'The Standard',
		re: /thestandard\.com\.hk/i,
		qid: 'Q908244'
	},{
		name: 'Daily Pakistan',
		re: /.+\.dailypakistan\.com\.pk/i,
		qid: 'Q5209334'
	},{
		name: 'The Independent',
		re: /independent\.co\.uk/i,
		qid: 'Q11149'
	},{
		name: 'CNBC Indonesia',
		re: /cnbcindonesia\.com/i,
		qid: 'Q25469731'
	},{
		name: 'Republic TV',
		re: /republicworld\.com/i,
		qid: 'Q28180276'
	},{
		name: 'YouTube',
		re: /youtube\.com/i,
		qid: 'Q866'
	},{
		name: 'Vice',
		re: /vice\.com/i,
		qid: 'Q249838'
	},{
		name: 'Time',
		re: /time\.com/i,
		qid: 'Q43297'
	},{
		name: 'Bilibili',
		re: /bilibili\.com/i,
		qid: 'Q3077586'
	},{
		name: 'The Economist',
		re: /economist\.com/i,
		qid: 'Q180089'
	},{
		name: 'Global Affairs Canada',
		re: /.+\.gc\.ca/i,
		qid: 'Q3315371'
	},{
		name: 'Monetary Authority of Singapore',
		re: /mas\.gov\.sg/i,
		qid: 'Q2661296'
	},{
		name: 'The Points',
		re: /points-media\.com/i,
		qid: 'Q118469534'
	},{
		name: 'Leju Finance',
		re: /lejucaijing\.com/i,
		qid: 'Q118469543'
	},{
		name: 'Toronto Star',
		re: /thestar\.com/i,
		qid: 'Q1067299'
	},{
		name: 'Press Information Bureau',
		re: /pib\.gov\.in/i,
		qid: 'Q7241619'
	},{
		name: 'Jiankang Shibao',
		re: /jksb\.com\.cn/i,
		qid: 'Q107684894'
	},{
		name: 'The Investor',
		re: /theinvestor\.vn/i,
		qid: 'Q118469789'
	},{
		name: 'Content Overseas Distribution Association',
		re: /coda-cj\.jp/i,
		qid: 'Q85871337'
	},{
		name: "Prime Minister's Office of Japan",
		re: /.+\.kantei\.go\.jp/i,
		qid: 'Q659013'
	},{
		name: 'Kookje Daily News',
		re: /kookje\.co\.kr/i,
		qid: 'Q46184449'
	}
]

//console.log( publishers.map(p=>`wd:${p.qid}`).join(' ') )

/* to help find organizations from websites
SELECT ?org ?orgLabel ?website
WHERE {
  ?org wdt:P856 ?website.
  FILTER ( REGEX( STR(?website), 'people.com.cn' ) )
  SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
}
LIMIT 100
*/

/* working on a query to identify CCP controlled sources
SELECT ?source ?sourceLabel ?owner ?is_ccp
WHERE {
  VALUES ?source { wd:Q938668 wd:Q969272 wd:Q965133 wd:Q970443 wd:Q17499997 wd:Q66436069 wd:Q204839 wd:Q20688847 wd:Q3273611 wd:Q207936 wd:Q17500632 }
  OPTIONAL { ?source ( wdt:P127 | wdt:P749 | wdt:P112 )+ ?owner }
  BIND( sameTerm( ?owner, wd:Q17427 ) AS ?is_ccp )
  SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
}

*/
