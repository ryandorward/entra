import { useParams } from 'react-router-dom'
import { useQuery, gql } from '@apollo/client'
// import { useReactiveVar } from '@apollo/client'
// import { timeRange } from '../timeRange.js'
import ShowOnlyTo from '../../ShowOnlyTo'
import Headlines from '../Headlines'
import FlexList from '../../layouts/FlexList'
import Title from '../../components/Title'
// import { sharedEventQueryArgs, sharedEventQueryVariables } from './sharedEventQueryArgs'

const query = gql`
query ( $tags: [Int]! ){
	tags ( id: $tags ) { id name themes { id name color } }
}`

export default function(){
	const { tag_id } = useParams()
	// const { before, after } = useReactiveVar(timeRange)
	const { data } = useQuery( query, { variables: {
		tags: Number(tag_id) ?? undefined
	} } )
	const tagName = data?.tags?.at(0)?.name
	const themes = data?.tags?.at(0)?.themes ?? []
	return (
		<>
			{ tagName  && <Title>
					{`Events tagged "${tagName}"`}
				</Title>
			}
			<div>
				<Headlines top={50} sort="date" tags={[Number(tag_id)]}/>
				{/* <Headlines top={50} sort="date" tags={[Number(tag_id)]}
					{...{before,after}}/> */}
			</div>
			{themes.length > 0 &&
				<div className="themes">
					<h3>{`Topics that include "${tagName}":`}</h3>
					<FlexList
						list={themes}
						nameFunc={theme=>theme.name}
						linkFunc={theme=>`/map/events/theme/${theme.id}`}
						colorFunc={theme=>theme.color}
						classFunc={()=>`theme`}
					/>
				</div>
			}

			<ShowOnlyTo minRole="analyst">
				<a href={`https://www.asiapacific.ca/taxonomy/term/${tag_id}/edit`}
					target="_blank" rel="noreferrer">Edit this tag</a>
			</ShowOnlyTo>
		</>
	)
}
