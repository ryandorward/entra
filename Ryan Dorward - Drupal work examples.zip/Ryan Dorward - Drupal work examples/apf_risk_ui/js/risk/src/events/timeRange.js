import { makeVar } from '@apollo/client'
import { DateTime } from 'luxon'

// TODO not stored anywhere yet // will always use default
const storedValue = JSON.parse(window.localStorage.getItem('timeRange'))

export const defaultValue = {
	before: DateTime.now().plus({days:1}).toISODate(),
	after: DateTime.now().minus({year:1}).toISODate()
}

export const timeRange = makeVar( storedValue ?? defaultValue )
