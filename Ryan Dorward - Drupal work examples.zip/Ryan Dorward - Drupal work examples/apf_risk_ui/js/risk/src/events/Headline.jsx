import { useState, useEffect, useRef } from 'react';
import { useReactiveVar } from '@apollo/client'
import { regionLabel } from '@apfcanada/jurisdictions'
import graph from '../jurisdictions/graph'
import { currentlyHoveredEventId, listenForHoverEvent } from '../utilities/hover.js'
import { colorFromThemes } from './ESG/colorFromThemes.js'
import { lighter } from '../utilities/lighter.js'
import { timeAgo } from '../utilities/time/format'
import LinkWrapper from '../LinkWrapper'
import './headline.less'

export default function Headline({id,title,date,themes,geo_ids,relation}){
	const ref = useRef()
	const [ region, setRegion ] = useState(undefined)
	const [ dotStyle, setDotStyle ] = useState(undefined)
	const hovered = id == useReactiveVar(currentlyHoveredEventId)
	useEffect(()=>{
		if(geo_ids){
			graph.lookup(geo_ids).then( jurs => setRegion( regionLabel(jurs) ) )
		}
	},[geo_ids])
	useEffect(()=>{
		if(themes){
			const color = colorFromThemes(themes)
			setDotStyle({
				backgroundColor: color ? lighter(color) : 'white',
				borderColor: color ?? 'grey'
			})
		}
	},[themes])

	useEffect(()=>{
		listenForHoverEvent(ref.current,id)
	},[])

	return (
		<LinkWrapper
			path={`/map/event/${id}`}
			className={`headline id-${id}`}
		>
			<div ref={ref} className={`standard` + (hovered?` active`:``)}>
				<div className='meta'>
					{relation && <div className='relation-label'>{relation}</div>}
					<div className='themeDot' style={dotStyle}/>
					<div className='age'>{timeAgo(date)}</div>
					{region &&
						<div className='region-label'>{region}</div>
					}
				</div>
				<div className="title">{title}</div>
			</div>
		</LinkWrapper>
	)
}