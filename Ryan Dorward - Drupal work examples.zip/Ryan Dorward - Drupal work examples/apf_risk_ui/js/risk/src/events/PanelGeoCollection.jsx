import { useParams } from 'react-router-dom'
import Headlines from './Headlines'
// import { timeRange } from './timeRange.js'

export default function(){
	const { geo_id } = useParams()
	// const indirect = useReactiveVar(indirectQuery)
	// const { before, after } = useReactiveVar(timeRange)
	return (
		<>
			{/*
				A bit inconsistent but title is handled external to this, along with nav and flag thing in /jurisdictions/PanelHeader
				via Panel.jsx
			*/}
			<div>
				<Headlines top={50} sort="date" in={Number(geo_id)}
					withDescendants={true}/>
			</div>
		</>
	)
}
