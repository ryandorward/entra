import { useEffect } from 'react'
import { makeVar, useReactiveVar } from '@apollo/client'

const storageVar = 'includeIndirectEvents'

export const indirectQuery = makeVar(
	Boolean(JSON.parse(window.localStorage.getItem(storageVar))) // default false
)

export default function QueryOptions(){
	const indirect = useReactiveVar(indirectQuery)
	useEffect(()=>{
		window.localStorage.setItem(storageVar,indirect)
	},[indirect])
	return(
		<div>
			<input id="indirect" type="checkbox" 
				checked={indirect} onChange={()=>indirectQuery(!indirect)}/>
			<label htmlFor="indirect"><i>Include indirect events</i></label>
		</div>
	)
}
