import { Link } from 'react-router-dom'
import { useQuery, gql } from '@apollo/client'
import { Spinner } from '../../Spinners'
import Headlines from '../Headlines'
import ContrastText from '../../layouts/ContrastText'

const query = gql`
fragment themeBasics on Theme { id name color }
query { 
	events ( top: 500 ) { id themes { id } }
	themes { 
		...themeBasics geo_ids
		tags { id } description isMeta 
		childThemes { ...themeBasics }
		parentThemes { ...themeBasics }
	} 
}`

export default function(){
	const { data } = useQuery(query)
	if(!data) return <Spinner contained size={50}/>;
	const { events, themes } = data
	const unthemedEvents = events.filter(e=>e.themes.length==0)
	return (
		<>
			<h1>Event theming stats</h1>
			<p>Includes all {themes.length} themes and last 500 published events</p>
			<table>
				<thead>
					<tr>
						<th>Name</th>
						<th>Children</th>
						<th>Parents</th>
						<th>Event Count</th>
						<th>Top theme</th>
						<th>Tag Count</th>
						<th>Desc. word count</th>
						<th>Scoped</th>
					</tr>
				</thead>
				<tbody>
				{[...themes].sort((a,b)=>b.isMeta-a.isMeta).map( theme => {
					const themeEvents = events.filter( event => {
						return event.themes.some( t => t.id == theme.id )
					} )
					const themePrimeEvents = themeEvents.filter( event => {
						return event.themes?.[0]?.id == theme.id
					} )
					const text = theme.description ?? ''
					const wordCount = text.match(/\S+/g)?.length ?? 0;
					const wordLengthGood = wordCount > 50 && wordCount < 200
					return (
						<tr key={theme.id}>
							<td style={{
								backgroundColor: theme.color,
								padding: '5px',textAlign:'center',
								fontWeight: theme.isMeta ? 'bold' : undefined
							}}>
								<ContrastText againstColor={theme.color}>
									<Link to={`/about/events/theme/${theme.id}`}>
										{theme.name}
									</Link>
								</ContrastText>
							</td>
							<td>{theme.childThemes.map(ct=><ThemeRef key={ct.id} theme={ct}/>)}</td>
							<td>{theme.parentThemes.map(pt=><ThemeRef key={pt.id} theme={pt}/>)}</td>
							<td>{themeEvents.length}</td>
							<td>{(100*(themePrimeEvents.length/themeEvents.length)).toPrecision(2)}%</td>
							<td>{theme.tags.length}</td>
							<td style={wordLengthGood?{}:{color:'red'}}>
								{wordCount}
							</td>
							<td>{theme.geo_ids.length > 0 ? '\u2713':''}</td>
						</tr>
					)
				} )}
				</tbody>
			</table>
			{unthemedEvents.length > 0 && <>
				<h3>Events with no themes assigned</h3>
				<Headlines ids={unthemedEvents.map(event=>event.id)}/>
			</>}
			
		</>	
	)
}

function ThemeRef({theme}){
	const { id, name, color } = theme
	return (
		<div title={name} style={{backgroundColor:color,textAlign:'center'}}>
			<ContrastText againstColor={color}>{id}</ContrastText>
		</div>
	)
}
