import { useState, useEffect } from 'react';
import { useQuery, gql } from '@apollo/client'
import { Spinner } from '../../Spinners'

const query = gql`query { events (withUnpublished:true) { id owner { id name } } }`

export default function(){
	const [ users, setUsers ] = useState([])
	const { data } = useQuery(query)
	useEffect(()=>{
		if(!data) return;
		const users = new Map();
		data.events.map( event => {
			let username = event.owner.name;
			if( users.has(username) ){
				users.get(username).count += 1
			}else{
				users.set(username,{ name: username, count: 1 })
			}
		} )
		setUsers([...users.values()])
	},[data])
	if(!data) return <Spinner contained size={50}/>;
	return (
		<>
			<h1>Event user stats</h1>
			<p>Includes {data && data.events.length} published AND unpublished events.</p>
			<table>
				<thead>
					<tr>
						<th>Username</th>
						<th>Count</th>
					</tr>
				</thead>
				<tbody>
				{users.sort((a,b)=>b.count-a.count).map( ({name,count}) => (
						<tr key={name}>
							<td>{name}</td>
							<td>{count}</td>
						</tr>
					))
				}
				</tbody>
			</table>
		</>	
	)
}
