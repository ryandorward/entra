import { lazy } from 'react';
import { Routes, Route } from 'react-router-dom'

const Count = lazy(()=>import('./Jurisdictions'))
const Tags = lazy(()=>import('./Tags'))
const SourcesUsed = lazy(()=>import('./SourcesUsed'))
const SourcesKnown = lazy(()=>import('./SourcesKnown'))
const Weight = lazy(()=>import('./Weight'))
const Themes = lazy(()=>import('./Themes'))
const Users = lazy(()=>import('./Users'))
const Actors = lazy(()=>import('./Actors'))

export default function(){
	return (
		<Routes>
			<Route path="impacts" element={<Count/>}/>
			<Route path="tags" element={<Tags/>}/>
			<Route path="sources-used" element={<SourcesUsed/>}/>
			<Route path="weight" element={<Weight/>}/>
			<Route path="themes" element={<Themes/>}/>
			<Route path="sources-known" element={<SourcesKnown/>}/>
			<Route path="users" element={<Users/>}/>
			<Route path="actors" element={<Actors/>}/>
		</Routes>
	)
}
