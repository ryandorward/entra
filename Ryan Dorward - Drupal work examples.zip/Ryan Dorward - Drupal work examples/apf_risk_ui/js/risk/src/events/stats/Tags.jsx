import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom'
import { useQuery, gql } from '@apollo/client'
import { Spinner } from '../../Spinners'
import { colorFromThemes } from '../ESG/colorFromThemes.js'

const eventTagsQuery = gql`
query eventTagStats { 
	events ( sort: "date" top: 500 ) { 
		id tags { id } 
	}
}`

const tagMetaQuery = gql`
query tagStatsMeta ( $ids: [Int]! ) {
	tags ( id: $ids ){
		id name isCanonical description
		themes { id color parentThemes { id } }
	}
}
`

export default function(){
	const [ ids, setIds ] = useState(undefined)
	const [ stats, setStats ] = useState(new Map())
	const { data: eventTagData } = useQuery(eventTagsQuery)
	const { data: tagMetaData } = useQuery(tagMetaQuery,{variables:{ids}})
	useEffect(()=>{
		if(!eventTagData) return;
		const { events } = eventTagData
		const stats = events.reduce( (stats,event) => {
			event.tags.forEach( tag => {
				if( stats.has(tag.id) ){
					stats.get(tag.id).count += 1
				}else{
					stats.set(tag.id,{count:1})
				}
			} )
			return stats
		}, new Map() )
		setStats(stats)
		setIds( [...stats.keys()] )
	},[eventTagData])
	if(!eventTagData) return <Spinner contained size={50}/>;
	return (
		<>
			<h1>Event tagging stats</h1>
			<p>Showing {stats.size} unique tags from the latest 500 published events</p>
			<table>
				<thead>
					<tr>
						<th>ID</th>
						<th>Color</th>
						<th>Name</th>
						<th>Count</th>
						<th>Canon</th>
						<th>Desc.?</th>
					</tr>
				</thead>
				<tbody>
				{[...stats.entries()]
					.sort((a,b)=>b[1].count-a[1].count)
					.map( ([id,data]) => {
						const meta = tagMetaData?.tags?.find(e=>id==e.id)
						return (
						<tr key={id}>
							<td>
								<a title="edit"
									href={`https://www.asiapacific.ca/taxonomy/term/${id}/edit`}>
									{id}
								</a>
							</td>
							<td style={meta && {backgroundColor: colorFromThemes(meta.themes)}}/>
							<td>
								{meta?.name}
							</td>
							<td>
								<Link to={`/timeline/events/tag/${id}`}>
									{data.count}
								</Link>
							</td>
							<td>{meta?.isCanonical ? '\u2713':''}</td>
							<td title={meta?.description}>{meta?.description ? '\u2713':''}</td>
						</tr>
						)
					})
				}
				</tbody>
			</table>
		</>	
	)
}
