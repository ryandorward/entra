import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useApolloClient, gql } from '@apollo/client'
import { Spinner } from '../../Spinners'

const query = gql`query { events { id title actors { id label description } } }`

export default function(){
	const client = useApolloClient()
	const [ actors, setActors ] = useState([])
	const [ stats, setStats ] = useState({})
	useEffect(()=>{
		const actors = new Map();
		const stats = {}
		client.query({query}).then( ({data}) => {
			stats.totalNumber = data.events.length
			stats.numberWithActors = data.events
				.filter(e=>e.actors.length>0).length;
			stats.withNoActors = data.events.filter(e=>e.actors.length==0);
			data.events.forEach( event => {
				event.actors.forEach( actor => {
					const { id, label, description } = actor
					if( actors.has(id) ){
						actors.get(id).count += 1
					}else{
						actors.set(id,{id,label,description,count:1})
					}
				} )
			} )
			setActors([...actors.values()])
			setStats(stats)
		} )
	},[])
	if(!actors.length>0) return <Spinner size={50} contained/>;
	return (
		<>
			<h1>Actor stats</h1>
			<p>{stats?.numberWithActors} events have one or more identified actors out of {stats?.totalNumber} published events.</p>
			<p>Some random events with no actors identified (yet!):</p>
			<ul>
				{shuffle(stats.withNoActors).slice(0,6).map( ({id,title}) => (
					<li key={id}>
						<Link to={`/map/event/${id}`}>{title}</Link>
					</li>
				) )}
			</ul>
			<table>
				<thead>
					<tr>
						<th>Actor</th>
						<th>Count</th>
					</tr>
				</thead>
				<tbody>
				{actors.sort((a,b)=>b.count-a.count).map( ({id,label,count,description}) => (
					<tr key={id}>
						<td>
							<a href={`https://www.wikidata.org/wiki/${id}`} title={description}>
								{label}
							</a>
						</td>
						<td>{count}</td>
					</tr>
				)) }
				</tbody>
			</table>
		</>
	)
}

// https://bost.ocks.org/mike/shuffle/
function shuffle(array) {
  var copy = [], n = array.length, i;
  // While there remain elements to shuffle…
  while (n) {
    // Pick a remaining element…
    i = Math.floor(Math.random() * n--);
    // And move it to the new array.
    copy.push(array.splice(i, 1)[0]);
  }
  return copy;
}
