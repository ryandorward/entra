import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom'
import Select from 'react-select'
import graph from '../../jurisdictions/graph'
import getMediaSources from '../../wikidata/queries/mediaSources.js'
import { Spinner } from '../../Spinners'

export default function(){
	const [ countryOptions, setCountryOptions ] = useState([])
	const [ country, setCountry ] = useState(undefined)
	const [ publishers, setPublishers ] = useState([])
	
	useEffect(()=>{
		graph.countries().then(setCountryOptions)
	},[])
	
	useEffect(()=>{
		setPublishers([])
		country && getMediaSources(country.wikidata).then(setPublishers)
	},[country])

	return (
		<>
			<h1>Known news-media sources by country / jurisdiction</h1>
			
			<Select placeholder={`Select a jurisdiction`} 
				options={countryOptions} 
				onChange={setCountry}
				getOptionLabel={jur=>jur.name.en}
				getOptionValue={(jur)=>jur.geo_id}
			/>
			{country && 
				<p>{publishers.length > 0 ? publishers.length : '???' } active news publishers identified from Wikidata for {country.name.en}</p>
			}
			{country && (publishers.length > 0 ? 
				<PublishersTable {...{publishers}}/> : <Spinner contained size={50}/>)
			}
		</>
	)
}

function PublishersTable({publishers}){
	return (
		<table>
			<thead>
				<tr>
					<th>Name</th>
					<th>Type(s)</th>
					<th>Language(s)</th>
					<th>Website(s)</th>
				</tr>
			</thead>
			<tbody>
			{publishers.map( (p,i) => {
				const websites = p.websites.value.split(' | ').filter(v=>v!='')
				return (
					<tr key={i}>
						<td> 
							<Link to={`../../source/${p.id.value}`}>
								{p.label.value}
							</Link>
						</td>
						<td>{p.types.value}</td>
						<td>{p.languages.value}</td>
						<td>{websites.map((href,i)=>(
							<a href={href} key={i} target="_blank" rel="noreferrer">
								{1+i}
							</a>
						))}</td>
					</tr>
				)
			} )}
			</tbody>
		</table>
	)
}
