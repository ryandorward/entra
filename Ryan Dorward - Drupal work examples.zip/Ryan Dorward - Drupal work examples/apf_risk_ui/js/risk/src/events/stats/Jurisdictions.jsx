import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom'
import { useQuery, gql } from '@apollo/client'
import graph from '../../jurisdictions/graph'
import assignPopulations from '../../wikidata/queries/assignPopulations.js'
import { format } from 'd3-format'
import { Spinner } from '../../Spinners'
import { connectionPoints } from '../../connections/pointScore.js'

const query = gql`query eventStats { events { id impacts { geo_id } } }`

function popFormat(number){ return format('.3s')(number).replace(/G$/,'B') }

export default function(){
	const { data } = useQuery(query)
	const [ stats, setStats ] = useState([])
	useEffect(()=>{
		if(!data) return;
		const events = data.events
		const geo_ids = [... new Set(
			events.map(e=>e.impacts).flat().map(i=>i.geo_id)
		)]
		graph.lookup(geo_ids)
			.then( assignPopulations )
			.then( jurs => {
				return jurs.map( jur => {
					let data = { jur }
					data.directEvents = events.filter( event => (
						event.impacts.some( impact => impact.geo_id == jur.geo_id )
					) );
					if(jur.children.length > 0){
						let descendants = new Set(jur.descendants.map(d=>d.geo_id))
						data.childEvents = events.filter( event => (
							event.impacts.some(i=>descendants.has(i.geo_id))
						) );
						let jurPlus = descendants
						jurPlus.add(jur.geo_id)
						data.anyEvents = events.filter( event => (
							event.impacts.some(i=>jurPlus.has(i.geo_id))
						) );
					}
					return data
				} )
				.sort((a,b)=>connectionPoints(b.jur)-connectionPoints(a.jur))
				.sort((a,b)=>a.jur.country?.geo_id - b.jur.country.geo_id)
			} )
			.then(setStats)
	},[data])
	if(!data) return <Spinner contained size={50}/>;
	return (
		<>
			<h1>Jurisdiction event stats</h1>
			<p>There are {data?.events?.length} events in {stats.length} distinct jurisdictions. The table below sorts jurisdictions first by country then by the relative strength of their transpacific connections.</p>
			<table>
				<thead>
					<tr>
						<th>Jurisdiction</th>
						<th>Direct Events</th>
						<th>Child Events</th>
						<th>Total Events</th>
						<th>Population</th>
						<th>Connection Points</th>
					</tr>
				</thead>
				<tbody>
				{stats.map(d=>(
					<tr key={d.jur.geo_id}
						style={d.jur==d.jur.country?{fontWeight:'bold'}:{}}>
						<td>
							<Link to={`/map/events/jurisdiction/${d.jur.geo_id}`}>
								{d.jur.name.en}
							</Link>
						</td>
						<td>{d.directEvents.length}</td>
						<td>{d?.childEvents?.length}</td>
						<td>{d?.anyEvents?.length}</td>
						<td>{popFormat(d.jur.population)}</td>
						<td>{format('.3')(connectionPoints(d.jur))}</td>
					</tr>
				))}
				</tbody>
			</table>
		</>
	)
}
