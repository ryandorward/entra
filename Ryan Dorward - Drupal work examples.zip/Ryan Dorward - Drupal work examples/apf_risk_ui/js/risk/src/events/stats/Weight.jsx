import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom'
import { useQuery, gql } from '@apollo/client'
import { Spinner } from '../../Spinners'
import graph from '../../jurisdictions/graph'

function impactScale(event){
	// each impacted country = 1
	// sub-jurisdictions treated as equal fractions of their parent
	const countryFraction = graph.lookupNow(event.impacts.map(i=>i.geo_id))
		.map( j => j.ancestors.reduce( (frac,a) => frac/a.children.length, 1) )
		.reduce( (cumSum,jurFrac) => cumSum + jurFrac, 0 )
	return Math.min(countryFraction,1)
}

function weight(event){
	let forwardLinks = event.links.filter( link => link.event.date > event.date )
	let forwardCausalLinks = forwardLinks.filter( link => link.linkType.id == 1 )
	return (
		( event.canadianInvolvement ? 3 : 1 )
		* event.archive_links.length**0.5  // may be zero
		* impactScale(event)               // may be zero
		* (1+forwardCausalLinks.length) // **1
		* (1+forwardLinks.length)**0.25
	)
}

const query = gql`
query eventWeightStats {
	events ( top: 250 sort: "date" ) {
		id title date archive_links impacts { id geo_id } weight calculatedWeight
		links { cid event { id date } linkType { id } }
		canadianInvolvement
	}
}`

export default function(){
	const [ ready, setReady ] = useState(false)
	useEffect(()=>{ graph.ready.then(()=>setReady(true)) },[])
	const { data } = useQuery(query)
	if(!data) return <Spinner contained size={50}/>;
	const events = data?.events ?? []
	return (
		<>
			<h1>Event weighting stats</h1>
			<p>Includes {events.length} recently published events. The algorithm used to assign the weights can be viewed <a href="https://github.com/apfcanada/cast-ui/blob/master/src/events/stats-pages/Weight.jsx">here</a></p>
			<table>
				<thead>
					<tr>
						<th>ID</th>
						<th>Title</th>
						<th>System Weight</th>
						<th>Calc&apos;d Weight</th>
						<th>Frozen Weight</th>
						<th>Impact</th>
						<th>Canadian</th>
						<th>Links</th>
					</tr>
				</thead>
				<tbody>
				{ready && [...events].sort( (a,b) => weight(b) - weight(a) ).map( event => (
						<tr key={event.id}>
							<td>{event.id}</td>
							<td><Link to={`/map/event/${event.id}`}>
								<small>{event.title}</small>
							</Link></td>
							<td>{event.calculatedWeight?.toPrecision(4)}</td>
							<td>{weight(event).toPrecision(4)}</td>
							<td>{(event.weight !== null ) ? event.weight.toPrecision(4) : '-'}</td>
							<td>{impactScale(event).toPrecision(3)}</td>
							<td>{event.canadianInvolvement?'true':''}</td>
							<td>{event.links.length}</td>
						</tr>
					))
				}
				</tbody>
			</table>
		</>
	)
}
