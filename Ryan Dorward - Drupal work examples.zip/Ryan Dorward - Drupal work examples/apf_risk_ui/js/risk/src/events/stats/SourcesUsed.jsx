import { Link } from 'react-router-dom'
import { useQuery, gql } from '@apollo/client'
import { Source } from '../sources/source.js'
import { Spinner } from '../../Spinners'

const query = gql`query { events { id archive_links } }`

export default function(){

	const { data } = useQuery(query)
	if(!data) return <Spinner contained size={50}/>;
	const events = data.events
	const sources = events
		.map( event => event.archive_links ).flat()
		.map( link => new Source(link) )
	const usedPublishers = [...new Set(sources.map(s=>s.publisher))]
		.filter( p => p ) // is defined
		.map( publisher => ({
			publisher,
			count: sources.filter(s=>s.publisher==publisher).length
		}) )
		.sort((a,b)=>a.publisher.name.localeCompare(b.publisher.name))
		.sort((a,b)=>b.count-a.count)
	const unknownSources = sources.filter(s=>!s.publisher)
	const unknownDomains = [...new Set(unknownSources.map(s=>s.domain))]
		.map( domain => ({
			domain,
			count: unknownSources.filter(s=>s.domain==domain).length
		}) )


	return (
		<>
			<h1>Event sourcing stats</h1>
			<p>Includes all {events.length} published events {`with ${sources.length} sources`} from {usedPublishers.length} known publishers (plus many others with publishers not yet identified).</p>
			<table>
				<thead>
					<tr><th>Count</th><th>Publisher</th><th>Owner</th></tr>
				</thead>
				<tbody>
				{usedPublishers.map( ({publisher,count}) => {
					return (
						<tr key={publisher.qid}>
							<td>{count}</td>
							<td><Link to={`../../source/${publisher.qid}`}>
								{publisher.name}
							</Link></td>
							<td>{
								publisher.owner ?
									<img src={publisher.owner.icon} height="12px"/> :
									null
							}</td>
						</tr>
					)
				} )}
				</tbody>
			</table>

			<h2>Domain names not yet associated with publishers</h2>
			<table>
				<thead><tr><th>Domain</th><th>Count</th></tr></thead>
				<tbody style={{textAlign:'right'}}>
					{unknownDomains
						.sort(({domain:a},{domain:b})=>{
							let A = a.split('').reverse().join('')
							let B = b.split('').reverse().join('')
							return A.localeCompare(B)
						})
						.map(({domain,count})=>(
							<tr key={domain}>
								<td>{domain}</td>
								<td>{count}</td>
							</tr>
						))
					}
				</tbody>
			</table>
		</>
	)
}
