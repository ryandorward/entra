import { useEffect, useContext } from 'react'
import { useParams } from 'react-router-dom'
import { useApolloClient, gql } from '@apollo/client'
import { Node } from '../maps/timeline/node'
import { Link } from '../maps/timeline/link'
import { Context as MapContext } from '../maps/timeline/TimelineMap'
import { Context as LayoutContext } from '../maps/MapLayout'
import { eventThemes } from './ESG/themesFragments.js'

export const query = gql`
${eventThemes}
fragment eventBasics on Event {
	id date title weight ...eventThemes
	impacts { id geo_id  }
}
fragment linkBasics on EventLink { cid linkType { id } }
query timelineFocused ( $id: Int! ) {
	event ( id: $id ) { ...eventBasics
		links { ...linkBasics event { ...eventBasics
			links { ...linkBasics event { ...eventBasics } }
		} }
	}
}`

export default function(){
	const { event_id } = useParams()
	const client = useApolloClient()
	const { setNodes, setLinks, init } = useContext(MapContext)
	const { setData } = useContext(LayoutContext)
	useEffect(()=>{
		init(false)
		client.query({query,variables:{id:Number(event_id)}}).then( response => {
			const event = response.data.event
			const focusNode = new Node(event)
			focusNode.focused = true
			const [ nodes, links ] = [ [focusNode], [] ]
			event.links.map( link => followLink(focusNode,link,nodes,links) )
			setNodes(nodes)
			setLinks(links)
			init(true)
			// set link types to show in legend
			setData({linkTypesShown:[...new Set(links.map(l=>l.type))]})
		} ).catch(()=>console.warn(`Event ${event_id} not found`))
	},[event_id])
	return null
}

function followLink(fromNode,link,allNodes,allLinks){
	let newNode = new Node(link.event)
	if( ! allNodes.map(n=>n.id).includes(newNode.id) ){
		allNodes.push(newNode)
	}else{ // if it is, retrieve it
		newNode = allNodes.find(n=>n.id==newNode.id)
	}
	let newLink = new Link(fromNode,newNode,link)
	if( ! allLinks.map(l=>l.id).includes(newLink.id) ){
		allLinks.push(newLink)
	}
	// recurse along any further links
	if(link.event?.links){
		link.event.links
			.filter( nextLink => fromNode.date < newNode.date ? // i.e. moving forward
				link.event.date <= nextLink.event.date :
				link.event.date >= nextLink.event.date
			)
			.map( link => followLink(newNode,link,allNodes,allLinks) )
	}
}

