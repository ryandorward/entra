import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { useApolloClient, gql } from '@apollo/client'
import { rgb } from 'd3-color'
import { scalePow } from 'd3-scale'
import graph from '../jurisdictions/graph'
import Choropleth from '../maps/geographic/Choropleth'
import { color as ESGcolor } from './ESG/scale.js'
import { reduceThemesToESG } from './ESG/reduceThemesToESG.js'
import { eventThemes } from './ESG/themesFragments.js'

const query = gql`
${eventThemes}
query ( $geo_id: [Int] $topN: Int! ){
	events ( themes:[12,13,14] in:$geo_id top:$topN sort:"date" indirect:true ) {
		id impacts { geo_id } ...eventThemes
	}
}`

const opacityScale = scalePow().exponent(0.5).range([0.1,1])

export default function EventsGeoOverview(){
	const client = useApolloClient()
	const { geo_id } = useParams()
	const [ jur, setJur ] = useState(undefined)
	const [ ESG, setESG ] = useState(undefined)
	useEffect(()=>{
		graph.lookup(geo_id)
			.then( jur => {
				setJur(jur)
				return client.query({query,variables:{
					geo_id: jur.parent?.geo_id,
					topN: 3*(1+jur.siblings.length)
				}})
			} )
			.then( ({data}) => {
				const ESG = new Map();
				const jur = graph.lookupNow(geo_id)
				const jurs = [jur,...jur.siblings]
				jurs.forEach( j => ESG.set(j,{E:0,S:0,G:0,w:0}) )
				data.events.forEach( ({impacts,themes}) => {
					const {E,S,G} = reduceThemesToESG(themes)
					impacts.forEach( ({geo_id}) => {
						let impactedJur = graph.lookupNow(geo_id)
						jurs.forEach( mapJur => {
							if(impactedJur.inLineWith(mapJur)){
								const d = ESG.get(mapJur)
								const scalar = impacts.length / ( 1+Math.abs(impactedJur.depth-mapJur.depth))
								d.E += E*scalar
								d.S += S*scalar
								d.G += G*scalar
								d.w += scalar
							}
						} )
					} )
				} );
				setESG(ESG);
				const weights = [...ESG.values()].map(o=>o.w)
				opacityScale.domain([Math.min(...weights),Math.max(...weights)])
			})
	},[geo_id])
	if( ! jur || ! ESG ) return null;
	return (
		<Choropleth
			jurisdiction={jur}
			colorFunc={jur=>{
				let d = ESG.get(jur)
				if(!d) return 'lightgrey'
				return rgb(ESGcolor(d))
					.copy({opacity:opacityScale(d.w)})
					.toString()
			}}
			linkFunc={jur=>`/map/jurisdiction/${jur.geo_id}`}
		/>
	)
}
