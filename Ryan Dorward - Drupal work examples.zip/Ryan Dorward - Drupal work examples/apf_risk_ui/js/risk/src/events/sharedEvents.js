import { makeVar } from '@apollo/client'
export const sharedEvents = makeVar([])
export const sharedEventsLoading = makeVar([])
