import { useState, useEffect, useContext } from 'react';
import { useParams } from 'react-router-dom'
import { useApolloClient, gql, useReactiveVar } from '@apollo/client'
import graph from '../jurisdictions/graph'
import { assignBoundaries } from '@apfcanada/jurisdictions'
import { MapContext } from '../maps/geographic/Context'
import { indirectQuery } from './QueryOptions'
import Boundary from '../maps/geographic/Boundary'
import FocusOn from '../jurisdictions/Focus'
import highlight from '../maps/geographic/styles/highlight.module.css'

const query = gql`
query ( $theme: [Int] $geo_id: [Int] $indirect: Boolean $tags: [Int] ){
	events(top:75 themes:$theme in:$geo_id tags:$tags indirect:$indirect){
		id impacts { geo_id }
	}
}`

export default function(){
	const { theme_id, geo_id, tag_id } = useParams()
	const indirect = useReactiveVar(indirectQuery)
	const client = useApolloClient()
	const [ jur, setJur ] = useState(undefined)
	const [ jurs, setJurs ] = useState([])
	const { init } = useContext(MapContext)

	useEffect(()=>{
		init(false)
		graph.lookup(geo_id).then(setJur)
		client.query({query,variables:{
			indirect, geo_id: Number(geo_id) ?? undefined,
			theme: Number(theme_id) ?? undefined,
			tags: Number(tag_id) ?? undefined
		}}).then( ({data}) => {
			let geo_ids = new Set(
				data.events.map(event=>event.impacts.map(imp=>imp.geo_id)).flat()
			)
			graph.lookup([...geo_ids])
				.then(assignBoundaries)
				.then( jurs => jurs.sort((a,b)=>a.depth-b.depth) )
				.then(setJurs)
				.then(()=>init(true))
		} )
	},[theme_id,geo_id,tag_id,indirect])

	return (<>
		{jur && <Boundary className={highlight.primary} jurisdiction={jur}/>}
		{jurs.filter(j=>j.geo_id!=Number(geo_id)).map( jur => (
			<Boundary key={jur.geo_id}
				className={geo_id ? highlight.secondary : highlight.primary}
				jurisdiction={jur}/>
		) )}
		{jurs.length > 0 && <FocusOn jurisdictions={jurs}/>}
	</>)
}
