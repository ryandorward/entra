 // TODO think through these arbitrary weights
export function connectionPoints(jur){
	return ( 
		jur.connections(/Twinning/,{descendants:true}).length * 0.2
		+ jur.connections(/TradeAgreement/).length * 0.5
		+ jur.connections(/Mission/,{descendants:true}).length * 0.3 
		+ jur.connections(/Business/,{descendants:true}).length * 0.025
		+ jur.connections(/FDI/,{descendants:true}).length * 0.025
		+ jur.connections(/Publication/,{descendants:true}).length * 0.01
	)
}
