import { Connection } from '@apfcanada/jurisdictions'

export class Twinning extends Connection {
	constructor(A,B){
		super(A,B)
	}
	get id(){
		return `Twinning:${super.id}`
	}
	partnerOf(refJur){
		return this.jurisdictions.find( jur => jur != refJur )
	}
}
