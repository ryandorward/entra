import { Link } from 'react-router-dom'
import { HiOutlineFlag as Flag } from 'react-icons/hi'
import { BiBuildingHouse as City } from 'react-icons/bi'
import styles from './twin-box.module.less'

const urban = /city|district|muni|metro/i

function twinLink(geo_id){
	return `/map/connections/twinning/jurisdiction/${geo_id}?tab=1`
}

export default function({self,reference,partner}){ // both jurisdictions
	let Icon = partner.type.label.en.match(urban) ? City : Flag
	return (
		<div className={`twin ${styles.container}`}>
			<Icon/>
			<Link to={twinLink(partner.geo_id)}>{partner.name.en}</Link>
			{ self != reference &&
				<span className={styles.localPartner}>
					(with <Link to={twinLink(self.geo_id)}>
						{self.name.en}
					</Link>)
				</span>
			}
		</div>
	)
}
