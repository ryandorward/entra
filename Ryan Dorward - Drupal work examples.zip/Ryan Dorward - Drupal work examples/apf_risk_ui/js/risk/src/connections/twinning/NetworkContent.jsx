import { useEffect, useContext } from 'react'
import { useParams } from 'react-router-dom'
import { MapContext } from '../../maps/network/Context'
import graph from '../../jurisdictions/graph'
import assignPopulations from '../../wikidata/queries/assignPopulations.js'

export default function(){
	const { geo_id } = useParams()
	const { setData, init } = useContext(MapContext)
	useEffect(()=>{
		init(false)
		graph.lookup(geo_id).then( jur => {
			let focus = jur
			let allTwins = [...new Set(
				jur.connections(/Twinning/,{descendants:true}).map(c=>c.jurisdictions).flat()
			)].filter( tj => tj.canadian != jur.canadian )
			const [ jurisdictions, connections ] = [ [jur], [] ]
			assignPopulations(allTwins).then( twins => {
				[...new Set(twins)].sort((A,B)=>B.population-A.population)
					.map( twin => {
						jurisdictions.push(twin)
						connections.push([jur,twin])
					} );
				setData({jurisdictions,connections,focus})
			} )
		} )
	},[geo_id])
	return null
}
