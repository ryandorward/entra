import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom'
import { assignBoundaries } from '@apfcanada/jurisdictions'
import Boundary from '../../maps/geographic/Boundary'
import Arc from '../../jurisdictions/GeoArc'
import FocusOn from '../../jurisdictions/Focus'
import graph from '../../jurisdictions/graph'
import highlight from '../../maps/geographic/styles/highlight.module.css'
import ancestor from '../../maps/geographic/styles/ancestor.module.css'

export default function(){
	var { geo_id } = useParams()
	const [ jur, setJur ] = useState(null)
	const [ uniqueJurs, setUniqueJurs ] = useState([])
	const [ ancestors, setAncestors ] = useState([])
	const [ twinPairs, setTwinPairs ] = useState([])
	useEffect(()=>{
		graph.lookup(geo_id).then( jur => {
			setJur(jur)
			const connections = jur.connections(/Twinning/,{descendants:true})
			const twinners = [...new Set(
				connections.map( conn => conn.jurisdictions ).flat()
			)]
			assignBoundaries(twinners)
				.then( twinners => {
					setUniqueJurs(twinners)
					setTwinPairs(connections)
					const ancestors = [...new Set(twinners.map(j=>j.ancestors).flat())]
						.sort((A,B)=>A.depth-B.depth)
					setAncestors(ancestors)
				} )
		} )
	},[geo_id])
	return (
		<g>
			<FocusOn jurisdictions={uniqueJurs}/>
			{ancestors.map(jur=>(
				<Boundary key={jur.geo_id} 
					className={ancestor.light}
					jurisdiction={jur}/>
			))}
			{twinPairs.map( conn => {
				const [A,B] = conn.jurisdictions;
				return <Arc key={conn.id} from={A} to={B} stroke="#0002"/>
			} ) }
			{jur && <Boundary jurisdiction={jur} className={highlight.secondary}/>}
			{uniqueJurs.map( jur => {
				return (
					<Boundary centroid key={jur.geo_id} jurisdiction={jur}
						className={highlight.primary} r="5"/>
				)
			} )}
		</g>
	)
}
