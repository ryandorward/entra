import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom'
import graph from '../../jurisdictions/graph'
import TwinBox from './TwinBox'

export default function TwinContent(){
	const { geo_id } = useParams()
	const [ jur, setJur ] = useState(null)
	useEffect(()=>{
		graph.lookup(geo_id).then( setJur ) 
	},[geo_id])
	if(!jur) return null;
	return (
		<div>
			<h3>Twinning Relations</h3>
			{jur.connections(/Twinning/,{descendants:true}).map( conn => {
				const [A,B] = conn.jurisdictions
				return (
					<TwinBox key={`${A.geo_id}/${B.geo_id}`} 
						self={A} partner={B} reference={jur}/>
				)
			} ) }
		</div>
	)
}
