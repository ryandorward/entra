import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'
import graph from '../../jurisdictions/graph'
import Select from 'react-select'

export default function(){
	const navigate = useNavigate()
	const [ bigTwinners, setBigTwinners ] = useState([])
	useEffect(()=>{
		graph.readyWith('Twinning').then( graph => {
			const canada = graph.lookupNow(2)
			const twinnings = canada.connections(/Twinning/,{descendants:true})
			const twinnedCountries = new Set( 
				twinnings.map(t=>t.jurisdictions).flat().map(j=>j.country) 
			)
			twinnedCountries.delete(canada)
			setBigTwinners([...twinnedCountries])
		} )
	},[])
	const options = bigTwinners
		.sort( (a,b)=> (
			b.connections(/Twinning/,{descendants:true}).length - 
			a.connections(/Twinning/,{descendants:true}).length
		) )
		.map( j => ({
			label: `${j.name.en} (${j.connections(/Twinning/,{descendants:true}).length})`,
			value: j.geo_id
		}) )
	return (
		<Select placeholder={`Select a jurisdiction with twins`} 
				options={options} onChange={select}/>
	)
	function select(option){
		navigate(`/graph/connections/twinning/jurisdiction/${option.value}`)
	}
}
