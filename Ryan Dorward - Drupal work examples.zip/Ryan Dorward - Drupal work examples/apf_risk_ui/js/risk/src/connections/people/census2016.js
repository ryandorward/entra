import graph from '../../jurisdictions/graph'
import getStatsCanId from '../../wikidata/queries/statsCanId.js'

// for API documentation, see:
// https://www12.statcan.gc.ca/wds-sdw/cpr2016-eng.cfm
// for Stats Can DGUID (geography param) see:
// https://www150.statcan.gc.ca/n1/pub/92f0138m/92f0138m2019001-eng.htm

const api = 'https://www12.statcan.gc.ca/rest/census-recensement/CPR2016.json'

const languageCodes = [
	671,672,675,676,678,679,681,682,683,684,685,
	692,693,694,695,697,739,740,741,742,743,744,
	745,746,747,748,749,750,763,766,768,795,796,
	797,798,799,800,801,804,805,806,809,810,815
]

const colNum = 13
const jurIndices = {
	3: d => d.DATA[66][colNum] + d.DATA[67][colNum],
	4: d => d.DATA[71][colNum],
	5: d => d.DATA[72][colNum],
	7: d => d.DATA[68][colNum],
	31: d => d.DATA[79][colNum],
	32: d => d.DATA[75][colNum],
	38: d => d.DATA[78][colNum],
	78: d => d.DATA[65][colNum],
	92: d => d.DATA[74][colNum],
	607: d => d.DATA[76][colNum]
}

const statsCanIdType = { 
	2: 'A0002', 
	4: 'A0003', 
	7: 'A0005' 
}

export default async function getCensus2016(Qid, topic) {
	var url = new URL(api);
	var year = "2016"
	var dguid = year + "A000011124" // Canada dguid
	if (Qid !== "Q16") {
		const statsCanId = await getStatsCanId(Qid)
		dguid = statsCanIdType?.[statsCanId.length] ?
			year + statsCanIdType[statsCanId.length] + statsCanId : 
			null
	}
	if (/immigration/i.test(topic)) {
		var params = {lang: "E", dguid, topic: "6", stat: "0"};
		url.search = new URLSearchParams(params).toString();
		return fetch(url).then(response=>response.json()).then( data => {
			return Promise.all( Object.entries(jurIndices).map( ([geo_id,func]) => {
				return graph.lookup(geo_id)
					.then( jur => ({geo_id,value:func(data),name:jur.name.en}) )
			}) )
		} )
	}
	if (/language/i.test(topic)) {
		params = {lang: "E", dguid, topic: "10", stat: "0"};
		url.search = new URLSearchParams(params).toString();
		return fetch(url)
			.then( response => response.json() )
			.then( data => {
				return languageCodes.map( langCode => ( {
					name: data.DATA[langCode][10].trimStart(),
					value: data.DATA[langCode][13]
				} ) )
			} )
	}
}
