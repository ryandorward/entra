import { useState, useEffect } from 'react';
import BigNumber from '../../layouts/BigNumber'
import getCensus2016 from './census2016.js'

export default function() {
	const [data, setData] = useState([])
	useEffect(()=>{
		getCensus2016("Q16", "Immigration").then(setData)
	},[])
	if( data.length < 1 ) return null;
	return(
		<div className='immigration-to-canada'>
			<h3>Asia-Pacific Immigrants In Canada</h3>
			{data.sort((a,b) => b.value - a.value).slice(0, 5).map ( d => (
			<BigNumber number={d.value} key={d.geo_id}
				labelPlural={`Immigrants from ${d.name}`}
				linkPath={`/map/jurisdiction/${d.geo_id}`}/>
			) )}
		</div>
	)
}
