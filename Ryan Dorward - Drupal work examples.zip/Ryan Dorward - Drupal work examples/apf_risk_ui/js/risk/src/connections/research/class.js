import { Connection } from '@apfcanada/jurisdictions'

export class Publication extends Connection {
	#data
	constructor(data,...jurs){
		super(...jurs)
		this.#data = data
	}
	get id(){
		return `Publication-${this.pubID}:${super.id}`
	}
	get pubID(){
		return this.#data.id
	}
}
