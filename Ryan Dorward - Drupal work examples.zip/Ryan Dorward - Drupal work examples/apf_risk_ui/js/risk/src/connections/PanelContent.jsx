import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import graph from '../jurisdictions/graph'
import BigNumber from '../layouts/BigNumber'

export default function(){
	const { geo_id } = useParams()
	const [ jur, setJur ] = useState(null)
	useEffect(()=>{
		graph.readyWith('FDI','Business','Publications')
			.then( graph => graph.lookupNow(geo_id) )
			.then(setJur)
	},[geo_id])

	if(!jur) return null;
	let partner = jur.canadian ? 'Asia' : 'Canada'
	if( jur && ! jur.connections(/.*/,{descendants:true}).length > 0 ){
		return <div style={{color:'var(--text-de)'}}>We’re not yet tracking any specific connections between {partner} and {jur.name.en}.</div>
	}
	const jpath = `jurisdiction/${geo_id}`
	return (
		<div className="connection-stats">
			<BigNumber
				number={jur.connections(/Mission/).length}
				labelSingle={`diplomatic mission sent or received`}
				labelPlural={`diplomatic missions sent or received`}
				linkPath={`/map/connections/diplomacy/${jpath}?tab=1`}
			/>
			<BigNumber
				number={jur.connections(/Twinning/,{descendants:true}).length}
				labelSingle={`twinning relation`}
				labelPlural={`twinning relations`}
				linkPath={`/map/connections/twinning/${jpath}?tab=1`}
			/>
			<BigNumber
				number={jur.connections(/Business/,{descendants:true}).length}
				labelSingle={jur.canadian?'business in Asia':'Canadian business'}
				labelPlural={jur.canadian?'businesses in Asia':'Canadian businesses'}
				linkPath={`/map/connections/business/${jpath}?tab=0`}
			/>
			<BigNumber
				number={jur.connections(/FDI/,{descendants:true}).length}
				labelSingle={`direct investment with ${partner}`}
				labelPlural={`direct investments with ${partner}`}
				linkPath={`/map/connections/investment/${jpath}?tab=1`}
			/>
			<BigNumber
				number={jur.connections(/Publication/,{descendants:true}).length}
				labelSingle={`major research collaboration with ${partner} in the last year`}
				labelPlural={`major research collaborations with ${partner} in the last year`}
			/>
			<BigNumber
				number={jur.connections(/TradeAgreement/).length}
				labelSingle={`trade agreement with ${partner}`}
				labelPlural={`trade agreements with ${partner}`}
				linkPath={`/map/connections/trade/${jpath}?tab=1`}
			/>
		</div>
	)
}

