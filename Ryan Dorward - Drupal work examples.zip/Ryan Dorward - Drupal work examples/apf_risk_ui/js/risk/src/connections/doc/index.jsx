import { Link } from 'react-router-dom'

export default function(){
	return (<>
		<h1>Connections</h1>
		<p>CAST tracks a variety of specific economic and cultural <b>connections</b> between Canada and the Asia Pacific. These different types of connections are what we use to refine the geographic focus of our <Link to="../../events">event tracking</Link> efforts. Each connection links two or more <Link to="../../jurisdictions">jurisdictions</Link> across the Pacific. The more strongly Canada is connected to a place, the more interested we are in what’s happening there.</p>
		
		<p>Each type of connection has Each of these is typically sourced differently:</p>
		
		<ul>
			<li><Link to="business">Canadian businesses Operating in Asia</Link></li>
			<li><Link to="twinning">Twinning or Sister-City Relations</Link></li>
			<li><Link to="diplomacy">Diplomatic missions</Link></li>
			<li><Link to="investment">Foreign Direct Investment</Link></li>
			<li>Trade and investment agreements</li>
		</ul>
		
		<p>Datasets we’re working on incorporating include:</p>
		<ul>
			<li>Research collaborations resulting in publication</li>
			<li>Asian diaspora communities in Canada</li>
			<li>Asian restaurants in Canada (“gastro-diplomacy”)</li>
			<li>Educational ties and study-abroad experiences</li>
			<li>Canadian popular culture in Asia (e.g. sports, music)</li>
		</ul>
	</>)
}
