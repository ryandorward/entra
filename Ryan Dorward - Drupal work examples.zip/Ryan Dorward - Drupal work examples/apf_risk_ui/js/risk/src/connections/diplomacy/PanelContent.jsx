import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom'
import graph from '../../jurisdictions/graph'
import MissionBox from './MissionBox'

export default function(){
	var { geo_id } = useParams()
	const [ jur, setJur ] = useState(null)
	useEffect(()=>{
		graph.lookup(geo_id).then(setJur)
	},[geo_id])
	if(!jur) return null;
	const missions = jur.connections(/Mission/,{descendants:true})
	const missionsFrom = missions.filter( m => m.from == jur )
	const missionsTo = missions.filter( m => m.from != jur )
	return (<>
		{missionsFrom.length > 0 && <div>
			<h3>Sends missions to</h3>
			{missionsFrom.map( mission => (
				<MissionBox key={mission.id} mission={mission} highlight="dst"/> 
			) ) }
		</div>}
		{missionsTo.length > 0 && <div>
			<h3>Receives missions from</h3>
			{missionsTo.map( mission => (
				<MissionBox key={mission.id} mission={mission} highlight="src"/> 
			) ) }
		</div>}
	</>)
}
