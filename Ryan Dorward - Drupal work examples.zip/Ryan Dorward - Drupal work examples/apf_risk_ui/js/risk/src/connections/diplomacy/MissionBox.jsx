import { Link } from 'react-router-dom'
import Flag from '../../jurisdictions/Flag'

import styles from './mission-box.module.css'

function dipLink(geo_id){
	return `/graph/connections/diplomacy/jurisdiction/${geo_id}`
}

// passed a Mission object as prop
export default function({mission,highlight}){
	if(highlight=='dst') { return (
		<div className={styles.container}>
			<div className={styles.flag}>
				<Flag jurisdiction={mission.to}/>
			</div>
			<span>
				<Link to={dipLink(mission.to.geo_id)}>
					{mission.to.name.en}
				</Link> <span className={styles.type}>({mission.type})</span>
			</span>
		</div>
	) }else if(highlight=='src'){ return (
		<div className={styles.container}>
			<div className={styles.flag}>
				<Flag jurisdiction={mission.from}/>
			</div>
			<span>
				<Link to={dipLink(mission.from.geo_id)}>
					{mission.from.name.en}
				</Link> in {''} 
				<Link to={dipLink(mission.to.geo_id)}>
					{mission.to.name.en}
				</Link> <span className={styles.type}>({mission.type})</span>
			</span>
		</div>
	) }
}
