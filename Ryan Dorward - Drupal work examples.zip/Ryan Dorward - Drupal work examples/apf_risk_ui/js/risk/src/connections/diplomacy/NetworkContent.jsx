import { useEffect, useContext } from 'react'
import { useParams } from 'react-router-dom'
import { MapContext } from '../../maps/network/Context'
import graph from '../../jurisdictions/graph'

export default function(){
	const { geo_id } = useParams()
	const { setData, init } = useContext(MapContext)
	useEffect(()=>{
		init(false)
		graph.lookup(geo_id).then( jur => {
			const focus = jur
			const [ jurs, connections ] = [ new Set([jur]), [] ]
			const missions = jur.connections(/Mission/,{descendants:true})
			missions.filter(m=>m.from==jur).map( mission => {
				jurs.add(mission.to)
				connections.push( [jur,mission.to] )
			} )
			missions
				.filter(m=>m.to==jur||m.to.ancestors.includes(jur))
				.map( mission => {
					jurs.add(mission.from)
					connections.push( [jur,mission.from] )
				} );
			setData({jurisdictions:[...jurs],connections,focus})
		} )
	},[geo_id])
	return null
}
