import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom'
import Boundary from '../../maps/geographic/Boundary'
import FocusOn from '../../jurisdictions/Focus'
import graph from '../../jurisdictions/graph'
import Arc from '../../jurisdictions/GeoArc'
import highlight from '../../maps/geographic/styles/highlight.module.css'

export default function(){
	var { geo_id } = useParams()
	const [ jur, setJur ] = useState(null)
	const [ canada, setCanada ] = useState(undefined)
	const [ focusPlaces, setFocusPlaces ] = useState([])
	const [ cities, setCities ] = useState([])
	useEffect(()=>{
		graph.lookup([geo_id,2]).then( ([jur,canada]) => {
			setJur(jur)
			setCanada(canada)
			const missions = jur.connections(/Mission/,{descendants:true})
			const cities = [...new Set(
				missions.map( m => [ m.to, m.from?.capital ?? m.from ]  ).flat()
			)]
			setCities(cities)
			setFocusPlaces([jur,...cities])
		} )
	},[geo_id])
	
	if(!jur) return null;
	
	return (<>
		<FocusOn jurisdictions={focusPlaces}/>
		<Boundary jurisdiction={jur} className={highlight.secondary}/>
		{( !jur.canadian ) && canada && 
			<Boundary jurisdiction={canada} className={highlight.secondary}/>
		}
		{cities.map( jur => (
			<Boundary centroid key={jur.geo_id} className={highlight.primary}
				jurisdiction={jur} r={5}/>
		) ) }
		{jur.connections(/Mission/,{descendants:true}).map( mission => (
			<Arc key={mission.id} 
				from={mission.from?.capital ?? mission.from} 
				to={mission.to}/>
		) )}
	</>)
}
