import { useEffect, useContext } from 'react'
import { useParams } from 'react-router-dom'
import { MapContext } from '../maps/network/Context'
import graph from '../jurisdictions/graph'
import assignBorders from '../wikidata/queries/assignBorders.js'
//import { connectionPoints } from './pointScore.js' 

//const rawScore = (node) => connectionPoints(node.jur)
//const relScore = (node) => connectionPoints(node.jur) / node.jur.population

export default function NetworkOverview(){
	const { geo_id } = useParams()
	const { init, setData } = useContext(MapContext)
	
	useEffect(()=>{
		let focus
		const [ jurs, connections ] = [ new Set(), [] ]
		init(false)
		// get bordering jurs and link them
		graph.lookup(geo_id)
			.then(assignBorders)
			.then( jur => {
				focus = jur
				jurs.add(focus)
				// add nodes for twins and bordered jurs
				jur.connections(/Twinning/).map( twinning => {
					const [A,B] = twinning.jurisdictions
					jurs.add(jur==A?B:A)
					connections.push( [A,B] )
				} )
				jur.connections(/Mission/)
					.filter( mission => mission.from == jur )
					.map( mission => {
						jurs.add(mission.to)
						connections.push( [jur,mission.to] )
					} )
				jur.borders().map( bj => jurs.add(bj) )
				// assign borders among those
				return assignBorders([...jurs])
			} )
			.then( () => {
				// add all border links among nodes
				[...jurs].map( jur => jur.borders().map( bj => {
					if( !jurs.has(bj) ) return;
						connections.push([jur,bj])
				} ) )
				setData({jurisdictions:[...jurs],connections,focus})
			} )
	},[geo_id])
	return null
}
