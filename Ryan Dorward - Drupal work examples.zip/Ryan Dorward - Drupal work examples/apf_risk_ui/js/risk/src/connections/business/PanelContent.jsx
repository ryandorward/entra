import { useParams } from 'react-router-dom'
import { useQuery, gql } from '@apollo/client'

const query = gql`
	query ( $geo_id: Int! ){ 
		businesses(in: $geo_id) { 
			uid name website sector
		}
	}`

export default function(){
	const { geo_id } = useParams()
	const { data, error, loading } = useQuery( 
		query, { variables: {geo_id: Number(geo_id)} } 
	) 
	if( loading || error ) return null;
	if(data.businesses.length == 0){
		return <p>No known Canadian businesses located here</p>
	}
	const distinctBusinesses = new Map()
	const sectors = new Set();
	data.businesses.map( biz => {
		if( ! distinctBusinesses.has(biz.name) ){
			sectors.add(biz.sector)
			distinctBusinesses.set(biz.name,{
				website: biz.website,
				sector: biz.sector,
				count: 1
			})
		}else{
			distinctBusinesses.get(biz.name).count += 1
		}
	} )
	return [...sectors].map( sectorName => (<div key={sectorName}>
		<h3>{sectorName}</h3>
		<ul className="bizlist">
			{[...distinctBusinesses.entries()]
				.filter( entry => entry[1].sector == sectorName )
				.sort( (a,b) => a[0].localeCompare(b[0]) )
				.sort( (a,b) => b[1].count - a[1].count )
				.sort( (a,b) => b[1].sector - a[1].sector )
				.map( ([name,data]) => {
					let bizLink = data.website ?
						<a href={data.website} target="_blank" rel="noreferrer">{name}</a> : name;
					let countText = data.count > 1 ? `(${data.count} locations)` : null
					return <li key={name}>{bizLink} {countText}</li>
				})
			}
		</ul>
	</div>) )
}
