import { DirectedConnection } from '@apfcanada/jurisdictions'

export class Business extends DirectedConnection{
	#data
	constructor(source,target,data){
		super(source,target)
		this.#data = data
	}
	get businessId(){
		return this.#data.uid
	}
	get id(){
		return `Business:${this.businessId}:${super.id}`
	}
}
