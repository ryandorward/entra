import { scalePow } from 'd3-scale'

export const radius = scalePow()
	.exponent(0.5)
	.domain([100,40000])
	.range([1,7])
