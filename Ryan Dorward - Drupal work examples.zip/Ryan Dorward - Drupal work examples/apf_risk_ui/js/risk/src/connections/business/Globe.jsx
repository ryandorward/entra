import { useContext, useState, useEffect } from 'react';
import { useApolloClient, gql } from '@apollo/client'
import { contourDensity } from 'd3-contour'
import { geoPath } from 'd3-geo'
import { assignBoundaries } from '@apfcanada/jurisdictions'
import Globe, { Context as globeContext } from '../../maps/globe/Map'
import graph from '../../jurisdictions/graph'
import countriesWithData from './countries-with-data.json'
import highlight from '../../maps/geographic/styles/highlight.module.css'
import './globe.less'

const bizQ = gql`query { businesses { uid geometry { coordinates } } }`

export default function(){
	return <Globe><GlobeContent/></Globe>
}

function GlobeContent(){
	const [ countries, setCountries ] = useState([])
	const [ contours, setContours ] = useState([])
	const { projection, pathGen, setLoading } = useContext(globeContext)
	const client = useApolloClient()
	useEffect(()=>{
		setLoading(true)
		graph.lookup(countriesWithData)
			.then(assignBoundaries)
			.then(setCountries)
		client.query({query:bizQ})
			.then(response => {
				const points = response.data.businesses.map( b => {
					let projected = projection(b.geometry.coordinates)
					return [ 400+projected[0], 400+projected[1] ]
				} )
				const contours = contourDensity().x(d=>d[0]).y(d=>d[1])
					.size([800,800])
					.thresholds([1/8,1/4,1/2,1,2,4,8,16]) // log2 scale
					.bandwidth(7)( points )
				setContours(contours)
				setLoading(false)
			} )
	},[])
	return (<>
		<g id="biz-globe-country">
			{countries.map( country => (
				<path key={country.geo_id} 
					className={highlight.primary}
					d={pathGen(country.boundary)}/>
			) )}
		</g>
		<g id="biz-globe-contours" transform="translate(-400,-400)">
			{contours.map( contour => (
				<path key={contour.value} d={geoPath()(contour)}/>
			) )}
		</g>
	</>)
}
