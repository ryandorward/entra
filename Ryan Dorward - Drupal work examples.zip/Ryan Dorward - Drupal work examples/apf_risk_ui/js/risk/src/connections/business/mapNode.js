import { ForceNode } from '../../maps/force-node.js'

export class Node extends ForceNode{
	constructor(id,cx,cy){
		super()
		this.x = cx
		this.y = cy
		this.cx = cx
		this.cy = cy
		this.id = id
	}
}
