import { useState, useEffect, useContext, useMemo } from 'react';
import { useParams } from 'react-router-dom'
import { useApolloClient, gql } from '@apollo/client'
import { forceSimulation, forceX, forceY, forceCollide } from 'd3-force'
import { Node } from './mapNode.js'
import { MapContext } from '../../maps/geographic/Context'
import FocusOn from '../../jurisdictions/Focus'
import graph from '../../jurisdictions/graph'
import Boundary from '../../maps/geographic/Boundary'
import { radius } from './geoScales.js'
import highlight from '../../maps/geographic/styles/highlight.module.css'
import styles from './business.module.css'

const bizGeometry = gql`
query bizGeo ( $geo_id: Int ) { 
	businesses ( in: $geo_id ) { uid geometry { coordinates } }
}`

export default function(){
	const { geo_id } = useParams()
	const [ jur, setJur ] = useState(null)
	const [ businesses, setBusinesses ] = useState([])
	const mapContext = useContext(MapContext)
	const client = useApolloClient()
	useEffect(()=>{
		graph.lookup(geo_id).then(setJur)
		client.query({query:bizGeometry,variables:{geo_id:Number(geo_id)}})
			.then(response=>setBusinesses(response.data.businesses))
	},[geo_id])
	const points = useMemo(()=>{
		if(businesses.length==0) return null;
		const r = radius(mapContext.projection.scale())
		let nodes = businesses.map( b => {
			let [cx,cy] = mapContext.projection(b.geometry.coordinates)
			return new Node(b.uid,cx,cy)
		} )
		forceSimulation(nodes)
			.force('x',forceX().x(p=>p.cx).strength(0.05))
			.force('y',forceY().y(p=>p.cy).strength(0.05))
			.force('collide',forceCollide().radius(r).iterations(5))
			.stop().tick(10)
		return nodes.map( p => (
			<circle key={p.uid} cx={p.x} cy={p.y} r={r} 
				className={styles.business}/>
		) )
	},[
		businesses.length,jur,
		mapContext.projection.scale(),
		...mapContext.projection.translate(),
		...mapContext.projection.center()
	])
	return ( <>
		<FocusOn geo_id={geo_id}/>
		{jur && <>
			<Boundary jurisdiction={jur} className={highlight.primary}/>
			{jur.ancestors.map( aj => (
				<Boundary key={aj.geo_id} jurisdiction={aj} 
					className={highlight.secondary}/>
			))}
		</>}
		<g>{points}</g>
	</> )
}
