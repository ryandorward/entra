import { useState, useEffect } from 'react';
import Select from 'react-select'
import { useNavigate } from 'react-router-dom'
import graph from '../../jurisdictions/graph'
import countriesWithData from './countries-with-data.json'

export default function(){
	const navigate = useNavigate()
	const [ jurs, setJurs ] = useState([])
	
	useEffect(()=>{
		graph.readyWith('Business').then( graph => {
			setJurs( graph.lookupNow(countriesWithData) )
		} )
	},[])
	
	const options = jurs.map( j => {
		let count = j.connections(/Business/,{descendants:true}).length
		return {
			label: `${j.name.en} (${count})`,
			value: j.geo_id, count
		}
	} ).sort((a,b)=>b.count-a.count)
	
	return (
		<Select placeholder={`Jurisdictions with businesses`} 
			options={options} onChange={select}/>
	)
	
	function select(option){
		navigate(`/map/connections/jurisdiction/${option.value}`)
	}
}
