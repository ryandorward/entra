import { DirectedConnection } from '@apfcanada/jurisdictions'

export class FDI extends DirectedConnection{
	#data
	constructor(source,target,data){
		super(source,target)
		this.#data = data
	}
	get id(){
		return `FDI:${this.#data.uid}:${super.id}`
	}
}
