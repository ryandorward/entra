import BigNumber from '../../layouts/BigNumber'
import { gql, useQuery } from '@apollo/client'

const query = gql`query { 
	investments ( involving: 2 r_and_d: true ) { uid value_cad_current } 
}`

export default function(){
	const { data } = useQuery(query)
	const totalValue = (data?.investments??[])
		.reduce((sum,i)=>sum+i.value_cad_current,0)
	return ( 
		<div>
			<BigNumber number={ data ? data.investments.length : 0 }
				labelPlural="foreign direct investments in R&D"/>
			<BigNumber number={totalValue}
				labelPlural="foreign direct investment in R&D (CAD, adjusted for inflation)"/>
		</div>
	)
}
