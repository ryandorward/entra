import { /*useContext,*/ useEffect } from 'react';
import { succinctSearch as API } from '../../API'
import graph from '../../jurisdictions/graph'
//import { Context as MapLayoutContext } from '../maps/Layout'
import Select from 'react-select/async'

export default function(){
	//const { data, setData } = useContext(MapLayoutContext)
	useEffect(()=>{
		return ()=>console.log('clean up!')
	},[])
	return (
		<Select isMulti 
			placeholder="filter by partner jurisdiction"
			loadOptions={promiseOptions}
			onChange={select}/>
	)
	function promiseOptions(input){
		return fetch(`${API}?name=${input.trim()}`)
			.then( resp => resp.json() )
			.then(graph.lookup)
			.then( jurs => {
				return jurs.map( jur => {
					return { label: jur.name.en, value: jur.geo_id }
				} )
		} )
	}
	function select(option){
		console.log(option)
	}
}
