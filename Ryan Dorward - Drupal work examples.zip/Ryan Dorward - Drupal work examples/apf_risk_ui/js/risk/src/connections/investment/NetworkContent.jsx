import { useEffect, useContext } from 'react'
import { useParams } from 'react-router-dom'
import { useApolloClient, gql } from '@apollo/client'
import graph from '../../jurisdictions/graph.js'
import { MapContext } from '../../maps/network/Context'

const query = gql`
query investmentsInvolving ( $geo_id: Int! ) { 
	investments ( involving: $geo_id ) { 
		src: src_geo_id 
		dst: dst_geo_id 
		value: value_cad_contemporary
	}
}`

export default function(){
	const { geo_id } = useParams()
	const { init, setData } = useContext(MapContext)
	const client = useApolloClient()
	const variables = { geo_id: Number(geo_id) }
	useEffect(()=>{
		const [ jurs, connections ] = [ new Set(), [] ]
		init(false)
		Promise.all( [ client.query({query,variables}), graph.lookup(geo_id) ] )
			.then( ([{data:{investments}},focus]) => {
				[...investments]
					.sort( (a,b) => b.value - a.value )
					.slice(0,50)
					.forEach( inv => {
						const [src,dst] = graph.lookupNow([inv.src,inv.dst])
						jurs.add(src)
						jurs.add(dst)
						connections.push([src,dst])
					} )
				setData({jurisdictions:[...jurs],connections,focus})
			} )
	},[geo_id])
	return null
}
