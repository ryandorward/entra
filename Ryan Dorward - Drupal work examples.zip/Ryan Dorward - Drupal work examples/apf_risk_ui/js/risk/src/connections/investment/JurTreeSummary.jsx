import { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom'
import { format } from 'd3-format'
import {
	AiOutlinePlus as ExpandIcon,
	AiOutlineMinus as CollapseIcon
} from 'react-icons/ai'
import { Context as LayoutContext } from '../../maps/MapLayout'
import './jur-tree.less'

function money(number){
	return format('$.2s')(number)
		.replace(/G$/,' billion')
		.replace(/M$/,' million')
		.replace(/k$/,' thousand')
}

// recursive summary of investment to/from jurisdictions
export default function JurSummary({jur,investments,open}){
	const [ collapsed, setCollapsed ] = useState(!open)
	const {
		data: layoutData,
		setData: setLayoutData
	} = useContext(LayoutContext)
	useEffect(()=>{
		if(open) addToExpandContext(jur)
	},[jur])
	return (
		<div className="investment-jur-summary" onClick={handleClick}>
			<div className="title">
				<span>
					{collapsed || ! jur.geo_id ? // this unlinks the false A-P jur
						jur.name.en :
						<Link to={`/graph/connections/investment/jurisdiction/${jur.geo_id}`}>
							{jur.name.en}
						</Link>
					}
					{collapsed &&
						<span className="meta"> ({investments.length})</span>
					}
				</span>
				{collapsed ?
					<ExpandIcon className="expand-icon"/> :
					<CollapseIcon className="collapse-icon"/>
				}
			</div>
			{collapsed || <ExpandedSummary {...{jur,investments}}/>}
		</div>
	)
	function handleClick(event){
		event.stopPropagation()
		collapsed ? addToExpandContext(jur) : removeFromExpandContext(jur)
		setCollapsed((val)=>!val)
	}
	function addToExpandContext(jur){
		layoutData.expanded.add(jur)
		setLayoutData(layoutData)
	}
	function removeFromExpandContext(jur){
		layoutData.expanded.delete(jur)
		setLayoutData(layoutData)
	}
}

function ExpandedSummary({jur,investments}){
	let family = [ jur.geo_id, ...jur.descendants.map( j => j.geo_id ) ]
	let inbound = investments.filter( inv => family.includes(inv.dst_geo_id) )
	let outbound = investments.filter( inv => family.includes(inv.src_geo_id) )
	let inboundValue = inbound.reduce((sum,inv)=>sum+inv.value_cad,0)
	let outboundValue = outbound.reduce((sum,inv)=>sum+inv.value_cad,0)
	return (
		<>
			<div className="stats">
				{inbound.length > 0 &&
					<div className="inbound">
						<span className="keyword">Inbound</span>:
						{inboundValue > 0 && ` ${money(inboundValue)} in ` }
						{` ${inbound.length} investments`}
						<Bar a={inboundValue} b={outboundValue}/>
					</div>
				}
				{outbound.length > 0 &&
					<div className="outbound">
						<span className="keyword">Outbound</span>:
						{outboundValue > 0 && ` ${money(outboundValue)} in ` }
						{` ${outbound.length} investments`}
						<Bar a={outboundValue} b={inboundValue}/>
					</div>
				}
			</div>
			<div className="children">
				{jur.children.map( child => {
					let places = new Set(
						[child.geo_id,...child.descendants.map(j=>j.geo_id)]
					)
					let childInvestments = investments
						.filter(i=>places.has(i.src_geo_id)||places.has(i.dst_geo_id))
					return {
						jur: child, 'investments': childInvestments,
						open: investments.length == childInvestments.length
					}
				} )
				.filter( v => v.investments.length > 0 )
				.sort( (a,b) => a.jur.name.en.localeCompare(b.jur.name.en) )
				.sort( (a,b) => b.investments.length - a.investments.length )
				.map( props => <JurSummary key={props.jur.geo_id} {...props}/> )
				}
			</div>
		</>
	)
}

function Bar({a,b}){
	if(a+b==0) return null;
	return (
		<svg width="200" height="5" viewBox="0 0 200 10"
			className="bar">
			<rect y="0" height="100%" x="0"
				width={`${100*(a/(a+b))}%`}/>
		</svg>
	)
}
