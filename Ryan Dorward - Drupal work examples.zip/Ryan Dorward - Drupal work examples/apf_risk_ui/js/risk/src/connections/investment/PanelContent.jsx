import { useState, useEffect, useContext } from 'react';
import { useParams } from 'react-router-dom'
import { useQuery, gql } from '@apollo/client'
import graph from '../../jurisdictions/graph'
import JurSummary from './JurTreeSummary'
import { Context as LayoutContext } from '../../maps/MapLayout'
import Filter from './Filter'

const query = gql`
query ( $geo_id: Int! ) {
	investments ( involving: $geo_id ) {
		uid src_geo_id dst_geo_id date value_cad:value_cad_current
	}
}`

export default function PanelContent(){
	const { geo_id } = useParams()
	const { setData: setLayoutData } = useContext(LayoutContext)
	const { data } = useQuery( query, {
		variables: { geo_id: Number(geo_id) }
	})
	const [ jur, setJur ] = useState(null)
	const [ otherPlace, setOtherPlace ] = useState(null)
	const investments = data?.investments ? data.investments : []
	useEffect(()=>{
		setLayoutData({ expanded: new Set()})
		graph.lookup(geo_id).then( jur => {
			setJur(jur)
			if(!jur.canadian) {
				graph.lookup(2).then(canada=>setOtherPlace(canada))
			}else{
				// spoofing a Jurisdiction
				graph.asianCountries().then( countries => {
					const asia = {
						geo_id: 0, name: { en: 'Asia Pacific' },
						children: countries,
						descendants: countries.map(c=>c.descendants).flat()
					}
					setOtherPlace(asia)
				})
			}
		})
	},[geo_id])
	if( investments.length == 0 ) return null;
	return (
		<div>
			{false && <Filter/>}
			{jur && <JurSummary open {...{jur,investments}}/>}
			{otherPlace && <JurSummary open {...{jur:otherPlace,investments}}/>}
		</div>
	)
}
