import { useState, useEffect, useContext } from 'react';
import { useParams } from 'react-router-dom'
import { scaleQuantize } from 'd3-scale'
import { ordinal } from '@apfcanada/brand-assets'
import Choropleth from '../../maps/geographic/Choropleth'
import graph from '../../jurisdictions/graph'
import assignPopulations from '../../wikidata/queries/assignPopulations.js'
import { Context as LayoutContext } from '../../maps/MapLayout'
import { connectionPoints } from '../../connections/pointScore.js'

const rawScore = jur => jur.geo_id == 2 ?
	undefined : Math.sqrt(connectionPoints(jur))
const relScore = jur => jur.geo_id == 2 ?
	undefined : Math.sqrt(connectionPoints(jur) / jur.population)

const fillColor = scaleQuantize()
	.range([...ordinal.redYellow.slice(1,-1)].reverse())
	.unknown('darkgrey')

export default function(){
	const { geo_id } = useParams()
	const [ jur, setJur ] = useState(null)
	const [ colorFunc, setColorFunc ] = useState(undefined)
	const { data } = useContext(LayoutContext)
	const variable = data?.control == 'population' ? relScore : rawScore;

	useEffect(()=>{
		graph.readyWith(/.+/)
			.then( graph => graph.lookup(geo_id) )
			.then( jur => {
				setJur(jur)
				let jurs = [jur,...jur.siblings]
				if(data?.control == 'population'){
					return assignPopulations(jurs)
				}
				return jurs
			} )
			.then( jurs => {
				let vals = jurs.map(variable).filter(v=>v)
				fillColor.domain([0,Math.max(...vals)])
				setColorFunc( () => jur => fillColor(variable(jur)) )
			} )
	},[geo_id,variable])
	if( ! jur || ! colorFunc ) return null;
	return (
		<Choropleth
			jurisdiction={jur}
			colorFunc={colorFunc}
			linkFunc={jur=>`/map/connections/jurisdiction/${jur.geo_id}`}
		/>
	)
}
