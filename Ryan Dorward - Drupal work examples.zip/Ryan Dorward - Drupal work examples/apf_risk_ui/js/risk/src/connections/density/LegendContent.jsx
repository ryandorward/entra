import { useContext } from 'react';
import { ordinal } from '@apfcanada/brand-assets'
import ControlVariableSwitch, { LayoutContext } from '../../maps/ControlVariableToggle'
import ColorRange from '../../maps/legend/ColorRange'

export default function(){
	const { data } = useContext(LayoutContext)
	return (
		<div className='legend'>
			<h4>Connection Strength {data?.control=='population'&&'per Capita'}</h4>
			<span className="note">A composite index of all the trans-Pacific connections we currently track</span>
			<ColorRange colors={ordinal.redYellow.slice(1,9).reverse()}
				lowerLabel="Low" upperLabel="High"/>
			<ControlVariableSwitch/>
		</div>
	)
}
