import { useState, useEffect, useContext } from 'react';
import { useParams } from 'react-router-dom'
import { assignBoundaries } from '@apfcanada/jurisdictions'
import Boundary from '../../maps/geographic/Boundary'
import FocusOn from '../../jurisdictions/Focus'
import graph from '../../jurisdictions/graph'
import { MapContext } from '../../maps/geographic/Context'
import highlight from '../../maps/geographic/styles/highlight.module.css'

export default function(){
	var { geo_id } = useParams()
	const [ jurs, setJurs ] = useState([])
	const { init } = useContext(MapContext)
	useEffect(()=>{
		init(false)
		graph.lookup(geo_id)
			.then( jur => {
				let signatories = jur.connections(/TradeAgreement/)
					.map(a=>a.signatories).flat()
				return assignBoundaries([...new Set(signatories)])
			} )
			.then( jurs => { setJurs(jurs); init(true) } )
	},[geo_id])
	return (
		<>
			<FocusOn jurisdictions={jurs}/>
			{jurs.map( jur => (
				<Boundary key={jur.geo_id} 
					jurisdiction={jur} 
					className={highlight.primary}/>
			) ) }
		</>
	)
}
