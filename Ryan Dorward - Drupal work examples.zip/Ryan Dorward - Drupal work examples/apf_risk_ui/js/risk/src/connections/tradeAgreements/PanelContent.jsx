import { useState, useEffect } from 'react';
import { useParams, Navigate } from 'react-router-dom'
import graph from '../../jurisdictions/graph'
import Summary from './AgreementSummary'

export default function(){
	const { geo_id } = useParams()
	const [ jur, setJur ] = useState(null)
	useEffect(()=>{
		graph.lookup(geo_id).then( setJur )
	},[geo_id])
	if( ! jur ) return null;
	const agreements = jur.connections(/TradeAgreement/)
	if(agreements.length == 0) return <Navigate to={`..`}/>;
	return (<div>
		<h3>Subject to {agreements.length} Trade Agreement{agreements.length==1?'':'s'} with {jur.canadian ? 'Asia' : 'Canada'}</h3>
		{agreements.map( ta => <Summary key={ta.id} agreement={ta}/> )}
	</div>)
}
