import { useEffect, useContext } from 'react'
import { useParams } from 'react-router-dom'
import { MapContext } from '../../maps/network/Context'
import graph from '../../jurisdictions/graph'

export default function(){
	const { geo_id } = useParams()
	const { setData, init } = useContext(MapContext)
	useEffect(()=>{
		init(false)
		graph.lookup(geo_id).then( jur => {
			const focus = jur
			const [ jurs, connections ] = [ new Set([jur]), [] ]
			jur.connections(/TradeAgreement/).map( agreement => {
				agreement.signatories.map( j1 => {
					jurs.add(j1)
					agreement.signatories.map( j2 => {
						if(j1!=j2) connections.push( [j1,j2] );
					} )
				} )
			} );
			setData({jurisdictions:[...jurs],connections,focus})
		} )
	},[geo_id])
	return null
}
