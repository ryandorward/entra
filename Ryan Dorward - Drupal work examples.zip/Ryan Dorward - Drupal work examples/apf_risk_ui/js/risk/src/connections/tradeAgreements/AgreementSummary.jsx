import FlexList from '../../layouts/FlexList'
import './agreement-summary.less'

export default function({agreement}){
	return (
		<div className="trade-agreement-summary">
			<span className="name">{agreement.name}</span> 
			{agreement.startDate && 
				<div className="date">{agreement.startDate}</div>}
			<FlexList list={agreement.signatories}
				nameFunc={jur=>jur.name.en}
				linkFunc={jur=>`/graph/connections/trade/jurisdiction/${jur.geo_id}`}
			/>
		</div>
	)
}
