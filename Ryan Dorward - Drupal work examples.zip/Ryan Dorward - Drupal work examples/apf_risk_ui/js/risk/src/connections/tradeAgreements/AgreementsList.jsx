import { useState, useEffect } from 'react';
import graph from '../../jurisdictions/graph'
import Summary from './AgreementSummary'

export default function(){
	const [ canada, setCanada ] = useState(false)
	useEffect(()=>{
		graph.lookup(2).then(setCanada)
	},[])
	if( ! canada ) return null;
	return canada.connections(/TradeAgreement/).map( ta => (
		<Summary key={ta.id} agreement={ta}/>
	) )
}
