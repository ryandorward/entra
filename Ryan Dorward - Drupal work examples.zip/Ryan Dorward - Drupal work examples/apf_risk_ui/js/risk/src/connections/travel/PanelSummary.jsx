import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom'
import { advisories } from '../../API'
import './travel.less'

export default function(){
	const { geo_id } = useParams()
	const [travelAdv, setTravelAdv]=useState(null);
	useEffect(()=>{
		fetch(`${advisories}?geo_id=${geo_id}`)
			.then( response => response.json() )
			.then(setTravelAdv);
	},[geo_id])
	if(!travelAdv?.data) return null;
	var advisoryText = travelAdv.data.eng["advisory-text"]
	return(
		<div className='travel-advisory'>
			<span id="title">Travel Advisory:</span> {advisoryText}
		</div>	
	)
}
