# Connections

Jurisdiction-to-jurisdiction _Connections_ are a key data type for CAST. Across a number of different dimensions, the intent is to track low-level bridging ties between subnational places. Not just Canada -- China, but Toronto -- Beijing, etc. 


