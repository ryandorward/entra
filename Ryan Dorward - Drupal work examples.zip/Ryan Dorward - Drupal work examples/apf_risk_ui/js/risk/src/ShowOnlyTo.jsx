import { roles } from './getRoles.js'
import styles from './show-only-to.module.css'

// component wraps functionality intended only for selected roles
// specify minRole as one of ['analyst','jrAnalyst','developer']
export default function({children,minRole}){
	if(roles().includes(minRole)){
		return (
			<div className={styles.container}>
				<title className={styles.title}>Analysts only</title>
				{children}
			</div>
		)
	}
}
