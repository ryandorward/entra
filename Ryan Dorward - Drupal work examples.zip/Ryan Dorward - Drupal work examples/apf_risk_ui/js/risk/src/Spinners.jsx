const color = "#e63539"

// animated APFC logo
const spinnerStyle = `
path.a {
	fill: none;
	stroke: ${color};
	stroke-width: 12;
	stroke-linecap: butt;
	stroke-dasharray: 50 50;
}
path.a { animation: dash 1.5s linear forwards infinite; }
@keyframes dash {
	0% { stroke-dashoffset: 100; }
	100% { stroke-dashoffset: 0; }
}`

export function Spinner({size,contained}){
	size = size ?? 100
	const style = {
		display: 'block',
		position: contained ? 'relative' : 'absolute',
		left: `calc(50% - ${size/2}px)`,
		top: `calc(50% - ${size/2}px)`
	}
	return (
		<svg viewBox="0 0 325.01 324.83" style={style} width={size} height={size} className="spinner">
			<style>{spinnerStyle}</style>
			<path className="a" d="m 75.672365,208.49036 c -52.144,-55.77574 -28.89032,-119.03203 0,-147.61871 M 181.09821,221.63297 c -28.59187,26.33652 -68.7935,23.21267 -92.218688,-0.51615 M 88.777687,48.001889 C 161.41431,-21.863234 253.57496,7.0680868 291.96848,47.829839" pathLength="100"/>
			<path className="a" d="m 277.13187,88.638007 c 69.86511,72.636613 40.93379,164.797263 0.17205,203.190783 M 103.04509,180.68391 c -26.336515,-28.59187 -23.212665,-68.7935 0.51615,-92.21869 m 12.89835,-12.655138 c 55.77574,-52.143995 119.03203,-28.890317 147.61871,0" pathLength="100"/>
	<path className="a" d="m 249.32367,116.3199 c 52.144,55.77574 28.89032,119.03203 0,147.61871 M 236.58656,276.8139 C 163.94994,346.67902 71.789292,317.7477 33.395774,276.98595 M 144.26604,103.18282 c 28.59187,-26.336524 68.7935,-23.21267 92.21869,0.51615" pathLength="100"/>
  <path className="a" d="m 221.95094,144.12635 c 26.33652,28.59187 23.21267,68.7935 -0.51615,92.21869 M 47.864165,236.17226 C -22.000951,163.53564 6.9303685,71.37499 47.692115,32.981472 M 208.90466,249.0057 c -55.77574,52.144 -119.032028,28.89032 -147.618708,0" pathLength="100"/>
		</svg>
	)
}
