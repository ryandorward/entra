import { useState, useEffect } from 'react'
import { ApolloProvider } from '@apollo/client'
import { Spinner } from './Spinners'
import { clientPromise } from './getSharedClient.js'

export default function Apollo({children}){
	const [client, setClient] = useState(undefined);
	useEffect(()=>{
		clientPromise.then(setClient)
	},[])
	return client ?
		<ApolloProvider client={client}>{children}</ApolloProvider> :
		<Spinner/>;
}
