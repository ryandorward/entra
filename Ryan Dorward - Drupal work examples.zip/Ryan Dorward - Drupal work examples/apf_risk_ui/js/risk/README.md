# CAST user interface

The CAST user interface is built in React, and fetches data from three main sources:
* the [GraphQL endpoint](https://cast.asiapacific.ca/gql/risk)
* the [PostgreSQL-based REST APIs](https://www.asiapacific.ca/pgapi/public/)
* various other sources built directly into this repository

The UI uses [`ApolloClient`](https://www.apollographql.com/docs/react/) for state management, and relies heavily on [D3](https://d3js.org/) for visualizations. Routing is handled by [`react-router`](https://www.npmjs.com/package/react-router-dom).

## Development

To develop the code, you'll need to clone this repository and install all the NPM packages.

```bash
npm install
```

Then start the Express server and leave it running. This serves the app on [localhost:8080](http://localhost:8080)

```bash
npm start
```

In a new terminal window, have [Webpack](https://webpack.js.org/) build the JS code in development mode. Leave this window open as well, as webpack will watch for changes and rebuild the code as necessary. 

```bash
npm run build-dev
```

Built code will be placed in a local `./dist/` folder which is not tracked. When new code is pushed tot he master branch on the production server, a deploy script will rebuild the code for production, i.e. minifying and doing other optimizations. 

### Configuration

If this is your first time developing this code, you'll need to create a `.env` file in the root folder of this repository. It will contain your cast login credentials in the form.

```txt
name=myUserName
pass=mySecretPassword
```

This will allow you to access the GQL endpoint withhout going through the normal login process you would do on the live site. This should be done before building the code. 

## Testing & Linting

The UI is covered by a set of [Cypress](https://www.cypress.io/) integration tests defined in [cypress/e2e](./cypress/e2e). 

All `js|jsx` source code is also checked against an [ESLint](https://eslint.org/) linter which can be run locally with `npm run lint`. 

Both the linting and the integration tests are run automatically by Github for pull requests to be merged into master and merging will be blocked by any lint errors or failing tests. 
