# Modules

This collection of modules were authored from scratch by Ryan Dorward, with the exception of apf_risk_ui, which was coauthored with Nate Wessel.

These modulues are what powers the CAST website at https://cast.asiapacific.ca

Initially, this project was called the "Risk" project, but it evolved into a different namespace "CAST". The original name has stuck around in the backend.

## apf_risk_entities

This module defines the custom entities that we use for the project.

Because the project is generating a huge amount of custom content, with very specific relationships between the data types, we found that using Drupal's built-in entities like Node would come with too much extra baggage, so we opted to use lean and mean custom entities.

There are 7 custom entity types in here, and they all are used in conjunction and are inter-connected.

I have put a lot of effort into optimizing the way these entities load and deliver data, because at one point in the project we were having some serious performance issues. I was able to identify the bottlenecks, and with some careful code optimization and careful use of caching in the right places, I was able to radically boost the performance of the queries we were conducting on these entities.

## apf_risk_admin

This module handles everything to do with the backend that the staff use to manage the CAST content.

There are typical Drupal forms for adding/updating/deleting content, but we needed a streamlined workflow so that staff could quickly and easily generate content, and also to manage custom editorial workflows. In order to do this I built a custom React-based interface to manage this content.

The admin interface itself is behind a login, but I've placed a screenshot of it in the same folder as this README: ./SEEME - Admin UI screenshot.jpg

This module uses Google's Material UI libraries for all of the UI form elements.

The React code for this module is found in ./apf_risk_admin/js/risk/src

## apf_risk_api

The admin interface, as well as the public facing app UI, connect to the Drupal site for all CRUD operations, so we needed an API. We opted for a GraphQL based API because of it's highly modular and structured nature. This module depends on the GraphQL Drupal module https://www.drupal.org/project/graphql (v4)

If you're into poking around at GraphQL schemas, you can check it out using a browser extension like Altair and connecting to: https://www.asiapacific.ca/gql/cast/public

## apf_risk_ui

This module powers the actual public frontend at https://cast.asiapacific.ca using React, and leans heavily on MapBox as well. This was built as a collaboration between myself and Nate Wessel (https://github.com/Nate-Wessel), who left the organization about a year ago. Since his departure, I've updated, extended, and refactored almost every line of code and css/less, but credit is due for his role in building the foundation of this module.

This module also powers the CAST Connect block on the APF homepage (https://asiapacific.ca), and is a good example of "progressive decoupling" because here we have a headless React-based component embedded within a traditional SSR Drupal page.

The React goodies are found in ./apf_risk_ui/js/risk/src